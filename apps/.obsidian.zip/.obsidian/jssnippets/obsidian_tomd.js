/**
 * @category default
 * @enabled false
 * @createdAt 1738305600000
 * @updatedAt 1770489305461
 */
/**
 * @category Conversion
 * @enabled false
 * @createdAt 1738305600000
 * @updatedAt 1770487856886
 */
/**
 * @category Conversion
 * @enabled true
 * @createdAt 1738305600000
 * @updatedAt 1770487856486
 */
/**
 * @category Conversion
 * @enabled false
 * @createdAt 1738305600000
 * @updatedAt 1770401414941
 */
/**
 * @category Conversion
 * @enabled true
 * @createdAt 1738305600000
 * @updatedAt 1770401409020
 */
/**
 * @category Conversion
 * @enabled false
 * @createdAt 1738305600000
 * @updatedAt 1770401258277
 */
/**
 * @category Conversion
 * @enabled true
 * @createdAt 1738305600000
 * @updatedAt 1738305600000
 */

// MyJS Script: 语雀语法转换为 Obsidian 语法
// 支持将语雀的高亮块标记转换为 Obsidian 的引用块格式

try {
    // 检查是否在 Obsidian 环境中运行
    if (!app || typeof app === 'undefined') {
        console.error('Error: Script must be executed within Obsidian environment');
        throw new Error('This script must be executed within Obsidian environment');
    }

    // 获取当前活动的视图（打开的文档）
    const activeView = app.workspace.activeLeaf;

    if (!activeView || !activeView.view) {
        console.error('Error: No active document found');
        throw new Error('No active document found. Please open a note first.');
    }

    // 获取编辑器实例
    const editor = activeView.view.editor;

    if (!editor) {
        console.error('Error: Unable to access editor');
        throw new Error('Unable to access editor. Please make sure you have a markdown file open.');
    }

    // 获取当前文档内容
    const content = editor.getValue();
    const originalContent = content; // 保存原始内容用于对比

    console.log('开始转换语雀语法...');

    // 统计转换次数
    let convertCount = 0;

    // 转换函数：将语雀的块语法转换为 Obsidian 的引用块语法
    function convertYuqueToObsidian(text) {
        // 匹配语雀的块标记语法：:::info 或 :::danger 到 :::
        // 使用正则表达式匹配多行内容
        const blockPattern = /:::(info|danger)\n([\s\S]*?)\n:::/g;

        return text.replace(blockPattern, (match, type, content) => {
            convertCount++;

            // 确定类型
            const obsidianType = type === 'info' ? 'note' : 'danger';

            // 将内容按行分割
            const lines = content.split('\n');

            // 为每一行添加引用标记
            const quotedLines = lines.map(line => {
                // 如果行首已经有引用标记，保留原样（避免重复添加）
                if (line.trim().startsWith('>')) {
                    return line;
                }
                return `> ${line}`;
            });

            // 组合转换后的内容
            const convertedContent = quotedLines.join('\n');

            // 返回 Obsidian 格式
            // 格式：> [!type]\n> 内容\n>
            return `> [!${obsidianType}]\n${convertedContent}\n>`;
        });
    }

    // 执行转换
    const convertedContent = convertYuqueToObsidian(content);

    // 如果内容没有变化，提示用户
    if (convertedContent === originalContent) {
        console.log('未发现需要转换的语雀语法块');
        return {
            success: true,
            message: '文档中未发现需要转换的语雀语法块',
            convertedCount: 0,
            hasChanges: false
        };
    }

    // 保存当前光标位置
    const originalCursor = editor.getCursor();
    const scrollInfo = editor.getScrollInfo();

    // 替换整个文档内容
    editor.setValue(convertedContent);

    // 恢复光标位置和滚动位置
    editor.setCursor(originalCursor);
    editor.scrollTo(scrollInfo.left, scrollInfo.top);

    console.log(`转换完成！共转换了 ${convertCount} 个语雀块标记`);

    // 返回执行结果
    return {
        success: true,
        message: `成功转换 ${convertCount} 个语雀块标记为 Obsidian 格式`,
        convertedCount: convertCount,
        hasChanges: true,
        details: {
            convertedBlocks: convertCount,
            format: 'Obsidian callout blocks'
        }
    };

} catch (error) {
    // 错误处理
    const errorMessage = error instanceof Error ? error.message : '未知错误';
    console.error('Yuque to Obsidian conversion failed:', errorMessage);

    // 返回错误信息
    return {
        success: false,
        message: `转换失败: ${errorMessage}`,
        error: errorMessage
    };
}
