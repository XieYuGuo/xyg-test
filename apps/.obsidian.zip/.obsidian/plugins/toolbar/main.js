"use strict";
var e = require("obsidian");
const t = [
    "Custom",
    "editingToolbar",
    "editingToolbarSub",
    "editingToolbarAdd",
    "editingToolbarDelete",
    "editingToolbarReload",
    "codeblock-glyph",
    "underline-glyph",
    "superscript-glyph",
    "subscript-glyph",
    "bot-glyph",
    "header-1",
    "header-2",
    "header-3",
    "header-4",
    "header-5",
    "header-6",
    "header-n",
    "obsidian",
    "obsidian-new",
    "accessibility",
    "activity",
    "air-vent",
    "airplay",
    "alarm-check",
    "alarm-clock-off",
    "alarm-clock",
    "alarm-minus",
    "alarm-plus",
    "album",
    "alert-circle",
    "alert-octagon",
    "alert-triangle",
    "align-center-horizontal",
    "align-center-vertical",
    "align-center",
    "align-end-horizontal",
    "align-end-vertical",
    "align-horizontal-distribute-center",
    "align-horizontal-distribute-end",
    "align-horizontal-distribute-start",
    "align-horizontal-justify-center",
    "align-horizontal-justify-end",
    "align-horizontal-justify-start",
    "align-horizontal-space-around",
    "align-horizontal-space-between",
    "align-justify",
    "align-left",
    "align-right",
    "align-start-horizontal",
    "align-start-vertical",
    "align-vertical-distribute-center",
    "align-vertical-distribute-end",
    "align-vertical-distribute-start",
    "align-vertical-justify-center",
    "align-vertical-justify-end",
    "align-vertical-justify-start",
    "align-vertical-space-around",
    "align-vertical-space-between",
    "anchor",
    "angry",
    "annoyed",
    "aperture",
    "apple",
    "archive-restore",
    "archive",
    "armchair",
    "arrow-big-down",
    "arrow-big-left",
    "arrow-big-right",
    "arrow-big-up",
    "arrow-down-circle",
    "arrow-down-left",
    "arrow-down-right",
    "arrow-down",
    "arrow-left-circle",
    "arrow-left-right",
    "arrow-left",
    "arrow-right-circle",
    "arrow-right",
    "arrow-up-circle",
    "arrow-up-left",
    "arrow-up-right",
    "arrow-up",
    "asterisk",
    "at-sign",
    "award",
    "axe",
    "axis-3d",
    "baby",
    "backpack",
    "baggage-claim",
    "banana",
    "banknote",
    "bar-chart-2",
    "bar-chart-3",
    "bar-chart-4",
    "bar-chart-horizontal",
    "bar-chart",
    "baseline",
    "bath",
    "battery-charging",
    "battery-full",
    "battery-low",
    "battery-medium",
    "battery",
    "beaker",
    "bed-double",
    "bed-single",
    "bed",
    "beer",
    "bell-minus",
    "bell-off",
    "bell-plus",
    "bell-ring",
    "bell",
    "bike",
    "binary",
    "bitcoin",
    "bluetooth-connected",
    "bluetooth-off",
    "bluetooth-searching",
    "bluetooth",
    "bold",
    "bomb",
    "bone",
    "book-open",
    "book",
    "bookmark-minus",
    "bookmark-plus",
    "bookmark",
    "bot",
    "box-select",
    "box",
    "boxes",
    "briefcase",
    "brush",
    "bug",
    "building-2",
    "building",
    "bus",
    "cake",
    "calculator",
    "calendar-check-2",
    "calendar-check",
    "calendar-clock",
    "calendar-days",
    "calendar-heart",
    "calendar-minus",
    "calendar-off",
    "calendar-plus",
    "calendar-range",
    "calendar-search",
    "calendar-x2",
    "calendar-x",
    "calendar",
    "camera-off",
    "camera",
    "car",
    "carrot",
    "cast",
    "check-circle-2",
    "check-circle",
    "check-square",
    "check",
    "chef-hat",
    "cherry",
    "chevron-down",
    "chevron-first",
    "chevron-last",
    "chevron-left",
    "chevron-right",
    "chevron-up",
    "chevrons-down-up",
    "chevrons-down",
    "chevrons-left-right",
    "chevrons-left",
    "chevrons-right-left",
    "chevrons-right",
    "chevrons-up-down",
    "chevrons-up",
    "chrome",
    "cigarette-off",
    "cigarette",
    "circle-dot",
    "circle-ellipsis",
    "circle-slashed",
    "circle",
    "citrus",
    "clapperboard",
    "clipboard-check",
    "clipboard-copy",
    "clipboard-edit",
    "clipboard-list",
    "clipboard-signature",
    "clipboard-type",
    "clipboard-x",
    "clipboard",
    "clock-1",
    "clock-10",
    "clock-11",
    "clock-12",
    "clock-2",
    "clock-3",
    "clock-4",
    "clock-5",
    "clock-6",
    "clock-7",
    "clock-8",
    "clock-9",
    "clock",
    "cloud-cog",
    "cloud-drizzle",
    "cloud-fog",
    "cloud-hail",
    "cloud-lightning",
    "cloud-moon-rain",
    "cloud-moon",
    "cloud-off",
    "cloud-rain-wind",
    "cloud-rain",
    "cloud-snow",
    "cloud-sun-rain",
    "cloud-sun",
    "cloud",
    "cloudy",
    "clover",
    "code-2",
    "code",
    "codepen",
    "codesandbox",
    "coffee",
    "cog",
    "coins",
    "columns",
    "command",
    "compass",
    "component",
    "contact",
    "contrast",
    "cookie",
    "copy",
    "copyleft",
    "copyright",
    "corner-down-left",
    "corner-down-right",
    "corner-left-down",
    "corner-left-up",
    "corner-right-down",
    "corner-right-up",
    "corner-up-left",
    "corner-up-right",
    "cpu",
    "credit-card",
    "croissant",
    "crop",
    "cross",
    "crosshair",
    "crown",
    "cup-soda",
    "curly-braces",
    "currency",
    "database",
    "delete",
    "diamond",
    "dice-1",
    "dice-2",
    "dice-3",
    "dice-4",
    "dice-5",
    "dice-6",
    "dices",
    "diff",
    "disc",
    "divide-circle",
    "divide-square",
    "divide",
    "dollar-sign",
    "download-cloud",
    "download",
    "dribbble",
    "droplet",
    "droplets",
    "drumstick",
    "edit-2",
    "edit-3",
    "edit",
    "egg-fried",
    "egg",
    "equal-not",
    "equal",
    "eraser",
    "euro",
    "expand",
    "external-link",
    "eye-off",
    "eye",
    "facebook",
    "factory",
    "fast-forward",
    "feather",
    "figma",
    "file-archive",
    "file-audio-2",
    "file-audio",
    "file-axis-3d",
    "file-badge-2",
    "file-badge",
    "file-bar-chart-2",
    "file-bar-chart",
    "file-box",
    "file-check-2",
    "file-check",
    "file-clock",
    "file-code",
    "file-cog-2",
    "file-cog",
    "file-diff",
    "file-digit",
    "file-down",
    "file-edit",
    "file-heart",
    "file-image",
    "file-input",
    "file-json-2",
    "file-json",
    "file-key-2",
    "file-key",
    "file-line-chart",
    "file-lock-2",
    "file-lock",
    "file-minus-2",
    "file-minus",
    "file-output",
    "file-pie-chart",
    "file-plus-2",
    "file-plus",
    "file-question",
    "file-scan",
    "file-search-2",
    "file-search",
    "file-signature",
    "file-spreadsheet",
    "file-symlink",
    "file-terminal",
    "file-text",
    "file-type-2",
    "file-type",
    "file-up",
    "file-video-2",
    "file-video",
    "file-volume-2",
    "file-volume",
    "file-warning",
    "file-x2",
    "file-x",
    "file",
    "files",
    "film",
    "filter",
    "fingerprint",
    "flag-off",
    "flag-triangle-left",
    "flag-triangle-right",
    "flag",
    "flame",
    "flashlight-off",
    "flashlight",
    "flask-conical",
    "flask-round",
    "flip-horizontal-2",
    "flip-horizontal",
    "flip-vertical-2",
    "flip-vertical",
    "flower-2",
    "flower",
    "focus",
    "folder-archive",
    "folder-check",
    "folder-clock",
    "folder-closed",
    "folder-cog-2",
    "folder-cog",
    "folder-down",
    "folder-edit",
    "folder-heart",
    "folder-input",
    "folder-key",
    "folder-lock",
    "folder-minus",
    "folder-open",
    "folder-output",
    "folder-plus",
    "folder-search-2",
    "folder-search",
    "folder-symlink",
    "folder-tree",
    "folder-up",
    "folder-x",
    "folder",
    "folders",
    "form-input",
    "forward",
    "frame",
    "framer",
    "frown",
    "fuel",
    "function-square",
    "gamepad-2",
    "gamepad",
    "gauge",
    "gavel",
    "gem",
    "ghost",
    "gift",
    "git-branch-plus",
    "git-branch",
    "git-commit",
    "git-compare",
    "git-fork",
    "git-merge",
    "git-pull-request-closed",
    "git-pull-request-draft",
    "git-pull-request",
    "github",
    "gitlab",
    "glass-water",
    "glasses",
    "globe-2",
    "globe",
    "grab",
    "graduation-cap",
    "grape",
    "grid",
    "grip-horizontal",
    "grip-vertical",
    "hammer",
    "hand-metal",
    "hand",
    "hard-drive",
    "hard-hat",
    "hash",
    "haze",
    "headphones",
    "heart-crack",
    "heart-handshake",
    "heart-off",
    "heart-pulse",
    "heart",
    "help-circle",
    "hexagon",
    "highlighter",
    "history",
    "home",
    "hourglass",
    "ice-cream",
    "image-minus",
    "image-off",
    "image-plus",
    "image",
    "import",
    "inbox",
    "indent",
    "indian-rupee",
    "infinity",
    "info",
    "inspect",
    "instagram",
    "italic",
    "japanese-yen",
    "joystick",
    "key",
    "keyboard",
    "lamp-ceiling",
    "lamp-desk",
    "lamp-floor",
    "lamp-wall-down",
    "lamp-wall-up",
    "lamp",
    "landmark",
    "languages",
    "laptop-2",
    "laptop",
    "lasso-select",
    "lasso",
    "laugh",
    "layers",
    "layout-dashboard",
    "layout-grid",
    "layout-list",
    "layout-template",
    "layout",
    "leaf",
    "library",
    "life-buoy",
    "lightbulb-off",
    "lightbulb",
    "line-chart",
    "link-2off",
    "link-2",
    "link",
    "linkedin",
    "list-checks",
    "list-end",
    "list-minus",
    "list-music",
    "list-ordered",
    "list-plus",
    "list-start",
    "list-video",
    "list-x",
    "list",
    "loader-2",
    "loader",
    "locate-fixed",
    "locate-off",
    "locate",
    "lock",
    "log-in",
    "log-out",
    "luggage",
    "magnet",
    "mail-check",
    "mail-minus",
    "mail-open",
    "mail-plus",
    "mail-question",
    "mail-search",
    "mail-warning",
    "mail-x",
    "mail",
    "mails",
    "map-pin-off",
    "map-pin",
    "map",
    "martini",
    "maximize-2",
    "maximize",
    "medal",
    "megaphone-off",
    "megaphone",
    "meh",
    "menu",
    "message-circle",
    "message-square",
    "mic-2",
    "mic-off",
    "mic",
    "microscope",
    "milestone",
    "minimize-2",
    "minimize",
    "minus-circle",
    "minus-square",
    "minus",
    "monitor-off",
    "monitor-speaker",
    "monitor",
    "moon",
    "more-horizontal",
    "more-vertical",
    "mountain-snow",
    "mountain",
    "mouse-pointer-2",
    "mouse-pointer-click",
    "mouse-pointer",
    "mouse",
    "move-3d",
    "move-diagonal-2",
    "move-diagonal",
    "move-horizontal",
    "move-vertical",
    "move",
    "music-2",
    "music-3",
    "music-4",
    "music",
    "navigation-2off",
    "navigation-2",
    "navigation-off",
    "navigation",
    "network",
    "newspaper",
    "octagon",
    "option",
    "outdent",
    "package-2",
    "package-check",
    "package-minus",
    "package-open",
    "package-plus",
    "package-search",
    "package-x",
    "package",
    "paint-bucket",
    "paintbrush-2",
    "paintbrush",
    "palette",
    "palmtree",
    "paperclip",
    "party-popper",
    "pause-circle",
    "pause-octagon",
    "pause",
    "pen-tool",
    "pencil",
    "percent",
    "person-standing",
    "phone-call",
    "phone-forwarded",
    "phone-incoming",
    "phone-missed",
    "phone-off",
    "phone-outgoing",
    "phone",
    "pie-chart",
    "piggy-bank",
    "pin-off",
    "pin",
    "pipette",
    "pizza",
    "plane",
    "play-circle",
    "play",
    "plug-zap",
    "plus-circle",
    "plus-square",
    "plus",
    "pocket",
    "podcast",
    "pointer",
    "pound-sterling",
    "power-off",
    "power",
    "printer",
    "puzzle",
    "qr-code",
    "quote",
    "radio-receiver",
    "radio",
    "recycle",
    "redo-2",
    "redo",
    "refresh-ccw",
    "refresh-cw",
    "regex",
    "repeat-1",
    "repeat",
    "reply-all",
    "reply",
    "rewind",
    "rocket",
    "rocking-chair",
    "rotate-3d",
    "rotate-ccw",
    "rotate-cw",
    "rss",
    "ruler",
    "russian-ruble",
    "save",
    "scale-3d",
    "scale",
    "scaling",
    "scan-face",
    "scan-line",
    "scan",
    "scissors",
    "screen-share-off",
    "screen-share",
    "scroll",
    "search",
    "send",
    "separator-horizontal",
    "separator-vertical",
    "server-cog",
    "server-crash",
    "server-off",
    "server",
    "settings-2",
    "settings",
    "share-2",
    "share",
    "sheet",
    "shield-alert",
    "shield-check",
    "shield-close",
    "shield-off",
    "shield",
    "shirt",
    "shopping-bag",
    "shopping-cart",
    "shovel",
    "shrink",
    "shrub",
    "shuffle",
    "sidebar-close",
    "sidebar-open",
    "sidebar",
    "sigma",
    "signal-high",
    "signal-low",
    "signal-medium",
    "signal-zero",
    "signal",
    "siren",
    "skip-back",
    "skip-forward",
    "skull",
    "slack",
    "slash",
    "slice",
    "sliders-horizontal",
    "sliders",
    "smartphone-charging",
    "smartphone",
    "smile-plus",
    "smile",
    "snowflake",
    "sofa",
    "sort-asc",
    "sort-desc",
    "speaker",
    "sprout",
    "square",
    "star-half",
    "star-off",
    "star",
    "stethoscope",
    "sticker",
    "sticky-note",
    "stop-circle",
    "stretch-horizontal",
    "stretch-vertical",
    "strikethrough",
    "subscript",
    "sun-dim",
    "sun-medium",
    "sun-moon",
    "sun-snow",
    "sun",
    "sunrise",
    "sunset",
    "superscript",
    "swiss-franc",
    "switch-camera",
    "sword",
    "swords",
    "syringe",
    "table-2",
    "table",
    "tablet",
    "tag",
    "tags",
    "target",
    "tent",
    "terminal-square",
    "terminal",
    "text-cursor-input",
    "text-cursor",
    "thermometer-snowflake",
    "thermometer-sun",
    "thermometer",
    "thumbs-down",
    "thumbs-up",
    "ticket",
    "timer-off",
    "timer-reset",
    "timer",
    "toggle-left",
    "toggle-right",
    "tornado",
    "toy-brick",
    "train",
    "trash-2",
    "trash",
    "tree-deciduous",
    "tree-pine",
    "trees",
    "trello",
    "trending-down",
    "trending-up",
    "triangle",
    "trophy",
    "truck",
    "tv-2",
    "tv",
    "twitch",
    "twitter",
    "type",
    "umbrella",
    "underline",
    "undo-2",
    "undo",
    "unlink-2",
    "unlink",
    "unlock",
    "upload-cloud",
    "upload",
    "usb",
    "user-check",
    "user-cog",
    "user-minus",
    "user-plus",
    "user-x",
    "user",
    "users",
    "utensils-crossed",
    "utensils",
    "venetian-mask",
    "verified",
    "vibrate-off",
    "vibrate",
    "video-off",
    "video",
    "view",
    "voicemail",
    "volume-1",
    "volume-2",
    "volume-x",
    "volume",
    "wallet",
    "wand-2",
    "wand",
    "watch",
    "waves",
    "webcam",
    "webhook",
    "wifi-off",
    "wifi",
    "wind",
    "wine",
    "wrap-text",
    "wrench",
    "x-circle",
    "x-octagon",
    "x-square",
    "x",
    "youtube",
    "zap-off",
    "zap",
    "zoom-in",
    "zoom-out",
    "create-new",
    "trash",
    "search",
    "right-triangle",
    "document",
    "folder",
    "pencil",
    "left-arrow",
    "right-arrow",
    "three-horizontal-bars",
    "dot-network",
    "audio-file",
    "image-file",
    "pdf-file",
    "gear",
    "documents",
    "blocks",
    "go-to-file",
    "presentation",
    "cross-in-box",
    "microphone",
    "microphone-filled",
    "two-columns",
    "link",
    "popup-open",
    "checkmark",
    "hashtag",
    "left-arrow-with-tail",
    "right-arrow-with-tail",
    "up-arrow-with-tail",
    "down-arrow-with-tail",
    "lines-of-text",
    "vertical-three-dots",
    "pin",
    "magnifying-glass",
    "info",
    "horizontal-split",
    "vertical-split",
    "calendar-with-checkmark",
    "folder-minus",
    "sheets-in-box",
    "up-and-down-arrows",
    "broken-link",
    "cross",
    "any-key",
    "reset",
    "star",
    "crossed-star",
    "dice",
    "filled-pin",
    "enter",
    "help",
    "vault",
    "open-vault",
    "paper-plane",
    "bullet-list",
    "uppercase-lowercase-a",
    "star-list",
    "expand-vertically",
    "languages",
    "switch",
    "pane-layout",
    "install",
    "sync",
    "check-in-circle",
    "sync-small",
    "check-small",
    "paused",
    "forward-arrow",
    "stacked-levels",
    "bracket-glyph",
    "note-glyph",
    "tag-glyph",
    "price-tag-glyph",
    "heading-glyph",
    "bold-glyph",
    "italic-glyph",
    "strikethrough-glyph",
    "highlight-glyph",
    "code-glyph",
    "quote-glyph",
    "link-glyph",
    "bullet-list-glyph",
    "number-list-glyph",
    "checkbox-glyph",
    "undo-glyph",
    "redo-glyph",
    "up-chevron-glyph",
    "down-chevron-glyph",
    "left-chevron-glyph",
    "right-chevron-glyph",
    "percent-sign-glyph",
    "keyboard-glyph",
    "double-up-arrow-glyph",
    "double-down-arrow-glyph",
    "image-glyph",
    "wrench-screwdriver-glyph",
    "clock",
    "plus-with-circle",
    "minus-with-circle",
    "indent-glyph",
    "unindent-glyph",
    "fullscreen",
    "exit-fullscreen",
    "cloud",
    "run-command",
    "compress-glyph",
    "enlarge-glyph",
    "scissors-glyph",
    "up-curly-arrow-glyph",
    "down-curly-arrow-glyph",
    "plus-minus-glyph",
    "links-going-out",
    "links-coming-in",
    "add-note-glyph",
    "duplicate-glyph",
    "clock-glyph",
    "calendar-glyph",
    "command-glyph",
    "dice-glyph",
    "file-explorer-glyph",
    "graph-glyph",
    "import-glyph",
    "navigate-glyph",
    "open-elsewhere-glyph",
    "presentation-glyph",
    "paper-plane-glyph",
    "question-mark-glyph",
    "restore-file-glyph",
    "search-glyph",
    "star-glyph",
    "play-audio-glyph",
    "stop-audio-glyph",
    "tomorrow-glyph",
    "wand-glyph",
    "workspace-glyph",
    "yesterday-glyph",
    "box-glyph",
    "merge-files-glyph",
    "merge-files",
    "two-blank-pages",
    "scissors",
    "paste",
    "paste-text",
    "split",
    "select-all-text",
    "wand",
    "github-glyph",
    "reading-glasses",
    "user-manual-filled",
    "discord-filled",
    "chat-bubbles-filled",
    "experiment-filled",
    "bracket-glyph",
    "box-glyph",
    "check-small",
    "dice-glyph",
    "dice",
    "discord",
    "right-triangle",
    "heading-glyph",
    "help",
    "keyboard-toggle",
    "broken-link",
    "experiment",
    "left-arrow",
    "link",
    "link-glyph",
    "links-coming-in",
    "links-going-out",
    "open-vault",
    "paused",
    "question-mark-glyph",
    "right-arrow",
    "sidebar-left",
    "sidebar-right",
    "sheets-in-box",
    "star-list",
    "sync-small",
    "tabs",
    "uppercase-lowercase-a",
    "vault",
    "stack-horizontal",
    "stack-vertical",
    "stretch-horizontal",
    "stretch-vertical",
    "distribute-space-horizontal",
    "distribute-space-vertical",
  ],
  i = 1024;
let o = 0;
class n {
  constructor(e, t) {
    ((this.from = e), (this.to = t));
  }
}
class s {
  constructor(e = {}) {
    ((this.id = o++),
      (this.perNode = !!e.perNode),
      (this.deserialize =
        e.deserialize ||
        (() => {
          throw new Error(
            "This node type doesn't define a deserialize function",
          );
        })),
      (this.combine = e.combine || null));
  }
  add(e) {
    if (this.perNode)
      throw new RangeError("Can't add per-node props to node types");
    return (
      "function" != typeof e && (e = l.match(e)),
      (t) => {
        let i = e(t);
        return void 0 === i ? null : [this, i];
      }
    );
  }
}
((s.closedBy = new s({ deserialize: (e) => e.split(" ") })),
  (s.openedBy = new s({ deserialize: (e) => e.split(" ") })),
  (s.group = new s({ deserialize: (e) => e.split(" ") })),
  (s.isolate = new s({
    deserialize: (e) => {
      if (e && "rtl" != e && "ltr" != e && "auto" != e)
        throw new RangeError("Invalid value for isolate: " + e);
      return e || "auto";
    },
  })),
  (s.contextHash = new s({ perNode: !0 })),
  (s.lookAhead = new s({ perNode: !0 })),
  (s.mounted = new s({ perNode: !0 })));
class r {
  constructor(e, t, i, o = !1) {
    ((this.tree = e),
      (this.overlay = t),
      (this.parser = i),
      (this.bracketed = o));
  }
  static get(e) {
    return e && e.props && e.props[s.mounted.id];
  }
}
const a = Object.create(null);
class l {
  constructor(e, t, i, o = 0) {
    ((this.name = e), (this.props = t), (this.id = i), (this.flags = o));
  }
  static define(e) {
    let t = e.props && e.props.length ? Object.create(null) : a,
      i =
        (e.top ? 1 : 0) |
        (e.skipped ? 2 : 0) |
        (e.error ? 4 : 0) |
        (null == e.name ? 8 : 0),
      o = new l(e.name || "", t, e.id, i);
    if (e.props)
      for (let i of e.props)
        if ((Array.isArray(i) || (i = i(o)), i)) {
          if (i[0].perNode)
            throw new RangeError("Can't store a per-node prop on a node type");
          t[i[0].id] = i[1];
        }
    return o;
  }
  prop(e) {
    return this.props[e.id];
  }
  get isTop() {
    return (1 & this.flags) > 0;
  }
  get isSkipped() {
    return (2 & this.flags) > 0;
  }
  get isError() {
    return (4 & this.flags) > 0;
  }
  get isAnonymous() {
    return (8 & this.flags) > 0;
  }
  is(e) {
    if ("string" == typeof e) {
      if (this.name == e) return !0;
      let t = this.prop(s.group);
      return !!t && t.indexOf(e) > -1;
    }
    return this.id == e;
  }
  static match(e) {
    let t = Object.create(null);
    for (let i in e) for (let o of i.split(" ")) t[o] = e[i];
    return (e) => {
      for (let i = e.prop(s.group), o = -1; o < (i ? i.length : 0); o++) {
        let n = t[o < 0 ? e.name : i[o]];
        if (n) return n;
      }
    };
  }
}
l.none = new l("", Object.create(null), 0, 8);
const c = new WeakMap(),
  d = new WeakMap();
var h;
!(function (e) {
  ((e[(e.ExcludeBuffers = 1)] = "ExcludeBuffers"),
    (e[(e.IncludeAnonymous = 2)] = "IncludeAnonymous"),
    (e[(e.IgnoreMounts = 4)] = "IgnoreMounts"),
    (e[(e.IgnoreOverlays = 8)] = "IgnoreOverlays"),
    (e[(e.EnterBracketed = 16)] = "EnterBracketed"));
})(h || (h = {}));
class u {
  constructor(e, t, i, o, n) {
    if (
      ((this.type = e),
      (this.children = t),
      (this.positions = i),
      (this.length = o),
      (this.props = null),
      n && n.length)
    ) {
      this.props = Object.create(null);
      for (let [e, t] of n) this.props["number" == typeof e ? e : e.id] = t;
    }
  }
  toString() {
    let e = r.get(this);
    if (e && !e.overlay) return e.tree.toString();
    let t = "";
    for (let e of this.children) {
      let i = e.toString();
      i && (t && (t += ","), (t += i));
    }
    return this.type.name
      ? (/\W/.test(this.type.name) && !this.type.isError
          ? JSON.stringify(this.type.name)
          : this.type.name) + (t.length ? "(" + t + ")" : "")
      : t;
  }
  cursor(e = 0) {
    return new T(this.topNode, e);
  }
  cursorAt(e, t = 0, i = 0) {
    let o = c.get(this) || this.topNode,
      n = new T(o);
    return (n.moveTo(e, t), c.set(this, n._tree), n);
  }
  get topNode() {
    return new y(this, 0, 0, null);
  }
  resolve(e, t = 0) {
    let i = f(c.get(this) || this.topNode, e, t, !1);
    return (c.set(this, i), i);
  }
  resolveInner(e, t = 0) {
    let i = f(d.get(this) || this.topNode, e, t, !0);
    return (d.set(this, i), i);
  }
  resolveStack(e, t = 0) {
    return (function (e, t, i) {
      let o = e.resolveInner(t, i),
        n = null;
      for (let e = o instanceof y ? o : o.context.parent; e; e = e.parent)
        if (e.index < 0) {
          let s = e.parent;
          ((n || (n = [o])).push(s.resolve(t, i)), (e = s));
        } else {
          let s = r.get(e.tree);
          if (
            s &&
            s.overlay &&
            s.overlay[0].from <= t &&
            s.overlay[s.overlay.length - 1].to >= t
          ) {
            let r = new y(s.tree, s.overlay[0].from + e.from, -1, e);
            (n || (n = [o])).push(f(r, t, i, !1));
          }
        }
      return n ? k(n) : o;
    })(this, e, t);
  }
  iterate(e) {
    let { enter: t, leave: i, from: o = 0, to: n = this.length } = e,
      s = e.mode || 0,
      r = (s & h.IncludeAnonymous) > 0;
    for (let e = this.cursor(s | h.IncludeAnonymous); ; ) {
      let s = !1;
      if (
        e.from <= n &&
        e.to >= o &&
        ((!r && e.type.isAnonymous) || !1 !== t(e))
      ) {
        if (e.firstChild()) continue;
        s = !0;
      }
      for (; s && i && (r || !e.type.isAnonymous) && i(e), !e.nextSibling(); ) {
        if (!e.parent()) return;
        s = !0;
      }
    }
  }
  prop(e) {
    return e.perNode
      ? this.props
        ? this.props[e.id]
        : void 0
      : this.type.prop(e);
  }
  get propValues() {
    let e = [];
    if (this.props) for (let t in this.props) e.push([+t, this.props[t]]);
    return e;
  }
  balance(e = {}) {
    return this.children.length <= 8
      ? this
      : I(
          l.none,
          this.children,
          this.positions,
          0,
          this.children.length,
          0,
          this.length,
          (e, t, i) => new u(this.type, e, t, i, this.propValues),
          e.makeTree || ((e, t, i) => new u(l.none, e, t, i)),
        );
  }
  static build(e) {
    return (function (e) {
      var t;
      let {
          buffer: o,
          nodeSet: n,
          maxBufferLength: r = i,
          reused: a = [],
          minRepeatType: l = n.types.length,
        } = e,
        c = Array.isArray(o) ? new p(o, o.length) : o,
        d = n.types,
        h = 0,
        g = 0;
      function f(e, t, i, o, s, u) {
        let { id: p, start: k, end: S, size: T } = c,
          E = g,
          M = h;
        if (T < 0) {
          if ((c.next(), -1 == T)) {
            let t = a[p];
            return (i.push(t), void o.push(k - e));
          }
          if (-3 == T) return void (h = p);
          if (-4 == T) return void (g = p);
          throw new RangeError(`Unrecognized record size: ${T}`);
        }
        let A,
          D,
          O = d[p],
          B = k - e;
        if (S - k <= r && (D = C(c.pos - t, s))) {
          let t = new Uint16Array(D.size - D.skip),
            i = c.pos - D.size,
            o = t.length;
          for (; c.pos > i; ) o = x(D.start, t, o);
          ((A = new m(t, S - D.start, n)), (B = D.start - e));
        } else {
          let e = c.pos - T;
          c.next();
          let t = [],
            i = [],
            o = p >= l ? p : -1,
            n = 0,
            s = S;
          for (; c.pos > e; )
            o >= 0 && c.id == o && c.size >= 0
              ? (c.end <= s - r &&
                  (w(t, i, k, n, c.end, s, o, E, M),
                  (n = t.length),
                  (s = c.end)),
                c.next())
              : u > 2500
                ? b(k, e, t, i)
                : f(k, e, t, i, o, u + 1);
          if (
            (o >= 0 && n > 0 && n < t.length && w(t, i, k, n, k, s, o, E, M),
            t.reverse(),
            i.reverse(),
            o > -1 && n > 0)
          ) {
            let e = y(O, M);
            A = I(O, t, i, 0, t.length, 0, S - k, e, e);
          } else A = v(O, t, i, S - k, E - S, M);
        }
        (i.push(A), o.push(B));
      }
      function b(e, t, i, o) {
        let s = [],
          a = 0,
          l = -1;
        for (; c.pos > t; ) {
          let { id: e, start: t, end: i, size: o } = c;
          if (o > 4) c.next();
          else {
            if (l > -1 && t < l) break;
            (l < 0 && (l = i - r), s.push(e, t, i), a++, c.next());
          }
        }
        if (a) {
          let t = new Uint16Array(4 * a),
            r = s[s.length - 2];
          for (let e = s.length - 3, i = 0; e >= 0; e -= 3)
            ((t[i++] = s[e]),
              (t[i++] = s[e + 1] - r),
              (t[i++] = s[e + 2] - r),
              (t[i++] = i));
          (i.push(new m(t, s[2] - r, n)), o.push(r - e));
        }
      }
      function y(e, t) {
        return (i, o, n) => {
          let r,
            a,
            l = 0,
            c = i.length - 1;
          if (c >= 0 && (r = i[c]) instanceof u) {
            if (!c && r.type == e && r.length == n) return r;
            (a = r.prop(s.lookAhead)) && (l = o[c] + r.length + a);
          }
          return v(e, i, o, n, l, t);
        };
      }
      function w(e, t, i, o, s, r, a, l, c) {
        let d = [],
          h = [];
        for (; e.length > o; ) (d.push(e.pop()), h.push(t.pop() + i - s));
        (e.push(v(n.types[a], d, h, r - s, l - r, c)), t.push(s - i));
      }
      function v(e, t, i, o, n, r, a) {
        if (r) {
          let e = [s.contextHash, r];
          a = a ? [e].concat(a) : [e];
        }
        if (n > 25) {
          let e = [s.lookAhead, n];
          a = a ? [e].concat(a) : [e];
        }
        return new u(e, t, i, o, a);
      }
      function C(e, t) {
        let i = c.fork(),
          o = 0,
          n = 0,
          s = 0,
          a = i.end - r,
          d = { size: 0, start: 0, skip: 0 };
        e: for (let r = i.pos - e; i.pos > r; ) {
          let e = i.size;
          if (i.id == t && e >= 0) {
            ((d.size = o),
              (d.start = n),
              (d.skip = s),
              (s += 4),
              (o += 4),
              i.next());
            continue;
          }
          let c = i.pos - e;
          if (e < 0 || c < r || i.start < a) break;
          let h = i.id >= l ? 4 : 0,
            u = i.start;
          for (i.next(); i.pos > c; ) {
            if (i.size < 0) {
              if (-3 != i.size && -4 != i.size) break e;
              h += 4;
            } else i.id >= l && (h += 4);
            i.next();
          }
          ((n = u), (o += e), (s += h));
        }
        return (
          (t < 0 || o == e) && ((d.size = o), (d.start = n), (d.skip = s)),
          d.size > 4 ? d : void 0
        );
      }
      function x(e, t, i) {
        let { id: o, start: n, end: s, size: r } = c;
        if ((c.next(), r >= 0 && o < l)) {
          let a = i;
          if (r > 4) {
            let o = c.pos - (r - 4);
            for (; c.pos > o; ) i = x(e, t, i);
          }
          ((t[--i] = a), (t[--i] = s - e), (t[--i] = n - e), (t[--i] = o));
        } else -3 == r ? (h = o) : -4 == r && (g = o);
        return i;
      }
      let k = [],
        S = [];
      for (; c.pos > 0; ) f(e.start || 0, e.bufferStart || 0, k, S, -1, 0);
      let T =
        null !== (t = e.length) && void 0 !== t
          ? t
          : k.length
            ? S[0] + k[0].length
            : 0;
      return new u(d[e.topID], k.reverse(), S.reverse(), T);
    })(e);
  }
}
u.empty = new u(l.none, [], [], 0);
class p {
  constructor(e, t) {
    ((this.buffer = e), (this.index = t));
  }
  get id() {
    return this.buffer[this.index - 4];
  }
  get start() {
    return this.buffer[this.index - 3];
  }
  get end() {
    return this.buffer[this.index - 2];
  }
  get size() {
    return this.buffer[this.index - 1];
  }
  get pos() {
    return this.index;
  }
  next() {
    this.index -= 4;
  }
  fork() {
    return new p(this.buffer, this.index);
  }
}
class m {
  constructor(e, t, i) {
    ((this.buffer = e), (this.length = t), (this.set = i));
  }
  get type() {
    return l.none;
  }
  toString() {
    let e = [];
    for (let t = 0; t < this.buffer.length; )
      (e.push(this.childString(t)), (t = this.buffer[t + 3]));
    return e.join(",");
  }
  childString(e) {
    let t = this.buffer[e],
      i = this.buffer[e + 3],
      o = this.set.types[t],
      n = o.name;
    if ((/\W/.test(n) && !o.isError && (n = JSON.stringify(n)), i == (e += 4)))
      return n;
    let s = [];
    for (; e < i; ) (s.push(this.childString(e)), (e = this.buffer[e + 3]));
    return n + "(" + s.join(",") + ")";
  }
  findChild(e, t, i, o, n) {
    let { buffer: s } = this,
      r = -1;
    for (
      let a = e;
      a != t && !(g(n, o, s[a + 1], s[a + 2]) && ((r = a), i > 0));
      a = s[a + 3]
    );
    return r;
  }
  slice(e, t, i) {
    let o = this.buffer,
      n = new Uint16Array(t - e),
      s = 0;
    for (let r = e, a = 0; r < t; ) {
      ((n[a++] = o[r++]), (n[a++] = o[r++] - i));
      let t = (n[a++] = o[r++] - i);
      ((n[a++] = o[r++] - e), (s = Math.max(s, t)));
    }
    return new m(n, s, this.set);
  }
}
function g(e, t, i, o) {
  switch (e) {
    case -2:
      return i < t;
    case -1:
      return o >= t && i < t;
    case 0:
      return i < t && o > t;
    case 1:
      return i <= t && o > t;
    case 2:
      return o > t;
    case 4:
      return !0;
  }
}
function f(e, t, i, o) {
  for (
    var n;
    e.from == e.to ||
    (i < 1 ? e.from >= t : e.from > t) ||
    (i > -1 ? e.to <= t : e.to < t);
  ) {
    let t = !o && e instanceof y && e.index < 0 ? null : e.parent;
    if (!t) return e;
    e = t;
  }
  let s = o ? 0 : h.IgnoreOverlays;
  if (o)
    for (let o = e, r = o.parent; r; o = r, r = o.parent)
      o instanceof y &&
        o.index < 0 &&
        (null === (n = r.enter(t, i, s)) || void 0 === n ? void 0 : n.from) !=
          o.from &&
        (e = r);
  for (;;) {
    let o = e.enter(t, i, s);
    if (!o) return e;
    e = o;
  }
}
class b {
  cursor(e = 0) {
    return new T(this, e);
  }
  getChild(e, t = null, i = null) {
    let o = w(this, e, t, i);
    return o.length ? o[0] : null;
  }
  getChildren(e, t = null, i = null) {
    return w(this, e, t, i);
  }
  resolve(e, t = 0) {
    return f(this, e, t, !1);
  }
  resolveInner(e, t = 0) {
    return f(this, e, t, !0);
  }
  matchContext(e) {
    return v(this.parent, e);
  }
  enterUnfinishedNodesBefore(e) {
    let t = this.childBefore(e),
      i = this;
    for (; t; ) {
      let e = t.lastChild;
      if (!e || e.to != t.to) break;
      e.type.isError && e.from == e.to
        ? ((i = t), (t = e.prevSibling))
        : (t = e);
    }
    return i;
  }
  get node() {
    return this;
  }
  get next() {
    return this.parent;
  }
}
class y extends b {
  constructor(e, t, i, o) {
    (super(),
      (this._tree = e),
      (this.from = t),
      (this.index = i),
      (this._parent = o));
  }
  get type() {
    return this._tree.type;
  }
  get name() {
    return this._tree.type.name;
  }
  get to() {
    return this.from + this._tree.length;
  }
  nextChild(e, t, i, o, n = 0) {
    var s;
    for (let a = this; ; ) {
      for (
        let { children: l, positions: c } = a._tree, d = t > 0 ? l.length : -1;
        e != d;
        e += t
      ) {
        let d = l[e],
          p = c[e] + a.from;
        if (
          (n & h.EnterBracketed &&
            d instanceof u &&
            null ===
              (null === (s = r.get(d)) || void 0 === s ? void 0 : s.overlay) &&
            (p >= i || p + d.length <= i)) ||
          g(o, i, p, p + d.length)
        )
          if (d instanceof m) {
            if (n & h.ExcludeBuffers) continue;
            let s = d.findChild(0, d.buffer.length, t, i - p, o);
            if (s > -1) return new x(new C(a, d, e, p), null, s);
          } else if (n & h.IncludeAnonymous || !d.type.isAnonymous || E(d)) {
            let s;
            if (!(n & h.IgnoreMounts) && (s = r.get(d)) && !s.overlay)
              return new y(s.tree, p, e, a);
            let l = new y(d, p, e, a);
            return n & h.IncludeAnonymous || !l.type.isAnonymous
              ? l
              : l.nextChild(t < 0 ? d.children.length - 1 : 0, t, i, o, n);
          }
      }
      if (n & h.IncludeAnonymous || !a.type.isAnonymous) return null;
      if (
        ((e =
          a.index >= 0
            ? a.index + t
            : t < 0
              ? -1
              : a._parent._tree.children.length),
        (a = a._parent),
        !a)
      )
        return null;
    }
  }
  get firstChild() {
    return this.nextChild(0, 1, 0, 4);
  }
  get lastChild() {
    return this.nextChild(this._tree.children.length - 1, -1, 0, 4);
  }
  childAfter(e) {
    return this.nextChild(0, 1, e, 2);
  }
  childBefore(e) {
    return this.nextChild(this._tree.children.length - 1, -1, e, -2);
  }
  prop(e) {
    return this._tree.prop(e);
  }
  enter(e, t, i = 0) {
    let o;
    if (!(i & h.IgnoreOverlays) && (o = r.get(this._tree)) && o.overlay) {
      let n = e - this.from,
        s = i & h.EnterBracketed && o.bracketed;
      for (let { from: e, to: i } of o.overlay)
        if ((t > 0 || s ? e <= n : e < n) && (t < 0 || s ? i >= n : i > n))
          return new y(o.tree, o.overlay[0].from + this.from, -1, this);
    }
    return this.nextChild(0, 1, e, t, i);
  }
  nextSignificantParent() {
    let e = this;
    for (; e.type.isAnonymous && e._parent; ) e = e._parent;
    return e;
  }
  get parent() {
    return this._parent ? this._parent.nextSignificantParent() : null;
  }
  get nextSibling() {
    return this._parent && this.index >= 0
      ? this._parent.nextChild(this.index + 1, 1, 0, 4)
      : null;
  }
  get prevSibling() {
    return this._parent && this.index >= 0
      ? this._parent.nextChild(this.index - 1, -1, 0, 4)
      : null;
  }
  get tree() {
    return this._tree;
  }
  toTree() {
    return this._tree;
  }
  toString() {
    return this._tree.toString();
  }
}
function w(e, t, i, o) {
  let n = e.cursor(),
    s = [];
  if (!n.firstChild()) return s;
  if (null != i)
    for (let e = !1; !e; ) if (((e = n.type.is(i)), !n.nextSibling())) return s;
  for (;;) {
    if (null != o && n.type.is(o)) return s;
    if ((n.type.is(t) && s.push(n.node), !n.nextSibling()))
      return null == o ? s : [];
  }
}
function v(e, t, i = t.length - 1) {
  for (let o = e; i >= 0; o = o.parent) {
    if (!o) return !1;
    if (!o.type.isAnonymous) {
      if (t[i] && t[i] != o.name) return !1;
      i--;
    }
  }
  return !0;
}
class C {
  constructor(e, t, i, o) {
    ((this.parent = e), (this.buffer = t), (this.index = i), (this.start = o));
  }
}
class x extends b {
  get name() {
    return this.type.name;
  }
  get from() {
    return this.context.start + this.context.buffer.buffer[this.index + 1];
  }
  get to() {
    return this.context.start + this.context.buffer.buffer[this.index + 2];
  }
  constructor(e, t, i) {
    (super(),
      (this.context = e),
      (this._parent = t),
      (this.index = i),
      (this.type = e.buffer.set.types[e.buffer.buffer[i]]));
  }
  child(e, t, i) {
    let { buffer: o } = this.context,
      n = o.findChild(
        this.index + 4,
        o.buffer[this.index + 3],
        e,
        t - this.context.start,
        i,
      );
    return n < 0 ? null : new x(this.context, this, n);
  }
  get firstChild() {
    return this.child(1, 0, 4);
  }
  get lastChild() {
    return this.child(-1, 0, 4);
  }
  childAfter(e) {
    return this.child(1, e, 2);
  }
  childBefore(e) {
    return this.child(-1, e, -2);
  }
  prop(e) {
    return this.type.prop(e);
  }
  enter(e, t, i = 0) {
    if (i & h.ExcludeBuffers) return null;
    let { buffer: o } = this.context,
      n = o.findChild(
        this.index + 4,
        o.buffer[this.index + 3],
        t > 0 ? 1 : -1,
        e - this.context.start,
        t,
      );
    return n < 0 ? null : new x(this.context, this, n);
  }
  get parent() {
    return this._parent || this.context.parent.nextSignificantParent();
  }
  externalSibling(e) {
    return this._parent
      ? null
      : this.context.parent.nextChild(this.context.index + e, e, 0, 4);
  }
  get nextSibling() {
    let { buffer: e } = this.context,
      t = e.buffer[this.index + 3];
    return t <
      (this._parent ? e.buffer[this._parent.index + 3] : e.buffer.length)
      ? new x(this.context, this._parent, t)
      : this.externalSibling(1);
  }
  get prevSibling() {
    let { buffer: e } = this.context,
      t = this._parent ? this._parent.index + 4 : 0;
    return this.index == t
      ? this.externalSibling(-1)
      : new x(this.context, this._parent, e.findChild(t, this.index, -1, 0, 4));
  }
  get tree() {
    return null;
  }
  toTree() {
    let e = [],
      t = [],
      { buffer: i } = this.context,
      o = this.index + 4,
      n = i.buffer[this.index + 3];
    if (n > o) {
      let s = i.buffer[this.index + 1];
      (e.push(i.slice(o, n, s)), t.push(0));
    }
    return new u(this.type, e, t, this.to - this.from);
  }
  toString() {
    return this.context.buffer.childString(this.index);
  }
}
function k(e) {
  if (!e.length) return null;
  let t = 0,
    i = e[0];
  for (let o = 1; o < e.length; o++) {
    let n = e[o];
    (n.from > i.from || n.to < i.to) && ((i = n), (t = o));
  }
  let o = i instanceof y && i.index < 0 ? null : i.parent,
    n = e.slice();
  return (o ? (n[t] = o) : n.splice(t, 1), new S(n, i));
}
class S {
  constructor(e, t) {
    ((this.heads = e), (this.node = t));
  }
  get next() {
    return k(this.heads);
  }
}
class T {
  get name() {
    return this.type.name;
  }
  constructor(e, t = 0) {
    if (
      ((this.buffer = null),
      (this.stack = []),
      (this.index = 0),
      (this.bufferNode = null),
      (this.mode = t & ~h.EnterBracketed),
      e instanceof y)
    )
      this.yieldNode(e);
    else {
      ((this._tree = e.context.parent), (this.buffer = e.context));
      for (let t = e._parent; t; t = t._parent) this.stack.unshift(t.index);
      ((this.bufferNode = e), this.yieldBuf(e.index));
    }
  }
  yieldNode(e) {
    return (
      !!e &&
      ((this._tree = e),
      (this.type = e.type),
      (this.from = e.from),
      (this.to = e.to),
      !0)
    );
  }
  yieldBuf(e, t) {
    this.index = e;
    let { start: i, buffer: o } = this.buffer;
    return (
      (this.type = t || o.set.types[o.buffer[e]]),
      (this.from = i + o.buffer[e + 1]),
      (this.to = i + o.buffer[e + 2]),
      !0
    );
  }
  yield(e) {
    return (
      !!e &&
      (e instanceof y
        ? ((this.buffer = null), this.yieldNode(e))
        : ((this.buffer = e.context), this.yieldBuf(e.index, e.type)))
    );
  }
  toString() {
    return this.buffer
      ? this.buffer.buffer.childString(this.index)
      : this._tree.toString();
  }
  enterChild(e, t, i) {
    if (!this.buffer)
      return this.yield(
        this._tree.nextChild(
          e < 0 ? this._tree._tree.children.length - 1 : 0,
          e,
          t,
          i,
          this.mode,
        ),
      );
    let { buffer: o } = this.buffer,
      n = o.findChild(
        this.index + 4,
        o.buffer[this.index + 3],
        e,
        t - this.buffer.start,
        i,
      );
    return !(n < 0) && (this.stack.push(this.index), this.yieldBuf(n));
  }
  firstChild() {
    return this.enterChild(1, 0, 4);
  }
  lastChild() {
    return this.enterChild(-1, 0, 4);
  }
  childAfter(e) {
    return this.enterChild(1, e, 2);
  }
  childBefore(e) {
    return this.enterChild(-1, e, -2);
  }
  enter(e, t, i = this.mode) {
    return this.buffer
      ? !(i & h.ExcludeBuffers) && this.enterChild(1, e, t)
      : this.yield(this._tree.enter(e, t, i));
  }
  parent() {
    if (!this.buffer)
      return this.yieldNode(
        this.mode & h.IncludeAnonymous ? this._tree._parent : this._tree.parent,
      );
    if (this.stack.length) return this.yieldBuf(this.stack.pop());
    let e =
      this.mode & h.IncludeAnonymous
        ? this.buffer.parent
        : this.buffer.parent.nextSignificantParent();
    return ((this.buffer = null), this.yieldNode(e));
  }
  sibling(e) {
    if (!this.buffer)
      return (
        !!this._tree._parent &&
        this.yield(
          this._tree.index < 0
            ? null
            : this._tree._parent.nextChild(
                this._tree.index + e,
                e,
                0,
                4,
                this.mode,
              ),
        )
      );
    let { buffer: t } = this.buffer,
      i = this.stack.length - 1;
    if (e < 0) {
      let e = i < 0 ? 0 : this.stack[i] + 4;
      if (this.index != e)
        return this.yieldBuf(t.findChild(e, this.index, -1, 0, 4));
    } else {
      let e = t.buffer[this.index + 3];
      if (e < (i < 0 ? t.buffer.length : t.buffer[this.stack[i] + 3]))
        return this.yieldBuf(e);
    }
    return (
      i < 0 &&
      this.yield(
        this.buffer.parent.nextChild(this.buffer.index + e, e, 0, 4, this.mode),
      )
    );
  }
  nextSibling() {
    return this.sibling(1);
  }
  prevSibling() {
    return this.sibling(-1);
  }
  atLastNode(e) {
    let t,
      i,
      { buffer: o } = this;
    if (o) {
      if (e > 0) {
        if (this.index < o.buffer.buffer.length) return !1;
      } else
        for (let e = 0; e < this.index; e++)
          if (o.buffer.buffer[e + 3] < this.index) return !1;
      ({ index: t, parent: i } = o);
    } else ({ index: t, _parent: i } = this._tree);
    for (; i; { index: t, _parent: i } = i)
      if (t > -1)
        for (
          let o = t + e, n = e < 0 ? -1 : i._tree.children.length;
          o != n;
          o += e
        ) {
          let e = i._tree.children[o];
          if (
            this.mode & h.IncludeAnonymous ||
            e instanceof m ||
            !e.type.isAnonymous ||
            E(e)
          )
            return !1;
        }
    return !0;
  }
  move(e, t) {
    if (t && this.enterChild(e, 0, 4)) return !0;
    for (;;) {
      if (this.sibling(e)) return !0;
      if (this.atLastNode(e) || !this.parent()) return !1;
    }
  }
  next(e = !0) {
    return this.move(1, e);
  }
  prev(e = !0) {
    return this.move(-1, e);
  }
  moveTo(e, t = 0) {
    for (
      ;
      (this.from == this.to ||
        (t < 1 ? this.from >= e : this.from > e) ||
        (t > -1 ? this.to <= e : this.to < e)) &&
      this.parent();
    );
    for (; this.enterChild(1, e, t); );
    return this;
  }
  get node() {
    if (!this.buffer) return this._tree;
    let e = this.bufferNode,
      t = null,
      i = 0;
    if (e && e.context == this.buffer)
      e: for (let o = this.index, n = this.stack.length; n >= 0; ) {
        for (let s = e; s; s = s._parent)
          if (s.index == o) {
            if (o == this.index) return s;
            ((t = s), (i = n + 1));
            break e;
          }
        o = this.stack[--n];
      }
    for (let e = i; e < this.stack.length; e++)
      t = new x(this.buffer, t, this.stack[e]);
    return (this.bufferNode = new x(this.buffer, t, this.index));
  }
  get tree() {
    return this.buffer ? null : this._tree._tree;
  }
  iterate(e, t) {
    for (let i = 0; ; ) {
      let o = !1;
      if (this.type.isAnonymous || !1 !== e(this)) {
        if (this.firstChild()) {
          i++;
          continue;
        }
        this.type.isAnonymous || (o = !0);
      }
      for (;;) {
        if ((o && t && t(this), (o = this.type.isAnonymous), !i)) return;
        if (this.nextSibling()) break;
        (this.parent(), i--, (o = !0));
      }
    }
  }
  matchContext(e) {
    if (!this.buffer) return v(this.node.parent, e);
    let { buffer: t } = this.buffer,
      { types: i } = t.set;
    for (let o = e.length - 1, n = this.stack.length - 1; o >= 0; n--) {
      if (n < 0) return v(this._tree, e, o);
      let s = i[t.buffer[this.stack[n]]];
      if (!s.isAnonymous) {
        if (e[o] && e[o] != s.name) return !1;
        o--;
      }
    }
    return !0;
  }
}
function E(e) {
  return e.children.some((e) => e instanceof m || !e.type.isAnonymous || E(e));
}
const M = new WeakMap();
function A(e, t) {
  if (!e.isAnonymous || t instanceof m || t.type != e) return 1;
  let i = M.get(t);
  if (null == i) {
    i = 1;
    for (let o of t.children) {
      if (o.type != e || !(o instanceof u)) {
        i = 1;
        break;
      }
      i += A(e, o);
    }
    M.set(t, i);
  }
  return i;
}
function I(e, t, i, o, n, s, r, a, l) {
  let c = 0;
  for (let i = o; i < n; i++) c += A(e, t[i]);
  let d = Math.ceil((1.5 * c) / 8),
    h = [],
    u = [];
  return (
    (function t(i, o, n, r, a) {
      for (let c = n; c < r; ) {
        let n = c,
          p = o[c],
          m = A(e, i[c]);
        for (c++; c < r; c++) {
          let t = A(e, i[c]);
          if (m + t >= d) break;
          m += t;
        }
        if (c == n + 1) {
          if (m > d) {
            let e = i[n];
            t(e.children, e.positions, 0, e.children.length, o[n] + a);
            continue;
          }
          h.push(i[n]);
        } else {
          let t = o[c - 1] + i[c - 1].length - p;
          h.push(I(e, i, o, n, c, p, t, null, l));
        }
        u.push(p + a - s);
      }
    })(t, i, o, n, 0),
    (a || l)(h, u, r)
  );
}
class D {
  constructor(e, t, i, o, n = !1, s = !1) {
    ((this.from = e),
      (this.to = t),
      (this.tree = i),
      (this.offset = o),
      (this.open = (n ? 1 : 0) | (s ? 2 : 0)));
  }
  get openStart() {
    return (1 & this.open) > 0;
  }
  get openEnd() {
    return (2 & this.open) > 0;
  }
  static addTree(e, t = [], i = !1) {
    let o = [new D(0, e.length, e, 0, !1, i)];
    for (let i of t) i.to > e.length && o.push(i);
    return o;
  }
  static applyChanges(e, t, i = 128) {
    if (!t.length) return e;
    let o = [],
      n = 1,
      s = e.length ? e[0] : null;
    for (let r = 0, a = 0, l = 0; ; r++) {
      let c = r < t.length ? t[r] : null,
        d = c ? c.fromA : 1e9;
      if (d - a >= i)
        for (; s && s.from < d; ) {
          let t = s;
          if (a >= t.from || d <= t.to || l) {
            let e = Math.max(t.from, a) - l,
              i = Math.min(t.to, d) - l;
            t = e >= i ? null : new D(e, i, t.tree, t.offset + l, r > 0, !!c);
          }
          if ((t && o.push(t), s.to > d)) break;
          s = n < e.length ? e[n++] : null;
        }
      if (!c) break;
      ((a = c.toA), (l = c.toA - c.toB));
    }
    return o;
  }
}
class O {
  startParse(e, t, i) {
    return (
      "string" == typeof e && (e = new B(e)),
      (i = i
        ? i.length
          ? i.map((e) => new n(e.from, e.to))
          : [new n(0, 0)]
        : [new n(0, e.length)]),
      this.createParse(e, t || [], i)
    );
  }
  parse(e, t, i) {
    let o = this.startParse(e, t, i);
    for (;;) {
      let e = o.advance();
      if (e) return e;
    }
  }
}
class B {
  constructor(e) {
    this.string = e;
  }
  get length() {
    return this.string.length;
  }
  chunk(e) {
    return this.string.slice(e);
  }
  get lineChunks() {
    return !1;
  }
  read(e, t) {
    return this.string.slice(e, t);
  }
}
new s({ perNode: !0 });
let L = [],
  P = [];
function N(e) {
  if (e < 768) return !1;
  for (let t = 0, i = L.length; ; ) {
    let o = (t + i) >> 1;
    if (e < L[o]) i = o;
    else {
      if (!(e >= P[o])) return !0;
      t = o + 1;
    }
    if (t == i) return !1;
  }
}
function R(e) {
  return e >= 127462 && e <= 127487;
}
(() => {
  let e =
    "lc,34,7n,7,7b,19,,,,2,,2,,,20,b,1c,l,g,,2t,7,2,6,2,2,,4,z,,u,r,2j,b,1m,9,9,,o,4,,9,,3,,5,17,3,3b,f,,w,1j,,,,4,8,4,,3,7,a,2,t,,1m,,,,2,4,8,,9,,a,2,q,,2,2,1l,,4,2,4,2,2,3,3,,u,2,3,,b,2,1l,,4,5,,2,4,,k,2,m,6,,,1m,,,2,,4,8,,7,3,a,2,u,,1n,,,,c,,9,,14,,3,,1l,3,5,3,,4,7,2,b,2,t,,1m,,2,,2,,3,,5,2,7,2,b,2,s,2,1l,2,,,2,4,8,,9,,a,2,t,,20,,4,,2,3,,,8,,29,,2,7,c,8,2q,,2,9,b,6,22,2,r,,,,,,1j,e,,5,,2,5,b,,10,9,,2u,4,,6,,2,2,2,p,2,4,3,g,4,d,,2,2,6,,f,,jj,3,qa,3,t,3,t,2,u,2,1s,2,,7,8,,2,b,9,,19,3,3b,2,y,,3a,3,4,2,9,,6,3,63,2,2,,1m,,,7,,,,,2,8,6,a,2,,1c,h,1r,4,1c,7,,,5,,14,9,c,2,w,4,2,2,,3,1k,,,2,3,,,3,1m,8,2,2,48,3,,d,,7,4,,6,,3,2,5i,1m,,5,ek,,5f,x,2da,3,3x,,2o,w,fe,6,2x,2,n9w,4,,a,w,2,28,2,7k,,3,,4,,p,2,5,,47,2,q,i,d,,12,8,p,b,1a,3,1c,,2,4,2,2,13,,1v,6,2,2,2,2,c,,8,,1b,,1f,,,3,2,2,5,2,,,16,2,8,,6m,,2,,4,,fn4,,kh,g,g,g,a6,2,gt,,6a,,45,5,1ae,3,,2,5,4,14,3,4,,4l,2,fx,4,ar,2,49,b,4w,,1i,f,1k,3,1d,4,2,2,1x,3,10,5,,8,1q,,c,2,1g,9,a,4,2,,2n,3,2,,,2,6,,4g,,3,8,l,2,1l,2,,,,,m,,e,7,3,5,5f,8,2,3,,,n,,29,,2,6,,,2,,,2,,2,6j,,2,4,6,2,,2,r,2,2d,8,2,,,2,2y,,,,2,6,,,2t,3,2,4,,5,77,9,,2,6t,,a,2,,,4,,40,4,2,2,4,,w,a,14,6,2,4,8,,9,6,2,3,1a,d,,2,ba,7,,6,,,2a,m,2,7,,2,,2,3e,6,3,,,2,,7,,,20,2,3,,,,9n,2,f0b,5,1n,7,t4,,1r,4,29,,f5k,2,43q,,,3,4,5,8,8,2,7,u,4,44,3,1iz,1j,4,1e,8,,e,,m,5,,f,11s,7,,h,2,7,,2,,5,79,7,c5,4,15s,7,31,7,240,5,gx7k,2o,3k,6o"
      .split(",")
      .map((e) => (e ? parseInt(e, 36) : 1));
  for (let t = 0, i = 0; t < e.length; t++) (t % 2 ? P : L).push((i += e[t]));
})();
function F(e, t, i = !0, o = !0) {
  return (i ? q : _)(e, t, o);
}
function q(e, t, i) {
  if (t == e.length) return t;
  t && V(e.charCodeAt(t)) && W(e.charCodeAt(t - 1)) && t--;
  let o = z(e, t);
  for (t += H(o); t < e.length; ) {
    let n = z(e, t);
    if (8205 == o || 8205 == n || (i && N(n))) ((t += H(n)), (o = n));
    else {
      if (!R(n)) break;
      {
        let i = 0,
          o = t - 2;
        for (; o >= 0 && R(z(e, o)); ) (i++, (o -= 2));
        if (i % 2 == 0) break;
        t += 2;
      }
    }
  }
  return t;
}
function _(e, t, i) {
  for (; t > 0; ) {
    let o = q(e, t - 2, i);
    if (o < t) return o;
    t--;
  }
  return 0;
}
function z(e, t) {
  let i = e.charCodeAt(t);
  if (!W(i) || t + 1 == e.length) return i;
  let o = e.charCodeAt(t + 1);
  return V(o) ? o - 56320 + ((i - 55296) << 10) + 65536 : i;
}
function V(e) {
  return e >= 56320 && e < 57344;
}
function W(e) {
  return e >= 55296 && e < 56320;
}
function H(e) {
  return e < 65536 ? 1 : 2;
}
class $ {
  lineAt(e) {
    if (e < 0 || e > this.length)
      throw new RangeError(
        `Invalid position ${e} in document of length ${this.length}`,
      );
    return this.lineInner(e, !1, 1, 0);
  }
  line(e) {
    if (e < 1 || e > this.lines)
      throw new RangeError(
        `Invalid line number ${e} in ${this.lines}-line document`,
      );
    return this.lineInner(e, !0, 1, 0);
  }
  replace(e, t, i) {
    [e, t] = Q(this, e, t);
    let o = [];
    return (
      this.decompose(0, e, o, 2),
      i.length && i.decompose(0, i.length, o, 3),
      this.decompose(t, this.length, o, 1),
      j.from(o, this.length - (t - e) + i.length)
    );
  }
  append(e) {
    return this.replace(this.length, this.length, e);
  }
  slice(e, t = this.length) {
    [e, t] = Q(this, e, t);
    let i = [];
    return (this.decompose(e, t, i, 0), j.from(i, t - e));
  }
  eq(e) {
    if (e == this) return !0;
    if (e.length != this.length || e.lines != this.lines) return !1;
    let t = this.scanIdentical(e, 1),
      i = this.length - this.scanIdentical(e, -1),
      o = new Z(this),
      n = new Z(e);
    for (let e = t, s = t; ; ) {
      if (
        (o.next(e),
        n.next(e),
        (e = 0),
        o.lineBreak != n.lineBreak || o.done != n.done || o.value != n.value)
      )
        return !1;
      if (((s += o.value.length), o.done || s >= i)) return !0;
    }
  }
  iter(e = 1) {
    return new Z(this, e);
  }
  iterRange(e, t = this.length) {
    return new K(this, e, t);
  }
  iterLines(e, t) {
    let i;
    if (null == e) i = this.iter();
    else {
      null == t && (t = this.lines + 1);
      let o = this.line(e).from;
      i = this.iterRange(
        o,
        Math.max(
          o,
          t == this.lines + 1 ? this.length : t <= 1 ? 0 : this.line(t - 1).to,
        ),
      );
    }
    return new J(i);
  }
  toString() {
    return this.sliceString(0);
  }
  toJSON() {
    let e = [];
    return (this.flatten(e), e);
  }
  constructor() {}
  static of(e) {
    if (0 == e.length)
      throw new RangeError("A document must have at least one line");
    return 1 != e.length || e[0]
      ? e.length <= 32
        ? new U(e)
        : j.from(U.split(e, []))
      : $.empty;
  }
}
class U extends $ {
  constructor(
    e,
    t = (function (e) {
      let t = -1;
      for (let i of e) t += i.length + 1;
      return t;
    })(e),
  ) {
    (super(), (this.text = e), (this.length = t));
  }
  get lines() {
    return this.text.length;
  }
  get children() {
    return null;
  }
  lineInner(e, t, i, o) {
    for (let n = 0; ; n++) {
      let s = this.text[n],
        r = o + s.length;
      if ((t ? i : r) >= e) return new X(o, r, i, s);
      ((o = r + 1), i++);
    }
  }
  decompose(e, t, i, o) {
    let n =
      e <= 0 && t >= this.length
        ? this
        : new U(G(this.text, e, t), Math.min(t, this.length) - Math.max(0, e));
    if (1 & o) {
      let e = i.pop(),
        t = Y(n.text, e.text.slice(), 0, n.length);
      if (t.length <= 32) i.push(new U(t, e.length + n.length));
      else {
        let e = t.length >> 1;
        i.push(new U(t.slice(0, e)), new U(t.slice(e)));
      }
    } else i.push(n);
  }
  replace(e, t, i) {
    if (!(i instanceof U)) return super.replace(e, t, i);
    [e, t] = Q(this, e, t);
    let o = Y(this.text, Y(i.text, G(this.text, 0, e)), t),
      n = this.length + i.length - (t - e);
    return o.length <= 32 ? new U(o, n) : j.from(U.split(o, []), n);
  }
  sliceString(e, t = this.length, i = "\n") {
    [e, t] = Q(this, e, t);
    let o = "";
    for (let n = 0, s = 0; n <= t && s < this.text.length; s++) {
      let r = this.text[s],
        a = n + r.length;
      (n > e && s && (o += i),
        e < a && t > n && (o += r.slice(Math.max(0, e - n), t - n)),
        (n = a + 1));
    }
    return o;
  }
  flatten(e) {
    for (let t of this.text) e.push(t);
  }
  scanIdentical() {
    return 0;
  }
  static split(e, t) {
    let i = [],
      o = -1;
    for (let n of e)
      (i.push(n),
        (o += n.length + 1),
        32 == i.length && (t.push(new U(i, o)), (i = []), (o = -1)));
    return (o > -1 && t.push(new U(i, o)), t);
  }
}
class j extends $ {
  constructor(e, t) {
    (super(), (this.children = e), (this.length = t), (this.lines = 0));
    for (let t of e) this.lines += t.lines;
  }
  lineInner(e, t, i, o) {
    for (let n = 0; ; n++) {
      let s = this.children[n],
        r = o + s.length,
        a = i + s.lines - 1;
      if ((t ? a : r) >= e) return s.lineInner(e, t, i, o);
      ((o = r + 1), (i = a + 1));
    }
  }
  decompose(e, t, i, o) {
    for (let n = 0, s = 0; s <= t && n < this.children.length; n++) {
      let r = this.children[n],
        a = s + r.length;
      if (e <= a && t >= s) {
        let n = o & ((s <= e ? 1 : 0) | (a >= t ? 2 : 0));
        s >= e && a <= t && !n ? i.push(r) : r.decompose(e - s, t - s, i, n);
      }
      s = a + 1;
    }
  }
  replace(e, t, i) {
    if ((([e, t] = Q(this, e, t)), i.lines < this.lines))
      for (let o = 0, n = 0; o < this.children.length; o++) {
        let s = this.children[o],
          r = n + s.length;
        if (e >= n && t <= r) {
          let a = s.replace(e - n, t - n, i),
            l = this.lines - s.lines + a.lines;
          if (a.lines < l >> 4 && a.lines > l >> 6) {
            let n = this.children.slice();
            return ((n[o] = a), new j(n, this.length - (t - e) + i.length));
          }
          return super.replace(n, r, a);
        }
        n = r + 1;
      }
    return super.replace(e, t, i);
  }
  sliceString(e, t = this.length, i = "\n") {
    [e, t] = Q(this, e, t);
    let o = "";
    for (let n = 0, s = 0; n < this.children.length && s <= t; n++) {
      let r = this.children[n],
        a = s + r.length;
      (s > e && n && (o += i),
        e < a && t > s && (o += r.sliceString(e - s, t - s, i)),
        (s = a + 1));
    }
    return o;
  }
  flatten(e) {
    for (let t of this.children) t.flatten(e);
  }
  scanIdentical(e, t) {
    if (!(e instanceof j)) return 0;
    let i = 0,
      [o, n, s, r] =
        t > 0
          ? [0, 0, this.children.length, e.children.length]
          : [this.children.length - 1, e.children.length - 1, -1, -1];
    for (; ; o += t, n += t) {
      if (o == s || n == r) return i;
      let a = this.children[o],
        l = e.children[n];
      if (a != l) return i + a.scanIdentical(l, t);
      i += a.length + 1;
    }
  }
  static from(e, t = e.reduce((e, t) => e + t.length + 1, -1)) {
    let i = 0;
    for (let t of e) i += t.lines;
    if (i < 32) {
      let i = [];
      for (let t of e) t.flatten(i);
      return new U(i, t);
    }
    let o = Math.max(32, i >> 5),
      n = o << 1,
      s = o >> 1,
      r = [],
      a = 0,
      l = -1,
      c = [];
    function d(e) {
      let t;
      if (e.lines > n && e instanceof j) for (let t of e.children) d(t);
      else
        e.lines > s && (a > s || !a)
          ? (h(), r.push(e))
          : e instanceof U &&
              a &&
              (t = c[c.length - 1]) instanceof U &&
              e.lines + t.lines <= 32
            ? ((a += e.lines),
              (l += e.length + 1),
              (c[c.length - 1] = new U(
                t.text.concat(e.text),
                t.length + 1 + e.length,
              )))
            : (a + e.lines > o && h(),
              (a += e.lines),
              (l += e.length + 1),
              c.push(e));
    }
    function h() {
      0 != a &&
        (r.push(1 == c.length ? c[0] : j.from(c, l)),
        (l = -1),
        (a = c.length = 0));
    }
    for (let t of e) d(t);
    return (h(), 1 == r.length ? r[0] : new j(r, t));
  }
}
function Y(e, t, i = 0, o = 1e9) {
  for (let n = 0, s = 0, r = !0; s < e.length && n <= o; s++) {
    let a = e[s],
      l = n + a.length;
    (l >= i &&
      (l > o && (a = a.slice(0, o - n)),
      n < i && (a = a.slice(i - n)),
      r ? ((t[t.length - 1] += a), (r = !1)) : t.push(a)),
      (n = l + 1));
  }
  return t;
}
function G(e, t, i) {
  return Y(e, [""], t, i);
}
$.empty = new U([""], 0);
class Z {
  constructor(e, t = 1) {
    ((this.dir = t),
      (this.done = !1),
      (this.lineBreak = !1),
      (this.value = ""),
      (this.nodes = [e]),
      (this.offsets = [
        t > 0 ? 1 : (e instanceof U ? e.text.length : e.children.length) << 1,
      ]));
  }
  nextInner(e, t) {
    for (this.done = this.lineBreak = !1; ; ) {
      let i = this.nodes.length - 1,
        o = this.nodes[i],
        n = this.offsets[i],
        s = n >> 1,
        r = o instanceof U ? o.text.length : o.children.length;
      if (s == (t > 0 ? r : 0)) {
        if (0 == i) return ((this.done = !0), (this.value = ""), this);
        (t > 0 && this.offsets[i - 1]++, this.nodes.pop(), this.offsets.pop());
      } else if ((1 & n) == (t > 0 ? 0 : 1)) {
        if (((this.offsets[i] += t), 0 == e))
          return ((this.lineBreak = !0), (this.value = "\n"), this);
        e--;
      } else if (o instanceof U) {
        let n = o.text[s + (t < 0 ? -1 : 0)];
        if (((this.offsets[i] += t), n.length > Math.max(0, e)))
          return (
            (this.value =
              0 == e ? n : t > 0 ? n.slice(e) : n.slice(0, n.length - e)),
            this
          );
        e -= n.length;
      } else {
        let n = o.children[s + (t < 0 ? -1 : 0)];
        e > n.length
          ? ((e -= n.length), (this.offsets[i] += t))
          : (t < 0 && this.offsets[i]--,
            this.nodes.push(n),
            this.offsets.push(
              t > 0
                ? 1
                : (n instanceof U ? n.text.length : n.children.length) << 1,
            ));
      }
    }
  }
  next(e = 0) {
    return (
      e < 0 && (this.nextInner(-e, -this.dir), (e = this.value.length)),
      this.nextInner(e, this.dir)
    );
  }
}
class K {
  constructor(e, t, i) {
    ((this.value = ""),
      (this.done = !1),
      (this.cursor = new Z(e, t > i ? -1 : 1)),
      (this.pos = t > i ? e.length : 0),
      (this.from = Math.min(t, i)),
      (this.to = Math.max(t, i)));
  }
  nextInner(e, t) {
    if (t < 0 ? this.pos <= this.from : this.pos >= this.to)
      return ((this.value = ""), (this.done = !0), this);
    e += Math.max(0, t < 0 ? this.pos - this.to : this.from - this.pos);
    let i = t < 0 ? this.pos - this.from : this.to - this.pos;
    (e > i && (e = i), (i -= e));
    let { value: o } = this.cursor.next(e);
    return (
      (this.pos += (o.length + e) * t),
      (this.value =
        o.length <= i ? o : t < 0 ? o.slice(o.length - i) : o.slice(0, i)),
      (this.done = !this.value),
      this
    );
  }
  next(e = 0) {
    return (
      e < 0
        ? (e = Math.max(e, this.from - this.pos))
        : e > 0 && (e = Math.min(e, this.to - this.pos)),
      this.nextInner(e, this.cursor.dir)
    );
  }
  get lineBreak() {
    return this.cursor.lineBreak && "" != this.value;
  }
}
class J {
  constructor(e) {
    ((this.inner = e),
      (this.afterBreak = !0),
      (this.value = ""),
      (this.done = !1));
  }
  next(e = 0) {
    let { done: t, lineBreak: i, value: o } = this.inner.next(e);
    return (
      t && this.afterBreak
        ? ((this.value = ""), (this.afterBreak = !1))
        : t
          ? ((this.done = !0), (this.value = ""))
          : i
            ? this.afterBreak
              ? (this.value = "")
              : ((this.afterBreak = !0), this.next())
            : ((this.value = o), (this.afterBreak = !1)),
      this
    );
  }
  get lineBreak() {
    return !1;
  }
}
"undefined" != typeof Symbol &&
  (($.prototype[Symbol.iterator] = function () {
    return this.iter();
  }),
  (Z.prototype[Symbol.iterator] =
    K.prototype[Symbol.iterator] =
    J.prototype[Symbol.iterator] =
      function () {
        return this;
      }));
class X {
  constructor(e, t, i, o) {
    ((this.from = e), (this.to = t), (this.number = i), (this.text = o));
  }
  get length() {
    return this.to - this.from;
  }
}
function Q(e, t, i) {
  return [
    (t = Math.max(0, Math.min(e.length, t))),
    Math.max(t, Math.min(e.length, i)),
  ];
}
function ee(e, t, i = !0, o = !0) {
  return F(e, t, i, o);
}
const te = /\r\n?|\n/;
var ie = (function (e) {
  return (
    (e[(e.Simple = 0)] = "Simple"),
    (e[(e.TrackDel = 1)] = "TrackDel"),
    (e[(e.TrackBefore = 2)] = "TrackBefore"),
    (e[(e.TrackAfter = 3)] = "TrackAfter"),
    e
  );
})(ie || (ie = {}));
class oe {
  constructor(e) {
    this.sections = e;
  }
  get length() {
    let e = 0;
    for (let t = 0; t < this.sections.length; t += 2) e += this.sections[t];
    return e;
  }
  get newLength() {
    let e = 0;
    for (let t = 0; t < this.sections.length; t += 2) {
      let i = this.sections[t + 1];
      e += i < 0 ? this.sections[t] : i;
    }
    return e;
  }
  get empty() {
    return (
      0 == this.sections.length ||
      (2 == this.sections.length && this.sections[1] < 0)
    );
  }
  iterGaps(e) {
    for (let t = 0, i = 0, o = 0; t < this.sections.length; ) {
      let n = this.sections[t++],
        s = this.sections[t++];
      (s < 0 ? (e(i, o, n), (o += n)) : (o += s), (i += n));
    }
  }
  iterChangedRanges(e, t = !1) {
    ae(this, e, t);
  }
  get invertedDesc() {
    let e = [];
    for (let t = 0; t < this.sections.length; ) {
      let i = this.sections[t++],
        o = this.sections[t++];
      o < 0 ? e.push(i, o) : e.push(o, i);
    }
    return new oe(e);
  }
  composeDesc(e) {
    return this.empty ? e : e.empty ? this : ce(this, e);
  }
  mapDesc(e, t = !1) {
    return e.empty ? this : le(this, e, t);
  }
  mapPos(e, t = -1, i = ie.Simple) {
    let o = 0,
      n = 0;
    for (let s = 0; s < this.sections.length; ) {
      let r = this.sections[s++],
        a = this.sections[s++],
        l = o + r;
      if (a < 0) {
        if (l > e) return n + (e - o);
        n += r;
      } else {
        if (
          i != ie.Simple &&
          l >= e &&
          ((i == ie.TrackDel && o < e && l > e) ||
            (i == ie.TrackBefore && o < e) ||
            (i == ie.TrackAfter && l > e))
        )
          return null;
        if (l > e || (l == e && t < 0 && !r))
          return e == o || t < 0 ? n : n + a;
        n += a;
      }
      o = l;
    }
    if (e > o)
      throw new RangeError(
        `Position ${e} is out of range for changeset of length ${o}`,
      );
    return n;
  }
  touchesRange(e, t = e) {
    for (let i = 0, o = 0; i < this.sections.length && o <= t; ) {
      let n = o + this.sections[i++];
      if (this.sections[i++] >= 0 && o <= t && n >= e)
        return !(o < e && n > t) || "cover";
      o = n;
    }
    return !1;
  }
  toString() {
    let e = "";
    for (let t = 0; t < this.sections.length; ) {
      let i = this.sections[t++],
        o = this.sections[t++];
      e += (e ? " " : "") + i + (o >= 0 ? ":" + o : "");
    }
    return e;
  }
  toJSON() {
    return this.sections;
  }
  static fromJSON(e) {
    if (
      !Array.isArray(e) ||
      e.length % 2 ||
      e.some((e) => "number" != typeof e)
    )
      throw new RangeError("Invalid JSON representation of ChangeDesc");
    return new oe(e);
  }
  static create(e) {
    return new oe(e);
  }
}
class ne extends oe {
  constructor(e, t) {
    (super(e), (this.inserted = t));
  }
  apply(e) {
    if (this.length != e.length)
      throw new RangeError(
        "Applying change set to a document with the wrong length",
      );
    return (
      ae(this, (t, i, o, n, s) => (e = e.replace(o, o + (i - t), s)), !1),
      e
    );
  }
  mapDesc(e, t = !1) {
    return le(this, e, t, !0);
  }
  invert(e) {
    let t = this.sections.slice(),
      i = [];
    for (let o = 0, n = 0; o < t.length; o += 2) {
      let s = t[o],
        r = t[o + 1];
      if (r >= 0) {
        ((t[o] = r), (t[o + 1] = s));
        let a = o >> 1;
        for (; i.length < a; ) i.push($.empty);
        i.push(s ? e.slice(n, n + s) : $.empty);
      }
      n += s;
    }
    return new ne(t, i);
  }
  compose(e) {
    return this.empty ? e : e.empty ? this : ce(this, e, !0);
  }
  map(e, t = !1) {
    return e.empty ? this : le(this, e, t, !0);
  }
  iterChanges(e, t = !1) {
    ae(this, e, t);
  }
  get desc() {
    return oe.create(this.sections);
  }
  filter(e) {
    let t = [],
      i = [],
      o = [],
      n = new de(this);
    e: for (let s = 0, r = 0; ; ) {
      let a = s == e.length ? 1e9 : e[s++];
      for (; r < a || (r == a && 0 == n.len); ) {
        if (n.done) break e;
        let e = Math.min(n.len, a - r);
        se(o, e, -1);
        let s = -1 == n.ins ? -1 : 0 == n.off ? n.ins : 0;
        (se(t, e, s), s > 0 && re(i, t, n.text), n.forward(e), (r += e));
      }
      let l = e[s++];
      for (; r < l; ) {
        if (n.done) break e;
        let e = Math.min(n.len, l - r);
        (se(t, e, -1),
          se(o, e, -1 == n.ins ? -1 : 0 == n.off ? n.ins : 0),
          n.forward(e),
          (r += e));
      }
    }
    return { changes: new ne(t, i), filtered: oe.create(o) };
  }
  toJSON() {
    let e = [];
    for (let t = 0; t < this.sections.length; t += 2) {
      let i = this.sections[t],
        o = this.sections[t + 1];
      o < 0
        ? e.push(i)
        : 0 == o
          ? e.push([i])
          : e.push([i].concat(this.inserted[t >> 1].toJSON()));
    }
    return e;
  }
  static of(e, t, i) {
    let o = [],
      n = [],
      s = 0,
      r = null;
    function a(e = !1) {
      if (!e && !o.length) return;
      s < t && se(o, t - s, -1);
      let i = new ne(o, n);
      ((r = r ? r.compose(i.map(r)) : i), (o = []), (n = []), (s = 0));
    }
    return (
      (function e(l) {
        if (Array.isArray(l)) for (let t of l) e(t);
        else if (l instanceof ne) {
          if (l.length != t)
            throw new RangeError(
              `Mismatched change set length (got ${l.length}, expected ${t})`,
            );
          (a(), (r = r ? r.compose(l.map(r)) : l));
        } else {
          let { from: e, to: r = e, insert: c } = l;
          if (e > r || e < 0 || r > t)
            throw new RangeError(
              `Invalid change range ${e} to ${r} (in doc of length ${t})`,
            );
          let d = c
              ? "string" == typeof c
                ? $.of(c.split(i || te))
                : c
              : $.empty,
            h = d.length;
          if (e == r && 0 == h) return;
          (e < s && a(),
            e > s && se(o, e - s, -1),
            se(o, r - e, h),
            re(n, o, d),
            (s = r));
        }
      })(e),
      a(!r),
      r
    );
  }
  static empty(e) {
    return new ne(e ? [e, -1] : [], []);
  }
  static fromJSON(e) {
    if (!Array.isArray(e))
      throw new RangeError("Invalid JSON representation of ChangeSet");
    let t = [],
      i = [];
    for (let o = 0; o < e.length; o++) {
      let n = e[o];
      if ("number" == typeof n) t.push(n, -1);
      else {
        if (
          !Array.isArray(n) ||
          "number" != typeof n[0] ||
          n.some((e, t) => t && "string" != typeof e)
        )
          throw new RangeError("Invalid JSON representation of ChangeSet");
        if (1 == n.length) t.push(n[0], 0);
        else {
          for (; i.length < o; ) i.push($.empty);
          ((i[o] = $.of(n.slice(1))), t.push(n[0], i[o].length));
        }
      }
    }
    return new ne(t, i);
  }
  static createSet(e, t) {
    return new ne(e, t);
  }
}
function se(e, t, i, o = !1) {
  if (0 == t && i <= 0) return;
  let n = e.length - 2;
  n >= 0 && i <= 0 && i == e[n + 1]
    ? (e[n] += t)
    : n >= 0 && 0 == t && 0 == e[n]
      ? (e[n + 1] += i)
      : o
        ? ((e[n] += t), (e[n + 1] += i))
        : e.push(t, i);
}
function re(e, t, i) {
  if (0 == i.length) return;
  let o = (t.length - 2) >> 1;
  if (o < e.length) e[e.length - 1] = e[e.length - 1].append(i);
  else {
    for (; e.length < o; ) e.push($.empty);
    e.push(i);
  }
}
function ae(e, t, i) {
  let o = e.inserted;
  for (let n = 0, s = 0, r = 0; r < e.sections.length; ) {
    let a = e.sections[r++],
      l = e.sections[r++];
    if (l < 0) ((n += a), (s += a));
    else {
      let c = n,
        d = s,
        h = $.empty;
      for (
        ;
        (c += a),
          (d += l),
          l && o && (h = h.append(o[(r - 2) >> 1])),
          !(i || r == e.sections.length || e.sections[r + 1] < 0);
      )
        ((a = e.sections[r++]), (l = e.sections[r++]));
      (t(n, c, s, d, h), (n = c), (s = d));
    }
  }
}
function le(e, t, i, o = !1) {
  let n = [],
    s = o ? [] : null,
    r = new de(e),
    a = new de(t);
  for (let e = -1; ; ) {
    if ((r.done && a.len) || (a.done && r.len))
      throw new Error("Mismatched change set lengths");
    if (-1 == r.ins && -1 == a.ins) {
      let e = Math.min(r.len, a.len);
      (se(n, e, -1), r.forward(e), a.forward(e));
    } else if (
      a.ins >= 0 &&
      (r.ins < 0 ||
        e == r.i ||
        (0 == r.off && (a.len < r.len || (a.len == r.len && !i))))
    ) {
      let t = a.len;
      for (se(n, a.ins, -1); t; ) {
        let i = Math.min(r.len, t);
        (r.ins >= 0 &&
          e < r.i &&
          r.len <= i &&
          (se(n, 0, r.ins), s && re(s, n, r.text), (e = r.i)),
          r.forward(i),
          (t -= i));
      }
      a.next();
    } else {
      if (!(r.ins >= 0)) {
        if (r.done && a.done) return s ? ne.createSet(n, s) : oe.create(n);
        throw new Error("Mismatched change set lengths");
      }
      {
        let t = 0,
          i = r.len;
        for (; i; )
          if (-1 == a.ins) {
            let e = Math.min(i, a.len);
            ((t += e), (i -= e), a.forward(e));
          } else {
            if (!(0 == a.ins && a.len < i)) break;
            ((i -= a.len), a.next());
          }
        (se(n, t, e < r.i ? r.ins : 0),
          s && e < r.i && re(s, n, r.text),
          (e = r.i),
          r.forward(r.len - i));
      }
    }
  }
}
function ce(e, t, i = !1) {
  let o = [],
    n = i ? [] : null,
    s = new de(e),
    r = new de(t);
  for (let e = !1; ; ) {
    if (s.done && r.done) return n ? ne.createSet(o, n) : oe.create(o);
    if (0 == s.ins) (se(o, s.len, 0, e), s.next());
    else if (0 != r.len || r.done) {
      if (s.done || r.done) throw new Error("Mismatched change set lengths");
      {
        let t = Math.min(s.len2, r.len),
          i = o.length;
        if (-1 == s.ins) {
          let i = -1 == r.ins ? -1 : r.off ? 0 : r.ins;
          (se(o, t, i, e), n && i && re(n, o, r.text));
        } else
          -1 == r.ins
            ? (se(o, s.off ? 0 : s.len, t, e), n && re(n, o, s.textBit(t)))
            : (se(o, s.off ? 0 : s.len, r.off ? 0 : r.ins, e),
              n && !r.off && re(n, o, r.text));
        ((e = (s.ins > t || (r.ins >= 0 && r.len > t)) && (e || o.length > i)),
          s.forward2(t),
          r.forward(t));
      }
    } else (se(o, 0, r.ins, e), n && re(n, o, r.text), r.next());
  }
}
class de {
  constructor(e) {
    ((this.set = e), (this.i = 0), this.next());
  }
  next() {
    let { sections: e } = this.set;
    (this.i < e.length
      ? ((this.len = e[this.i++]), (this.ins = e[this.i++]))
      : ((this.len = 0), (this.ins = -2)),
      (this.off = 0));
  }
  get done() {
    return -2 == this.ins;
  }
  get len2() {
    return this.ins < 0 ? this.len : this.ins;
  }
  get text() {
    let { inserted: e } = this.set,
      t = (this.i - 2) >> 1;
    return t >= e.length ? $.empty : e[t];
  }
  textBit(e) {
    let { inserted: t } = this.set,
      i = (this.i - 2) >> 1;
    return i >= t.length && !e
      ? $.empty
      : t[i].slice(this.off, null == e ? void 0 : this.off + e);
  }
  forward(e) {
    e == this.len ? this.next() : ((this.len -= e), (this.off += e));
  }
  forward2(e) {
    -1 == this.ins
      ? this.forward(e)
      : e == this.ins
        ? this.next()
        : ((this.ins -= e), (this.off += e));
  }
}
class he {
  constructor(e, t, i) {
    ((this.from = e), (this.to = t), (this.flags = i));
  }
  get anchor() {
    return 32 & this.flags ? this.to : this.from;
  }
  get head() {
    return 32 & this.flags ? this.from : this.to;
  }
  get empty() {
    return this.from == this.to;
  }
  get assoc() {
    return 8 & this.flags ? -1 : 16 & this.flags ? 1 : 0;
  }
  get bidiLevel() {
    let e = 7 & this.flags;
    return 7 == e ? null : e;
  }
  get goalColumn() {
    let e = this.flags >> 6;
    return 16777215 == e ? void 0 : e;
  }
  map(e, t = -1) {
    let i, o;
    return (
      this.empty
        ? (i = o = e.mapPos(this.from, t))
        : ((i = e.mapPos(this.from, 1)), (o = e.mapPos(this.to, -1))),
      i == this.from && o == this.to ? this : new he(i, o, this.flags)
    );
  }
  extend(e, t = e) {
    if (e <= this.anchor && t >= this.anchor) return ue.range(e, t);
    let i = Math.abs(e - this.anchor) > Math.abs(t - this.anchor) ? e : t;
    return ue.range(this.anchor, i);
  }
  eq(e, t = !1) {
    return !(
      this.anchor != e.anchor ||
      this.head != e.head ||
      this.goalColumn != e.goalColumn ||
      (t && this.empty && this.assoc != e.assoc)
    );
  }
  toJSON() {
    return { anchor: this.anchor, head: this.head };
  }
  static fromJSON(e) {
    if (!e || "number" != typeof e.anchor || "number" != typeof e.head)
      throw new RangeError("Invalid JSON representation for SelectionRange");
    return ue.range(e.anchor, e.head);
  }
  static create(e, t, i) {
    return new he(e, t, i);
  }
}
class ue {
  constructor(e, t) {
    ((this.ranges = e), (this.mainIndex = t));
  }
  map(e, t = -1) {
    return e.empty
      ? this
      : ue.create(
          this.ranges.map((i) => i.map(e, t)),
          this.mainIndex,
        );
  }
  eq(e, t = !1) {
    if (this.ranges.length != e.ranges.length || this.mainIndex != e.mainIndex)
      return !1;
    for (let i = 0; i < this.ranges.length; i++)
      if (!this.ranges[i].eq(e.ranges[i], t)) return !1;
    return !0;
  }
  get main() {
    return this.ranges[this.mainIndex];
  }
  asSingle() {
    return 1 == this.ranges.length ? this : new ue([this.main], 0);
  }
  addRange(e, t = !0) {
    return ue.create([e].concat(this.ranges), t ? 0 : this.mainIndex + 1);
  }
  replaceRange(e, t = this.mainIndex) {
    let i = this.ranges.slice();
    return ((i[t] = e), ue.create(i, this.mainIndex));
  }
  toJSON() {
    return { ranges: this.ranges.map((e) => e.toJSON()), main: this.mainIndex };
  }
  static fromJSON(e) {
    if (
      !e ||
      !Array.isArray(e.ranges) ||
      "number" != typeof e.main ||
      e.main >= e.ranges.length
    )
      throw new RangeError("Invalid JSON representation for EditorSelection");
    return new ue(
      e.ranges.map((e) => he.fromJSON(e)),
      e.main,
    );
  }
  static single(e, t = e) {
    return new ue([ue.range(e, t)], 0);
  }
  static create(e, t = 0) {
    if (0 == e.length)
      throw new RangeError("A selection needs at least one range");
    for (let i = 0, o = 0; o < e.length; o++) {
      let n = e[o];
      if (n.empty ? n.from <= i : n.from < i)
        return ue.normalized(e.slice(), t);
      i = n.to;
    }
    return new ue(e, t);
  }
  static cursor(e, t = 0, i, o) {
    return he.create(
      e,
      e,
      (0 == t ? 0 : t < 0 ? 8 : 16) |
        (null == i ? 7 : Math.min(6, i)) |
        ((null != o ? o : 16777215) << 6),
    );
  }
  static range(e, t, i, o) {
    let n =
      ((null != i ? i : 16777215) << 6) | (null == o ? 7 : Math.min(6, o));
    return t < e
      ? he.create(t, e, 48 | n)
      : he.create(e, t, (t > e ? 8 : 0) | n);
  }
  static normalized(e, t = 0) {
    let i = e[t];
    (e.sort((e, t) => e.from - t.from), (t = e.indexOf(i)));
    for (let i = 1; i < e.length; i++) {
      let o = e[i],
        n = e[i - 1];
      if (o.empty ? o.from <= n.to : o.from < n.to) {
        let s = n.from,
          r = Math.max(o.to, n.to);
        (i <= t && t--,
          e.splice(
            --i,
            2,
            o.anchor > o.head ? ue.range(r, s) : ue.range(s, r),
          ));
      }
    }
    return new ue(e, t);
  }
}
function pe(e, t) {
  for (let i of e.ranges)
    if (i.to > t) throw new RangeError("Selection points outside of document");
}
let me = 0;
class ge {
  constructor(e, t, i, o, n) {
    ((this.combine = e),
      (this.compareInput = t),
      (this.compare = i),
      (this.isStatic = o),
      (this.id = me++),
      (this.default = e([])),
      (this.extensions = "function" == typeof n ? n(this) : n));
  }
  get reader() {
    return this;
  }
  static define(e = {}) {
    return new ge(
      e.combine || ((e) => e),
      e.compareInput || ((e, t) => e === t),
      e.compare || (e.combine ? (e, t) => e === t : fe),
      !!e.static,
      e.enables,
    );
  }
  of(e) {
    return new be([], this, 0, e);
  }
  compute(e, t) {
    if (this.isStatic) throw new Error("Can't compute a static facet");
    return new be(e, this, 1, t);
  }
  computeN(e, t) {
    if (this.isStatic) throw new Error("Can't compute a static facet");
    return new be(e, this, 2, t);
  }
  from(e, t) {
    return (t || (t = (e) => e), this.compute([e], (i) => t(i.field(e))));
  }
}
function fe(e, t) {
  return e == t || (e.length == t.length && e.every((e, i) => e === t[i]));
}
class be {
  constructor(e, t, i, o) {
    ((this.dependencies = e),
      (this.facet = t),
      (this.type = i),
      (this.value = o),
      (this.id = me++));
  }
  dynamicSlot(e) {
    var t;
    let i = this.value,
      o = this.facet.compareInput,
      n = this.id,
      s = e[n] >> 1,
      r = 2 == this.type,
      a = !1,
      l = !1,
      c = [];
    for (let i of this.dependencies)
      "doc" == i
        ? (a = !0)
        : "selection" == i
          ? (l = !0)
          : 1 & (null !== (t = e[i.id]) && void 0 !== t ? t : 1) ||
            c.push(e[i.id]);
    return {
      create: (e) => ((e.values[s] = i(e)), 1),
      update(e, t) {
        if (
          (a && t.docChanged) ||
          (l && (t.docChanged || t.selection)) ||
          we(e, c)
        ) {
          let t = i(e);
          if (r ? !ye(t, e.values[s], o) : !o(t, e.values[s]))
            return ((e.values[s] = t), 1);
        }
        return 0;
      },
      reconfigure: (e, t) => {
        let a,
          l = t.config.address[n];
        if (null != l) {
          let n = Pe(t, l);
          if (
            this.dependencies.every((i) =>
              i instanceof ge
                ? t.facet(i) === e.facet(i)
                : !(i instanceof xe) || t.field(i, !1) == e.field(i, !1),
            ) ||
            (r ? ye((a = i(e)), n, o) : o((a = i(e)), n))
          )
            return ((e.values[s] = n), 0);
        } else a = i(e);
        return ((e.values[s] = a), 1);
      },
    };
  }
}
function ye(e, t, i) {
  if (e.length != t.length) return !1;
  for (let o = 0; o < e.length; o++) if (!i(e[o], t[o])) return !1;
  return !0;
}
function we(e, t) {
  let i = !1;
  for (let o of t) 1 & Le(e, o) && (i = !0);
  return i;
}
function ve(e, t, i) {
  let o = i.map((t) => e[t.id]),
    n = i.map((e) => e.type),
    s = o.filter((e) => !(1 & e)),
    r = e[t.id] >> 1;
  function a(e) {
    let i = [];
    for (let t = 0; t < o.length; t++) {
      let s = Pe(e, o[t]);
      if (2 == n[t]) for (let e of s) i.push(e);
      else i.push(s);
    }
    return t.combine(i);
  }
  return {
    create(e) {
      for (let t of o) Le(e, t);
      return ((e.values[r] = a(e)), 1);
    },
    update(e, i) {
      if (!we(e, s)) return 0;
      let o = a(e);
      return t.compare(o, e.values[r]) ? 0 : ((e.values[r] = o), 1);
    },
    reconfigure(e, n) {
      let s = we(e, o),
        l = n.config.facets[t.id],
        c = n.facet(t);
      if (l && !s && fe(i, l)) return ((e.values[r] = c), 0);
      let d = a(e);
      return t.compare(d, c) ? ((e.values[r] = c), 0) : ((e.values[r] = d), 1);
    },
  };
}
const Ce = ge.define({ static: !0 });
class xe {
  constructor(e, t, i, o, n) {
    ((this.id = e),
      (this.createF = t),
      (this.updateF = i),
      (this.compareF = o),
      (this.spec = n),
      (this.provides = void 0));
  }
  static define(e) {
    let t = new xe(
      me++,
      e.create,
      e.update,
      e.compare || ((e, t) => e === t),
      e,
    );
    return (e.provide && (t.provides = e.provide(t)), t);
  }
  create(e) {
    let t = e.facet(Ce).find((e) => e.field == this);
    return ((null == t ? void 0 : t.create) || this.createF)(e);
  }
  slot(e) {
    let t = e[this.id] >> 1;
    return {
      create: (e) => ((e.values[t] = this.create(e)), 1),
      update: (e, i) => {
        let o = e.values[t],
          n = this.updateF(o, i);
        return this.compareF(o, n) ? 0 : ((e.values[t] = n), 1);
      },
      reconfigure: (e, i) => {
        let o,
          n = e.facet(Ce),
          s = i.facet(Ce);
        return (o = n.find((e) => e.field == this)) &&
          o != s.find((e) => e.field == this)
          ? ((e.values[t] = o.create(e)), 1)
          : null != i.config.address[this.id]
            ? ((e.values[t] = i.field(this)), 0)
            : ((e.values[t] = this.create(e)), 1);
      },
    };
  }
  init(e) {
    return [this, Ce.of({ field: this, create: e })];
  }
  get extension() {
    return this;
  }
}
const ke = 4,
  Se = 3,
  Te = 2,
  Ee = 1;
function Me(e) {
  return (t) => new Ie(t, e);
}
const Ae = {
  highest: Me(0),
  high: Me(Ee),
  default: Me(Te),
  low: Me(Se),
  lowest: Me(ke),
};
class Ie {
  constructor(e, t) {
    ((this.inner = e), (this.prec = t));
  }
}
class De {
  of(e) {
    return new Oe(this, e);
  }
  reconfigure(e) {
    return De.reconfigure.of({ compartment: this, extension: e });
  }
  get(e) {
    return e.config.compartments.get(this);
  }
}
class Oe {
  constructor(e, t) {
    ((this.compartment = e), (this.inner = t));
  }
}
class Be {
  constructor(e, t, i, o, n, s) {
    for (
      this.base = e,
        this.compartments = t,
        this.dynamicSlots = i,
        this.address = o,
        this.staticValues = n,
        this.facets = s,
        this.statusTemplate = [];
      this.statusTemplate.length < i.length;
    )
      this.statusTemplate.push(0);
  }
  staticFacet(e) {
    let t = this.address[e.id];
    return null == t ? e.default : this.staticValues[t >> 1];
  }
  static resolve(e, t, i) {
    let o = [],
      n = Object.create(null),
      s = new Map();
    for (let i of (function (e, t, i) {
      let o = [[], [], [], [], []],
        n = new Map();
      function s(e, r) {
        let a = n.get(e);
        if (null != a) {
          if (a <= r) return;
          let t = o[a].indexOf(e);
          (t > -1 && o[a].splice(t, 1),
            e instanceof Oe && i.delete(e.compartment));
        }
        if ((n.set(e, r), Array.isArray(e))) for (let t of e) s(t, r);
        else if (e instanceof Oe) {
          if (i.has(e.compartment))
            throw new RangeError("Duplicate use of compartment in extensions");
          let o = t.get(e.compartment) || e.inner;
          (i.set(e.compartment, o), s(o, r));
        } else if (e instanceof Ie) s(e.inner, e.prec);
        else if (e instanceof xe)
          (o[r].push(e), e.provides && s(e.provides, r));
        else if (e instanceof be)
          (o[r].push(e), e.facet.extensions && s(e.facet.extensions, Te));
        else {
          let t = e.extension;
          if (!t)
            throw new Error(
              `Unrecognized extension value in extension set (${e}). This sometimes happens because multiple instances of @codemirror/state are loaded, breaking instanceof checks.`,
            );
          s(t, r);
        }
      }
      return (s(e, Te), o.reduce((e, t) => e.concat(t)));
    })(e, t, s))
      i instanceof xe
        ? o.push(i)
        : (n[i.facet.id] || (n[i.facet.id] = [])).push(i);
    let r = Object.create(null),
      a = [],
      l = [];
    for (let e of o) ((r[e.id] = l.length << 1), l.push((t) => e.slot(t)));
    let c = null == i ? void 0 : i.config.facets;
    for (let e in n) {
      let t = n[e],
        o = t[0].facet,
        s = (c && c[e]) || [];
      if (t.every((e) => 0 == e.type))
        if (((r[o.id] = (a.length << 1) | 1), fe(s, t))) a.push(i.facet(o));
        else {
          let e = o.combine(t.map((e) => e.value));
          a.push(i && o.compare(e, i.facet(o)) ? i.facet(o) : e);
        }
      else {
        for (let e of t)
          0 == e.type
            ? ((r[e.id] = (a.length << 1) | 1), a.push(e.value))
            : ((r[e.id] = l.length << 1), l.push((t) => e.dynamicSlot(t)));
        ((r[o.id] = l.length << 1), l.push((e) => ve(e, o, t)));
      }
    }
    let d = l.map((e) => e(r));
    return new Be(e, s, d, r, a, n);
  }
}
function Le(e, t) {
  if (1 & t) return 2;
  let i = t >> 1,
    o = e.status[i];
  if (4 == o) throw new Error("Cyclic dependency between fields and/or facets");
  if (2 & o) return o;
  e.status[i] = 4;
  let n = e.computeSlot(e, e.config.dynamicSlots[i]);
  return (e.status[i] = 2 | n);
}
function Pe(e, t) {
  return 1 & t ? e.config.staticValues[t >> 1] : e.values[t >> 1];
}
const Ne = ge.define(),
  Re = ge.define({ combine: (e) => e.some((e) => e), static: !0 }),
  Fe = ge.define({ combine: (e) => (e.length ? e[0] : void 0), static: !0 }),
  qe = ge.define(),
  _e = ge.define(),
  ze = ge.define(),
  Ve = ge.define({ combine: (e) => !!e.length && e[0] });
class We {
  constructor(e, t) {
    ((this.type = e), (this.value = t));
  }
  static define() {
    return new He();
  }
}
class He {
  of(e) {
    return new We(this, e);
  }
}
class $e {
  constructor(e) {
    this.map = e;
  }
  of(e) {
    return new Ue(this, e);
  }
}
class Ue {
  constructor(e, t) {
    ((this.type = e), (this.value = t));
  }
  map(e) {
    let t = this.type.map(this.value, e);
    return void 0 === t
      ? void 0
      : t == this.value
        ? this
        : new Ue(this.type, t);
  }
  is(e) {
    return this.type == e;
  }
  static define(e = {}) {
    return new $e(e.map || ((e) => e));
  }
  static mapEffects(e, t) {
    if (!e.length) return e;
    let i = [];
    for (let o of e) {
      let e = o.map(t);
      e && i.push(e);
    }
    return i;
  }
}
((Ue.reconfigure = Ue.define()), (Ue.appendConfig = Ue.define()));
class je {
  constructor(e, t, i, o, n, s) {
    ((this.startState = e),
      (this.changes = t),
      (this.selection = i),
      (this.effects = o),
      (this.annotations = n),
      (this.scrollIntoView = s),
      (this._doc = null),
      (this._state = null),
      i && pe(i, t.newLength),
      n.some((e) => e.type == je.time) ||
        (this.annotations = n.concat(je.time.of(Date.now()))));
  }
  static create(e, t, i, o, n, s) {
    return new je(e, t, i, o, n, s);
  }
  get newDoc() {
    return this._doc || (this._doc = this.changes.apply(this.startState.doc));
  }
  get newSelection() {
    return this.selection || this.startState.selection.map(this.changes);
  }
  get state() {
    return (this._state || this.startState.applyTransaction(this), this._state);
  }
  annotation(e) {
    for (let t of this.annotations) if (t.type == e) return t.value;
  }
  get docChanged() {
    return !this.changes.empty;
  }
  get reconfigured() {
    return this.startState.config != this.state.config;
  }
  isUserEvent(e) {
    let t = this.annotation(je.userEvent);
    return !(
      !t ||
      !(
        t == e ||
        (t.length > e.length && t.slice(0, e.length) == e && "." == t[e.length])
      )
    );
  }
}
function Ye(e, t) {
  let i = [];
  for (let o = 0, n = 0; ; ) {
    let s, r;
    if (o < e.length && (n == t.length || t[n] >= e[o]))
      ((s = e[o++]), (r = e[o++]));
    else {
      if (!(n < t.length)) return i;
      ((s = t[n++]), (r = t[n++]));
    }
    !i.length || i[i.length - 1] < s
      ? i.push(s, r)
      : i[i.length - 1] < r && (i[i.length - 1] = r);
  }
}
function Ge(e, t, i) {
  var o;
  let n, s, r;
  return (
    i
      ? ((n = t.changes),
        (s = ne.empty(t.changes.length)),
        (r = e.changes.compose(t.changes)))
      : ((n = t.changes.map(e.changes)),
        (s = e.changes.mapDesc(t.changes, !0)),
        (r = e.changes.compose(n))),
    {
      changes: r,
      selection: t.selection
        ? t.selection.map(s)
        : null === (o = e.selection) || void 0 === o
          ? void 0
          : o.map(n),
      effects: Ue.mapEffects(e.effects, n).concat(Ue.mapEffects(t.effects, s)),
      annotations: e.annotations.length
        ? e.annotations.concat(t.annotations)
        : t.annotations,
      scrollIntoView: e.scrollIntoView || t.scrollIntoView,
    }
  );
}
function Ze(e, t, i) {
  let o = t.selection,
    n = Xe(t.annotations);
  return (
    t.userEvent && (n = n.concat(je.userEvent.of(t.userEvent))),
    {
      changes:
        t.changes instanceof ne
          ? t.changes
          : ne.of(t.changes || [], i, e.facet(Fe)),
      selection: o && (o instanceof ue ? o : ue.single(o.anchor, o.head)),
      effects: Xe(t.effects),
      annotations: n,
      scrollIntoView: !!t.scrollIntoView,
    }
  );
}
function Ke(e, t, i) {
  let o = Ze(e, t.length ? t[0] : {}, e.doc.length);
  t.length && !1 === t[0].filter && (i = !1);
  for (let n = 1; n < t.length; n++) {
    !1 === t[n].filter && (i = !1);
    let s = !!t[n].sequential;
    o = Ge(o, Ze(e, t[n], s ? o.changes.newLength : e.doc.length), s);
  }
  let n = je.create(
    e,
    o.changes,
    o.selection,
    o.effects,
    o.annotations,
    o.scrollIntoView,
  );
  return (function (e) {
    let t = e.startState,
      i = t.facet(ze),
      o = e;
    for (let n = i.length - 1; n >= 0; n--) {
      let s = i[n](e);
      s &&
        Object.keys(s).length &&
        (o = Ge(o, Ze(t, s, e.changes.newLength), !0));
    }
    return o == e
      ? e
      : je.create(
          t,
          e.changes,
          e.selection,
          o.effects,
          o.annotations,
          o.scrollIntoView,
        );
  })(
    i
      ? (function (e) {
          let t = e.startState,
            i = !0;
          for (let o of t.facet(qe)) {
            let t = o(e);
            if (!1 === t) {
              i = !1;
              break;
            }
            Array.isArray(t) && (i = !0 === i ? t : Ye(i, t));
          }
          if (!0 !== i) {
            let o, n;
            if (!1 === i)
              ((n = e.changes.invertedDesc), (o = ne.empty(t.doc.length)));
            else {
              let t = e.changes.filter(i);
              ((o = t.changes),
                (n = t.filtered.mapDesc(t.changes).invertedDesc));
            }
            e = je.create(
              t,
              o,
              e.selection && e.selection.map(n),
              Ue.mapEffects(e.effects, n),
              e.annotations,
              e.scrollIntoView,
            );
          }
          let o = t.facet(_e);
          for (let i = o.length - 1; i >= 0; i--) {
            let n = o[i](e);
            e =
              n instanceof je
                ? n
                : Array.isArray(n) && 1 == n.length && n[0] instanceof je
                  ? n[0]
                  : Ke(t, Xe(n), !1);
          }
          return e;
        })(n)
      : n,
  );
}
((je.time = We.define()),
  (je.userEvent = We.define()),
  (je.addToHistory = We.define()),
  (je.remote = We.define()));
const Je = [];
function Xe(e) {
  return null == e ? Je : Array.isArray(e) ? e : [e];
}
var Qe = (function (e) {
  return (
    (e[(e.Word = 0)] = "Word"),
    (e[(e.Space = 1)] = "Space"),
    (e[(e.Other = 2)] = "Other"),
    e
  );
})(Qe || (Qe = {}));
const et =
  /[\u00df\u0587\u0590-\u05f4\u0600-\u06ff\u3040-\u309f\u30a0-\u30ff\u3400-\u4db5\u4e00-\u9fcc\uac00-\ud7af]/;
let tt;
try {
  tt = new RegExp("[\\p{Alphabetic}\\p{Number}_]", "u");
} catch (e) {}
function it(e) {
  return (t) => {
    if (!/\S/.test(t)) return Qe.Space;
    if (
      (function (e) {
        if (tt) return tt.test(e);
        for (let t = 0; t < e.length; t++) {
          let i = e[t];
          if (
            /\w/.test(i) ||
            (i > "" && (i.toUpperCase() != i.toLowerCase() || et.test(i)))
          )
            return !0;
        }
        return !1;
      })(t)
    )
      return Qe.Word;
    for (let i = 0; i < e.length; i++) if (t.indexOf(e[i]) > -1) return Qe.Word;
    return Qe.Other;
  };
}
class ot {
  constructor(e, t, i, o, n, s) {
    ((this.config = e),
      (this.doc = t),
      (this.selection = i),
      (this.values = o),
      (this.status = e.statusTemplate.slice()),
      (this.computeSlot = n),
      s && (s._state = this));
    for (let e = 0; e < this.config.dynamicSlots.length; e++) Le(this, e << 1);
    this.computeSlot = null;
  }
  field(e, t = !0) {
    let i = this.config.address[e.id];
    if (null != i) return (Le(this, i), Pe(this, i));
    if (t) throw new RangeError("Field is not present in this state");
  }
  update(...e) {
    return Ke(this, e, !0);
  }
  applyTransaction(e) {
    let t,
      i = this.config,
      { base: o, compartments: n } = i;
    for (let t of e.effects)
      t.is(De.reconfigure)
        ? (i &&
            ((n = new Map()),
            i.compartments.forEach((e, t) => n.set(t, e)),
            (i = null)),
          n.set(t.value.compartment, t.value.extension))
        : t.is(Ue.reconfigure)
          ? ((i = null), (o = t.value))
          : t.is(Ue.appendConfig) && ((i = null), (o = Xe(o).concat(t.value)));
    if (i) t = e.startState.values.slice();
    else {
      ((i = Be.resolve(o, n, this)),
        (t = new ot(
          i,
          this.doc,
          this.selection,
          i.dynamicSlots.map(() => null),
          (e, t) => t.reconfigure(e, this),
          null,
        ).values));
    }
    let s = e.startState.facet(Re) ? e.newSelection : e.newSelection.asSingle();
    new ot(i, e.newDoc, s, t, (t, i) => i.update(t, e), e);
  }
  replaceSelection(e) {
    return (
      "string" == typeof e && (e = this.toText(e)),
      this.changeByRange((t) => ({
        changes: { from: t.from, to: t.to, insert: e },
        range: ue.cursor(t.from + e.length),
      }))
    );
  }
  changeByRange(e) {
    let t = this.selection,
      i = e(t.ranges[0]),
      o = this.changes(i.changes),
      n = [i.range],
      s = Xe(i.effects);
    for (let i = 1; i < t.ranges.length; i++) {
      let r = e(t.ranges[i]),
        a = this.changes(r.changes),
        l = a.map(o);
      for (let e = 0; e < i; e++) n[e] = n[e].map(l);
      let c = o.mapDesc(a, !0);
      (n.push(r.range.map(c)),
        (o = o.compose(l)),
        (s = Ue.mapEffects(s, l).concat(Ue.mapEffects(Xe(r.effects), c))));
    }
    return { changes: o, selection: ue.create(n, t.mainIndex), effects: s };
  }
  changes(e = []) {
    return e instanceof ne
      ? e
      : ne.of(e, this.doc.length, this.facet(ot.lineSeparator));
  }
  toText(e) {
    return $.of(e.split(this.facet(ot.lineSeparator) || te));
  }
  sliceDoc(e = 0, t = this.doc.length) {
    return this.doc.sliceString(e, t, this.lineBreak);
  }
  facet(e) {
    let t = this.config.address[e.id];
    return null == t ? e.default : (Le(this, t), Pe(this, t));
  }
  toJSON(e) {
    let t = { doc: this.sliceDoc(), selection: this.selection.toJSON() };
    if (e)
      for (let i in e) {
        let o = e[i];
        o instanceof xe &&
          null != this.config.address[o.id] &&
          (t[i] = o.spec.toJSON(this.field(e[i]), this));
      }
    return t;
  }
  static fromJSON(e, t = {}, i) {
    if (!e || "string" != typeof e.doc)
      throw new RangeError("Invalid JSON representation for EditorState");
    let o = [];
    if (i)
      for (let t in i)
        if (Object.prototype.hasOwnProperty.call(e, t)) {
          let n = i[t],
            s = e[t];
          o.push(n.init((e) => n.spec.fromJSON(s, e)));
        }
    return ot.create({
      doc: e.doc,
      selection: ue.fromJSON(e.selection),
      extensions: t.extensions ? o.concat([t.extensions]) : o,
    });
  }
  static create(e = {}) {
    let t = Be.resolve(e.extensions || [], new Map()),
      i =
        e.doc instanceof $
          ? e.doc
          : $.of((e.doc || "").split(t.staticFacet(ot.lineSeparator) || te)),
      o = e.selection
        ? e.selection instanceof ue
          ? e.selection
          : ue.single(e.selection.anchor, e.selection.head)
        : ue.single(0);
    return (
      pe(o, i.length),
      t.staticFacet(Re) || (o = o.asSingle()),
      new ot(
        t,
        i,
        o,
        t.dynamicSlots.map(() => null),
        (e, t) => t.create(e),
        null,
      )
    );
  }
  get tabSize() {
    return this.facet(ot.tabSize);
  }
  get lineBreak() {
    return this.facet(ot.lineSeparator) || "\n";
  }
  get readOnly() {
    return this.facet(Ve);
  }
  phrase(e, ...t) {
    for (let t of this.facet(ot.phrases))
      if (Object.prototype.hasOwnProperty.call(t, e)) {
        e = t[e];
        break;
      }
    return (
      t.length &&
        (e = e.replace(/\$(\$|\d*)/g, (e, i) => {
          if ("$" == i) return "$";
          let o = +(i || 1);
          return !o || o > t.length ? e : t[o - 1];
        })),
      e
    );
  }
  languageDataAt(e, t, i = -1) {
    let o = [];
    for (let n of this.facet(Ne))
      for (let s of n(this, t, i))
        Object.prototype.hasOwnProperty.call(s, e) && o.push(s[e]);
    return o;
  }
  charCategorizer(e) {
    let t = this.languageDataAt("wordChars", e);
    return it(t.length ? t[0] : "");
  }
  wordAt(e) {
    let { text: t, from: i, length: o } = this.doc.lineAt(e),
      n = this.charCategorizer(e),
      s = e - i,
      r = e - i;
    for (; s > 0; ) {
      let e = ee(t, s, !1);
      if (n(t.slice(e, s)) != Qe.Word) break;
      s = e;
    }
    for (; r < o; ) {
      let e = ee(t, r);
      if (n(t.slice(r, e)) != Qe.Word) break;
      r = e;
    }
    return s == r ? null : ue.range(s + i, r + i);
  }
}
((ot.allowMultipleSelections = Re),
  (ot.tabSize = ge.define({ combine: (e) => (e.length ? e[0] : 4) })),
  (ot.lineSeparator = Fe),
  (ot.readOnly = Ve),
  (ot.phrases = ge.define({
    compare(e, t) {
      let i = Object.keys(e),
        o = Object.keys(t);
      return i.length == o.length && i.every((i) => e[i] == t[i]);
    },
  })),
  (ot.languageData = Ne),
  (ot.changeFilter = qe),
  (ot.transactionFilter = _e),
  (ot.transactionExtender = ze),
  (De.reconfigure = Ue.define()));
class nt {
  eq(e) {
    return this == e;
  }
  range(e, t = e) {
    return rt.create(e, t, this);
  }
}
function st(e, t) {
  return e == t || (e.constructor == t.constructor && e.eq(t));
}
((nt.prototype.startSide = nt.prototype.endSide = 0),
  (nt.prototype.point = !1),
  (nt.prototype.mapMode = ie.TrackDel));
class rt {
  constructor(e, t, i) {
    ((this.from = e), (this.to = t), (this.value = i));
  }
  static create(e, t, i) {
    return new rt(e, t, i);
  }
}
function at(e, t) {
  return e.from - t.from || e.value.startSide - t.value.startSide;
}
class lt {
  constructor(e, t, i, o) {
    ((this.from = e), (this.to = t), (this.value = i), (this.maxPoint = o));
  }
  get length() {
    return this.to[this.to.length - 1];
  }
  findIndex(e, t, i, o = 0) {
    let n = i ? this.to : this.from;
    for (let s = o, r = n.length; ; ) {
      if (s == r) return s;
      let o = (s + r) >> 1,
        a =
          n[o] - e || (i ? this.value[o].endSide : this.value[o].startSide) - t;
      if (o == s) return a >= 0 ? s : r;
      a >= 0 ? (r = o) : (s = o + 1);
    }
  }
  between(e, t, i, o) {
    for (
      let n = this.findIndex(t, -1e9, !0), s = this.findIndex(i, 1e9, !1, n);
      n < s;
      n++
    )
      if (!1 === o(this.from[n] + e, this.to[n] + e, this.value[n])) return !1;
  }
  map(e, t) {
    let i = [],
      o = [],
      n = [],
      s = -1,
      r = -1;
    for (let a = 0; a < this.value.length; a++) {
      let l,
        c,
        d = this.value[a],
        h = this.from[a] + e,
        u = this.to[a] + e;
      if (h == u) {
        let e = t.mapPos(h, d.startSide, d.mapMode);
        if (null == e) continue;
        if (
          ((l = c = e),
          d.startSide != d.endSide && ((c = t.mapPos(h, d.endSide)), c < l))
        )
          continue;
      } else if (
        ((l = t.mapPos(h, d.startSide)),
        (c = t.mapPos(u, d.endSide)),
        l > c || (l == c && d.startSide > 0 && d.endSide <= 0))
      )
        continue;
      (c - l || d.endSide - d.startSide) < 0 ||
        (s < 0 && (s = l),
        d.point && (r = Math.max(r, c - l)),
        i.push(d),
        o.push(l - s),
        n.push(c - s));
    }
    return { mapped: i.length ? new lt(o, n, i, r) : null, pos: s };
  }
}
class ct {
  constructor(e, t, i, o) {
    ((this.chunkPos = e),
      (this.chunk = t),
      (this.nextLayer = i),
      (this.maxPoint = o));
  }
  static create(e, t, i, o) {
    return new ct(e, t, i, o);
  }
  get length() {
    let e = this.chunk.length - 1;
    return e < 0 ? 0 : Math.max(this.chunkEnd(e), this.nextLayer.length);
  }
  get size() {
    if (this.isEmpty) return 0;
    let e = this.nextLayer.size;
    for (let t of this.chunk) e += t.value.length;
    return e;
  }
  chunkEnd(e) {
    return this.chunkPos[e] + this.chunk[e].length;
  }
  update(e) {
    let {
        add: t = [],
        sort: i = !1,
        filterFrom: o = 0,
        filterTo: n = this.length,
      } = e,
      s = e.filter;
    if (0 == t.length && !s) return this;
    if ((i && (t = t.slice().sort(at)), this.isEmpty))
      return t.length ? ct.of(t) : this;
    let r = new ut(this, null, -1).goto(0),
      a = 0,
      l = [],
      c = new dt();
    for (; r.value || a < t.length; )
      if (
        a < t.length &&
        (r.from - t[a].from || r.startSide - t[a].value.startSide) >= 0
      ) {
        let e = t[a++];
        c.addInner(e.from, e.to, e.value) || l.push(e);
      } else
        1 == r.rangeIndex &&
        r.chunkIndex < this.chunk.length &&
        (a == t.length || this.chunkEnd(r.chunkIndex) < t[a].from) &&
        (!s ||
          o > this.chunkEnd(r.chunkIndex) ||
          n < this.chunkPos[r.chunkIndex]) &&
        c.addChunk(this.chunkPos[r.chunkIndex], this.chunk[r.chunkIndex])
          ? r.nextChunk()
          : ((!s || o > r.to || n < r.from || s(r.from, r.to, r.value)) &&
              (c.addInner(r.from, r.to, r.value) ||
                l.push(rt.create(r.from, r.to, r.value))),
            r.next());
    return c.finishInner(
      this.nextLayer.isEmpty && !l.length
        ? ct.empty
        : this.nextLayer.update({
            add: l,
            filter: s,
            filterFrom: o,
            filterTo: n,
          }),
    );
  }
  map(e) {
    if (e.empty || this.isEmpty) return this;
    let t = [],
      i = [],
      o = -1;
    for (let n = 0; n < this.chunk.length; n++) {
      let s = this.chunkPos[n],
        r = this.chunk[n],
        a = e.touchesRange(s, s + r.length);
      if (!1 === a)
        ((o = Math.max(o, r.maxPoint)), t.push(r), i.push(e.mapPos(s)));
      else if (!0 === a) {
        let { mapped: n, pos: a } = r.map(s, e);
        n && ((o = Math.max(o, n.maxPoint)), t.push(n), i.push(a));
      }
    }
    let n = this.nextLayer.map(e);
    return 0 == t.length ? n : new ct(i, t, n || ct.empty, o);
  }
  between(e, t, i) {
    if (!this.isEmpty) {
      for (let o = 0; o < this.chunk.length; o++) {
        let n = this.chunkPos[o],
          s = this.chunk[o];
        if (t >= n && e <= n + s.length && !1 === s.between(n, e - n, t - n, i))
          return;
      }
      this.nextLayer.between(e, t, i);
    }
  }
  iter(e = 0) {
    return pt.from([this]).goto(e);
  }
  get isEmpty() {
    return this.nextLayer == this;
  }
  static iter(e, t = 0) {
    return pt.from(e).goto(t);
  }
  static compare(e, t, i, o, n = -1) {
    let s = e.filter((e) => e.maxPoint > 0 || (!e.isEmpty && e.maxPoint >= n)),
      r = t.filter((e) => e.maxPoint > 0 || (!e.isEmpty && e.maxPoint >= n)),
      a = ht(s, r, i),
      l = new gt(s, a, n),
      c = new gt(r, a, n);
    (i.iterGaps((e, t, i) => ft(l, e, c, t, i, o)),
      i.empty && 0 == i.length && ft(l, 0, c, 0, 0, o));
  }
  static eq(e, t, i = 0, o) {
    null == o && (o = 999999999);
    let n = e.filter((e) => !e.isEmpty && t.indexOf(e) < 0),
      s = t.filter((t) => !t.isEmpty && e.indexOf(t) < 0);
    if (n.length != s.length) return !1;
    if (!n.length) return !0;
    let r = ht(n, s),
      a = new gt(n, r, 0).goto(i),
      l = new gt(s, r, 0).goto(i);
    for (;;) {
      if (
        a.to != l.to ||
        !bt(a.active, l.active) ||
        (a.point && (!l.point || !st(a.point, l.point)))
      )
        return !1;
      if (a.to > o) return !0;
      (a.next(), l.next());
    }
  }
  static spans(e, t, i, o, n = -1) {
    let s = new gt(e, null, n).goto(t),
      r = t,
      a = s.openStart;
    for (;;) {
      let e = Math.min(s.to, i);
      if (s.point) {
        let i = s.activeForPoint(s.to),
          n =
            s.pointFrom < t
              ? i.length + 1
              : s.point.startSide < 0
                ? i.length
                : Math.min(i.length, a);
        (o.point(r, e, s.point, i, n, s.pointRank),
          (a = Math.min(s.openEnd(e), i.length)));
      } else e > r && (o.span(r, e, s.active, a), (a = s.openEnd(e)));
      if (s.to > i) return a + (s.point && s.to > i ? 1 : 0);
      ((r = s.to), s.next());
    }
  }
  static of(e, t = !1) {
    let i = new dt();
    for (let o of e instanceof rt
      ? [e]
      : t
        ? (function (e) {
            if (e.length > 1)
              for (let t = e[0], i = 1; i < e.length; i++) {
                let o = e[i];
                if (at(t, o) > 0) return e.slice().sort(at);
                t = o;
              }
            return e;
          })(e)
        : e)
      i.add(o.from, o.to, o.value);
    return i.finish();
  }
  static join(e) {
    if (!e.length) return ct.empty;
    let t = e[e.length - 1];
    for (let i = e.length - 2; i >= 0; i--)
      for (let o = e[i]; o != ct.empty; o = o.nextLayer)
        t = new ct(o.chunkPos, o.chunk, t, Math.max(o.maxPoint, t.maxPoint));
    return t;
  }
}
((ct.empty = new ct([], [], null, -1)), (ct.empty.nextLayer = ct.empty));
class dt {
  finishChunk(e) {
    (this.chunks.push(new lt(this.from, this.to, this.value, this.maxPoint)),
      this.chunkPos.push(this.chunkStart),
      (this.chunkStart = -1),
      (this.setMaxPoint = Math.max(this.setMaxPoint, this.maxPoint)),
      (this.maxPoint = -1),
      e && ((this.from = []), (this.to = []), (this.value = [])));
  }
  constructor() {
    ((this.chunks = []),
      (this.chunkPos = []),
      (this.chunkStart = -1),
      (this.last = null),
      (this.lastFrom = -1e9),
      (this.lastTo = -1e9),
      (this.from = []),
      (this.to = []),
      (this.value = []),
      (this.maxPoint = -1),
      (this.setMaxPoint = -1),
      (this.nextLayer = null));
  }
  add(e, t, i) {
    this.addInner(e, t, i) ||
      (this.nextLayer || (this.nextLayer = new dt())).add(e, t, i);
  }
  addInner(e, t, i) {
    let o = e - this.lastTo || i.startSide - this.last.endSide;
    if (o <= 0 && (e - this.lastFrom || i.startSide - this.last.startSide) < 0)
      throw new Error(
        "Ranges must be added sorted by `from` position and `startSide`",
      );
    return (
      !(o < 0) &&
      (250 == this.from.length && this.finishChunk(!0),
      this.chunkStart < 0 && (this.chunkStart = e),
      this.from.push(e - this.chunkStart),
      this.to.push(t - this.chunkStart),
      (this.last = i),
      (this.lastFrom = e),
      (this.lastTo = t),
      this.value.push(i),
      i.point && (this.maxPoint = Math.max(this.maxPoint, t - e)),
      !0)
    );
  }
  addChunk(e, t) {
    if ((e - this.lastTo || t.value[0].startSide - this.last.endSide) < 0)
      return !1;
    (this.from.length && this.finishChunk(!0),
      (this.setMaxPoint = Math.max(this.setMaxPoint, t.maxPoint)),
      this.chunks.push(t),
      this.chunkPos.push(e));
    let i = t.value.length - 1;
    return (
      (this.last = t.value[i]),
      (this.lastFrom = t.from[i] + e),
      (this.lastTo = t.to[i] + e),
      !0
    );
  }
  finish() {
    return this.finishInner(ct.empty);
  }
  finishInner(e) {
    if ((this.from.length && this.finishChunk(!1), 0 == this.chunks.length))
      return e;
    let t = ct.create(
      this.chunkPos,
      this.chunks,
      this.nextLayer ? this.nextLayer.finishInner(e) : e,
      this.setMaxPoint,
    );
    return ((this.from = null), t);
  }
}
function ht(e, t, i) {
  let o = new Map();
  for (let t of e)
    for (let e = 0; e < t.chunk.length; e++)
      t.chunk[e].maxPoint <= 0 && o.set(t.chunk[e], t.chunkPos[e]);
  let n = new Set();
  for (let e of t)
    for (let t = 0; t < e.chunk.length; t++) {
      let s = o.get(e.chunk[t]);
      null == s ||
        (i ? i.mapPos(s) : s) != e.chunkPos[t] ||
        (null == i ? void 0 : i.touchesRange(s, s + e.chunk[t].length)) ||
        n.add(e.chunk[t]);
    }
  return n;
}
class ut {
  constructor(e, t, i, o = 0) {
    ((this.layer = e), (this.skip = t), (this.minPoint = i), (this.rank = o));
  }
  get startSide() {
    return this.value ? this.value.startSide : 0;
  }
  get endSide() {
    return this.value ? this.value.endSide : 0;
  }
  goto(e, t = -1e9) {
    return (
      (this.chunkIndex = this.rangeIndex = 0),
      this.gotoInner(e, t, !1),
      this
    );
  }
  gotoInner(e, t, i) {
    for (; this.chunkIndex < this.layer.chunk.length; ) {
      let t = this.layer.chunk[this.chunkIndex];
      if (
        !(
          (this.skip && this.skip.has(t)) ||
          this.layer.chunkEnd(this.chunkIndex) < e ||
          t.maxPoint < this.minPoint
        )
      )
        break;
      (this.chunkIndex++, (i = !1));
    }
    if (this.chunkIndex < this.layer.chunk.length) {
      let o = this.layer.chunk[this.chunkIndex].findIndex(
        e - this.layer.chunkPos[this.chunkIndex],
        t,
        !0,
      );
      (!i || this.rangeIndex < o) && this.setRangeIndex(o);
    }
    this.next();
  }
  forward(e, t) {
    (this.to - e || this.endSide - t) < 0 && this.gotoInner(e, t, !0);
  }
  next() {
    for (;;) {
      if (this.chunkIndex == this.layer.chunk.length) {
        ((this.from = this.to = 1e9), (this.value = null));
        break;
      }
      {
        let e = this.layer.chunkPos[this.chunkIndex],
          t = this.layer.chunk[this.chunkIndex],
          i = e + t.from[this.rangeIndex];
        if (
          ((this.from = i),
          (this.to = e + t.to[this.rangeIndex]),
          (this.value = t.value[this.rangeIndex]),
          this.setRangeIndex(this.rangeIndex + 1),
          this.minPoint < 0 ||
            (this.value.point && this.to - this.from >= this.minPoint))
        )
          break;
      }
    }
  }
  setRangeIndex(e) {
    if (e == this.layer.chunk[this.chunkIndex].value.length) {
      if ((this.chunkIndex++, this.skip))
        for (
          ;
          this.chunkIndex < this.layer.chunk.length &&
          this.skip.has(this.layer.chunk[this.chunkIndex]);
        )
          this.chunkIndex++;
      this.rangeIndex = 0;
    } else this.rangeIndex = e;
  }
  nextChunk() {
    (this.chunkIndex++, (this.rangeIndex = 0), this.next());
  }
  compare(e) {
    return (
      this.from - e.from ||
      this.startSide - e.startSide ||
      this.rank - e.rank ||
      this.to - e.to ||
      this.endSide - e.endSide
    );
  }
}
class pt {
  constructor(e) {
    this.heap = e;
  }
  static from(e, t = null, i = -1) {
    let o = [];
    for (let n = 0; n < e.length; n++)
      for (let s = e[n]; !s.isEmpty; s = s.nextLayer)
        s.maxPoint >= i && o.push(new ut(s, t, i, n));
    return 1 == o.length ? o[0] : new pt(o);
  }
  get startSide() {
    return this.value ? this.value.startSide : 0;
  }
  goto(e, t = -1e9) {
    for (let i of this.heap) i.goto(e, t);
    for (let e = this.heap.length >> 1; e >= 0; e--) mt(this.heap, e);
    return (this.next(), this);
  }
  forward(e, t) {
    for (let i of this.heap) i.forward(e, t);
    for (let e = this.heap.length >> 1; e >= 0; e--) mt(this.heap, e);
    (this.to - e || this.value.endSide - t) < 0 && this.next();
  }
  next() {
    if (0 == this.heap.length)
      ((this.from = this.to = 1e9), (this.value = null), (this.rank = -1));
    else {
      let e = this.heap[0];
      ((this.from = e.from),
        (this.to = e.to),
        (this.value = e.value),
        (this.rank = e.rank),
        e.value && e.next(),
        mt(this.heap, 0));
    }
  }
}
function mt(e, t) {
  for (let i = e[t]; ; ) {
    let o = 1 + (t << 1);
    if (o >= e.length) break;
    let n = e[o];
    if (
      (o + 1 < e.length && n.compare(e[o + 1]) >= 0 && ((n = e[o + 1]), o++),
      i.compare(n) < 0)
    )
      break;
    ((e[o] = i), (e[t] = n), (t = o));
  }
}
class gt {
  constructor(e, t, i) {
    ((this.minPoint = i),
      (this.active = []),
      (this.activeTo = []),
      (this.activeRank = []),
      (this.minActive = -1),
      (this.point = null),
      (this.pointFrom = 0),
      (this.pointRank = 0),
      (this.to = -1e9),
      (this.endSide = 0),
      (this.openStart = -1),
      (this.cursor = pt.from(e, t, i)));
  }
  goto(e, t = -1e9) {
    return (
      this.cursor.goto(e, t),
      (this.active.length = this.activeTo.length = this.activeRank.length = 0),
      (this.minActive = -1),
      (this.to = e),
      (this.endSide = t),
      (this.openStart = -1),
      this.next(),
      this
    );
  }
  forward(e, t) {
    for (
      ;
      this.minActive > -1 &&
      (this.activeTo[this.minActive] - e ||
        this.active[this.minActive].endSide - t) < 0;
    )
      this.removeActive(this.minActive);
    this.cursor.forward(e, t);
  }
  removeActive(e) {
    (yt(this.active, e),
      yt(this.activeTo, e),
      yt(this.activeRank, e),
      (this.minActive = vt(this.active, this.activeTo)));
  }
  addActive(e) {
    let t = 0,
      { value: i, to: o, rank: n } = this.cursor;
    for (
      ;
      t < this.activeRank.length &&
      (n - this.activeRank[t] || o - this.activeTo[t]) > 0;
    )
      t++;
    (wt(this.active, t, i),
      wt(this.activeTo, t, o),
      wt(this.activeRank, t, n),
      e && wt(e, t, this.cursor.from),
      (this.minActive = vt(this.active, this.activeTo)));
  }
  next() {
    let e = this.to,
      t = this.point;
    this.point = null;
    let i = this.openStart < 0 ? [] : null;
    for (;;) {
      let o = this.minActive;
      if (
        o > -1 &&
        (this.activeTo[o] - this.cursor.from ||
          this.active[o].endSide - this.cursor.startSide) < 0
      ) {
        if (this.activeTo[o] > e) {
          ((this.to = this.activeTo[o]),
            (this.endSide = this.active[o].endSide));
          break;
        }
        (this.removeActive(o), i && yt(i, o));
      } else {
        if (!this.cursor.value) {
          this.to = this.endSide = 1e9;
          break;
        }
        if (this.cursor.from > e) {
          ((this.to = this.cursor.from),
            (this.endSide = this.cursor.startSide));
          break;
        }
        {
          let e = this.cursor.value;
          if (e.point) {
            if (
              !(
                t &&
                this.cursor.to == this.to &&
                this.cursor.from < this.cursor.to
              )
            ) {
              ((this.point = e),
                (this.pointFrom = this.cursor.from),
                (this.pointRank = this.cursor.rank),
                (this.to = this.cursor.to),
                (this.endSide = e.endSide),
                this.cursor.next(),
                this.forward(this.to, this.endSide));
              break;
            }
            this.cursor.next();
          } else (this.addActive(i), this.cursor.next());
        }
      }
    }
    if (i) {
      this.openStart = 0;
      for (let t = i.length - 1; t >= 0 && i[t] < e; t--) this.openStart++;
    }
  }
  activeForPoint(e) {
    if (!this.active.length) return this.active;
    let t = [];
    for (
      let i = this.active.length - 1;
      i >= 0 && !(this.activeRank[i] < this.pointRank);
      i--
    )
      (this.activeTo[i] > e ||
        (this.activeTo[i] == e &&
          this.active[i].endSide >= this.point.endSide)) &&
        t.push(this.active[i]);
    return t.reverse();
  }
  openEnd(e) {
    let t = 0;
    for (let i = this.activeTo.length - 1; i >= 0 && this.activeTo[i] > e; i--)
      t++;
    return t;
  }
}
function ft(e, t, i, o, n, s) {
  (e.goto(t), i.goto(o));
  let r = o + n,
    a = o,
    l = o - t,
    c = !!s.boundChange;
  for (let t = !1; ; ) {
    let o = e.to + l - i.to,
      n = o || e.endSide - i.endSide,
      d = n < 0 ? e.to + l : i.to,
      h = Math.min(d, r);
    if (
      (e.point || i.point
        ? ((e.point &&
            i.point &&
            st(e.point, i.point) &&
            bt(e.activeForPoint(e.to), i.activeForPoint(i.to))) ||
            s.comparePoint(a, h, e.point, i.point),
          (t = !1))
        : (t && s.boundChange(a),
          h > a &&
            !bt(e.active, i.active) &&
            s.compareRange(a, h, e.active, i.active),
          c && h < r && (o || e.openEnd(d) != i.openEnd(d)) && (t = !0)),
      d > r)
    )
      break;
    ((a = d), n <= 0 && e.next(), n >= 0 && i.next());
  }
}
function bt(e, t) {
  if (e.length != t.length) return !1;
  for (let i = 0; i < e.length; i++)
    if (e[i] != t[i] && !st(e[i], t[i])) return !1;
  return !0;
}
function yt(e, t) {
  for (let i = t, o = e.length - 1; i < o; i++) e[i] = e[i + 1];
  e.pop();
}
function wt(e, t, i) {
  for (let i = e.length - 1; i >= t; i--) e[i + 1] = e[i];
  e[t] = i;
}
function vt(e, t) {
  let i = -1,
    o = 1e9;
  for (let n = 0; n < t.length; n++)
    (t[n] - o || e[n].endSide - e[i].endSide) < 0 && ((i = n), (o = t[n]));
  return i;
}
const Ct = "undefined" == typeof Symbol ? "__ͼ" : Symbol.for("ͼ"),
  xt =
    "undefined" == typeof Symbol
      ? "__styleSet" + Math.floor(1e8 * Math.random())
      : Symbol("styleSet"),
  kt =
    "undefined" != typeof globalThis
      ? globalThis
      : "undefined" != typeof window
        ? window
        : {};
class St {
  constructor(e, t) {
    this.rules = [];
    let { finish: i } = t || {};
    function o(e) {
      return /^@/.test(e) ? [e] : e.split(/,\s*/);
    }
    function n(e, t, s, r) {
      let a = [],
        l = /^@(\w+)\b/.exec(e[0]),
        c = l && "keyframes" == l[1];
      if (l && null == t) return s.push(e[0] + ";");
      for (let i in t) {
        let r = t[i];
        if (/&/.test(i))
          n(
            i
              .split(/,\s*/)
              .map((t) => e.map((e) => t.replace(/&/, e)))
              .reduce((e, t) => e.concat(t)),
            r,
            s,
          );
        else if (r && "object" == typeof r) {
          if (!l)
            throw new RangeError(
              "The value of a property (" +
                i +
                ") should be a primitive value.",
            );
          n(o(i), r, a, c);
        } else
          null != r &&
            a.push(
              i
                .replace(/_.*/, "")
                .replace(/[A-Z]/g, (e) => "-" + e.toLowerCase()) +
                ": " +
                r +
                ";",
            );
      }
      (a.length || c) &&
        s.push(
          (!i || l || r ? e : e.map(i)).join(", ") + " {" + a.join(" ") + "}",
        );
    }
    for (let t in e) n(o(t), e[t], this.rules);
  }
  getRules() {
    return this.rules.join("\n");
  }
  static newName() {
    let e = kt[Ct] || 1;
    return ((kt[Ct] = e + 1), "ͼ" + e.toString(36));
  }
  static mount(e, t, i) {
    let o = e[xt],
      n = i && i.nonce;
    (o ? n && o.setNonce(n) : (o = new Et(e, n)),
      o.mount(Array.isArray(t) ? t : [t], e));
  }
}
let Tt = new Map();
class Et {
  constructor(e, t) {
    let i = e.ownerDocument || e,
      o = i.defaultView;
    if (!e.head && e.adoptedStyleSheets && o.CSSStyleSheet) {
      let t = Tt.get(i);
      if (t) return (e[xt] = t);
      ((this.sheet = new o.CSSStyleSheet()), Tt.set(i, this));
    } else
      ((this.styleTag = i.createElement("style")),
        t && this.styleTag.setAttribute("nonce", t));
    ((this.modules = []), (e[xt] = this));
  }
  mount(e, t) {
    let i = this.sheet,
      o = 0,
      n = 0;
    for (let t = 0; t < e.length; t++) {
      let s = e[t],
        r = this.modules.indexOf(s);
      if (
        (r < n && r > -1 && (this.modules.splice(r, 1), n--, (r = -1)), -1 == r)
      ) {
        if ((this.modules.splice(n++, 0, s), i))
          for (let e = 0; e < s.rules.length; e++)
            i.insertRule(s.rules[e], o++);
      } else {
        for (; n < r; ) o += this.modules[n++].rules.length;
        ((o += s.rules.length), n++);
      }
    }
    if (i)
      t.adoptedStyleSheets.indexOf(this.sheet) < 0 &&
        (t.adoptedStyleSheets = [this.sheet, ...t.adoptedStyleSheets]);
    else {
      let e = "";
      for (let t = 0; t < this.modules.length; t++)
        e += this.modules[t].getRules() + "\n";
      this.styleTag.textContent = e;
      let i = t.head || t;
      this.styleTag.parentNode != i &&
        i.insertBefore(this.styleTag, i.firstChild);
    }
  }
  setNonce(e) {
    this.styleTag &&
      this.styleTag.getAttribute("nonce") != e &&
      this.styleTag.setAttribute("nonce", e);
  }
}
var Mt = {
    8: "Backspace",
    9: "Tab",
    10: "Enter",
    12: "NumLock",
    13: "Enter",
    16: "Shift",
    17: "Control",
    18: "Alt",
    20: "CapsLock",
    27: "Escape",
    32: " ",
    33: "PageUp",
    34: "PageDown",
    35: "End",
    36: "Home",
    37: "ArrowLeft",
    38: "ArrowUp",
    39: "ArrowRight",
    40: "ArrowDown",
    44: "PrintScreen",
    45: "Insert",
    46: "Delete",
    59: ";",
    61: "=",
    91: "Meta",
    92: "Meta",
    106: "*",
    107: "+",
    108: ",",
    109: "-",
    110: ".",
    111: "/",
    144: "NumLock",
    145: "ScrollLock",
    160: "Shift",
    161: "Shift",
    162: "Control",
    163: "Control",
    164: "Alt",
    165: "Alt",
    173: "-",
    186: ";",
    187: "=",
    188: ",",
    189: "-",
    190: ".",
    191: "/",
    192: "`",
    219: "[",
    220: "\\",
    221: "]",
    222: "'",
  },
  At = {
    48: ")",
    49: "!",
    50: "@",
    51: "#",
    52: "$",
    53: "%",
    54: "^",
    55: "&",
    56: "*",
    57: "(",
    59: ":",
    61: "+",
    173: "_",
    186: ":",
    187: "+",
    188: "<",
    189: "_",
    190: ">",
    191: "?",
    192: "~",
    219: "{",
    220: "|",
    221: "}",
    222: '"',
  };
("undefined" != typeof navigator && /Mac/.test(navigator.platform),
  "undefined" != typeof navigator &&
    /MSIE \d|Trident\/(?:[7-9]|\d{2,})\..*rv:(\d+)/.exec(navigator.userAgent));
for (var It = 0; It < 10; It++) Mt[48 + It] = Mt[96 + It] = String(It);
for (It = 1; It <= 24; It++) Mt[It + 111] = "F" + It;
for (It = 65; It <= 90; It++)
  ((Mt[It] = String.fromCharCode(It + 32)), (At[It] = String.fromCharCode(It)));
for (var Dt in Mt) At.hasOwnProperty(Dt) || (At[Dt] = Mt[Dt]);
let Ot =
    "undefined" != typeof navigator
      ? navigator
      : { userAgent: "", vendor: "", platform: "" },
  Bt =
    "undefined" != typeof document
      ? document
      : { documentElement: { style: {} } };
const Lt = /Edge\/(\d+)/.exec(Ot.userAgent),
  Pt = /MSIE \d/.test(Ot.userAgent),
  Nt = /Trident\/(?:[7-9]|\d{2,})\..*rv:(\d+)/.exec(Ot.userAgent),
  Rt = !!(Pt || Nt || Lt),
  Ft = !Rt && /gecko\/(\d+)/i.test(Ot.userAgent),
  qt = !Rt && /Chrome\/(\d+)/.exec(Ot.userAgent),
  _t = "webkitFontSmoothing" in Bt.documentElement.style,
  zt = !Rt && /Apple Computer/.test(Ot.vendor),
  Vt = zt && (/Mobile\/\w+/.test(Ot.userAgent) || Ot.maxTouchPoints > 2);
var Wt = {
  mac: Vt || /Mac/.test(Ot.platform),
  windows: /Win/.test(Ot.platform),
  linux: /Linux|X11/.test(Ot.platform),
  ie: Rt,
  ie_version: Pt ? Bt.documentMode || 6 : Nt ? +Nt[1] : Lt ? +Lt[1] : 0,
  gecko: Ft,
  gecko_version: Ft ? +(/Firefox\/(\d+)/.exec(Ot.userAgent) || [0, 0])[1] : 0,
  chrome: !!qt,
  chrome_version: qt ? +qt[1] : 0,
  ios: Vt,
  android: /Android\b/.test(Ot.userAgent),
  webkit: _t,
  webkit_version: _t
    ? +(/\bAppleWebKit\/(\d+)/.exec(Ot.userAgent) || [0, 0])[1]
    : 0,
  safari: zt,
  safari_version: zt
    ? +(/\bVersion\/(\d+(\.\d+)?)/.exec(Ot.userAgent) || [0, 0])[1]
    : 0,
  tabSize:
    null != Bt.documentElement.style.tabSize ? "tab-size" : "-moz-tab-size",
};
function Ht(e, t) {
  for (let i in e)
    "class" == i && t.class
      ? (t.class += " " + e.class)
      : "style" == i && t.style
        ? (t.style += ";" + e.style)
        : (t[i] = e[i]);
  return t;
}
const $t = Object.create(null);
function Ut(e, t, i) {
  if (e == t) return !0;
  (e || (e = $t), t || (t = $t));
  let o = Object.keys(e),
    n = Object.keys(t);
  if (
    o.length - (i && o.indexOf(i) > -1 ? 1 : 0) !=
    n.length - (i && n.indexOf(i) > -1 ? 1 : 0)
  )
    return !1;
  for (let s of o)
    if (s != i && (-1 == n.indexOf(s) || e[s] !== t[s])) return !1;
  return !0;
}
function jt(e, t, i) {
  let o = !1;
  if (t)
    for (let n in t)
      (i && n in i) ||
        ((o = !0),
        "style" == n ? (e.style.cssText = "") : e.removeAttribute(n));
  if (i)
    for (let n in i)
      (t && t[n] == i[n]) ||
        ((o = !0),
        "style" == n ? (e.style.cssText = i[n]) : e.setAttribute(n, i[n]));
  return o;
}
function Yt(e) {
  let t = Object.create(null);
  for (let i = 0; i < e.attributes.length; i++) {
    let o = e.attributes[i];
    t[o.name] = o.value;
  }
  return t;
}
class Gt {
  eq(e) {
    return !1;
  }
  updateDOM(e, t) {
    return !1;
  }
  compare(e) {
    return this == e || (this.constructor == e.constructor && this.eq(e));
  }
  get estimatedHeight() {
    return -1;
  }
  get lineBreaks() {
    return 0;
  }
  ignoreEvent(e) {
    return !0;
  }
  coordsAt(e, t, i) {
    return null;
  }
  get isHidden() {
    return !1;
  }
  get editable() {
    return !1;
  }
  destroy(e) {}
}
var Zt = (function (e) {
  return (
    (e[(e.Text = 0)] = "Text"),
    (e[(e.WidgetBefore = 1)] = "WidgetBefore"),
    (e[(e.WidgetAfter = 2)] = "WidgetAfter"),
    (e[(e.WidgetRange = 3)] = "WidgetRange"),
    e
  );
})(Zt || (Zt = {}));
class Kt extends nt {
  constructor(e, t, i, o) {
    (super(),
      (this.startSide = e),
      (this.endSide = t),
      (this.widget = i),
      (this.spec = o));
  }
  get heightRelevant() {
    return !1;
  }
  static mark(e) {
    return new Jt(e);
  }
  static widget(e) {
    let t = Math.max(-1e4, Math.min(1e4, e.side || 0)),
      i = !!e.block;
    return (
      (t += i && !e.inlineOrder ? (t > 0 ? 3e8 : -4e8) : t > 0 ? 1e8 : -1e8),
      new Qt(e, t, t, i, e.widget || null, !1)
    );
  }
  static replace(e) {
    let t,
      i,
      o = !!e.block;
    if (e.isBlockGap) ((t = -5e8), (i = 4e8));
    else {
      let { start: n, end: s } = ei(e, o);
      ((t = (n ? (o ? -3e8 : -1) : 5e8) - 1),
        (i = 1 + (s ? (o ? 2e8 : 1) : -6e8)));
    }
    return new Qt(e, t, i, o, e.widget || null, !0);
  }
  static line(e) {
    return new Xt(e);
  }
  static set(e, t = !1) {
    return ct.of(e, t);
  }
  hasHeight() {
    return !!this.widget && this.widget.estimatedHeight > -1;
  }
}
Kt.none = ct.empty;
class Jt extends Kt {
  constructor(e) {
    let { start: t, end: i } = ei(e);
    (super(t ? -1 : 5e8, i ? 1 : -6e8, null, e),
      (this.tagName = e.tagName || "span"),
      (this.attrs =
        e.class && e.attributes
          ? Ht(e.attributes, { class: e.class })
          : e.class
            ? { class: e.class }
            : e.attributes || $t));
  }
  eq(e) {
    return (
      this == e ||
      (e instanceof Jt && this.tagName == e.tagName && Ut(this.attrs, e.attrs))
    );
  }
  range(e, t = e) {
    if (e >= t) throw new RangeError("Mark decorations may not be empty");
    return super.range(e, t);
  }
}
Jt.prototype.point = !1;
class Xt extends Kt {
  constructor(e) {
    super(-2e8, -2e8, null, e);
  }
  eq(e) {
    return (
      e instanceof Xt &&
      this.spec.class == e.spec.class &&
      Ut(this.spec.attributes, e.spec.attributes)
    );
  }
  range(e, t = e) {
    if (t != e)
      throw new RangeError("Line decoration ranges must be zero-length");
    return super.range(e, t);
  }
}
((Xt.prototype.mapMode = ie.TrackBefore), (Xt.prototype.point = !0));
class Qt extends Kt {
  constructor(e, t, i, o, n, s) {
    (super(t, i, n, e),
      (this.block = o),
      (this.isReplace = s),
      (this.mapMode = o
        ? t <= 0
          ? ie.TrackBefore
          : ie.TrackAfter
        : ie.TrackDel));
  }
  get type() {
    return this.startSide != this.endSide
      ? Zt.WidgetRange
      : this.startSide <= 0
        ? Zt.WidgetBefore
        : Zt.WidgetAfter;
  }
  get heightRelevant() {
    return (
      this.block ||
      (!!this.widget &&
        (this.widget.estimatedHeight >= 5 || this.widget.lineBreaks > 0))
    );
  }
  eq(e) {
    return (
      e instanceof Qt &&
      ((t = this.widget),
      (i = e.widget),
      t == i || !!(t && i && t.compare(i))) &&
      this.block == e.block &&
      this.startSide == e.startSide &&
      this.endSide == e.endSide
    );
    var t, i;
  }
  range(e, t = e) {
    if (
      this.isReplace &&
      (e > t || (e == t && this.startSide > 0 && this.endSide <= 0))
    )
      throw new RangeError("Invalid range for replacement decoration");
    if (!this.isReplace && t != e)
      throw new RangeError(
        "Widget decorations can only have zero-length ranges",
      );
    return super.range(e, t);
  }
}
function ei(e, t = !1) {
  let { inclusiveStart: i, inclusiveEnd: o } = e;
  return (
    null == i && (i = e.inclusive),
    null == o && (o = e.inclusive),
    { start: null != i ? i : t, end: null != o ? o : t }
  );
}
function ti(e, t, i, o = 0) {
  let n = i.length - 1;
  n >= 0 && i[n] + o >= e ? (i[n] = Math.max(i[n], t)) : i.push(e, t);
}
Qt.prototype.point = !0;
class ii extends nt {
  constructor(e, t) {
    (super(), (this.tagName = e), (this.attributes = t));
  }
  eq(e) {
    return (
      e == this ||
      (e instanceof ii &&
        this.tagName == e.tagName &&
        Ut(this.attributes, e.attributes))
    );
  }
  static create(e) {
    return new ii(e.tagName, e.attributes || $t);
  }
  static set(e, t = !1) {
    return ct.of(e, t);
  }
}
function oi(e) {
  let t;
  return (
    (t = 11 == e.nodeType ? (e.getSelection ? e : e.ownerDocument) : e),
    t.getSelection()
  );
}
function ni(e, t) {
  return !!t && (e == t || e.contains(1 != t.nodeType ? t.parentNode : t));
}
function si(e, t) {
  if (!t.anchorNode) return !1;
  try {
    return ni(e, t.anchorNode);
  } catch (e) {
    return !1;
  }
}
function ri(e) {
  return 3 == e.nodeType
    ? wi(e, 0, e.nodeValue.length).getClientRects()
    : 1 == e.nodeType
      ? e.getClientRects()
      : [];
}
function ai(e, t, i, o) {
  return !!i && (di(e, t, i, o, -1) || di(e, t, i, o, 1));
}
function li(e) {
  for (var t = 0; ; t++) if (!(e = e.previousSibling)) return t;
}
function ci(e) {
  return (
    1 == e.nodeType &&
    /^(DIV|P|LI|UL|OL|BLOCKQUOTE|DD|DT|H\d|SECTION|PRE)$/.test(e.nodeName)
  );
}
function di(e, t, i, o, n) {
  for (;;) {
    if (e == i && t == o) return !0;
    if (t == (n < 0 ? 0 : hi(e))) {
      if ("DIV" == e.nodeName) return !1;
      let i = e.parentNode;
      if (!i || 1 != i.nodeType) return !1;
      ((t = li(e) + (n < 0 ? 0 : 1)), (e = i));
    } else {
      if (1 != e.nodeType) return !1;
      if (
        1 == (e = e.childNodes[t + (n < 0 ? -1 : 0)]).nodeType &&
        "false" == e.contentEditable
      )
        return !1;
      t = n < 0 ? hi(e) : 0;
    }
  }
}
function hi(e) {
  return 3 == e.nodeType ? e.nodeValue.length : e.childNodes.length;
}
function ui(e, t) {
  let i = t ? e.left : e.right;
  return { left: i, right: i, top: e.top, bottom: e.bottom };
}
function pi(e) {
  let t = e.visualViewport;
  return t
    ? { left: 0, right: t.width, top: 0, bottom: t.height }
    : { left: 0, right: e.innerWidth, top: 0, bottom: e.innerHeight };
}
function mi(e, t) {
  let i = t.width / e.offsetWidth,
    o = t.height / e.offsetHeight;
  return (
    ((i > 0.995 && i < 1.005) ||
      !isFinite(i) ||
      Math.abs(t.width - e.offsetWidth) < 1) &&
      (i = 1),
    ((o > 0.995 && o < 1.005) ||
      !isFinite(o) ||
      Math.abs(t.height - e.offsetHeight) < 1) &&
      (o = 1),
    { scaleX: i, scaleY: o }
  );
}
ii.prototype.startSide = ii.prototype.endSide = -1;
class gi {
  constructor() {
    ((this.anchorNode = null),
      (this.anchorOffset = 0),
      (this.focusNode = null),
      (this.focusOffset = 0));
  }
  eq(e) {
    return (
      this.anchorNode == e.anchorNode &&
      this.anchorOffset == e.anchorOffset &&
      this.focusNode == e.focusNode &&
      this.focusOffset == e.focusOffset
    );
  }
  setRange(e) {
    let { anchorNode: t, focusNode: i } = e;
    this.set(
      t,
      Math.min(e.anchorOffset, t ? hi(t) : 0),
      i,
      Math.min(e.focusOffset, i ? hi(i) : 0),
    );
  }
  set(e, t, i, o) {
    ((this.anchorNode = e),
      (this.anchorOffset = t),
      (this.focusNode = i),
      (this.focusOffset = o));
  }
}
let fi,
  bi = null;
function yi(e) {
  if (e.setActive) return e.setActive();
  if (bi) return e.focus(bi);
  let t = [];
  for (
    let i = e;
    i && (t.push(i, i.scrollTop, i.scrollLeft), i != i.ownerDocument);
    i = i.parentNode
  );
  if (
    (e.focus(
      null == bi
        ? {
            get preventScroll() {
              return ((bi = { preventScroll: !0 }), !0);
            },
          }
        : void 0,
    ),
    !bi)
  ) {
    bi = !1;
    for (let e = 0; e < t.length; ) {
      let i = t[e++],
        o = t[e++],
        n = t[e++];
      (i.scrollTop != o && (i.scrollTop = o),
        i.scrollLeft != n && (i.scrollLeft = n));
    }
  }
}
function wi(e, t, i = t) {
  let o = fi || (fi = document.createRange());
  return (o.setEnd(e, i), o.setStart(e, t), o);
}
function vi(e, t, i, o) {
  let n = { key: t, code: t, keyCode: i, which: i, cancelable: !0 };
  o &&
    ({
      altKey: n.altKey,
      ctrlKey: n.ctrlKey,
      shiftKey: n.shiftKey,
      metaKey: n.metaKey,
    } = o);
  let s = new KeyboardEvent("keydown", n);
  ((s.synthetic = !0), e.dispatchEvent(s));
  let r = new KeyboardEvent("keyup", n);
  return (
    (r.synthetic = !0),
    e.dispatchEvent(r),
    s.defaultPrevented || r.defaultPrevented
  );
}
function Ci(e) {
  return e.scrollTop > Math.max(1, e.scrollHeight - e.clientHeight - 4);
}
function xi(e, t) {
  for (let i = e, o = t; ; ) {
    if (3 == i.nodeType && o > 0) return { node: i, offset: o };
    if (1 == i.nodeType && o > 0) {
      if ("false" == i.contentEditable) return null;
      ((i = i.childNodes[o - 1]), (o = hi(i)));
    } else {
      if (!i.parentNode || ci(i)) return null;
      ((o = li(i)), (i = i.parentNode));
    }
  }
}
function ki(e, t) {
  for (let i = e, o = t; ; ) {
    if (3 == i.nodeType && o < i.nodeValue.length)
      return { node: i, offset: o };
    if (1 == i.nodeType && o < i.childNodes.length) {
      if ("false" == i.contentEditable) return null;
      ((i = i.childNodes[o]), (o = 0));
    } else {
      if (!i.parentNode || ci(i)) return null;
      ((o = li(i) + 1), (i = i.parentNode));
    }
  }
}
Wt.safari && Wt.safari_version >= 26 && (bi = !1);
class Si {
  constructor(e, t, i = !0) {
    ((this.node = e), (this.offset = t), (this.precise = i));
  }
  static before(e, t) {
    return new Si(e.parentNode, li(e), t);
  }
  static after(e, t) {
    return new Si(e.parentNode, li(e) + 1, t);
  }
}
var Ti = (function (e) {
  return ((e[(e.LTR = 0)] = "LTR"), (e[(e.RTL = 1)] = "RTL"), e);
})(Ti || (Ti = {}));
const Ei = Ti.LTR,
  Mi = Ti.RTL;
function Ai(e) {
  let t = [];
  for (let i = 0; i < e.length; i++) t.push(1 << +e[i]);
  return t;
}
const Ii = Ai(
    "88888888888888888888888888888888888666888888787833333333337888888000000000000000000000000008888880000000000000000000000000088888888888888888888888888888888888887866668888088888663380888308888800000000000000000000000800000000000000000000000000000008",
  ),
  Di = Ai(
    "4444448826627288999999999992222222222222222222222222222222222222222222222229999999999999999999994444444444644222822222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222999999949999999229989999223333333333",
  ),
  Oi = Object.create(null),
  Bi = [];
for (let e of ["()", "[]", "{}"]) {
  let t = e.charCodeAt(0),
    i = e.charCodeAt(1);
  ((Oi[t] = i), (Oi[i] = -t));
}
function Li(e) {
  return e <= 247
    ? Ii[e]
    : 1424 <= e && e <= 1524
      ? 2
      : 1536 <= e && e <= 1785
        ? Di[e - 1536]
        : 1774 <= e && e <= 2220
          ? 4
          : 8192 <= e && e <= 8204
            ? 256
            : 64336 <= e && e <= 65023
              ? 4
              : 1;
}
const Pi = /[\u0590-\u05f4\u0600-\u06ff\u0700-\u08ac\ufb50-\ufdff]/;
class Ni {
  get dir() {
    return this.level % 2 ? Mi : Ei;
  }
  constructor(e, t, i) {
    ((this.from = e), (this.to = t), (this.level = i));
  }
  side(e, t) {
    return (this.dir == t) == e ? this.to : this.from;
  }
  forward(e, t) {
    return e == (this.dir == t);
  }
  static find(e, t, i, o) {
    let n = -1;
    for (let s = 0; s < e.length; s++) {
      let r = e[s];
      if (r.from <= t && r.to >= t) {
        if (r.level == i) return s;
        (n < 0 ||
          (0 != o ? (o < 0 ? r.from < t : r.to > t) : e[n].level > r.level)) &&
          (n = s);
      }
    }
    if (n < 0) throw new RangeError("Index out of range");
    return n;
  }
}
function Ri(e, t) {
  if (e.length != t.length) return !1;
  for (let i = 0; i < e.length; i++) {
    let o = e[i],
      n = t[i];
    if (
      o.from != n.from ||
      o.to != n.to ||
      o.direction != n.direction ||
      !Ri(o.inner, n.inner)
    )
      return !1;
  }
  return !0;
}
const Fi = [];
function qi(e, t, i, o, n, s, r) {
  let a = o % 2 ? 2 : 1;
  if (o % 2 == n % 2)
    for (let l = t, c = 0; l < i; ) {
      let t = !0,
        d = !1;
      if (c == s.length || l < s[c].from) {
        let e = Fi[l];
        e != a && ((t = !1), (d = 16 == e));
      }
      let h = t || 1 != a ? null : [],
        u = t ? o : o + 1,
        p = l;
      e: for (;;)
        if (c < s.length && p == s[c].from) {
          if (d) break e;
          let m = s[c];
          if (!t)
            for (let e = m.to, t = c + 1; ; ) {
              if (e == i) break e;
              if (!(t < s.length && s[t].from == e)) {
                if (Fi[e] == a) break e;
                break;
              }
              e = s[t++].to;
            }
          if ((c++, h)) h.push(m);
          else {
            (m.from > l && r.push(new Ni(l, m.from, u)),
              _i(
                e,
                (m.direction == Ei) != !(u % 2) ? o + 1 : o,
                n,
                m.inner,
                m.from,
                m.to,
                r,
              ),
              (l = m.to));
          }
          p = m.to;
        } else {
          if (p == i || (t ? Fi[p] != a : Fi[p] == a)) break;
          p++;
        }
      (h ? qi(e, l, p, o + 1, n, h, r) : l < p && r.push(new Ni(l, p, u)),
        (l = p));
    }
  else
    for (let l = i, c = s.length; l > t; ) {
      let i = !0,
        d = !1;
      if (!c || l > s[c - 1].to) {
        let e = Fi[l - 1];
        e != a && ((i = !1), (d = 16 == e));
      }
      let h = i || 1 != a ? null : [],
        u = i ? o : o + 1,
        p = l;
      e: for (;;)
        if (c && p == s[c - 1].to) {
          if (d) break e;
          let m = s[--c];
          if (!i)
            for (let e = m.from, i = c; ; ) {
              if (e == t) break e;
              if (!i || s[i - 1].to != e) {
                if (Fi[e - 1] == a) break e;
                break;
              }
              e = s[--i].from;
            }
          if (h) h.push(m);
          else {
            (m.to < l && r.push(new Ni(m.to, l, u)),
              _i(
                e,
                (m.direction == Ei) != !(u % 2) ? o + 1 : o,
                n,
                m.inner,
                m.from,
                m.to,
                r,
              ),
              (l = m.from));
          }
          p = m.from;
        } else {
          if (p == t || (i ? Fi[p - 1] != a : Fi[p - 1] == a)) break;
          p--;
        }
      (h ? qi(e, p, l, o + 1, n, h, r) : p < l && r.push(new Ni(p, l, u)),
        (l = p));
    }
}
function _i(e, t, i, o, n, s, r) {
  let a = t % 2 ? 2 : 1;
  (!(function (e, t, i, o, n) {
    for (let s = 0; s <= o.length; s++) {
      let r = s ? o[s - 1].to : t,
        a = s < o.length ? o[s].from : i,
        l = s ? 256 : n;
      for (let t = r, i = l, o = l; t < a; t++) {
        let n = Li(e.charCodeAt(t));
        (512 == n ? (n = i) : 8 == n && 4 == o && (n = 16),
          (Fi[t] = 4 == n ? 2 : n),
          7 & n && (o = n),
          (i = n));
      }
      for (let e = r, t = l, o = l; e < a; e++) {
        let n = Fi[e];
        if (128 == n)
          e < a - 1 && t == Fi[e + 1] && 24 & t
            ? (n = Fi[e] = t)
            : (Fi[e] = 256);
        else if (64 == n) {
          let n = e + 1;
          for (; n < a && 64 == Fi[n]; ) n++;
          let s =
            (e && 8 == t) || (n < i && 8 == Fi[n]) ? (1 == o ? 1 : 8) : 256;
          for (let t = e; t < n; t++) Fi[t] = s;
          e = n - 1;
        } else 8 == n && 1 == o && (Fi[e] = 1);
        ((t = n), 7 & n && (o = n));
      }
    }
  })(e, n, s, o, a),
    (function (e, t, i, o, n) {
      let s = 1 == n ? 2 : 1;
      for (let r = 0, a = 0, l = 0; r <= o.length; r++) {
        let c = r ? o[r - 1].to : t,
          d = r < o.length ? o[r].from : i;
        for (let t, i, o, r = c; r < d; r++)
          if ((i = Oi[(t = e.charCodeAt(r))]))
            if (i < 0) {
              for (let e = a - 3; e >= 0; e -= 3)
                if (Bi[e + 1] == -i) {
                  let t = Bi[e + 2],
                    i = 2 & t ? n : 4 & t ? (1 & t ? s : n) : 0;
                  (i && (Fi[r] = Fi[Bi[e]] = i), (a = e));
                  break;
                }
            } else {
              if (189 == Bi.length) break;
              ((Bi[a++] = r), (Bi[a++] = t), (Bi[a++] = l));
            }
          else if (2 == (o = Fi[r]) || 1 == o) {
            let e = o == n;
            l = e ? 0 : 1;
            for (let t = a - 3; t >= 0; t -= 3) {
              let i = Bi[t + 2];
              if (2 & i) break;
              if (e) Bi[t + 2] |= 2;
              else {
                if (4 & i) break;
                Bi[t + 2] |= 4;
              }
            }
          }
      }
    })(e, n, s, o, a),
    (function (e, t, i, o) {
      for (let n = 0, s = o; n <= i.length; n++) {
        let r = n ? i[n - 1].to : e,
          a = n < i.length ? i[n].from : t;
        for (let l = r; l < a; ) {
          let r = Fi[l];
          if (256 == r) {
            let r = l + 1;
            for (;;)
              if (r == a) {
                if (n == i.length) break;
                ((r = i[n++].to), (a = n < i.length ? i[n].from : t));
              } else {
                if (256 != Fi[r]) break;
                r++;
              }
            let c = 1 == s,
              d = c == (1 == (r < t ? Fi[r] : o)) ? (c ? 1 : 2) : o;
            for (let t = r, o = n, s = o ? i[o - 1].to : e; t > l; )
              (t == s && ((t = i[--o].from), (s = o ? i[o - 1].to : e)),
                (Fi[--t] = d));
            l = r;
          } else ((s = r), l++);
        }
      }
    })(n, s, o, a),
    qi(e, n, s, t, i, o, r));
}
function zi(e) {
  return [new Ni(0, e, 0)];
}
let Vi = "";
function Wi(e, t, i, o, n) {
  var s;
  let r = o.head - e.from,
    a = Ni.find(
      t,
      r,
      null !== (s = o.bidiLevel) && void 0 !== s ? s : -1,
      o.assoc,
    ),
    l = t[a],
    c = l.side(n, i);
  if (r == c) {
    let e = (a += n ? 1 : -1);
    if (e < 0 || e >= t.length) return null;
    ((l = t[(a = e)]), (r = l.side(!n, i)), (c = l.side(n, i)));
  }
  let d = ee(e.text, r, l.forward(n, i));
  ((d < l.from || d > l.to) && (d = c),
    (Vi = e.text.slice(Math.min(r, d), Math.max(r, d))));
  let h = a == (n ? t.length - 1 : 0) ? null : t[a + (n ? 1 : -1)];
  return h && d == c && h.level + (n ? 0 : 1) < l.level
    ? ue.cursor(h.side(!n, i) + e.from, h.forward(n, i) ? 1 : -1, h.level)
    : ue.cursor(d + e.from, l.forward(n, i) ? -1 : 1, l.level);
}
function Hi(e, t, i) {
  for (let o = t; o < i; o++) {
    let t = Li(e.charCodeAt(o));
    if (1 == t) return Ei;
    if (2 == t || 4 == t) return Mi;
  }
  return Ei;
}
const $i = ge.define(),
  Ui = ge.define(),
  ji = ge.define(),
  Yi = ge.define(),
  Gi = ge.define(),
  Zi = ge.define(),
  Ki = ge.define(),
  Ji = ge.define(),
  Xi = ge.define(),
  Qi = ge.define({ combine: (e) => e.some((e) => e) }),
  eo = ge.define({ combine: (e) => e.some((e) => e) }),
  to = ge.define();
class io {
  constructor(e, t = "nearest", i = "nearest", o = 5, n = 5, s = !1) {
    ((this.range = e),
      (this.y = t),
      (this.x = i),
      (this.yMargin = o),
      (this.xMargin = n),
      (this.isSnapshot = s));
  }
  map(e) {
    return e.empty
      ? this
      : new io(
          this.range.map(e),
          this.y,
          this.x,
          this.yMargin,
          this.xMargin,
          this.isSnapshot,
        );
  }
  clip(e) {
    return this.range.to <= e.doc.length
      ? this
      : new io(
          ue.cursor(e.doc.length),
          this.y,
          this.x,
          this.yMargin,
          this.xMargin,
          this.isSnapshot,
        );
  }
}
const oo = Ue.define({ map: (e, t) => e.map(t) }),
  no = Ue.define();
function so(e, t, i) {
  let o = e.facet(Yi);
  o.length
    ? o[0](t)
    : (window.onerror && window.onerror(String(t), i, void 0, void 0, t)) ||
      (i ? console.error(i + ":", t) : console.error(t));
}
const ro = ge.define({ combine: (e) => !e.length || e[0] });
let ao = 0;
const lo = ge.define({
  combine: (e) =>
    e.filter((t, i) => {
      for (let o = 0; o < i; o++) if (e[o].plugin == t.plugin) return !1;
      return !0;
    }),
});
class co {
  constructor(e, t, i, o, n) {
    ((this.id = e),
      (this.create = t),
      (this.domEventHandlers = i),
      (this.domEventObservers = o),
      (this.baseExtensions = n(this)),
      (this.extension = this.baseExtensions.concat(
        lo.of({ plugin: this, arg: void 0 }),
      )));
  }
  of(e) {
    return this.baseExtensions.concat(lo.of({ plugin: this, arg: e }));
  }
  static define(e, t) {
    const {
      eventHandlers: i,
      eventObservers: o,
      provide: n,
      decorations: s,
    } = t || {};
    return new co(ao++, e, i, o, (e) => {
      let t = [];
      return (
        s &&
          t.push(
            mo.of((t) => {
              let i = t.plugin(e);
              return i ? s(i) : Kt.none;
            }),
          ),
        n && t.push(n(e)),
        t
      );
    });
  }
  static fromClass(e, t) {
    return co.define((t, i) => new e(t, i), t);
  }
}
class ho {
  constructor(e) {
    ((this.spec = e), (this.mustUpdate = null), (this.value = null));
  }
  get plugin() {
    return this.spec && this.spec.plugin;
  }
  update(e) {
    if (this.value) {
      if (this.mustUpdate) {
        let e = this.mustUpdate;
        if (((this.mustUpdate = null), this.value.update))
          try {
            this.value.update(e);
          } catch (t) {
            if (
              (so(e.state, t, "CodeMirror plugin crashed"), this.value.destroy)
            )
              try {
                this.value.destroy();
              } catch (e) {}
            this.deactivate();
          }
      }
    } else if (this.spec)
      try {
        this.value = this.spec.plugin.create(e, this.spec.arg);
      } catch (t) {
        (so(e.state, t, "CodeMirror plugin crashed"), this.deactivate());
      }
    return this;
  }
  destroy(e) {
    var t;
    if (null === (t = this.value) || void 0 === t ? void 0 : t.destroy)
      try {
        this.value.destroy();
      } catch (t) {
        so(e.state, t, "CodeMirror plugin crashed");
      }
  }
  deactivate() {
    this.spec = this.value = null;
  }
}
const uo = ge.define(),
  po = ge.define(),
  mo = ge.define(),
  go = ge.define(),
  fo = ge.define(),
  bo = ge.define(),
  yo = ge.define();
function wo(e, t) {
  let i = e.state.facet(yo);
  if (!i.length) return i;
  let o = i.map((t) => (t instanceof Function ? t(e) : t)),
    n = [];
  return (
    ct.spans(o, t.from, t.to, {
      point() {},
      span(e, i, o, s) {
        let r = e - t.from,
          a = i - t.from,
          l = n;
        for (let e = o.length - 1; e >= 0; e--, s--) {
          let i,
            n = o[e].spec.bidiIsolate;
          if (
            (null == n && (n = Hi(t.text, r, a)),
            s > 0 &&
              l.length &&
              (i = l[l.length - 1]).to == r &&
              i.direction == n)
          )
            ((i.to = a), (l = i.inner));
          else {
            let e = { from: r, to: a, direction: n, inner: [] };
            (l.push(e), (l = e.inner));
          }
        }
      },
    }),
    n
  );
}
const vo = ge.define();
function Co(e) {
  let t = 0,
    i = 0,
    o = 0,
    n = 0;
  for (let s of e.state.facet(vo)) {
    let r = s(e);
    r &&
      (null != r.left && (t = Math.max(t, r.left)),
      null != r.right && (i = Math.max(i, r.right)),
      null != r.top && (o = Math.max(o, r.top)),
      null != r.bottom && (n = Math.max(n, r.bottom)));
  }
  return { left: t, right: i, top: o, bottom: n };
}
const xo = ge.define();
class ko {
  constructor(e, t, i, o) {
    ((this.fromA = e), (this.toA = t), (this.fromB = i), (this.toB = o));
  }
  join(e) {
    return new ko(
      Math.min(this.fromA, e.fromA),
      Math.max(this.toA, e.toA),
      Math.min(this.fromB, e.fromB),
      Math.max(this.toB, e.toB),
    );
  }
  addToSet(e) {
    let t = e.length,
      i = this;
    for (; t > 0; t--) {
      let o = e[t - 1];
      if (!(o.fromA > i.toA)) {
        if (o.toA < i.fromA) break;
        ((i = i.join(o)), e.splice(t - 1, 1));
      }
    }
    return (e.splice(t, 0, i), e);
  }
  static extendWithRanges(e, t) {
    if (0 == t.length) return e;
    let i = [];
    for (let o = 0, n = 0, s = 0; ; ) {
      let r = o < e.length ? e[o].fromB : 1e9,
        a = n < t.length ? t[n] : 1e9,
        l = Math.min(r, a);
      if (1e9 == l) break;
      let c = l + s,
        d = l,
        h = c;
      for (;;)
        if (n < t.length && t[n] <= d) {
          let i = t[n + 1];
          ((n += 2), (d = Math.max(d, i)));
          for (let t = o; t < e.length && e[t].fromB <= d; t++)
            s = e[t].toA - e[t].toB;
          h = Math.max(h, i + s);
        } else {
          if (!(o < e.length && e[o].fromB <= d)) break;
          {
            let t = e[o++];
            ((d = Math.max(d, t.toB)),
              (h = Math.max(h, t.toA)),
              (s = t.toA - t.toB));
          }
        }
      i.push(new ko(c, h, l, d));
    }
    return i;
  }
}
class So {
  constructor(e, t, i) {
    ((this.view = e),
      (this.state = t),
      (this.transactions = i),
      (this.flags = 0),
      (this.startState = e.state),
      (this.changes = ne.empty(this.startState.doc.length)));
    for (let e of i) this.changes = this.changes.compose(e.changes);
    let o = [];
    (this.changes.iterChangedRanges((e, t, i, n) => o.push(new ko(e, t, i, n))),
      (this.changedRanges = o));
  }
  static create(e, t, i) {
    return new So(e, t, i);
  }
  get viewportChanged() {
    return (4 & this.flags) > 0;
  }
  get viewportMoved() {
    return (8 & this.flags) > 0;
  }
  get heightChanged() {
    return (2 & this.flags) > 0;
  }
  get geometryChanged() {
    return this.docChanged || (18 & this.flags) > 0;
  }
  get focusChanged() {
    return (1 & this.flags) > 0;
  }
  get docChanged() {
    return !this.changes.empty;
  }
  get selectionSet() {
    return this.transactions.some((e) => e.selection);
  }
  get empty() {
    return 0 == this.flags && 0 == this.transactions.length;
  }
}
const To = [];
class Eo {
  constructor(e, t, i = 0) {
    ((this.dom = e),
      (this.length = t),
      (this.flags = i),
      (this.parent = null),
      (e.cmTile = this));
  }
  get breakAfter() {
    return 1 & this.flags;
  }
  get children() {
    return To;
  }
  isWidget() {
    return !1;
  }
  get isHidden() {
    return !1;
  }
  isComposite() {
    return !1;
  }
  isLine() {
    return !1;
  }
  isText() {
    return !1;
  }
  isBlock() {
    return !1;
  }
  get domAttrs() {
    return null;
  }
  sync(e) {
    if (((this.flags |= 2), 4 & this.flags)) {
      this.flags &= -5;
      let e = this.domAttrs;
      e &&
        (function (e, t) {
          for (let i = e.attributes.length - 1; i >= 0; i--) {
            let o = e.attributes[i].name;
            null == t[o] && e.removeAttribute(o);
          }
          for (let i in t) {
            let o = t[i];
            "style" == i
              ? (e.style.cssText = o)
              : e.getAttribute(i) != o && e.setAttribute(i, o);
          }
        })(this.dom, e);
    }
  }
  toString() {
    return (
      this.constructor.name +
      (this.children.length ? `(${this.children})` : "") +
      (this.breakAfter ? "#" : "")
    );
  }
  destroy() {
    this.parent = null;
  }
  setDOM(e) {
    ((this.dom = e), (e.cmTile = this));
  }
  get posAtStart() {
    return this.parent ? this.parent.posBefore(this) : 0;
  }
  get posAtEnd() {
    return this.posAtStart + this.length;
  }
  posBefore(e, t = this.posAtStart) {
    let i = t;
    for (let t of this.children) {
      if (t == e) return i;
      i += t.length + t.breakAfter;
    }
    throw new RangeError("Invalid child in posBefore");
  }
  posAfter(e) {
    return this.posBefore(e) + e.length;
  }
  covers(e) {
    return !0;
  }
  coordsIn(e, t) {
    return null;
  }
  domPosFor(e, t) {
    let i = li(this.dom),
      o = this.length ? e > 0 : t > 0;
    return new Si(this.parent.dom, i + (o ? 1 : 0), 0 == e || e == this.length);
  }
  markDirty(e) {
    ((this.flags &= -3),
      e && (this.flags |= 4),
      this.parent && 2 & this.parent.flags && this.parent.markDirty(!1));
  }
  get overrideDOMText() {
    return null;
  }
  get root() {
    for (let e = this; e; e = e.parent) if (e instanceof Io) return e;
    return null;
  }
  static get(e) {
    return e.cmTile;
  }
}
class Mo extends Eo {
  constructor(e) {
    (super(e, 0), (this._children = []));
  }
  isComposite() {
    return !0;
  }
  get children() {
    return this._children;
  }
  get lastChild() {
    return this.children.length
      ? this.children[this.children.length - 1]
      : null;
  }
  append(e) {
    (this.children.push(e), (e.parent = this));
  }
  sync(e) {
    if (2 & this.flags) return;
    super.sync(e);
    let t,
      i = this.dom,
      o = null,
      n = (null == e ? void 0 : e.node) == i ? e : null,
      s = 0;
    for (let r of this.children) {
      if (
        (r.sync(e),
        (s += r.length + r.breakAfter),
        (t = o ? o.nextSibling : i.firstChild),
        n && t != r.dom && (n.written = !0),
        r.dom.parentNode == i)
      )
        for (; t && t != r.dom; ) t = Ao(t);
      else i.insertBefore(r.dom, t);
      o = r.dom;
    }
    for (t = o ? o.nextSibling : i.firstChild, n && t && (n.written = !0); t; )
      t = Ao(t);
    this.length = s;
  }
}
function Ao(e) {
  let t = e.nextSibling;
  return (e.parentNode.removeChild(e), t);
}
class Io extends Mo {
  constructor(e, t) {
    (super(t), (this.view = e));
  }
  owns(e) {
    for (; e; e = e.parent) if (e == this) return !0;
    return !1;
  }
  isBlock() {
    return !0;
  }
  nearest(e) {
    for (;;) {
      if (!e) return null;
      let t = Eo.get(e);
      if (t && this.owns(t)) return t;
      e = e.parentNode;
    }
  }
  blockTiles(e) {
    for (let t = [], i = this, o = 0, n = 0; ; )
      if (o == i.children.length) {
        if (!t.length) return;
        ((i = i.parent), i.breakAfter && n++, (o = t.pop()));
      } else {
        let s = i.children[o++];
        if (s instanceof Do) (t.push(o), (i = s), (o = 0));
        else {
          let t = n + s.length,
            i = e(s, n);
          if (void 0 !== i) return i;
          n = t + s.breakAfter;
        }
      }
  }
  resolveBlock(e, t) {
    let i,
      o,
      n = -1,
      s = -1;
    if (
      (this.blockTiles((r, a) => {
        let l = a + r.length;
        if (e >= a && e <= l) {
          if (r.isWidget() && t >= -1 && t <= 1) {
            if (32 & r.flags) return !0;
            16 & r.flags && (i = void 0);
          }
          ((a < e || (e == l && (t < -1 ? r.length : r.covers(1)))) &&
            (!i || (!r.isWidget() && i.isWidget())) &&
            ((i = r), (n = e - a)),
            (l > e || (e == a && (t > 1 ? r.length : r.covers(-1)))) &&
              (!o || (!r.isWidget() && o.isWidget())) &&
              ((o = r), (s = e - a)));
        }
      }),
      !i && !o)
    )
      throw new Error("No tile at position " + e);
    return (i && t < 0) || !o ? { tile: i, offset: n } : { tile: o, offset: s };
  }
}
class Do extends Mo {
  constructor(e, t) {
    (super(e), (this.wrapper = t));
  }
  isBlock() {
    return !0;
  }
  covers(e) {
    return (
      !!this.children.length &&
      (e < 0 ? this.children[0].covers(-1) : this.lastChild.covers(1))
    );
  }
  get domAttrs() {
    return this.wrapper.attributes;
  }
  static of(e, t) {
    let i = new Do(t || document.createElement(e.tagName), e);
    return (t || (i.flags |= 4), i);
  }
}
class Oo extends Mo {
  constructor(e, t) {
    (super(e), (this.attrs = t));
  }
  isLine() {
    return !0;
  }
  static start(e, t, i) {
    let o = new Oo(t || document.createElement("div"), e);
    return ((t && i) || (o.flags |= 4), o);
  }
  get domAttrs() {
    return this.attrs;
  }
  resolveInline(e, t, i) {
    let o = null,
      n = -1,
      s = null,
      r = -1;
    !(function e(a, l) {
      for (let c = 0, d = 0; c < a.children.length && d <= l; c++) {
        let h = a.children[c],
          u = d + h.length;
        (u >= l &&
          (h.isComposite()
            ? e(h, l - d)
            : (!s || (s.isHidden && (t > 0 || (i && Bo(s, h))))) &&
                (u > l || 32 & h.flags)
              ? ((s = h), (r = l - d))
              : (d < l || (16 & h.flags && !h.isHidden)) &&
                ((o = h), (n = l - d))),
          (d = u));
      }
    })(this, e);
    let a = (t < 0 ? o : s) || o || s;
    return a ? { tile: a, offset: a == o ? n : r } : null;
  }
  coordsIn(e, t) {
    let i = this.resolveInline(e, t, !0);
    return i
      ? i.tile.coordsIn(Math.max(0, i.offset), t)
      : (function (e) {
          let t = e.dom.lastChild;
          if (!t) return e.dom.getBoundingClientRect();
          let i = ri(t);
          return i[i.length - 1] || null;
        })(this);
  }
  domIn(e, t) {
    let i = this.resolveInline(e, t);
    if (i) {
      let { tile: e, offset: o } = i;
      if (this.dom.contains(e.dom))
        return e.isText()
          ? new Si(e.dom, Math.min(e.dom.nodeValue.length, o))
          : e.domPosFor(o, 16 & e.flags ? 1 : 32 & e.flags ? -1 : t);
      let n = i.tile.parent,
        s = !1;
      for (let e of n.children) {
        if (s) return new Si(e.dom, 0);
        e == i.tile && (s = !0);
      }
    }
    return new Si(this.dom, 0);
  }
}
function Bo(e, t) {
  let i = e.coordsIn(0, 1),
    o = t.coordsIn(0, 1);
  return i && o && o.top < i.bottom;
}
class Lo extends Mo {
  constructor(e, t) {
    (super(e), (this.mark = t));
  }
  get domAttrs() {
    return this.mark.attrs;
  }
  static of(e, t) {
    let i = new Lo(t || document.createElement(e.tagName), e);
    return (t || (i.flags |= 4), i);
  }
}
class Po extends Eo {
  constructor(e, t) {
    (super(e, t.length), (this.text = t));
  }
  sync(e) {
    2 & this.flags ||
      (super.sync(e),
      this.dom.nodeValue != this.text &&
        (e && e.node == this.dom && (e.written = !0),
        (this.dom.nodeValue = this.text)));
  }
  isText() {
    return !0;
  }
  toString() {
    return JSON.stringify(this.text);
  }
  coordsIn(e, t) {
    let i = this.dom.nodeValue.length;
    e > i && (e = i);
    let o = e,
      n = e,
      s = 0;
    (0 == e && t < 0) || (e == i && t >= 0)
      ? Wt.chrome || Wt.gecko || (e ? (o--, (s = 1)) : n < i && (n++, (s = -1)))
      : t < 0
        ? o--
        : n < i && n++;
    let r = wi(this.dom, o, n).getClientRects();
    if (!r.length) return null;
    let a = r[(s ? s < 0 : t >= 0) ? 0 : r.length - 1];
    return (
      Wt.safari &&
        !s &&
        0 == a.width &&
        (a = Array.prototype.find.call(r, (e) => e.width) || a),
      s ? ui(a, s < 0) : a || null
    );
  }
  static of(e, t) {
    let i = new Po(t || document.createTextNode(e), e);
    return (t || (i.flags |= 2), i);
  }
}
class No extends Eo {
  constructor(e, t, i, o) {
    (super(e, t, o), (this.widget = i));
  }
  isWidget() {
    return !0;
  }
  get isHidden() {
    return this.widget.isHidden;
  }
  covers(e) {
    return !(48 & this.flags) && (this.flags & (e < 0 ? 64 : 128)) > 0;
  }
  coordsIn(e, t) {
    return this.coordsInWidget(e, t, !1);
  }
  coordsInWidget(e, t, i) {
    let o = this.widget.coordsAt(this.dom, e, t);
    if (o) return o;
    if (i)
      return ui(
        this.dom.getBoundingClientRect(),
        this.length ? 0 == e : t <= 0,
      );
    {
      let t = this.dom.getClientRects(),
        i = null;
      if (!t.length) return null;
      let o = !!(16 & this.flags) || (!(32 & this.flags) && e > 0);
      for (
        let n = o ? t.length - 1 : 0;
        (i = t[n]), !(e > 0 ? 0 == n : n == t.length - 1 || i.top < i.bottom);
        n += o ? -1 : 1
      );
      return ui(i, !o);
    }
  }
  get overrideDOMText() {
    if (!this.length) return $.empty;
    let { root: e } = this;
    if (!e) return $.empty;
    let t = this.posAtStart;
    return e.view.state.doc.slice(t, t + this.length);
  }
  destroy() {
    (super.destroy(), this.widget.destroy(this.dom));
  }
  static of(e, t, i, o, n) {
    return (
      n || ((n = e.toDOM(t)), e.editable || (n.contentEditable = "false")),
      new No(n, i, e, o)
    );
  }
}
class Ro extends Eo {
  constructor(e) {
    let t = document.createElement("img");
    ((t.className = "cm-widgetBuffer"),
      t.setAttribute("aria-hidden", "true"),
      super(t, 0, e));
  }
  get isHidden() {
    return !0;
  }
  get overrideDOMText() {
    return $.empty;
  }
  coordsIn(e) {
    return this.dom.getBoundingClientRect();
  }
}
class Fo {
  constructor(e) {
    ((this.index = 0),
      (this.beforeBreak = !1),
      (this.parents = []),
      (this.tile = e));
  }
  advance(e, t, i) {
    let { tile: o, index: n, beforeBreak: s, parents: r } = this;
    for (; e || t > 0; )
      if (o.isComposite())
        if (s) {
          if (!e) break;
          (i && i.break(), e--, (s = !1));
        } else if (n == o.children.length) {
          if (!e && !r.length) break;
          (i && i.leave(o),
            (s = !!o.breakAfter),
            ({ tile: o, index: n } = r.pop()),
            n++);
        } else {
          let a = o.children[n],
            l = a.breakAfter;
          !(t > 0 ? a.length <= e : a.length < e) ||
          (i && !1 === i.skip(a, 0, a.length) && a.isComposite)
            ? (r.push({ tile: o, index: n }),
              (o = a),
              (n = 0),
              i && a.isComposite() && i.enter(a))
            : ((s = !!l), n++, (e -= a.length));
        }
      else if (n == o.length)
        ((s = !!o.breakAfter), ({ tile: o, index: n } = r.pop()), n++);
      else {
        if (!e) break;
        {
          let t = Math.min(e, o.length - n);
          (i && i.skip(o, n, n + t), (e -= t), (n += t));
        }
      }
    return ((this.tile = o), (this.index = n), (this.beforeBreak = s), this);
  }
  get root() {
    return this.parents.length ? this.parents[0].tile : this.tile;
  }
}
class qo {
  constructor(e, t, i, o) {
    ((this.from = e), (this.to = t), (this.wrapper = i), (this.rank = o));
  }
}
class _o {
  constructor(e, t, i) {
    ((this.cache = e),
      (this.root = t),
      (this.blockWrappers = i),
      (this.curLine = null),
      (this.lastBlock = null),
      (this.afterWidget = null),
      (this.pos = 0),
      (this.wrappers = []),
      (this.wrapperPos = 0));
  }
  addText(e, t, i, o) {
    var n;
    this.flushBuffer();
    let s = this.ensureMarks(t, i),
      r = s.lastChild;
    if (!r || !r.isText() || 8 & r.flags)
      s.append(
        o ||
          Po.of(
            e,
            null === (n = this.cache.find(Po)) || void 0 === n ? void 0 : n.dom,
          ),
      );
    else {
      (this.cache.reused.set(r, 2),
        ((s.children[s.children.length - 1] = new Po(
          r.dom,
          r.text + e,
        )).parent = s));
    }
    ((this.pos += e.length), (this.afterWidget = null));
  }
  addComposition(e, t) {
    let i = this.curLine;
    i.dom != t.line.dom &&
      (i.setDOM(this.cache.reused.has(t.line) ? jo(t.line.dom) : t.line.dom),
      this.cache.reused.set(t.line, 2));
    let o = i;
    for (let e = t.marks.length - 1; e >= 0; e--) {
      let i = t.marks[e],
        n = o.lastChild;
      if (n instanceof Lo && n.mark.eq(i.mark))
        (n.dom != i.dom && n.setDOM(jo(i.dom)), (o = n));
      else {
        if (this.cache.reused.get(i)) {
          let e = Eo.get(i.dom);
          e && e.setDOM(jo(i.dom));
        }
        let e = Lo.of(i.mark, i.dom);
        (o.append(e), (o = e));
      }
      this.cache.reused.set(i, 2);
    }
    let n = Eo.get(e.text);
    n && this.cache.reused.set(n, 2);
    let s = new Po(e.text, e.text.nodeValue);
    ((s.flags |= 8), o.append(s));
  }
  addInlineWidget(e, t, i) {
    let o =
      this.afterWidget &&
      48 & e.flags &&
      (48 & this.afterWidget.flags) == (48 & e.flags);
    o || this.flushBuffer();
    let n = this.ensureMarks(t, i);
    (o || 16 & e.flags || n.append(this.getBuffer(1)),
      n.append(e),
      (this.pos += e.length),
      (this.afterWidget = e));
  }
  addMark(e, t, i) {
    (this.flushBuffer(),
      this.ensureMarks(t, i).append(e),
      (this.pos += e.length),
      (this.afterWidget = null));
  }
  addBlockWidget(e) {
    (this.getBlockPos().append(e),
      (this.pos += e.length),
      (this.lastBlock = e),
      this.endLine());
  }
  continueWidget(e) {
    (((this.afterWidget || this.lastBlock).length += e), (this.pos += e));
  }
  addLineStart(e, t) {
    var i;
    e || (e = Uo);
    let o = Oo.start(
      e,
      t ||
        (null === (i = this.cache.find(Oo)) || void 0 === i ? void 0 : i.dom),
      !!t,
    );
    this.getBlockPos().append((this.lastBlock = this.curLine = o));
  }
  addLine(e) {
    (this.getBlockPos().append(e),
      (this.pos += e.length),
      (this.lastBlock = e),
      this.endLine());
  }
  addBreak() {
    ((this.lastBlock.flags |= 1), this.endLine(), this.pos++);
  }
  addLineStartIfNotCovered(e) {
    this.blockPosCovered() || this.addLineStart(e);
  }
  ensureLine(e) {
    this.curLine || this.addLineStart(e);
  }
  ensureMarks(e, t) {
    var i;
    let o = this.curLine;
    for (let n = e.length - 1; n >= 0; n--) {
      let s,
        r = e[n];
      if (t > 0 && (s = o.lastChild) && s instanceof Lo && s.mark.eq(r))
        ((o = s), t--);
      else {
        let e = Lo.of(
          r,
          null === (i = this.cache.find(Lo, (e) => e.mark.eq(r))) ||
            void 0 === i
            ? void 0
            : i.dom,
        );
        (o.append(e), (o = e), (t = 0));
      }
    }
    return o;
  }
  endLine() {
    if (this.curLine) {
      this.flushBuffer();
      let e = this.curLine.lastChild;
      ((e &&
        $o(this.curLine, !1) &&
        ("BR" == e.dom.nodeName ||
          !e.isWidget() ||
          (Wt.ios && $o(this.curLine, !0)))) ||
        this.curLine.append(
          this.cache.findWidget(Go, 0, 32) || new No(Go.toDOM(), 0, Go, 32),
        ),
        (this.curLine = this.afterWidget = null));
    }
  }
  updateBlockWrappers() {
    this.wrapperPos > this.pos + 1e4 &&
      (this.blockWrappers.goto(this.pos), (this.wrappers.length = 0));
    for (let e = this.wrappers.length - 1; e >= 0; e--)
      this.wrappers[e].to < this.pos && this.wrappers.splice(e, 1);
    for (let e = this.blockWrappers; e.value && e.from <= this.pos; e.next())
      if (e.to >= this.pos) {
        let t = new qo(e.from, e.to, e.value, e.rank),
          i = this.wrappers.length;
        for (
          ;
          i > 0 &&
          (this.wrappers[i - 1].rank - t.rank ||
            this.wrappers[i - 1].to - t.to) < 0;
        )
          i--;
        this.wrappers.splice(i, 0, t);
      }
    this.wrapperPos = this.pos;
  }
  getBlockPos() {
    var e;
    this.updateBlockWrappers();
    let t = this.root;
    for (let i of this.wrappers) {
      let o = t.lastChild;
      if (i.from < this.pos && o instanceof Do && o.wrapper.eq(i.wrapper))
        t = o;
      else {
        let o = Do.of(
          i.wrapper,
          null === (e = this.cache.find(Do, (e) => e.wrapper.eq(i.wrapper))) ||
            void 0 === e
            ? void 0
            : e.dom,
        );
        (t.append(o), (t = o));
      }
    }
    return t;
  }
  blockPosCovered() {
    let e = this.lastBlock;
    return null != e && !e.breakAfter && (!e.isWidget() || (160 & e.flags) > 0);
  }
  getBuffer(e) {
    let t = 2 | (e < 0 ? 16 : 32),
      i = this.cache.find(Ro, void 0, 1);
    return (i && (i.flags = t), i || new Ro(t));
  }
  flushBuffer() {
    !this.afterWidget ||
      32 & this.afterWidget.flags ||
      (this.afterWidget.parent.append(this.getBuffer(-1)),
      (this.afterWidget = null));
  }
}
class zo {
  constructor(e) {
    ((this.skipCount = 0),
      (this.text = ""),
      (this.textOff = 0),
      (this.cursor = e.iter()));
  }
  skip(e) {
    this.textOff + e <= this.text.length
      ? (this.textOff += e)
      : ((this.skipCount += e - (this.text.length - this.textOff)),
        (this.text = ""),
        (this.textOff = 0));
  }
  next(e) {
    if (this.textOff == this.text.length) {
      let {
        value: t,
        lineBreak: i,
        done: o,
      } = this.cursor.next(this.skipCount);
      if (((this.skipCount = 0), o))
        throw new Error("Ran out of text content when drawing inline views");
      this.text = t;
      let n = (this.textOff = Math.min(e, t.length));
      return i ? null : t.slice(0, n);
    }
    let t = Math.min(this.text.length, this.textOff + e),
      i = this.text.slice(this.textOff, t);
    return ((this.textOff = t), i);
  }
}
const Vo = [No, Oo, Po, Lo, Ro, Do, Io];
for (let e = 0; e < Vo.length; e++) Vo[e].bucket = e;
class Wo {
  constructor(e) {
    ((this.view = e),
      (this.buckets = Vo.map(() => [])),
      (this.index = Vo.map(() => 0)),
      (this.reused = new Map()));
  }
  add(e) {
    let t = e.constructor.bucket,
      i = this.buckets[t];
    i.length < 6
      ? i.push(e)
      : (i[(this.index[t] = (this.index[t] + 1) % 6)] = e);
  }
  find(e, t, i = 2) {
    let o = e.bucket,
      n = this.buckets[o],
      s = this.index[o];
    for (let e = n.length - 1; e >= 0; e--) {
      let r = (e + s) % n.length,
        a = n[r];
      if ((!t || t(a)) && !this.reused.has(a))
        return (
          n.splice(r, 1),
          r < s && this.index[o]--,
          this.reused.set(a, i),
          a
        );
    }
    return null;
  }
  findWidget(e, t, i) {
    let o = this.buckets[0];
    if (o.length)
      for (let n = 0, s = 0; ; n++) {
        if (n == o.length) {
          if (s) return null;
          ((s = 1), (n = 0));
        }
        let r = o[n];
        if (
          !this.reused.has(r) &&
          (0 == s
            ? r.widget.compare(e)
            : r.widget.constructor == e.constructor &&
              e.updateDOM(r.dom, this.view))
        )
          return (
            o.splice(n, 1),
            n < this.index[0] && this.index[0]--,
            r.widget == e && r.length == t && (497 & r.flags) == i
              ? (this.reused.set(r, 1), r)
              : (this.reused.set(r, 2),
                new No(r.dom, t, e, (-498 & r.flags) | i))
          );
      }
  }
  reuse(e) {
    return (this.reused.set(e, 1), e);
  }
  maybeReuse(e, t = 2) {
    if (!this.reused.has(e)) return (this.reused.set(e, t), e.dom);
  }
  clear() {
    for (let e = 0; e < this.buckets.length; e++)
      this.buckets[e].length = this.index[e] = 0;
  }
}
class Ho {
  constructor(e, t, i, o, n) {
    ((this.view = e),
      (this.decorations = o),
      (this.disallowBlockEffectsFor = n),
      (this.openWidget = !1),
      (this.openMarks = 0),
      (this.cache = new Wo(e)),
      (this.text = new zo(e.state.doc)),
      (this.builder = new _o(this.cache, new Io(e, e.contentDOM), ct.iter(i))),
      this.cache.reused.set(t, 2),
      (this.old = new Fo(t)),
      (this.reuseWalker = {
        skip: (e, t, i) => {
          if ((this.cache.add(e), e.isComposite())) return !1;
        },
        enter: (e) => this.cache.add(e),
        leave: () => {},
        break: () => {},
      }));
  }
  run(e, t) {
    let i = t && this.getCompositionContext(t.text);
    for (let o = 0, n = 0, s = 0; ; ) {
      let r = s < e.length ? e[s++] : null,
        a = r ? r.fromA : this.old.root.length;
      if (a > o) {
        let e = a - o;
        (this.preserve(e, !s, !r), (o = a), (n += e));
      }
      if (!r) break;
      (t && r.fromA <= t.range.fromA && r.toA >= t.range.toA
        ? (this.forward(
            r.fromA,
            t.range.fromA,
            t.range.fromA < t.range.toA ? 1 : -1,
          ),
          this.emit(n, t.range.fromB),
          this.cache.clear(),
          this.builder.addComposition(t, i),
          this.text.skip(t.range.toB - t.range.fromB),
          this.forward(t.range.fromA, r.toA),
          this.emit(t.range.toB, r.toB))
        : (this.forward(r.fromA, r.toA), this.emit(n, r.toB)),
        (n = r.toB),
        (o = r.toA));
    }
    return (this.builder.curLine && this.builder.endLine(), this.builder.root);
  }
  preserve(e, t, i) {
    let o = (function (e) {
        let t = [];
        for (let i = e.parents.length; i > 1; i--) {
          let o = i == e.parents.length ? e.tile : e.parents[i].tile;
          o instanceof Lo && t.push(o.mark);
        }
        return t;
      })(this.old),
      n = this.openMarks;
    (this.old.advance(e, i ? 1 : -1, {
      skip: (e, t, i) => {
        if (e.isWidget())
          if (this.openWidget) this.builder.continueWidget(i - t);
          else {
            let s =
              i > 0 || t < e.length
                ? No.of(
                    e.widget,
                    this.view,
                    i - t,
                    496 & e.flags,
                    this.cache.maybeReuse(e),
                  )
                : this.cache.reuse(e);
            256 & s.flags
              ? ((s.flags &= -2), this.builder.addBlockWidget(s))
              : (this.builder.ensureLine(null),
                this.builder.addInlineWidget(s, o, n),
                (n = o.length));
          }
        else if (e.isText())
          (this.builder.ensureLine(null),
            t || i != e.length
              ? (this.cache.add(e),
                this.builder.addText(e.text.slice(t, i), o, n))
              : this.builder.addText(e.text, o, n, this.cache.reuse(e)),
            (n = o.length));
        else if (e.isLine())
          ((e.flags &= -2),
            this.cache.reused.set(e, 1),
            this.builder.addLine(e));
        else if (e instanceof Ro) this.cache.add(e);
        else {
          if (!(e instanceof Lo)) return !1;
          (this.builder.ensureLine(null),
            this.builder.addMark(e, o, n),
            this.cache.reused.set(e, 1),
            (n = o.length));
        }
        this.openWidget = !1;
      },
      enter: (e) => {
        (e.isLine()
          ? this.builder.addLineStart(e.attrs, this.cache.maybeReuse(e))
          : (this.cache.add(e), e instanceof Lo && o.unshift(e.mark)),
          (this.openWidget = !1));
      },
      leave: (e) => {
        e.isLine()
          ? o.length && (o.length = n = 0)
          : e instanceof Lo && (o.shift(), (n = Math.min(n, o.length)));
      },
      break: () => {
        (this.builder.addBreak(), (this.openWidget = !1));
      },
    }),
      this.text.skip(e));
  }
  emit(e, t) {
    let i = null,
      o = this.builder,
      n = 0,
      s = ct.spans(this.decorations, e, t, {
        point: (e, t, s, r, a, l) => {
          if (s instanceof Qt) {
            if (this.disallowBlockEffectsFor[l]) {
              if (s.block)
                throw new RangeError(
                  "Block decorations may not be specified via plugins",
                );
              if (t > this.view.state.doc.lineAt(e).to)
                throw new RangeError(
                  "Decorations that replace line breaks may not be specified via plugins",
                );
            }
            if (((n = r.length), a > r.length)) o.continueWidget(t - e);
            else {
              let n = s.widget || (s.block ? Yo.block : Yo.inline),
                l = (function (e) {
                  let t = e.isReplace
                    ? (e.startSide < 0 ? 64 : 0) | (e.endSide > 0 ? 128 : 0)
                    : e.startSide > 0
                      ? 32
                      : 16;
                  e.block && (t |= 256);
                  return t;
                })(s),
                c =
                  this.cache.findWidget(n, t - e, l) ||
                  No.of(n, this.view, t - e, l);
              s.block
                ? (s.startSide > 0 && o.addLineStartIfNotCovered(i),
                  o.addBlockWidget(c))
                : (o.ensureLine(i), o.addInlineWidget(c, r, a));
            }
            i = null;
          } else
            i = (function (e, t) {
              let i = t.spec.attributes,
                o = t.spec.class;
              if (!i && !o) return e;
              e || (e = { class: "cm-line" });
              i && Ht(i, e);
              o && (e.class += " " + o);
              return e;
            })(i, s);
          t > e && this.text.skip(t - e);
        },
        span: (e, t, n, s) => {
          for (let r = e; r < t; ) {
            let e = this.text.next(Math.min(512, t - r));
            (null == e
              ? (o.addLineStartIfNotCovered(i), o.addBreak(), r++)
              : (o.ensureLine(i), o.addText(e, n, s), (r += e.length)),
              (i = null));
          }
        },
      });
    (o.addLineStartIfNotCovered(i),
      (this.openWidget = s > n),
      (this.openMarks = s));
  }
  forward(e, t, i = 1) {
    t - e <= 10
      ? this.old.advance(t - e, i, this.reuseWalker)
      : (this.old.advance(5, -1, this.reuseWalker),
        this.old.advance(t - e - 10, -1),
        this.old.advance(5, i, this.reuseWalker));
  }
  getCompositionContext(e) {
    let t = [],
      i = null;
    for (let o = e.parentNode; ; o = o.parentNode) {
      let e = Eo.get(o);
      if (o == this.view.contentDOM) break;
      e instanceof Lo
        ? t.push(e)
        : (null == e ? void 0 : e.isLine())
          ? (i = e)
          : "DIV" != o.nodeName || i || o == this.view.contentDOM
            ? t.push(
                Lo.of(
                  new Jt({
                    tagName: o.nodeName.toLowerCase(),
                    attributes: Yt(o),
                  }),
                  o,
                ),
              )
            : (i = new Oo(o, Uo));
    }
    return { line: i, marks: t };
  }
}
function $o(e, t) {
  let i = (e) => {
    for (let o of e.children)
      if ((t ? o.isText() : o.length) || i(o)) return !0;
    return !1;
  };
  return i(e);
}
const Uo = { class: "cm-line" };
function jo(e) {
  let t = Eo.get(e);
  return (t && t.setDOM(e.cloneNode()), e);
}
class Yo extends Gt {
  constructor(e) {
    (super(), (this.tag = e));
  }
  eq(e) {
    return e.tag == this.tag;
  }
  toDOM() {
    return document.createElement(this.tag);
  }
  updateDOM(e) {
    return e.nodeName.toLowerCase() == this.tag;
  }
  get isHidden() {
    return !0;
  }
}
((Yo.inline = new Yo("span")), (Yo.block = new Yo("div")));
const Go = new (class extends Gt {
  toDOM() {
    return document.createElement("br");
  }
  get isHidden() {
    return !0;
  }
  get editable() {
    return !0;
  }
})();
class Zo {
  constructor(e) {
    ((this.view = e),
      (this.decorations = []),
      (this.blockWrappers = []),
      (this.dynamicDecorationMap = [!1]),
      (this.domChanged = null),
      (this.hasComposition = null),
      (this.editContextFormatting = Kt.none),
      (this.lastCompositionAfterCursor = !1),
      (this.minWidth = 0),
      (this.minWidthFrom = 0),
      (this.minWidthTo = 0),
      (this.impreciseAnchor = null),
      (this.impreciseHead = null),
      (this.forceSelection = !1),
      (this.lastUpdate = Date.now()),
      this.updateDeco(),
      (this.tile = new Io(e, e.contentDOM)),
      this.updateInner([new ko(0, 0, 0, e.state.doc.length)], null));
  }
  update(e) {
    var t;
    let i = e.changedRanges;
    (this.minWidth > 0 &&
      i.length &&
      (i.every(
        ({ fromA: e, toA: t }) => t < this.minWidthFrom || e > this.minWidthTo,
      )
        ? ((this.minWidthFrom = e.changes.mapPos(this.minWidthFrom, 1)),
          (this.minWidthTo = e.changes.mapPos(this.minWidthTo, 1)))
        : (this.minWidth = this.minWidthFrom = this.minWidthTo = 0)),
      this.updateEditContextFormatting(e));
    let o = -1;
    this.view.inputState.composing >= 0 &&
      !this.view.observer.editContext &&
      ((null === (t = this.domChanged) || void 0 === t ? void 0 : t.newSel)
        ? (o = this.domChanged.newSel.head)
        : (function (e, t) {
            let i = !1;
            t &&
              e.iterChangedRanges((e, o) => {
                e < t.to && o > t.from && (i = !0);
              });
            return i;
          })(e.changes, this.hasComposition) ||
          e.selectionSet ||
          (o = e.state.selection.main.head));
    let n =
      o > -1
        ? (function (e, t, i) {
            let o = Jo(e, i);
            if (!o) return null;
            let { node: n, from: s, to: r } = o,
              a = n.nodeValue;
            if (/[\n\r]/.test(a)) return null;
            if (e.state.doc.sliceString(o.from, o.to) != a) return null;
            let l = t.invertedDesc;
            return { range: new ko(l.mapPos(s), l.mapPos(r), s, r), text: n };
          })(this.view, e.changes, o)
        : null;
    if (((this.domChanged = null), this.hasComposition)) {
      let { from: t, to: o } = this.hasComposition;
      i = new ko(
        t,
        o,
        e.changes.mapPos(t, -1),
        e.changes.mapPos(o, 1),
      ).addToSet(i.slice());
    }
    ((this.hasComposition = n
      ? { from: n.range.fromB, to: n.range.toB }
      : null),
      (Wt.ie || Wt.chrome) &&
        !n &&
        e &&
        e.state.doc.lines != e.startState.doc.lines &&
        (this.forceSelection = !0));
    let s = this.decorations,
      r = this.blockWrappers;
    this.updateDeco();
    let a = (function (e, t, i) {
      let o = new Xo();
      return (ct.compare(e, t, i, o), o.changes);
    })(s, this.decorations, e.changes);
    a.length && (i = ko.extendWithRanges(i, a));
    let l = (function (e, t, i) {
      let o = new Qo();
      return (ct.compare(e, t, i, o), o.changes);
    })(r, this.blockWrappers, e.changes);
    return (
      l.length && (i = ko.extendWithRanges(i, l)),
      n &&
        !i.some((e) => e.fromA <= n.range.fromA && e.toA >= n.range.toA) &&
        (i = n.range.addToSet(i.slice())),
      !(2 & this.tile.flags && 0 == i.length) &&
        (this.updateInner(i, n),
        e.transactions.length && (this.lastUpdate = Date.now()),
        !0)
    );
  }
  updateInner(e, t) {
    this.view.viewState.mustMeasureContent = !0;
    let { observer: i } = this.view;
    i.ignore(() => {
      if (t || e.length) {
        let i = this.tile,
          o = new Ho(
            this.view,
            i,
            this.blockWrappers,
            this.decorations,
            this.dynamicDecorationMap,
          );
        ((this.tile = o.run(e, t)), Ko(i, o.cache.reused));
      }
      ((this.tile.dom.style.height =
        this.view.viewState.contentHeight / this.view.scaleY + "px"),
        (this.tile.dom.style.flexBasis = this.minWidth
          ? this.minWidth + "px"
          : ""));
      let o =
        Wt.chrome || Wt.ios
          ? { node: i.selectionRange.focusNode, written: !1 }
          : void 0;
      (this.tile.sync(o),
        !o ||
          (!o.written &&
            i.selectionRange.focusNode == o.node &&
            this.tile.dom.contains(o.node)) ||
          (this.forceSelection = !0),
        (this.tile.dom.style.height = ""));
    });
    let o = [];
    if (
      this.view.viewport.from ||
      this.view.viewport.to < this.view.state.doc.length
    )
      for (let e of this.tile.children)
        e.isWidget() && e.widget instanceof en && o.push(e.dom);
    i.updateGaps(o);
  }
  updateEditContextFormatting(e) {
    this.editContextFormatting = this.editContextFormatting.map(e.changes);
    for (let t of e.transactions)
      for (let e of t.effects)
        e.is(no) && (this.editContextFormatting = e.value);
  }
  updateSelection(e = !1, t = !1) {
    (!e && this.view.observer.selectionRange.focusNode) ||
      this.view.observer.readSelectionRange();
    let { dom: i } = this.tile,
      o = this.view.root.activeElement,
      n = o == i,
      s =
        !n &&
        !(this.view.state.facet(ro) || i.tabIndex > -1) &&
        si(i, this.view.observer.selectionRange) &&
        !(o && i.contains(o));
    if (!(n || t || s)) return;
    let r = this.forceSelection;
    this.forceSelection = !1;
    let a,
      l,
      c = this.view.state.selection.main;
    if (
      (c.empty
        ? (l = a = this.inlineDOMNearPos(c.anchor, c.assoc || 1))
        : ((l = this.inlineDOMNearPos(c.head, c.head == c.from ? 1 : -1)),
          (a = this.inlineDOMNearPos(c.anchor, c.anchor == c.from ? 1 : -1))),
      Wt.gecko &&
        c.empty &&
        !this.hasComposition &&
        1 == (d = a).node.nodeType &&
        d.node.firstChild &&
        (0 == d.offset ||
          "false" == d.node.childNodes[d.offset - 1].contentEditable) &&
        (d.offset == d.node.childNodes.length ||
          "false" == d.node.childNodes[d.offset].contentEditable))
    ) {
      let e = document.createTextNode("");
      (this.view.observer.ignore(() =>
        a.node.insertBefore(e, a.node.childNodes[a.offset] || null),
      ),
        (a = l = new Si(e, 0)),
        (r = !0));
    }
    var d;
    let h = this.view.observer.selectionRange;
    ((!r &&
      h.focusNode &&
      ((ai(a.node, a.offset, h.anchorNode, h.anchorOffset) &&
        ai(l.node, l.offset, h.focusNode, h.focusOffset)) ||
        this.suppressWidgetCursorChange(h, c))) ||
      (this.view.observer.ignore(() => {
        Wt.android &&
          Wt.chrome &&
          i.contains(h.focusNode) &&
          (function (e, t) {
            for (let i = e; i && i != t; i = i.assignedSlot || i.parentNode)
              if (1 == i.nodeType && "false" == i.contentEditable) return !0;
            return !1;
          })(h.focusNode, i) &&
          (i.blur(), i.focus({ preventScroll: !0 }));
        let e = oi(this.view.root);
        if (e)
          if (c.empty) {
            if (Wt.gecko) {
              let e =
                ((t = a.node),
                (n = a.offset),
                1 != t.nodeType
                  ? 0
                  : (n && "false" == t.childNodes[n - 1].contentEditable
                      ? 1
                      : 0) |
                    (n < t.childNodes.length &&
                    "false" == t.childNodes[n].contentEditable
                      ? 2
                      : 0));
              if (e && 3 != e) {
                let t = (1 == e ? xi : ki)(a.node, a.offset);
                t && (a = new Si(t.node, t.offset));
              }
            }
            (e.collapse(a.node, a.offset),
              null != c.bidiLevel &&
                void 0 !== e.caretBidiLevel &&
                (e.caretBidiLevel = c.bidiLevel));
          } else if (e.extend) {
            e.collapse(a.node, a.offset);
            try {
              e.extend(l.node, l.offset);
            } catch (e) {}
          } else {
            let t = document.createRange();
            (c.anchor > c.head && ([a, l] = [l, a]),
              t.setEnd(l.node, l.offset),
              t.setStart(a.node, a.offset),
              e.removeAllRanges(),
              e.addRange(t));
          }
        else;
        var t, n;
        s && this.view.root.activeElement == i && (i.blur(), o && o.focus());
      }),
      this.view.observer.setSelectionRange(a, l)),
      (this.impreciseAnchor = a.precise
        ? null
        : new Si(h.anchorNode, h.anchorOffset)),
      (this.impreciseHead = l.precise
        ? null
        : new Si(h.focusNode, h.focusOffset)));
  }
  suppressWidgetCursorChange(e, t) {
    return (
      this.hasComposition &&
      t.empty &&
      ai(e.focusNode, e.focusOffset, e.anchorNode, e.anchorOffset) &&
      this.posFromDOM(e.focusNode, e.focusOffset) == t.head
    );
  }
  enforceCursorAssoc() {
    if (this.hasComposition) return;
    let { view: e } = this,
      t = e.state.selection.main,
      i = oi(e.root),
      { anchorNode: o, anchorOffset: n } = e.observer.selectionRange;
    if (!(i && t.empty && t.assoc && i.modify)) return;
    let s = this.lineAt(t.head, t.assoc);
    if (!s) return;
    let r = s.posAtStart;
    if (t.head == r || t.head == r + s.length) return;
    let a = this.coordsAt(t.head, -1),
      l = this.coordsAt(t.head, 1);
    if (!a || !l || a.bottom > l.top) return;
    let c = this.domAtPos(t.head + t.assoc, t.assoc);
    (i.collapse(c.node, c.offset),
      i.modify("move", t.assoc < 0 ? "forward" : "backward", "lineboundary"),
      e.observer.readSelectionRange());
    let d = e.observer.selectionRange;
    e.docView.posFromDOM(d.anchorNode, d.anchorOffset) != t.from &&
      i.collapse(o, n);
  }
  posFromDOM(e, t) {
    let i = this.tile.nearest(e);
    if (!i)
      return 2 & this.tile.dom.compareDocumentPosition(e)
        ? 0
        : this.view.state.doc.length;
    let o = i.posAtStart;
    if (!i.isComposite())
      return i.isText() ? (e == i.dom ? o + t : o + (t ? i.length : 0)) : o;
    {
      let n;
      if (e == i.dom) n = i.dom.childNodes[t];
      else {
        let o = 0 == hi(e) ? 0 : 0 == t ? -1 : 1;
        for (;;) {
          let t = e.parentNode;
          if (t == i.dom) break;
          (0 == o &&
            t.firstChild != t.lastChild &&
            (o = e == t.firstChild ? -1 : 1),
            (e = t));
        }
        n = o < 0 ? e : e.nextSibling;
      }
      if (n == i.dom.firstChild) return o;
      for (; n && !Eo.get(n); ) n = n.nextSibling;
      if (!n) return o + i.length;
      for (let e = 0, t = o; ; e++) {
        let o = i.children[e];
        if (o.dom == n) return t;
        t += o.length + o.breakAfter;
      }
    }
  }
  domAtPos(e, t) {
    let { tile: i, offset: o } = this.tile.resolveBlock(e, t);
    return i.isWidget() ? i.domPosFor(e, t) : i.domIn(o, t);
  }
  inlineDOMNearPos(e, t) {
    let i,
      o,
      n = -1,
      s = !1,
      r = -1,
      a = !1;
    return (
      this.tile.blockTiles((t, l) => {
        if (t.isWidget()) {
          if (32 & t.flags && l >= e) return !0;
          16 & t.flags && (s = !0);
        } else {
          let c = l + t.length;
          if (
            (l <= e && ((i = t), (n = e - l), (s = c < e)),
            c >= e && !o && ((o = t), (r = e - l), (a = l > e)),
            l > e && o)
          )
            return !0;
        }
      }),
      i || o
        ? (s && o ? (i = null) : a && i && (o = null),
          (i && t < 0) || !o ? i.domIn(n, t) : o.domIn(r, t))
        : this.domAtPos(e, t)
    );
  }
  coordsAt(e, t) {
    let { tile: i, offset: o } = this.tile.resolveBlock(e, t);
    return i.isWidget()
      ? i.widget instanceof en
        ? null
        : i.coordsInWidget(o, t, !0)
      : i.coordsIn(o, t);
  }
  lineAt(e, t) {
    let { tile: i } = this.tile.resolveBlock(e, t);
    return i.isLine() ? i : null;
  }
  coordsForChar(e) {
    let { tile: t, offset: i } = this.tile.resolveBlock(e, 1);
    if (!t.isLine()) return null;
    return (function e(t, i) {
      if (t.isComposite())
        for (let o of t.children) {
          if (o.length >= i) {
            let t = e(o, i);
            if (t) return t;
          }
          if ((i -= o.length) < 0) break;
        }
      else if (t.isText() && i < t.length) {
        let e = ee(t.text, i);
        if (e == i) return null;
        let o = wi(t.dom, i, e).getClientRects();
        for (let e = 0; e < o.length; e++) {
          let t = o[e];
          if (e == o.length - 1 || (t.top < t.bottom && t.left < t.right))
            return t;
        }
      }
      return null;
    })(t, i);
  }
  measureVisibleLineHeights(e) {
    let t = [],
      { from: i, to: o } = e,
      n = this.view.contentDOM.clientWidth,
      s = n > Math.max(this.view.scrollDOM.clientWidth, this.minWidth) + 1,
      r = -1,
      a = this.view.textDirection == Ti.LTR,
      l = 0,
      c = (e, d, h) => {
        for (let u = 0; u < e.children.length && !(d > o); u++) {
          let o = e.children[u],
            p = d + o.length,
            m = o.dom.getBoundingClientRect(),
            { height: g } = m;
          if ((h && !u && (l += m.top - h.top), o instanceof Do))
            p > i && c(o, d, m);
          else if (d >= i && (l > 0 && t.push(-l), t.push(g + l), (l = 0), s)) {
            let e = o.dom.lastChild,
              t = e ? ri(e) : [];
            if (t.length) {
              let e = t[t.length - 1],
                i = a ? e.right - m.left : m.right - e.left;
              i > r &&
                ((r = i),
                (this.minWidth = n),
                (this.minWidthFrom = d),
                (this.minWidthTo = p));
            }
          }
          (h && u == e.children.length - 1 && (l += h.bottom - m.bottom),
            (d = p + o.breakAfter));
        }
      };
    return (c(this.tile, 0, null), t);
  }
  textDirectionAt(e) {
    let { tile: t } = this.tile.resolveBlock(e, 1);
    return "rtl" == getComputedStyle(t.dom).direction ? Ti.RTL : Ti.LTR;
  }
  measureTextSize() {
    let e = this.tile.blockTiles((e) => {
      if (e.isLine() && e.children.length && e.length <= 20) {
        let t,
          i = 0;
        for (let o of e.children) {
          if (!o.isText() || /[^ -~]/.test(o.text)) return;
          let e = ri(o.dom);
          if (1 != e.length) return;
          ((i += e[0].width), (t = e[0].height));
        }
        if (i)
          return {
            lineHeight: e.dom.getBoundingClientRect().height,
            charWidth: i / e.length,
            textHeight: t,
          };
      }
    });
    if (e) return e;
    let t,
      i,
      o,
      n = document.createElement("div");
    return (
      (n.className = "cm-line"),
      (n.style.width = "99999px"),
      (n.style.position = "absolute"),
      (n.textContent = "abc def ghi jkl mno pqr stu"),
      this.view.observer.ignore(() => {
        this.tile.dom.appendChild(n);
        let e = ri(n.firstChild)[0];
        ((t = n.getBoundingClientRect().height),
          (i = e && e.width ? e.width / 27 : 7),
          (o = e && e.height ? e.height : t),
          n.remove());
      }),
      { lineHeight: t, charWidth: i, textHeight: o }
    );
  }
  computeBlockGapDeco() {
    let e = [],
      t = this.view.viewState;
    for (let i = 0, o = 0; ; o++) {
      let n = o == t.viewports.length ? null : t.viewports[o],
        s = n ? n.from - 1 : this.view.state.doc.length;
      if (s > i) {
        let o =
          (t.lineBlockAt(s).bottom - t.lineBlockAt(i).top) / this.view.scaleY;
        e.push(
          Kt.replace({
            widget: new en(o),
            block: !0,
            inclusive: !0,
            isBlockGap: !0,
          }).range(i, s),
        );
      }
      if (!n) break;
      i = n.to + 1;
    }
    return Kt.set(e);
  }
  updateDeco() {
    let e = 1,
      t = this.view.state
        .facet(mo)
        .map((t) =>
          (this.dynamicDecorationMap[e++] = "function" == typeof t)
            ? t(this.view)
            : t,
        ),
      i = !1,
      o = this.view.state.facet(fo).map((e, t) => {
        let o = "function" == typeof e;
        return (o && (i = !0), o ? e(this.view) : e);
      });
    for (
      o.length && ((this.dynamicDecorationMap[e++] = i), t.push(ct.join(o))),
        this.decorations = [
          this.editContextFormatting,
          ...t,
          this.computeBlockGapDeco(),
          this.view.viewState.lineGapDeco,
        ];
      e < this.decorations.length;
    )
      this.dynamicDecorationMap[e++] = !1;
    this.blockWrappers = this.view.state
      .facet(go)
      .map((e) => ("function" == typeof e ? e(this.view) : e));
  }
  scrollIntoView(e) {
    if (e.isSnapshot) {
      let t = this.view.viewState.lineBlockAt(e.range.head);
      return (
        (this.view.scrollDOM.scrollTop = t.top - e.yMargin),
        void (this.view.scrollDOM.scrollLeft = e.xMargin)
      );
    }
    for (let t of this.view.state.facet(to))
      try {
        if (t(this.view, e.range, e)) return !0;
      } catch (e) {
        so(this.view.state, e, "scroll handler");
      }
    let t,
      { range: i } = e,
      o = this.coordsAt(i.head, i.empty ? i.assoc : i.head > i.anchor ? -1 : 1);
    if (!o) return;
    !i.empty &&
      (t = this.coordsAt(i.anchor, i.anchor > i.head ? -1 : 1)) &&
      (o = {
        left: Math.min(o.left, t.left),
        top: Math.min(o.top, t.top),
        right: Math.max(o.right, t.right),
        bottom: Math.max(o.bottom, t.bottom),
      });
    let n = Co(this.view),
      s = {
        left: o.left - n.left,
        top: o.top - n.top,
        right: o.right + n.right,
        bottom: o.bottom + n.bottom,
      },
      { offsetWidth: r, offsetHeight: a } = this.view.scrollDOM;
    !(function (e, t, i, o, n, s, r, a) {
      let l = e.ownerDocument,
        c = l.defaultView || window;
      for (let d = e, h = !1; d && !h; )
        if (1 == d.nodeType) {
          let e,
            u = d == l.body,
            p = 1,
            m = 1;
          if (u) e = pi(c);
          else {
            if (
              (/^(fixed|sticky)$/.test(getComputedStyle(d).position) &&
                (h = !0),
              d.scrollHeight <= d.clientHeight &&
                d.scrollWidth <= d.clientWidth)
            ) {
              d = d.assignedSlot || d.parentNode;
              continue;
            }
            let t = d.getBoundingClientRect();
            (({ scaleX: p, scaleY: m } = mi(d, t)),
              (e = {
                left: t.left,
                right: t.left + d.clientWidth * p,
                top: t.top,
                bottom: t.top + d.clientHeight * m,
              }));
          }
          let g = 0,
            f = 0;
          if ("nearest" == n)
            t.top < e.top
              ? ((f = t.top - (e.top + r)),
                i > 0 &&
                  t.bottom > e.bottom + f &&
                  (f = t.bottom - e.bottom + r))
              : t.bottom > e.bottom &&
                ((f = t.bottom - e.bottom + r),
                i < 0 && t.top - f < e.top && (f = t.top - (e.top + r)));
          else {
            let o = t.bottom - t.top,
              s = e.bottom - e.top;
            f =
              ("center" == n && o <= s
                ? t.top + o / 2 - s / 2
                : "start" == n || ("center" == n && i < 0)
                  ? t.top - r
                  : t.bottom - s + r) - e.top;
          }
          if (
            ("nearest" == o
              ? t.left < e.left
                ? ((g = t.left - (e.left + s)),
                  i > 0 && t.right > e.right + g && (g = t.right - e.right + s))
                : t.right > e.right &&
                  ((g = t.right - e.right + s),
                  i < 0 && t.left < e.left + g && (g = t.left - (e.left + s)))
              : (g =
                  ("center" == o
                    ? t.left + (t.right - t.left) / 2 - (e.right - e.left) / 2
                    : ("start" == o) == a
                      ? t.left - s
                      : t.right - (e.right - e.left) + s) - e.left),
            g || f)
          )
            if (u) c.scrollBy(g, f);
            else {
              let e = 0,
                i = 0;
              if (f) {
                let e = d.scrollTop;
                ((d.scrollTop += f / m), (i = (d.scrollTop - e) * m));
              }
              if (g) {
                let t = d.scrollLeft;
                ((d.scrollLeft += g / p), (e = (d.scrollLeft - t) * p));
              }
              ((t = {
                left: t.left - e,
                top: t.top - i,
                right: t.right - e,
                bottom: t.bottom - i,
              }),
                e && Math.abs(e - g) < 1 && (o = "nearest"),
                i && Math.abs(i - f) < 1 && (n = "nearest"));
            }
          if (u) break;
          ((t.top < e.top ||
            t.bottom > e.bottom ||
            t.left < e.left ||
            t.right > e.right) &&
            (t = {
              left: Math.max(t.left, e.left),
              right: Math.min(t.right, e.right),
              top: Math.max(t.top, e.top),
              bottom: Math.min(t.bottom, e.bottom),
            }),
            (d = d.assignedSlot || d.parentNode));
        } else {
          if (11 != d.nodeType) break;
          d = d.host;
        }
    })(
      this.view.scrollDOM,
      s,
      i.head < i.anchor ? -1 : 1,
      e.x,
      e.y,
      Math.max(Math.min(e.xMargin, r), -r),
      Math.max(Math.min(e.yMargin, a), -a),
      this.view.textDirection == Ti.LTR,
    );
  }
  lineHasWidget(e) {
    let t = (e) => e.isWidget() || e.children.some(t);
    return t(this.tile.resolveBlock(e, 1).tile);
  }
  destroy() {
    Ko(this.tile);
  }
}
function Ko(e, t) {
  let i = null == t ? void 0 : t.get(e);
  if (1 != i) {
    null == i && e.destroy();
    for (let i of e.children) Ko(i, t);
  }
}
function Jo(e, t) {
  let i = e.observer.selectionRange;
  if (!i.focusNode) return null;
  let o = xi(i.focusNode, i.focusOffset),
    n = ki(i.focusNode, i.focusOffset),
    s = o || n;
  if (n && o && n.node != o.node) {
    let t = Eo.get(n.node);
    if (!t || (t.isText() && t.text != n.node.nodeValue)) s = n;
    else if (e.docView.lastCompositionAfterCursor) {
      let e = Eo.get(o.node);
      !e || (e.isText() && e.text != o.node.nodeValue) || (s = n);
    }
  }
  if (((e.docView.lastCompositionAfterCursor = s != o), !s)) return null;
  let r = t - s.offset;
  return { from: r, to: r + s.node.nodeValue.length, node: s.node };
}
let Xo = class {
  constructor() {
    this.changes = [];
  }
  compareRange(e, t) {
    ti(e, t, this.changes);
  }
  comparePoint(e, t) {
    ti(e, t, this.changes);
  }
  boundChange(e) {
    ti(e, e, this.changes);
  }
};
class Qo {
  constructor() {
    this.changes = [];
  }
  compareRange(e, t) {
    ti(e, t, this.changes);
  }
  comparePoint() {}
  boundChange(e) {
    ti(e, e, this.changes);
  }
}
class en extends Gt {
  constructor(e) {
    (super(), (this.height = e));
  }
  toDOM() {
    let e = document.createElement("div");
    return ((e.className = "cm-gap"), this.updateDOM(e), e);
  }
  eq(e) {
    return e.height == this.height;
  }
  updateDOM(e) {
    return ((e.style.height = this.height + "px"), !0);
  }
  get editable() {
    return !0;
  }
  get estimatedHeight() {
    return this.height;
  }
  ignoreEvent() {
    return !1;
  }
}
function tn(e, t, i, o, n) {
  let s = Math.round((o - t.left) * e.defaultCharacterWidth);
  if (e.lineWrapping && i.height > 1.5 * e.defaultLineHeight) {
    let t = e.viewState.heightOracle.textHeight;
    s +=
      Math.floor((n - i.top - 0.5 * (e.defaultLineHeight - t)) / t) *
      e.viewState.heightOracle.lineLength;
  }
  let r = e.state.sliceDoc(i.from, i.to);
  return (
    i.from +
    (function (e, t, i, o) {
      for (let o = 0, n = 0; ; ) {
        if (n >= t) return o;
        if (o == e.length) break;
        ((n += 9 == e.charCodeAt(o) ? i - (n % i) : 1), (o = ee(e, o)));
      }
      return !0 === o ? -1 : e.length;
    })(r, s, e.state.tabSize)
  );
}
function on(e, t, i, o) {
  let n = (function (e, t, i) {
      let o = e.lineBlockAt(t);
      if (Array.isArray(o.type)) {
        let e;
        for (let n of o.type) {
          if (n.from > t) break;
          if (!(n.to < t)) {
            if (n.from < t && n.to > t) return n;
            (e &&
              (n.type != Zt.Text ||
                (e.type == n.type && !(i < 0 ? n.from < t : n.to > t)))) ||
              (e = n);
          }
        }
        return e || o;
      }
      return o;
    })(e, t.head, t.assoc || -1),
    s =
      o && n.type == Zt.Text && (e.lineWrapping || n.widgetLineBreaks)
        ? e.coordsAtPos(t.assoc < 0 && t.head > n.from ? t.head - 1 : t.head)
        : null;
  if (s) {
    let t = e.dom.getBoundingClientRect(),
      o = e.textDirectionAt(n.from),
      r = e.posAtCoords({
        x: i == (o == Ti.LTR) ? t.right - 1 : t.left + 1,
        y: (s.top + s.bottom) / 2,
      });
    if (null != r) return ue.cursor(r, i ? -1 : 1);
  }
  return ue.cursor(i ? n.to : n.from, i ? -1 : 1);
}
function nn(e, t, i, o) {
  let n = e.state.doc.lineAt(t.head),
    s = e.bidiSpans(n),
    r = e.textDirectionAt(n.from);
  for (let a = t, l = null; ; ) {
    let t = Wi(n, s, r, a, i),
      c = Vi;
    if (!t) {
      if (n.number == (i ? e.state.doc.lines : 1)) return a;
      ((c = "\n"),
        (n = e.state.doc.line(n.number + (i ? 1 : -1))),
        (s = e.bidiSpans(n)),
        (t = e.visualLineSide(n, !i)));
    }
    if (l) {
      if (!l(c)) return a;
    } else {
      if (!o) return t;
      l = o(c);
    }
    a = t;
  }
}
function sn(e, t, i) {
  for (;;) {
    let o = 0;
    for (let n of e)
      n.between(t - 1, t + 1, (e, n, s) => {
        if (t > e && t < n) {
          let s = o || i || (t - e < n - t ? -1 : 1);
          ((t = s < 0 ? e : n), (o = s));
        }
      });
    if (!o) return t;
  }
}
function rn(e, t) {
  let i = null;
  for (let o = 0; o < t.ranges.length; o++) {
    let n = t.ranges[o],
      s = null;
    if (n.empty) {
      let t = sn(e, n.from, 0);
      t != n.from && (s = ue.cursor(t, -1));
    } else {
      let t = sn(e, n.from, -1),
        i = sn(e, n.to, 1);
      (t == n.from && i == n.to) ||
        (s = ue.range(n.from == n.anchor ? t : i, n.from == n.head ? t : i));
    }
    s && (i || (i = t.ranges.slice()), (i[o] = s));
  }
  return i ? ue.create(i, t.mainIndex) : t;
}
function an(e, t, i) {
  let o = sn(
    e.state.facet(bo).map((t) => t(e)),
    i.from,
    t.head > i.from ? -1 : 1,
  );
  return o == i.from ? i : ue.cursor(o, o < i.from ? 1 : -1);
}
class ln {
  constructor(e, t) {
    ((this.pos = e), (this.assoc = t));
  }
}
function cn(e, t, i, o) {
  let n,
    s = e.contentDOM.getBoundingClientRect(),
    r = s.top + e.viewState.paddingTop,
    { x: a, y: l } = t,
    c = l - r;
  for (;;) {
    if (c < 0) return new ln(0, 1);
    if (c > e.viewState.docHeight) return new ln(e.state.doc.length, -1);
    if (((n = e.elementAtHeight(c)), null == o)) break;
    if (n.type == Zt.Text) {
      let t = e.docView.coordsAt(o < 0 ? n.from : n.to, o);
      if (t && (o < 0 ? t.top <= c + r : t.bottom >= c + r)) break;
    }
    let t = e.viewState.heightOracle.textHeight / 2;
    c = o > 0 ? n.bottom + t : n.top - t;
  }
  if (e.viewport.from >= n.to || e.viewport.to <= n.from) {
    if (i) return null;
    if (n.type == Zt.Text) {
      let t = tn(e, s, n, a, l);
      return new ln(t, t == n.from ? 1 : -1);
    }
  }
  if (n.type != Zt.Text)
    return c < (n.top + n.bottom) / 2 ? new ln(n.from, 1) : new ln(n.to, -1);
  let d = e.docView.lineAt(n.from, 2);
  return (
    (d && d.length == n.length) || (d = e.docView.lineAt(n.from, -2)),
    dn(e, d, n.from, a, l)
  );
}
function dn(e, t, i, o, n) {
  let s = -1,
    r = null,
    a = 1e9,
    l = 1e9,
    c = n,
    d = n,
    h = (e, t) => {
      for (let i = 0; i < e.length; i++) {
        let h = e[i];
        if (h.top == h.bottom) continue;
        let u = h.left > o ? h.left - o : h.right < o ? o - h.right : 0,
          p = h.top > n ? h.top - n : h.bottom < n ? n - h.bottom : 0;
        (h.top <= d &&
          h.bottom >= c &&
          ((c = Math.min(h.top, c)), (d = Math.max(h.bottom, d)), (p = 0)),
          (s < 0 || (p - l || u - a) < 0) &&
            (s >= 0 && l && a < u && r.top <= d - 2 && r.bottom >= c + 2
              ? (l = 0)
              : ((s = t), (a = u), (l = p), (r = h))));
      }
    };
  if (t.isText()) {
    for (let e = 0; e < t.length; ) {
      let i = ee(t.text, e);
      if ((h(wi(t.dom, e, i).getClientRects(), e), !a && !l)) break;
      e = i;
    }
    return o > (r.left + r.right) / 2 == (hn(e, s + i) == Ti.LTR)
      ? new ln(i + ee(t.text, s), -1)
      : new ln(i + s, 1);
  }
  {
    if (!t.length) return new ln(i, 1);
    for (let e = 0; e < t.children.length; e++) {
      let i = t.children[e];
      if (
        !(48 & i.flags) &&
        (h(
          (1 == i.dom.nodeType
            ? i.dom
            : wi(i.dom, 0, i.length)
          ).getClientRects(),
          e,
        ),
        !a && !l)
      )
        break;
    }
    let c = t.children[s],
      d = t.posBefore(c, i);
    return c.isComposite() || c.isText()
      ? dn(e, c, d, Math.max(r.left, Math.min(r.right, o)), n)
      : o > (r.left + r.right) / 2 == (hn(e, s + i) == Ti.LTR)
        ? new ln(d + c.length, -1)
        : new ln(d, 1);
  }
}
function hn(e, t) {
  let i = e.state.doc.lineAt(t);
  return e.bidiSpans(i)[Ni.find(e.bidiSpans(i), t - i.from, -1, 1)].dir;
}
const un = "￿";
class pn {
  constructor(e, t) {
    ((this.points = e),
      (this.view = t),
      (this.text = ""),
      (this.lineSeparator = t.state.facet(ot.lineSeparator)));
  }
  append(e) {
    this.text += e;
  }
  lineBreak() {
    this.text += un;
  }
  readRange(e, t) {
    if (!e) return this;
    let i = e.parentNode;
    for (let o = e; ; ) {
      this.findPointBefore(i, o);
      let e = this.text.length;
      this.readNode(o);
      let n = Eo.get(o),
        s = o.nextSibling;
      if (s == t) {
        (null == n ? void 0 : n.breakAfter) &&
          !s &&
          i != this.view.contentDOM &&
          this.lineBreak();
        break;
      }
      let r = Eo.get(s);
      ((n && r
        ? n.breakAfter
        : (n ? n.breakAfter : ci(o)) ||
          (ci(s) &&
            ("BR" != o.nodeName || (null == n ? void 0 : n.isWidget())) &&
            this.text.length > e)) &&
        !gn(s, t) &&
        this.lineBreak(),
        (o = s));
    }
    return (this.findPointBefore(i, t), this);
  }
  readTextNode(e) {
    let t = e.nodeValue;
    for (let i of this.points)
      i.node == e && (i.pos = this.text.length + Math.min(i.offset, t.length));
    for (let i = 0, o = this.lineSeparator ? null : /\r\n?|\n/g; ; ) {
      let n,
        s = -1,
        r = 1;
      if (
        (this.lineSeparator
          ? ((s = t.indexOf(this.lineSeparator, i)),
            (r = this.lineSeparator.length))
          : (n = o.exec(t)) && ((s = n.index), (r = n[0].length)),
        this.append(t.slice(i, s < 0 ? t.length : s)),
        s < 0)
      )
        break;
      if ((this.lineBreak(), r > 1))
        for (let t of this.points)
          t.node == e && t.pos > this.text.length && (t.pos -= r - 1);
      i = s + r;
    }
  }
  readNode(e) {
    let t = Eo.get(e),
      i = t && t.overrideDOMText;
    if (null != i) {
      this.findPointInside(e, i.length);
      for (let e = i.iter(); !e.next().done; )
        e.lineBreak ? this.lineBreak() : this.append(e.value);
    } else
      3 == e.nodeType
        ? this.readTextNode(e)
        : "BR" == e.nodeName
          ? e.nextSibling && this.lineBreak()
          : 1 == e.nodeType && this.readRange(e.firstChild, null);
  }
  findPointBefore(e, t) {
    for (let i of this.points)
      i.node == e && e.childNodes[i.offset] == t && (i.pos = this.text.length);
  }
  findPointInside(e, t) {
    for (let i of this.points)
      (3 == e.nodeType ? i.node == e : e.contains(i.node)) &&
        (i.pos = this.text.length + (mn(e, i.node, i.offset) ? t : 0));
  }
}
function mn(e, t, i) {
  for (;;) {
    if (!t || i < hi(t)) return !1;
    if (t == e) return !0;
    ((i = li(t) + 1), (t = t.parentNode));
  }
}
function gn(e, t) {
  let i;
  for (; e != t && e; e = e.nextSibling) {
    let t = Eo.get(e);
    if (!(null == t ? void 0 : t.isWidget())) return !1;
    t && (i || (i = [])).push(t);
  }
  if (i)
    for (let e of i) {
      let t = e.overrideDOMText;
      if (null == t ? void 0 : t.length) return !1;
    }
  return !0;
}
class fn {
  constructor(e, t) {
    ((this.node = e), (this.offset = t), (this.pos = -1));
  }
}
class bn {
  constructor(e, t, i, o) {
    ((this.typeOver = o),
      (this.bounds = null),
      (this.text = ""),
      (this.domChanged = t > -1));
    let { impreciseHead: n, impreciseAnchor: s } = e.docView;
    if (e.state.readOnly && t > -1) this.newSel = null;
    else if (t > -1 && (this.bounds = yn(e.docView.tile, t, i, 0))) {
      let t =
          n || s
            ? []
            : (function (e) {
                let t = [];
                if (e.root.activeElement != e.contentDOM) return t;
                let {
                  anchorNode: i,
                  anchorOffset: o,
                  focusNode: n,
                  focusOffset: s,
                } = e.observer.selectionRange;
                i &&
                  (t.push(new fn(i, o)),
                  (n == i && s == o) || t.push(new fn(n, s)));
                return t;
              })(e),
        i = new pn(t, e);
      (i.readRange(this.bounds.startDOM, this.bounds.endDOM),
        (this.text = i.text),
        (this.newSel = (function (e, t) {
          if (0 == e.length) return null;
          let i = e[0].pos,
            o = 2 == e.length ? e[1].pos : i;
          return i > -1 && o > -1 ? ue.single(i + t, o + t) : null;
        })(t, this.bounds.from)));
    } else {
      let t = e.observer.selectionRange,
        i =
          (n && n.node == t.focusNode && n.offset == t.focusOffset) ||
          !ni(e.contentDOM, t.focusNode)
            ? e.state.selection.main.head
            : e.docView.posFromDOM(t.focusNode, t.focusOffset),
        o =
          (s && s.node == t.anchorNode && s.offset == t.anchorOffset) ||
          !ni(e.contentDOM, t.anchorNode)
            ? e.state.selection.main.anchor
            : e.docView.posFromDOM(t.anchorNode, t.anchorOffset),
        r = e.viewport;
      if (
        (Wt.ios || Wt.chrome) &&
        e.state.selection.main.empty &&
        i != o &&
        (r.from > 0 || r.to < e.state.doc.length)
      ) {
        let t = Math.min(i, o),
          n = Math.max(i, o),
          s = r.from - t,
          a = r.to - n;
        (0 != s && 1 != s && 0 != t) ||
          (0 != a && -1 != a && n != e.state.doc.length) ||
          ((i = 0), (o = e.state.doc.length));
      }
      e.inputState.composing > -1 && e.state.selection.ranges.length > 1
        ? (this.newSel = e.state.selection.replaceRange(ue.range(o, i)))
        : (this.newSel = ue.single(o, i));
    }
  }
}
function yn(e, t, i, o) {
  if (e.isComposite()) {
    let n = -1,
      s = -1,
      r = -1,
      a = -1;
    for (let l = 0, c = o, d = o; l < e.children.length; l++) {
      let o = e.children[l],
        h = c + o.length;
      if (c < t && h > i) return yn(o, t, i, c);
      if (
        (h >= t && -1 == n && ((n = l), (s = c)),
        c > i && o.dom.parentNode == e.dom)
      ) {
        ((r = l), (a = d));
        break;
      }
      ((d = h), (c = h + o.breakAfter));
    }
    return {
      from: s,
      to: a < 0 ? o + e.length : a,
      startDOM:
        (n ? e.children[n - 1].dom.nextSibling : null) || e.dom.firstChild,
      endDOM: r < e.children.length && r >= 0 ? e.children[r].dom : null,
    };
  }
  return e.isText()
    ? { from: o, to: o + e.length, startDOM: e.dom, endDOM: e.dom.nextSibling }
    : null;
}
function wn(e, t) {
  let i,
    { newSel: o } = t,
    n = e.state.selection.main,
    s =
      e.inputState.lastKeyTime > Date.now() - 100
        ? e.inputState.lastKeyCode
        : -1;
  if (t.bounds) {
    let { from: o, to: r } = t.bounds,
      a = n.from,
      l = null;
    (8 === s || (Wt.android && t.text.length < r - o)) &&
      ((a = n.to), (l = "end"));
    let c = Cn(e.state.doc.sliceString(o, r, un), t.text, a - o, l);
    c &&
      (Wt.chrome &&
        13 == s &&
        c.toB == c.from + 2 &&
        t.text.slice(c.from, c.toB) == un + un &&
        c.toB--,
      (i = {
        from: o + c.from,
        to: o + c.toA,
        insert: $.of(t.text.slice(c.from, c.toB).split(un)),
      }));
  } else o && ((!e.hasFocus && e.state.facet(ro)) || xn(o, n)) && (o = null);
  if (!i && !o) return !1;
  if (
    (!i && t.typeOver && !n.empty && o && o.main.empty
      ? (i = {
          from: n.from,
          to: n.to,
          insert: e.state.doc.slice(n.from, n.to),
        })
      : (Wt.mac || Wt.android) &&
          i &&
          i.from == i.to &&
          i.from == n.head - 1 &&
          /^\. ?$/.test(i.insert.toString()) &&
          "off" == e.contentDOM.getAttribute("autocorrect")
        ? (o &&
            2 == i.insert.length &&
            (o = ue.single(o.main.anchor - 1, o.main.head - 1)),
          (i = {
            from: i.from,
            to: i.to,
            insert: $.of([i.insert.toString().replace(".", " ")]),
          }))
        : i &&
            i.from >= n.from &&
            i.to <= n.to &&
            (i.from != n.from || i.to != n.to) &&
            n.to - n.from - (i.to - i.from) <= 4
          ? (i = {
              from: n.from,
              to: n.to,
              insert: e.state.doc
                .slice(n.from, i.from)
                .append(i.insert)
                .append(e.state.doc.slice(i.to, n.to)),
            })
          : e.state.doc.lineAt(n.from).to < n.to &&
              e.docView.lineHasWidget(n.to) &&
              e.inputState.insertingTextAt > Date.now() - 50
            ? (i = {
                from: n.from,
                to: n.to,
                insert: e.state.toText(e.inputState.insertingText),
              })
            : Wt.chrome &&
              i &&
              i.from == i.to &&
              i.from == n.head &&
              "\n " == i.insert.toString() &&
              e.lineWrapping &&
              (o && (o = ue.single(o.main.anchor - 1, o.main.head - 1)),
              (i = { from: n.from, to: n.to, insert: $.of([" "]) })),
    i)
  )
    return vn(e, i, o, s);
  if (o && !xn(o, n)) {
    let t = !1,
      i = "select";
    return (
      e.inputState.lastSelectionTime > Date.now() - 50 &&
        ("select" == e.inputState.lastSelectionOrigin && (t = !0),
        (i = e.inputState.lastSelectionOrigin),
        "select.pointer" == i &&
          (o = rn(
            e.state.facet(bo).map((t) => t(e)),
            o,
          ))),
      e.dispatch({ selection: o, scrollIntoView: t, userEvent: i }),
      !0
    );
  }
  return !1;
}
function vn(e, t, i, o = -1) {
  if (Wt.ios && e.inputState.flushIOSKey(t)) return !0;
  let n = e.state.selection.main;
  if (
    Wt.android &&
    ((t.to == n.to &&
      (t.from == n.from ||
        (t.from == n.from - 1 && " " == e.state.sliceDoc(t.from, n.from))) &&
      1 == t.insert.length &&
      2 == t.insert.lines &&
      vi(e.contentDOM, "Enter", 13)) ||
      (((t.from == n.from - 1 && t.to == n.to && 0 == t.insert.length) ||
        (8 == o && t.insert.length < t.to - t.from && t.to > n.head)) &&
        vi(e.contentDOM, "Backspace", 8)) ||
      (t.from == n.from &&
        t.to == n.to + 1 &&
        0 == t.insert.length &&
        vi(e.contentDOM, "Delete", 46)))
  )
    return !0;
  let s,
    r = t.insert.toString();
  e.inputState.composing >= 0 && e.inputState.composing++;
  let a = () =>
    s ||
    (s = (function (e, t, i) {
      let o,
        n = e.state,
        s = n.selection.main,
        r = -1;
      if ((t.from == t.to && t.from < s.from) || t.from > s.to) {
        let i = t.from < s.from ? -1 : 1,
          o = i < 0 ? s.from : s.to,
          a = sn(
            n.facet(bo).map((t) => t(e)),
            o,
            i,
          );
        t.from == a && (r = a);
      }
      if (r > -1)
        o = { changes: t, selection: ue.cursor(t.from + t.insert.length, -1) };
      else if (
        t.from >= s.from &&
        t.to <= s.to &&
        t.to - t.from >= (s.to - s.from) / 3 &&
        (!i || (i.main.empty && i.main.from == t.from + t.insert.length)) &&
        e.inputState.composing < 0
      ) {
        let i = s.from < t.from ? n.sliceDoc(s.from, t.from) : "",
          r = s.to > t.to ? n.sliceDoc(t.to, s.to) : "";
        o = n.replaceSelection(
          e.state.toText(
            i + t.insert.sliceString(0, void 0, e.state.lineBreak) + r,
          ),
        );
      } else {
        let r = n.changes(t),
          a = i && i.main.to <= r.newLength ? i.main : void 0;
        if (
          n.selection.ranges.length > 1 &&
          (e.inputState.composing >= 0 ||
            e.inputState.compositionPendingChange) &&
          t.to <= s.to + 10 &&
          t.to >= s.to - 10
        ) {
          let l,
            c = e.state.sliceDoc(t.from, t.to),
            d = i && Jo(e, i.main.head);
          if (d) {
            let e = t.insert.length - (t.to - t.from);
            l = { from: d.from, to: d.to - e };
          } else l = e.state.doc.lineAt(s.head);
          let h = s.to - t.to;
          o = n.changeByRange((i) => {
            if (i.from == s.from && i.to == s.to)
              return { changes: r, range: a || i.map(r) };
            let o = i.to - h,
              d = o - c.length;
            if (e.state.sliceDoc(d, o) != c || (o >= l.from && d <= l.to))
              return { range: i };
            let u = n.changes({ from: d, to: o, insert: t.insert }),
              p = i.to - s.to;
            return {
              changes: u,
              range: a
                ? ue.range(Math.max(0, a.anchor + p), Math.max(0, a.head + p))
                : i.map(u),
            };
          });
        } else o = { changes: r, selection: a && n.selection.replaceRange(a) };
      }
      let a = "input.type";
      (e.composing ||
        (e.inputState.compositionPendingChange &&
          e.inputState.compositionEndedAt > Date.now() - 50)) &&
        ((e.inputState.compositionPendingChange = !1),
        (a += ".compose"),
        e.inputState.compositionFirstChange &&
          ((a += ".start"), (e.inputState.compositionFirstChange = !1)));
      return n.update(o, { userEvent: a, scrollIntoView: !0 });
    })(e, t, i));
  return (
    e.state.facet(Zi).some((i) => i(e, t.from, t.to, r, a)) || e.dispatch(a()),
    !0
  );
}
function Cn(e, t, i, o) {
  let n = Math.min(e.length, t.length),
    s = 0;
  for (; s < n && e.charCodeAt(s) == t.charCodeAt(s); ) s++;
  if (s == n && e.length == t.length) return null;
  let r = e.length,
    a = t.length;
  for (; r > 0 && a > 0 && e.charCodeAt(r - 1) == t.charCodeAt(a - 1); )
    (r--, a--);
  if ("end" == o) {
    i -= r + Math.max(0, s - Math.min(r, a)) - s;
  }
  if (r < s && e.length < t.length) {
    ((s -= i <= s && i >= r ? s - i : 0), (a = s + (a - r)), (r = s));
  } else if (a < s) {
    ((s -= i <= s && i >= a ? s - i : 0), (r = s + (r - a)), (a = s));
  }
  return { from: s, toA: r, toB: a };
}
function xn(e, t) {
  return t.head == e.main.head && t.anchor == e.main.anchor;
}
class kn {
  setSelectionOrigin(e) {
    ((this.lastSelectionOrigin = e), (this.lastSelectionTime = Date.now()));
  }
  constructor(e) {
    ((this.view = e),
      (this.lastKeyCode = 0),
      (this.lastKeyTime = 0),
      (this.lastTouchTime = 0),
      (this.lastFocusTime = 0),
      (this.lastScrollTop = 0),
      (this.lastScrollLeft = 0),
      (this.pendingIOSKey = void 0),
      (this.tabFocusMode = -1),
      (this.lastSelectionOrigin = null),
      (this.lastSelectionTime = 0),
      (this.lastContextMenu = 0),
      (this.scrollHandlers = []),
      (this.handlers = Object.create(null)),
      (this.composing = -1),
      (this.compositionFirstChange = null),
      (this.compositionEndedAt = 0),
      (this.compositionPendingKey = !1),
      (this.compositionPendingChange = !1),
      (this.insertingText = ""),
      (this.insertingTextAt = 0),
      (this.mouseSelection = null),
      (this.draggedContent = null),
      (this.handleEvent = this.handleEvent.bind(this)),
      (this.notifiedFocused = e.hasFocus),
      Wt.safari && e.contentDOM.addEventListener("input", () => null),
      Wt.gecko &&
        (function (e) {
          Yn.has(e) ||
            (Yn.add(e),
            e.addEventListener("copy", () => {}),
            e.addEventListener("cut", () => {}));
        })(e.contentDOM.ownerDocument));
  }
  handleEvent(e) {
    (function (e, t) {
      if (!t.bubbles) return !0;
      if (t.defaultPrevented) return !1;
      for (let i, o = t.target; o != e.contentDOM; o = o.parentNode)
        if (
          !o ||
          11 == o.nodeType ||
          ((i = Eo.get(o)) &&
            i.isWidget() &&
            !i.isHidden &&
            i.widget.ignoreEvent(t))
        )
          return !1;
      return !0;
    })(this.view, e) &&
      !this.ignoreDuringComposition(e) &&
      (("keydown" == e.type && this.keydown(e)) ||
        (0 != this.view.updateState
          ? Promise.resolve().then(() => this.runHandlers(e.type, e))
          : this.runHandlers(e.type, e)));
  }
  runHandlers(e, t) {
    let i = this.handlers[e];
    if (i) {
      for (let e of i.observers) e(this.view, t);
      for (let e of i.handlers) {
        if (t.defaultPrevented) break;
        if (e(this.view, t)) {
          t.preventDefault();
          break;
        }
      }
    }
  }
  ensureHandlers(e) {
    let t = Tn(e),
      i = this.handlers,
      o = this.view.contentDOM;
    for (let e in t)
      if ("scroll" != e) {
        let n = !t[e].handlers.length,
          s = i[e];
        (s &&
          n != !s.handlers.length &&
          (o.removeEventListener(e, this.handleEvent), (s = null)),
          s || o.addEventListener(e, this.handleEvent, { passive: n }));
      }
    for (let e in i)
      "scroll" == e || t[e] || o.removeEventListener(e, this.handleEvent);
    this.handlers = t;
  }
  keydown(e) {
    if (
      ((this.lastKeyCode = e.keyCode),
      (this.lastKeyTime = Date.now()),
      9 == e.keyCode &&
        this.tabFocusMode > -1 &&
        (!this.tabFocusMode || Date.now() <= this.tabFocusMode))
    )
      return !0;
    if (
      (this.tabFocusMode > 0 &&
        27 != e.keyCode &&
        An.indexOf(e.keyCode) < 0 &&
        (this.tabFocusMode = -1),
      Wt.android &&
        Wt.chrome &&
        !e.synthetic &&
        (13 == e.keyCode || 8 == e.keyCode))
    )
      return (this.view.observer.delayAndroidKey(e.key, e.keyCode), !0);
    let t;
    return !Wt.ios ||
      e.synthetic ||
      e.altKey ||
      e.metaKey ||
      !(
        ((t = En.find((t) => t.keyCode == e.keyCode)) && !e.ctrlKey) ||
        (Mn.indexOf(e.key) > -1 && e.ctrlKey && !e.shiftKey)
      )
      ? (229 != e.keyCode && this.view.observer.forceFlush(), !1)
      : ((this.pendingIOSKey = t || e),
        setTimeout(() => this.flushIOSKey(), 250),
        !0);
  }
  flushIOSKey(e) {
    let t = this.pendingIOSKey;
    return (
      !!t &&
      !(
        "Enter" == t.key &&
        e &&
        e.from < e.to &&
        /^\S+$/.test(e.insert.toString())
      ) &&
      ((this.pendingIOSKey = void 0),
      vi(
        this.view.contentDOM,
        t.key,
        t.keyCode,
        t instanceof KeyboardEvent ? t : void 0,
      ))
    );
  }
  ignoreDuringComposition(e) {
    return (
      !(!/^key/.test(e.type) || e.synthetic) &&
      (this.composing > 0 ||
        (!!(
          Wt.safari &&
          !Wt.ios &&
          this.compositionPendingKey &&
          Date.now() - this.compositionEndedAt < 100
        ) &&
          ((this.compositionPendingKey = !1), !0)))
    );
  }
  startMouseSelection(e) {
    (this.mouseSelection && this.mouseSelection.destroy(),
      (this.mouseSelection = e));
  }
  update(e) {
    (this.view.observer.update(e),
      this.mouseSelection && this.mouseSelection.update(e),
      this.draggedContent &&
        e.docChanged &&
        (this.draggedContent = this.draggedContent.map(e.changes)),
      e.transactions.length && (this.lastKeyCode = this.lastSelectionTime = 0));
  }
  destroy() {
    this.mouseSelection && this.mouseSelection.destroy();
  }
}
function Sn(e, t) {
  return (i, o) => {
    try {
      return t.call(e, o, i);
    } catch (e) {
      so(i.state, e);
    }
  };
}
function Tn(e) {
  let t = Object.create(null);
  function i(e) {
    return t[e] || (t[e] = { observers: [], handlers: [] });
  }
  for (let t of e) {
    let e = t.spec,
      o = e && e.plugin.domEventHandlers,
      n = e && e.plugin.domEventObservers;
    if (o)
      for (let e in o) {
        let n = o[e];
        n && i(e).handlers.push(Sn(t.value, n));
      }
    if (n)
      for (let e in n) {
        let o = n[e];
        o && i(e).observers.push(Sn(t.value, o));
      }
  }
  for (let e in On) i(e).handlers.push(On[e]);
  for (let e in Bn) i(e).observers.push(Bn[e]);
  return t;
}
const En = [
    { key: "Backspace", keyCode: 8, inputType: "deleteContentBackward" },
    { key: "Enter", keyCode: 13, inputType: "insertParagraph" },
    { key: "Enter", keyCode: 13, inputType: "insertLineBreak" },
    { key: "Delete", keyCode: 46, inputType: "deleteContentForward" },
  ],
  Mn = "dthko",
  An = [16, 17, 18, 20, 91, 92, 224, 225];
function In(e) {
  return 0.7 * Math.max(0, e) + 8;
}
class Dn {
  constructor(e, t, i, o) {
    ((this.view = e),
      (this.startEvent = t),
      (this.style = i),
      (this.mustSelect = o),
      (this.scrollSpeed = { x: 0, y: 0 }),
      (this.scrolling = -1),
      (this.lastEvent = t),
      (this.scrollParents = (function (e) {
        let t,
          i,
          o = e.ownerDocument;
        for (let n = e.parentNode; n && !(n == o.body || (t && i)); )
          if (1 == n.nodeType)
            (!i && n.scrollHeight > n.clientHeight && (i = n),
              !t && n.scrollWidth > n.clientWidth && (t = n),
              (n = n.assignedSlot || n.parentNode));
          else {
            if (11 != n.nodeType) break;
            n = n.host;
          }
        return { x: t, y: i };
      })(e.contentDOM)),
      (this.atoms = e.state.facet(bo).map((t) => t(e))));
    let n = e.contentDOM.ownerDocument;
    (n.addEventListener("mousemove", (this.move = this.move.bind(this))),
      n.addEventListener("mouseup", (this.up = this.up.bind(this))),
      (this.extend = t.shiftKey),
      (this.multiple =
        e.state.facet(ot.allowMultipleSelections) &&
        (function (e, t) {
          let i = e.state.facet($i);
          return i.length ? i[0](t) : Wt.mac ? t.metaKey : t.ctrlKey;
        })(e, t)),
      (this.dragging =
        !(
          !(function (e, t) {
            let { main: i } = e.state.selection;
            if (i.empty) return !1;
            let o = oi(e.root);
            if (!o || 0 == o.rangeCount) return !0;
            let n = o.getRangeAt(0).getClientRects();
            for (let e = 0; e < n.length; e++) {
              let i = n[e];
              if (
                i.left <= t.clientX &&
                i.right >= t.clientX &&
                i.top <= t.clientY &&
                i.bottom >= t.clientY
              )
                return !0;
            }
            return !1;
          })(e, t) || 1 != Vn(t)
        ) && null));
  }
  start(e) {
    !1 === this.dragging && this.select(e);
  }
  move(e) {
    if (0 == e.buttons) return this.destroy();
    if (
      this.dragging ||
      (null == this.dragging &&
        ((t = this.startEvent),
        (i = e),
        Math.max(
          Math.abs(t.clientX - i.clientX),
          Math.abs(t.clientY - i.clientY),
        ) < 10))
    )
      return;
    var t, i;
    this.select((this.lastEvent = e));
    let o = 0,
      n = 0,
      s = 0,
      r = 0,
      a = this.view.win.innerWidth,
      l = this.view.win.innerHeight;
    (this.scrollParents.x &&
      ({ left: s, right: a } = this.scrollParents.x.getBoundingClientRect()),
      this.scrollParents.y &&
        ({ top: r, bottom: l } = this.scrollParents.y.getBoundingClientRect()));
    let c = Co(this.view);
    (e.clientX - c.left <= s + 6
      ? (o = -In(s - e.clientX))
      : e.clientX + c.right >= a - 6 && (o = In(e.clientX - a)),
      e.clientY - c.top <= r + 6
        ? (n = -In(r - e.clientY))
        : e.clientY + c.bottom >= l - 6 && (n = In(e.clientY - l)),
      this.setScrollSpeed(o, n));
  }
  up(e) {
    (null == this.dragging && this.select(this.lastEvent),
      this.dragging || e.preventDefault(),
      this.destroy());
  }
  destroy() {
    this.setScrollSpeed(0, 0);
    let e = this.view.contentDOM.ownerDocument;
    (e.removeEventListener("mousemove", this.move),
      e.removeEventListener("mouseup", this.up),
      (this.view.inputState.mouseSelection =
        this.view.inputState.draggedContent =
          null));
  }
  setScrollSpeed(e, t) {
    ((this.scrollSpeed = { x: e, y: t }),
      e || t
        ? this.scrolling < 0 &&
          (this.scrolling = setInterval(() => this.scroll(), 50))
        : this.scrolling > -1 &&
          (clearInterval(this.scrolling), (this.scrolling = -1)));
  }
  scroll() {
    let { x: e, y: t } = this.scrollSpeed;
    (e &&
      this.scrollParents.x &&
      ((this.scrollParents.x.scrollLeft += e), (e = 0)),
      t &&
        this.scrollParents.y &&
        ((this.scrollParents.y.scrollTop += t), (t = 0)),
      (e || t) && this.view.win.scrollBy(e, t),
      !1 === this.dragging && this.select(this.lastEvent));
  }
  select(e) {
    let { view: t } = this,
      i = rn(this.atoms, this.style.get(e, this.extend, this.multiple));
    ((!this.mustSelect && i.eq(t.state.selection, !1 === this.dragging)) ||
      this.view.dispatch({ selection: i, userEvent: "select.pointer" }),
      (this.mustSelect = !1));
  }
  update(e) {
    e.transactions.some((e) => e.isUserEvent("input.type"))
      ? this.destroy()
      : this.style.update(e) &&
        setTimeout(() => this.select(this.lastEvent), 20);
  }
}
const On = Object.create(null),
  Bn = Object.create(null),
  Ln = (Wt.ie && Wt.ie_version < 15) || (Wt.ios && Wt.webkit_version < 604);
function Pn(e, t, i) {
  for (let o of e.facet(t)) i = o(i, e);
  return i;
}
function Nn(e, t) {
  t = Pn(e.state, Ji, t);
  let i,
    { state: o } = e,
    n = 1,
    s = o.toText(t),
    r = s.lines == o.selection.ranges.length;
  if (
    null != Hn &&
    o.selection.ranges.every((e) => e.empty) &&
    Hn == s.toString()
  ) {
    let e = -1;
    i = o.changeByRange((i) => {
      let a = o.doc.lineAt(i.from);
      if (a.from == e) return { range: i };
      e = a.from;
      let l = o.toText((r ? s.line(n++).text : t) + o.lineBreak);
      return {
        changes: { from: a.from, insert: l },
        range: ue.cursor(i.from + l.length),
      };
    });
  } else
    i = r
      ? o.changeByRange((e) => {
          let t = s.line(n++);
          return {
            changes: { from: e.from, to: e.to, insert: t.text },
            range: ue.cursor(e.from + t.length),
          };
        })
      : o.replaceSelection(s);
  e.dispatch(i, { userEvent: "input.paste", scrollIntoView: !0 });
}
function Rn(e, t, i, o) {
  if (1 == o) return ue.cursor(t, i);
  if (2 == o)
    return (function (e, t, i = 1) {
      let o = e.charCategorizer(t),
        n = e.doc.lineAt(t),
        s = t - n.from;
      if (0 == n.length) return ue.cursor(t);
      0 == s ? (i = 1) : s == n.length && (i = -1);
      let r = s,
        a = s;
      i < 0 ? (r = ee(n.text, s, !1)) : (a = ee(n.text, s));
      let l = o(n.text.slice(r, a));
      for (; r > 0; ) {
        let e = ee(n.text, r, !1);
        if (o(n.text.slice(e, r)) != l) break;
        r = e;
      }
      for (; a < n.length; ) {
        let e = ee(n.text, a);
        if (o(n.text.slice(a, e)) != l) break;
        a = e;
      }
      return ue.range(r + n.from, a + n.from);
    })(e.state, t, i);
  {
    let o = e.docView.lineAt(t, i),
      n = e.state.doc.lineAt(o ? o.posAtEnd : t),
      s = o ? o.posAtStart : n.from,
      r = o ? o.posAtEnd : n.to;
    return (r < e.state.doc.length && r == n.to && r++, ue.range(s, r));
  }
}
((Bn.scroll = (e) => {
  ((e.inputState.lastScrollTop = e.scrollDOM.scrollTop),
    (e.inputState.lastScrollLeft = e.scrollDOM.scrollLeft));
}),
  (On.keydown = (e, t) => (
    e.inputState.setSelectionOrigin("select"),
    27 == t.keyCode &&
      0 != e.inputState.tabFocusMode &&
      (e.inputState.tabFocusMode = Date.now() + 2e3),
    !1
  )),
  (Bn.touchstart = (e, t) => {
    ((e.inputState.lastTouchTime = Date.now()),
      e.inputState.setSelectionOrigin("select.pointer"));
  }),
  (Bn.touchmove = (e) => {
    e.inputState.setSelectionOrigin("select.pointer");
  }),
  (On.mousedown = (e, t) => {
    if ((e.observer.flush(), e.inputState.lastTouchTime > Date.now() - 2e3))
      return !1;
    let i = null;
    for (let o of e.state.facet(ji)) if (((i = o(e, t)), i)) break;
    if (
      (i ||
        0 != t.button ||
        (i = (function (e, t) {
          let i = e.posAndSideAtCoords({ x: t.clientX, y: t.clientY }, !1),
            o = Vn(t),
            n = e.state.selection;
          return {
            update(e) {
              e.docChanged &&
                ((i.pos = e.changes.mapPos(i.pos)), (n = n.map(e.changes)));
            },
            get(t, s, r) {
              let a,
                l = e.posAndSideAtCoords({ x: t.clientX, y: t.clientY }, !1),
                c = Rn(e, l.pos, l.assoc, o);
              if (i.pos != l.pos && !s) {
                let t = Rn(e, i.pos, i.assoc, o),
                  n = Math.min(t.from, c.from),
                  s = Math.max(t.to, c.to);
                c = n < c.from ? ue.range(n, s) : ue.range(s, n);
              }
              return s
                ? n.replaceRange(n.main.extend(c.from, c.to))
                : r &&
                    1 == o &&
                    n.ranges.length > 1 &&
                    (a = (function (e, t) {
                      for (let i = 0; i < e.ranges.length; i++) {
                        let { from: o, to: n } = e.ranges[i];
                        if (o <= t && n >= t)
                          return ue.create(
                            e.ranges.slice(0, i).concat(e.ranges.slice(i + 1)),
                            e.mainIndex == i
                              ? 0
                              : e.mainIndex - (e.mainIndex > i ? 1 : 0),
                          );
                      }
                      return null;
                    })(n, l.pos))
                  ? a
                  : r
                    ? n.addRange(c)
                    : ue.create([c]);
            },
          };
        })(e, t)),
      i)
    ) {
      let o = !e.hasFocus;
      (e.inputState.startMouseSelection(new Dn(e, t, i, o)),
        o &&
          e.observer.ignore(() => {
            yi(e.contentDOM);
            let t = e.root.activeElement;
            t && !t.contains(e.contentDOM) && t.blur();
          }));
      let n = e.inputState.mouseSelection;
      if (n) return (n.start(t), !1 === n.dragging);
    } else e.inputState.setSelectionOrigin("select.pointer");
    return !1;
  }));
const Fn = Wt.ie && Wt.ie_version <= 11;
let qn = null,
  _n = 0,
  zn = 0;
function Vn(e) {
  if (!Fn) return e.detail;
  let t = qn,
    i = zn;
  return (
    (qn = e),
    (zn = Date.now()),
    (_n =
      !t ||
      (i > Date.now() - 400 &&
        Math.abs(t.clientX - e.clientX) < 2 &&
        Math.abs(t.clientY - e.clientY) < 2)
        ? (_n + 1) % 3
        : 1)
  );
}
function Wn(e, t, i, o) {
  if (!(i = Pn(e.state, Ji, i))) return;
  let n = e.posAtCoords({ x: t.clientX, y: t.clientY }, !1),
    { draggedContent: s } = e.inputState,
    r =
      o &&
      s &&
      (function (e, t) {
        let i = e.state.facet(Ui);
        return i.length ? i[0](t) : Wt.mac ? !t.altKey : !t.ctrlKey;
      })(e, t)
        ? { from: s.from, to: s.to }
        : null,
    a = { from: n, insert: i },
    l = e.state.changes(r ? [r, a] : a);
  (e.focus(),
    e.dispatch({
      changes: l,
      selection: { anchor: l.mapPos(n, -1), head: l.mapPos(n, 1) },
      userEvent: r ? "move.drop" : "input.drop",
    }),
    (e.inputState.draggedContent = null));
}
((On.dragstart = (e, t) => {
  let {
    selection: { main: i },
  } = e.state;
  if (t.target.draggable) {
    let o = e.docView.tile.nearest(t.target);
    if (o && o.isWidget()) {
      let e = o.posAtStart,
        t = e + o.length;
      (e >= i.to || t <= i.from) && (i = ue.range(e, t));
    }
  }
  let { inputState: o } = e;
  return (
    o.mouseSelection && (o.mouseSelection.dragging = !0),
    (o.draggedContent = i),
    t.dataTransfer &&
      (t.dataTransfer.setData(
        "Text",
        Pn(e.state, Xi, e.state.sliceDoc(i.from, i.to)),
      ),
      (t.dataTransfer.effectAllowed = "copyMove")),
    !1
  );
}),
  (On.dragend = (e) => ((e.inputState.draggedContent = null), !1)),
  (On.drop = (e, t) => {
    if (!t.dataTransfer) return !1;
    if (e.state.readOnly) return !0;
    let i = t.dataTransfer.files;
    if (i && i.length) {
      let o = Array(i.length),
        n = 0,
        s = () => {
          ++n == i.length &&
            Wn(e, t, o.filter((e) => null != e).join(e.state.lineBreak), !1);
        };
      for (let e = 0; e < i.length; e++) {
        let t = new FileReader();
        ((t.onerror = s),
          (t.onload = () => {
            (/[\x00-\x08\x0e-\x1f]{2}/.test(t.result) || (o[e] = t.result),
              s());
          }),
          t.readAsText(i[e]));
      }
      return !0;
    }
    {
      let i = t.dataTransfer.getData("Text");
      if (i) return (Wn(e, t, i, !0), !0);
    }
    return !1;
  }),
  (On.paste = (e, t) => {
    if (e.state.readOnly) return !0;
    e.observer.flush();
    let i = Ln ? null : t.clipboardData;
    return i
      ? (Nn(e, i.getData("text/plain") || i.getData("text/uri-list")), !0)
      : ((function (e) {
          let t = e.dom.parentNode;
          if (!t) return;
          let i = t.appendChild(document.createElement("textarea"));
          ((i.style.cssText = "position: fixed; left: -10000px; top: 10px"),
            i.focus(),
            setTimeout(() => {
              (e.focus(), i.remove(), Nn(e, i.value));
            }, 50));
        })(e),
        !1);
  }));
let Hn = null;
On.copy = On.cut = (e, t) => {
  let i = oi(e.root);
  if (i && !si(e.contentDOM, i)) return !1;
  let {
    text: o,
    ranges: n,
    linewise: s,
  } = (function (e) {
    let t = [],
      i = [],
      o = !1;
    for (let o of e.selection.ranges)
      o.empty || (t.push(e.sliceDoc(o.from, o.to)), i.push(o));
    if (!t.length) {
      let n = -1;
      for (let { from: o } of e.selection.ranges) {
        let s = e.doc.lineAt(o);
        (s.number > n &&
          (t.push(s.text),
          i.push({ from: s.from, to: Math.min(e.doc.length, s.to + 1) })),
          (n = s.number));
      }
      o = !0;
    }
    return { text: Pn(e, Xi, t.join(e.lineBreak)), ranges: i, linewise: o };
  })(e.state);
  if (!o && !s) return !1;
  ((Hn = s ? o : null),
    "cut" != t.type ||
      e.state.readOnly ||
      e.dispatch({ changes: n, scrollIntoView: !0, userEvent: "delete.cut" }));
  let r = Ln ? null : t.clipboardData;
  return r
    ? (r.clearData(), r.setData("text/plain", o), !0)
    : ((function (e, t) {
        let i = e.dom.parentNode;
        if (!i) return;
        let o = i.appendChild(document.createElement("textarea"));
        ((o.style.cssText = "position: fixed; left: -10000px; top: 10px"),
          (o.value = t),
          o.focus(),
          (o.selectionEnd = t.length),
          (o.selectionStart = 0),
          setTimeout(() => {
            (o.remove(), e.focus());
          }, 50));
      })(e, o),
      !1);
};
const $n = We.define();
function Un(e, t) {
  let i = [];
  for (let o of e.facet(Ki)) {
    let n = o(e, t);
    n && i.push(n);
  }
  return i.length ? e.update({ effects: i, annotations: $n.of(!0) }) : null;
}
function jn(e) {
  setTimeout(() => {
    let t = e.hasFocus;
    if (t != e.inputState.notifiedFocused) {
      let i = Un(e.state, t);
      i ? e.dispatch(i) : e.update([]);
    }
  }, 10);
}
((Bn.focus = (e) => {
  ((e.inputState.lastFocusTime = Date.now()),
    e.scrollDOM.scrollTop ||
      (!e.inputState.lastScrollTop && !e.inputState.lastScrollLeft) ||
      ((e.scrollDOM.scrollTop = e.inputState.lastScrollTop),
      (e.scrollDOM.scrollLeft = e.inputState.lastScrollLeft)),
    jn(e));
}),
  (Bn.blur = (e) => {
    (e.observer.clearSelectionRange(), jn(e));
  }),
  (Bn.compositionstart = Bn.compositionupdate =
    (e) => {
      e.observer.editContext ||
        (null == e.inputState.compositionFirstChange &&
          (e.inputState.compositionFirstChange = !0),
        e.inputState.composing < 0 && (e.inputState.composing = 0));
    }),
  (Bn.compositionend = (e) => {
    e.observer.editContext ||
      ((e.inputState.composing = -1),
      (e.inputState.compositionEndedAt = Date.now()),
      (e.inputState.compositionPendingKey = !0),
      (e.inputState.compositionPendingChange =
        e.observer.pendingRecords().length > 0),
      (e.inputState.compositionFirstChange = null),
      Wt.chrome && Wt.android
        ? e.observer.flushSoon()
        : e.inputState.compositionPendingChange
          ? Promise.resolve().then(() => e.observer.flush())
          : setTimeout(() => {
              e.inputState.composing < 0 &&
                e.docView.hasComposition &&
                e.update([]);
            }, 50));
  }),
  (Bn.contextmenu = (e) => {
    e.inputState.lastContextMenu = Date.now();
  }),
  (On.beforeinput = (e, t) => {
    var i, o;
    if (
      (("insertText" != t.inputType &&
        "insertCompositionText" != t.inputType) ||
        ((e.inputState.insertingText = t.data),
        (e.inputState.insertingTextAt = Date.now())),
      "insertReplacementText" == t.inputType && e.observer.editContext)
    ) {
      let o =
          null === (i = t.dataTransfer) || void 0 === i
            ? void 0
            : i.getData("text/plain"),
        n = t.getTargetRanges();
      if (o && n.length) {
        let t = n[0],
          i = e.posAtDOM(t.startContainer, t.startOffset),
          s = e.posAtDOM(t.endContainer, t.endOffset);
        return (vn(e, { from: i, to: s, insert: e.state.toText(o) }, null), !0);
      }
    }
    let n;
    if (
      Wt.chrome &&
      Wt.android &&
      (n = En.find((e) => e.inputType == t.inputType)) &&
      (e.observer.delayAndroidKey(n.key, n.keyCode),
      "Backspace" == n.key || "Delete" == n.key)
    ) {
      let t =
        (null === (o = window.visualViewport) || void 0 === o
          ? void 0
          : o.height) || 0;
      setTimeout(() => {
        var i;
        ((null === (i = window.visualViewport) || void 0 === i
          ? void 0
          : i.height) || 0) >
          t + 10 &&
          e.hasFocus &&
          (e.contentDOM.blur(), e.focus());
      }, 100);
    }
    return (
      Wt.ios && "deleteContentForward" == t.inputType && e.observer.flushSoon(),
      Wt.safari &&
        "insertText" == t.inputType &&
        e.inputState.composing >= 0 &&
        setTimeout(() => Bn.compositionend(e, t), 20),
      !1
    );
  }));
const Yn = new Set();
const Gn = ["pre-wrap", "normal", "pre-line", "break-spaces"];
let Zn = !1;
function Kn() {
  Zn = !1;
}
class Jn {
  constructor(e) {
    ((this.lineWrapping = e),
      (this.doc = $.empty),
      (this.heightSamples = {}),
      (this.lineHeight = 14),
      (this.charWidth = 7),
      (this.textHeight = 14),
      (this.lineLength = 30));
  }
  heightForGap(e, t) {
    let i = this.doc.lineAt(t).number - this.doc.lineAt(e).number + 1;
    return (
      this.lineWrapping &&
        (i += Math.max(
          0,
          Math.ceil((t - e - i * this.lineLength * 0.5) / this.lineLength),
        )),
      this.lineHeight * i
    );
  }
  heightForLine(e) {
    if (!this.lineWrapping) return this.lineHeight;
    return (
      (1 +
        Math.max(
          0,
          Math.ceil((e - this.lineLength) / Math.max(1, this.lineLength - 5)),
        )) *
      this.lineHeight
    );
  }
  setDoc(e) {
    return ((this.doc = e), this);
  }
  mustRefreshForWrapping(e) {
    return Gn.indexOf(e) > -1 != this.lineWrapping;
  }
  mustRefreshForHeights(e) {
    let t = !1;
    for (let i = 0; i < e.length; i++) {
      let o = e[i];
      o < 0
        ? i++
        : this.heightSamples[Math.floor(10 * o)] ||
          ((t = !0), (this.heightSamples[Math.floor(10 * o)] = !0));
    }
    return t;
  }
  refresh(e, t, i, o, n, s) {
    let r = Gn.indexOf(e) > -1,
      a =
        Math.abs(t - this.lineHeight) > 0.3 ||
        this.lineWrapping != r ||
        Math.abs(i - this.charWidth) > 0.1;
    if (
      ((this.lineWrapping = r),
      (this.lineHeight = t),
      (this.charWidth = i),
      (this.textHeight = o),
      (this.lineLength = n),
      a)
    ) {
      this.heightSamples = {};
      for (let e = 0; e < s.length; e++) {
        let t = s[e];
        t < 0 ? e++ : (this.heightSamples[Math.floor(10 * t)] = !0);
      }
    }
    return a;
  }
}
class Xn {
  constructor(e, t) {
    ((this.from = e), (this.heights = t), (this.index = 0));
  }
  get more() {
    return this.index < this.heights.length;
  }
}
class Qn {
  constructor(e, t, i, o, n) {
    ((this.from = e),
      (this.length = t),
      (this.top = i),
      (this.height = o),
      (this._content = n));
  }
  get type() {
    return "number" == typeof this._content
      ? Zt.Text
      : Array.isArray(this._content)
        ? this._content
        : this._content.type;
  }
  get to() {
    return this.from + this.length;
  }
  get bottom() {
    return this.top + this.height;
  }
  get widget() {
    return this._content instanceof Qt ? this._content.widget : null;
  }
  get widgetLineBreaks() {
    return "number" == typeof this._content ? this._content : 0;
  }
  join(e) {
    let t = (Array.isArray(this._content) ? this._content : [this]).concat(
      Array.isArray(e._content) ? e._content : [e],
    );
    return new Qn(
      this.from,
      this.length + e.length,
      this.top,
      this.height + e.height,
      t,
    );
  }
}
var es = (function (e) {
  return (
    (e[(e.ByPos = 0)] = "ByPos"),
    (e[(e.ByHeight = 1)] = "ByHeight"),
    (e[(e.ByPosNoHeight = 2)] = "ByPosNoHeight"),
    e
  );
})(es || (es = {}));
const ts = 0.001;
class is {
  constructor(e, t, i = 2) {
    ((this.length = e), (this.height = t), (this.flags = i));
  }
  get outdated() {
    return (2 & this.flags) > 0;
  }
  set outdated(e) {
    this.flags = (e ? 2 : 0) | (-3 & this.flags);
  }
  setHeight(e) {
    this.height != e &&
      (Math.abs(this.height - e) > ts && (Zn = !0), (this.height = e));
  }
  replace(e, t, i) {
    return is.of(i);
  }
  decomposeLeft(e, t) {
    t.push(this);
  }
  decomposeRight(e, t) {
    t.push(this);
  }
  applyChanges(e, t, i, o) {
    let n = this,
      s = i.doc;
    for (let r = o.length - 1; r >= 0; r--) {
      let { fromA: a, toA: l, fromB: c, toB: d } = o[r],
        h = n.lineAt(a, es.ByPosNoHeight, i.setDoc(t), 0, 0),
        u = h.to >= l ? h : n.lineAt(l, es.ByPosNoHeight, i, 0, 0);
      for (d += u.to - l, l = u.to; r > 0 && h.from <= o[r - 1].toA; )
        ((a = o[r - 1].fromA),
          (c = o[r - 1].fromB),
          r--,
          a < h.from && (h = n.lineAt(a, es.ByPosNoHeight, i, 0, 0)));
      ((c += h.from - a), (a = h.from));
      let p = ds.build(i.setDoc(s), e, c, d);
      n = os(n, n.replace(a, l, p));
    }
    return n.updateHeight(i, 0);
  }
  static empty() {
    return new rs(0, 0, 0);
  }
  static of(e) {
    if (1 == e.length) return e[0];
    let t = 0,
      i = e.length,
      o = 0,
      n = 0;
    for (;;)
      if (t == i)
        if (o > 2 * n) {
          let n = e[t - 1];
          (n.break
            ? e.splice(--t, 1, n.left, null, n.right)
            : e.splice(--t, 1, n.left, n.right),
            (i += 1 + n.break),
            (o -= n.size));
        } else {
          if (!(n > 2 * o)) break;
          {
            let t = e[i];
            (t.break
              ? e.splice(i, 1, t.left, null, t.right)
              : e.splice(i, 1, t.left, t.right),
              (i += 2 + t.break),
              (n -= t.size));
          }
        }
      else if (o < n) {
        let i = e[t++];
        i && (o += i.size);
      } else {
        let t = e[--i];
        t && (n += t.size);
      }
    let s = 0;
    return (
      null == e[t - 1] ? ((s = 1), t--) : null == e[t] && ((s = 1), i++),
      new ls(is.of(e.slice(0, t)), s, is.of(e.slice(i)))
    );
  }
}
function os(e, t) {
  return e == t ? e : (e.constructor != t.constructor && (Zn = !0), t);
}
is.prototype.size = 1;
const ns = Kt.replace({});
class ss extends is {
  constructor(e, t, i) {
    (super(e, t), (this.deco = i), (this.spaceAbove = 0));
  }
  mainBlock(e, t) {
    return new Qn(
      t,
      this.length,
      e + this.spaceAbove,
      this.height - this.spaceAbove,
      this.deco || 0,
    );
  }
  blockAt(e, t, i, o) {
    return this.spaceAbove && e < i + this.spaceAbove
      ? new Qn(o, 0, i, this.spaceAbove, ns)
      : this.mainBlock(i, o);
  }
  lineAt(e, t, i, o, n) {
    let s = this.mainBlock(o, n);
    return this.spaceAbove ? this.blockAt(0, i, o, n).join(s) : s;
  }
  forEachLine(e, t, i, o, n, s) {
    e <= n + this.length && t >= n && s(this.lineAt(0, es.ByPos, i, o, n));
  }
  setMeasuredHeight(e) {
    let t = e.heights[e.index++];
    (t < 0
      ? ((this.spaceAbove = -t), (t = e.heights[e.index++]))
      : (this.spaceAbove = 0),
      this.setHeight(t));
  }
  updateHeight(e, t = 0, i = !1, o) {
    return (
      o && o.from <= t && o.more && this.setMeasuredHeight(o),
      (this.outdated = !1),
      this
    );
  }
  toString() {
    return `block(${this.length})`;
  }
}
class rs extends ss {
  constructor(e, t, i) {
    (super(e, t, null),
      (this.collapsed = 0),
      (this.widgetHeight = 0),
      (this.breaks = 0),
      (this.spaceAbove = i));
  }
  mainBlock(e, t) {
    return new Qn(
      t,
      this.length,
      e + this.spaceAbove,
      this.height - this.spaceAbove,
      this.breaks,
    );
  }
  replace(e, t, i) {
    let o = i[0];
    return 1 == i.length &&
      (o instanceof rs || (o instanceof as && 4 & o.flags)) &&
      Math.abs(this.length - o.length) < 10
      ? (o instanceof as
          ? (o = new rs(o.length, this.height, this.spaceAbove))
          : (o.height = this.height),
        this.outdated || (o.outdated = !1),
        o)
      : is.of(i);
  }
  updateHeight(e, t = 0, i = !1, o) {
    return (
      o && o.from <= t && o.more
        ? this.setMeasuredHeight(o)
        : (i || this.outdated) &&
          ((this.spaceAbove = 0),
          this.setHeight(
            Math.max(
              this.widgetHeight,
              e.heightForLine(this.length - this.collapsed),
            ) +
              this.breaks * e.lineHeight,
          )),
      (this.outdated = !1),
      this
    );
  }
  toString() {
    return `line(${this.length}${this.collapsed ? -this.collapsed : ""}${this.widgetHeight ? ":" + this.widgetHeight : ""})`;
  }
}
class as extends is {
  constructor(e) {
    super(e, 0);
  }
  heightMetrics(e, t) {
    let i,
      o = e.doc.lineAt(t).number,
      n = e.doc.lineAt(t + this.length).number,
      s = n - o + 1,
      r = 0;
    if (e.lineWrapping) {
      let t = Math.min(this.height, e.lineHeight * s);
      ((i = t / s),
        this.length > s + 1 && (r = (this.height - t) / (this.length - s - 1)));
    } else i = this.height / s;
    return { firstLine: o, lastLine: n, perLine: i, perChar: r };
  }
  blockAt(e, t, i, o) {
    let {
      firstLine: n,
      lastLine: s,
      perLine: r,
      perChar: a,
    } = this.heightMetrics(t, o);
    if (t.lineWrapping) {
      let n =
          o +
          (e < t.lineHeight
            ? 0
            : Math.round(
                Math.max(0, Math.min(1, (e - i) / this.height)) * this.length,
              )),
        s = t.doc.lineAt(n),
        l = r + s.length * a,
        c = Math.max(i, e - l / 2);
      return new Qn(s.from, s.length, c, l, 0);
    }
    {
      let o = Math.max(0, Math.min(s - n, Math.floor((e - i) / r))),
        { from: a, length: l } = t.doc.line(n + o);
      return new Qn(a, l, i + r * o, r, 0);
    }
  }
  lineAt(e, t, i, o, n) {
    if (t == es.ByHeight) return this.blockAt(e, i, o, n);
    if (t == es.ByPosNoHeight) {
      let { from: t, to: o } = i.doc.lineAt(e);
      return new Qn(t, o - t, 0, 0, 0);
    }
    let { firstLine: s, perLine: r, perChar: a } = this.heightMetrics(i, n),
      l = i.doc.lineAt(e),
      c = r + l.length * a,
      d = l.number - s,
      h = o + r * d + a * (l.from - n - d);
    return new Qn(
      l.from,
      l.length,
      Math.max(o, Math.min(h, o + this.height - c)),
      c,
      0,
    );
  }
  forEachLine(e, t, i, o, n, s) {
    ((e = Math.max(e, n)), (t = Math.min(t, n + this.length)));
    let { firstLine: r, perLine: a, perChar: l } = this.heightMetrics(i, n);
    for (let c = e, d = o; c <= t; ) {
      let t = i.doc.lineAt(c);
      if (c == e) {
        let i = t.number - r;
        d += a * i + l * (e - n - i);
      }
      let o = a + l * t.length;
      (s(new Qn(t.from, t.length, d, o, 0)), (d += o), (c = t.to + 1));
    }
  }
  replace(e, t, i) {
    let o = this.length - t;
    if (o > 0) {
      let e = i[i.length - 1];
      e instanceof as
        ? (i[i.length - 1] = new as(e.length + o))
        : i.push(null, new as(o - 1));
    }
    if (e > 0) {
      let t = i[0];
      t instanceof as
        ? (i[0] = new as(e + t.length))
        : i.unshift(new as(e - 1), null);
    }
    return is.of(i);
  }
  decomposeLeft(e, t) {
    t.push(new as(e - 1), null);
  }
  decomposeRight(e, t) {
    t.push(null, new as(this.length - e - 1));
  }
  updateHeight(e, t = 0, i = !1, o) {
    let n = t + this.length;
    if (o && o.from <= t + this.length && o.more) {
      let i = [],
        s = Math.max(t, o.from),
        r = -1;
      for (
        o.from > t && i.push(new as(o.from - t - 1).updateHeight(e, t));
        s <= n && o.more;
      ) {
        let t = e.doc.lineAt(s).length;
        i.length && i.push(null);
        let n = o.heights[o.index++],
          a = 0;
        (n < 0 && ((a = -n), (n = o.heights[o.index++])),
          -1 == r ? (r = n) : Math.abs(n - r) >= ts && (r = -2));
        let l = new rs(t, n, a);
        ((l.outdated = !1), i.push(l), (s += t + 1));
      }
      s <= n && i.push(null, new as(n - s).updateHeight(e, s));
      let a = is.of(i);
      return (
        (r < 0 ||
          Math.abs(a.height - this.height) >= ts ||
          Math.abs(r - this.heightMetrics(e, t).perLine) >= ts) &&
          (Zn = !0),
        os(this, a)
      );
    }
    return (
      (i || this.outdated) &&
        (this.setHeight(e.heightForGap(t, t + this.length)),
        (this.outdated = !1)),
      this
    );
  }
  toString() {
    return `gap(${this.length})`;
  }
}
class ls extends is {
  constructor(e, t, i) {
    (super(
      e.length + t + i.length,
      e.height + i.height,
      t | (e.outdated || i.outdated ? 2 : 0),
    ),
      (this.left = e),
      (this.right = i),
      (this.size = e.size + i.size));
  }
  get break() {
    return 1 & this.flags;
  }
  blockAt(e, t, i, o) {
    let n = i + this.left.height;
    return e < n
      ? this.left.blockAt(e, t, i, o)
      : this.right.blockAt(e, t, n, o + this.left.length + this.break);
  }
  lineAt(e, t, i, o, n) {
    let s = o + this.left.height,
      r = n + this.left.length + this.break,
      a = t == es.ByHeight ? e < s : e < r,
      l = a
        ? this.left.lineAt(e, t, i, o, n)
        : this.right.lineAt(e, t, i, s, r);
    if (this.break || (a ? l.to < r : l.from > r)) return l;
    let c = t == es.ByPosNoHeight ? es.ByPosNoHeight : es.ByPos;
    return a
      ? l.join(this.right.lineAt(r, c, i, s, r))
      : this.left.lineAt(r, c, i, o, n).join(l);
  }
  forEachLine(e, t, i, o, n, s) {
    let r = o + this.left.height,
      a = n + this.left.length + this.break;
    if (this.break)
      (e < a && this.left.forEachLine(e, t, i, o, n, s),
        t >= a && this.right.forEachLine(e, t, i, r, a, s));
    else {
      let l = this.lineAt(a, es.ByPos, i, o, n);
      (e < l.from && this.left.forEachLine(e, l.from - 1, i, o, n, s),
        l.to >= e && l.from <= t && s(l),
        t > l.to && this.right.forEachLine(l.to + 1, t, i, r, a, s));
    }
  }
  replace(e, t, i) {
    let o = this.left.length + this.break;
    if (t < o) return this.balanced(this.left.replace(e, t, i), this.right);
    if (e > this.left.length)
      return this.balanced(this.left, this.right.replace(e - o, t - o, i));
    let n = [];
    e > 0 && this.decomposeLeft(e, n);
    let s = n.length;
    for (let e of i) n.push(e);
    if ((e > 0 && cs(n, s - 1), t < this.length)) {
      let e = n.length;
      (this.decomposeRight(t, n), cs(n, e));
    }
    return is.of(n);
  }
  decomposeLeft(e, t) {
    let i = this.left.length;
    if (e <= i) return this.left.decomposeLeft(e, t);
    (t.push(this.left),
      this.break && (i++, e >= i && t.push(null)),
      e > i && this.right.decomposeLeft(e - i, t));
  }
  decomposeRight(e, t) {
    let i = this.left.length,
      o = i + this.break;
    if (e >= o) return this.right.decomposeRight(e - o, t);
    (e < i && this.left.decomposeRight(e, t),
      this.break && e < o && t.push(null),
      t.push(this.right));
  }
  balanced(e, t) {
    return e.size > 2 * t.size || t.size > 2 * e.size
      ? is.of(this.break ? [e, null, t] : [e, t])
      : ((this.left = os(this.left, e)),
        (this.right = os(this.right, t)),
        this.setHeight(e.height + t.height),
        (this.outdated = e.outdated || t.outdated),
        (this.size = e.size + t.size),
        (this.length = e.length + this.break + t.length),
        this);
  }
  updateHeight(e, t = 0, i = !1, o) {
    let { left: n, right: s } = this,
      r = t + n.length + this.break,
      a = null;
    return (
      o && o.from <= t + n.length && o.more
        ? (a = n = n.updateHeight(e, t, i, o))
        : n.updateHeight(e, t, i),
      o && o.from <= r + s.length && o.more
        ? (a = s = s.updateHeight(e, r, i, o))
        : s.updateHeight(e, r, i),
      a
        ? this.balanced(n, s)
        : ((this.height = this.left.height + this.right.height),
          (this.outdated = !1),
          this)
    );
  }
  toString() {
    return this.left + (this.break ? " " : "-") + this.right;
  }
}
function cs(e, t) {
  let i, o;
  null == e[t] &&
    (i = e[t - 1]) instanceof as &&
    (o = e[t + 1]) instanceof as &&
    e.splice(t - 1, 3, new as(i.length + 1 + o.length));
}
class ds {
  constructor(e, t) {
    ((this.pos = e),
      (this.oracle = t),
      (this.nodes = []),
      (this.lineStart = -1),
      (this.lineEnd = -1),
      (this.covering = null),
      (this.writtenTo = e));
  }
  get isCovered() {
    return this.covering && this.nodes[this.nodes.length - 1] == this.covering;
  }
  span(e, t) {
    if (this.lineStart > -1) {
      let e = Math.min(t, this.lineEnd),
        i = this.nodes[this.nodes.length - 1];
      (i instanceof rs
        ? (i.length += e - this.pos)
        : (e > this.pos || !this.isCovered) &&
          this.nodes.push(new rs(e - this.pos, -1, 0)),
        (this.writtenTo = e),
        t > e &&
          (this.nodes.push(null), this.writtenTo++, (this.lineStart = -1)));
    }
    this.pos = t;
  }
  point(e, t, i) {
    if (e < t || i.heightRelevant) {
      let o = i.widget ? i.widget.estimatedHeight : 0,
        n = i.widget ? i.widget.lineBreaks : 0;
      o < 0 && (o = this.oracle.lineHeight);
      let s = t - e;
      i.block
        ? this.addBlock(new ss(s, o, i))
        : (s || n || o >= 5) && this.addLineDeco(o, n, s);
    } else t > e && this.span(e, t);
    this.lineEnd > -1 &&
      this.lineEnd < this.pos &&
      (this.lineEnd = this.oracle.doc.lineAt(this.pos).to);
  }
  enterLine() {
    if (this.lineStart > -1) return;
    let { from: e, to: t } = this.oracle.doc.lineAt(this.pos);
    ((this.lineStart = e),
      (this.lineEnd = t),
      this.writtenTo < e &&
        ((this.writtenTo < e - 1 ||
          null == this.nodes[this.nodes.length - 1]) &&
          this.nodes.push(this.blankContent(this.writtenTo, e - 1)),
        this.nodes.push(null)),
      this.pos > e && this.nodes.push(new rs(this.pos - e, -1, 0)),
      (this.writtenTo = this.pos));
  }
  blankContent(e, t) {
    let i = new as(t - e);
    return (this.oracle.doc.lineAt(e).to == t && (i.flags |= 4), i);
  }
  ensureLine() {
    this.enterLine();
    let e = this.nodes.length ? this.nodes[this.nodes.length - 1] : null;
    if (e instanceof rs) return e;
    let t = new rs(0, -1, 0);
    return (this.nodes.push(t), t);
  }
  addBlock(e) {
    this.enterLine();
    let t = e.deco;
    (t && t.startSide > 0 && !this.isCovered && this.ensureLine(),
      this.nodes.push(e),
      (this.writtenTo = this.pos = this.pos + e.length),
      t && t.endSide > 0 && (this.covering = e));
  }
  addLineDeco(e, t, i) {
    let o = this.ensureLine();
    ((o.length += i),
      (o.collapsed += i),
      (o.widgetHeight = Math.max(o.widgetHeight, e)),
      (o.breaks += t),
      (this.writtenTo = this.pos = this.pos + i));
  }
  finish(e) {
    let t = 0 == this.nodes.length ? null : this.nodes[this.nodes.length - 1];
    !(this.lineStart > -1) || t instanceof rs || this.isCovered
      ? (this.writtenTo < this.pos || null == t) &&
        this.nodes.push(this.blankContent(this.writtenTo, this.pos))
      : this.nodes.push(new rs(0, -1, 0));
    let i = e;
    for (let e of this.nodes)
      (e instanceof rs && e.updateHeight(this.oracle, i),
        (i += e ? e.length : 1));
    return this.nodes;
  }
  static build(e, t, i, o) {
    let n = new ds(i, e);
    return (ct.spans(t, i, o, n, 0), n.finish(i));
  }
}
class hs {
  constructor() {
    this.changes = [];
  }
  compareRange() {}
  comparePoint(e, t, i, o) {
    (e < t || (i && i.heightRelevant) || (o && o.heightRelevant)) &&
      ti(e, t, this.changes, 5);
  }
}
function us(e, t) {
  let i = e.getBoundingClientRect(),
    o = e.ownerDocument,
    n = o.defaultView || window,
    s = Math.max(0, i.left),
    r = Math.min(n.innerWidth, i.right),
    a = Math.max(0, i.top),
    l = Math.min(n.innerHeight, i.bottom);
  for (let t = e.parentNode; t && t != o.body; )
    if (1 == t.nodeType) {
      let i = t,
        o = window.getComputedStyle(i);
      if (
        (i.scrollHeight > i.clientHeight || i.scrollWidth > i.clientWidth) &&
        "visible" != o.overflow
      ) {
        let o = i.getBoundingClientRect();
        ((s = Math.max(s, o.left)),
          (r = Math.min(r, o.right)),
          (a = Math.max(a, o.top)),
          (l = Math.min(t == e.parentNode ? n.innerHeight : l, o.bottom)));
      }
      t =
        "absolute" == o.position || "fixed" == o.position
          ? i.offsetParent
          : i.parentNode;
    } else {
      if (11 != t.nodeType) break;
      t = t.host;
    }
  return {
    left: s - i.left,
    right: Math.max(s, r) - i.left,
    top: a - (i.top + t),
    bottom: Math.max(a, l) - (i.top + t),
  };
}
function ps(e, t) {
  let i = e.getBoundingClientRect();
  return {
    left: 0,
    right: i.right - i.left,
    top: t,
    bottom: i.bottom - (i.top + t),
  };
}
class ms {
  constructor(e, t, i, o) {
    ((this.from = e), (this.to = t), (this.size = i), (this.displaySize = o));
  }
  static same(e, t) {
    if (e.length != t.length) return !1;
    for (let i = 0; i < e.length; i++) {
      let o = e[i],
        n = t[i];
      if (o.from != n.from || o.to != n.to || o.size != n.size) return !1;
    }
    return !0;
  }
  draw(e, t) {
    return Kt.replace({
      widget: new gs(this.displaySize * (t ? e.scaleY : e.scaleX), t),
    }).range(this.from, this.to);
  }
}
class gs extends Gt {
  constructor(e, t) {
    (super(), (this.size = e), (this.vertical = t));
  }
  eq(e) {
    return e.size == this.size && e.vertical == this.vertical;
  }
  toDOM() {
    let e = document.createElement("div");
    return (
      this.vertical
        ? (e.style.height = this.size + "px")
        : ((e.style.width = this.size + "px"),
          (e.style.height = "2px"),
          (e.style.display = "inline-block")),
      e
    );
  }
  get estimatedHeight() {
    return this.vertical ? this.size : -1;
  }
}
class fs {
  constructor(e) {
    ((this.state = e),
      (this.pixelViewport = {
        left: 0,
        right: window.innerWidth,
        top: 0,
        bottom: 0,
      }),
      (this.inView = !0),
      (this.paddingTop = 0),
      (this.paddingBottom = 0),
      (this.contentDOMWidth = 0),
      (this.contentDOMHeight = 0),
      (this.editorHeight = 0),
      (this.editorWidth = 0),
      (this.scrollTop = 0),
      (this.scrolledToBottom = !1),
      (this.scaleX = 1),
      (this.scaleY = 1),
      (this.scrollAnchorPos = 0),
      (this.scrollAnchorHeight = -1),
      (this.scaler = vs),
      (this.scrollTarget = null),
      (this.printing = !1),
      (this.mustMeasureContent = !0),
      (this.defaultTextDirection = Ti.LTR),
      (this.visibleRanges = []),
      (this.mustEnforceCursorAssoc = !1));
    let t = e
      .facet(po)
      .some((e) => "function" != typeof e && "cm-lineWrapping" == e.class);
    ((this.heightOracle = new Jn(t)),
      (this.stateDeco = Cs(e)),
      (this.heightMap = is
        .empty()
        .applyChanges(
          this.stateDeco,
          $.empty,
          this.heightOracle.setDoc(e.doc),
          [new ko(0, 0, 0, e.doc.length)],
        )));
    for (
      let e = 0;
      e < 2 &&
      ((this.viewport = this.getViewport(0, null)), this.updateForViewport());
      e++
    );
    (this.updateViewportLines(),
      (this.lineGaps = this.ensureLineGaps([])),
      (this.lineGapDeco = Kt.set(this.lineGaps.map((e) => e.draw(this, !1)))),
      this.computeVisibleRanges());
  }
  updateForViewport() {
    let e = [this.viewport],
      { main: t } = this.state.selection;
    for (let i = 0; i <= 1; i++) {
      let o = i ? t.head : t.anchor;
      if (!e.some(({ from: e, to: t }) => o >= e && o <= t)) {
        let { from: t, to: i } = this.lineBlockAt(o);
        e.push(new bs(t, i));
      }
    }
    return (
      (this.viewports = e.sort((e, t) => e.from - t.from)),
      this.updateScaler()
    );
  }
  updateScaler() {
    let e = this.scaler;
    return (
      (this.scaler =
        this.heightMap.height <= 7e6
          ? vs
          : new xs(this.heightOracle, this.heightMap, this.viewports)),
      e.eq(this.scaler) ? 0 : 2
    );
  }
  updateViewportLines() {
    ((this.viewportLines = []),
      this.heightMap.forEachLine(
        this.viewport.from,
        this.viewport.to,
        this.heightOracle.setDoc(this.state.doc),
        0,
        0,
        (e) => {
          this.viewportLines.push(ks(e, this.scaler));
        },
      ));
  }
  update(e, t = null) {
    this.state = e.state;
    let i = this.stateDeco;
    this.stateDeco = Cs(this.state);
    let o = e.changedRanges,
      n = ko.extendWithRanges(
        o,
        (function (e, t, i) {
          let o = new hs();
          return (ct.compare(e, t, i, o, 0), o.changes);
        })(i, this.stateDeco, e ? e.changes : ne.empty(this.state.doc.length)),
      ),
      s = this.heightMap.height,
      r = this.scrolledToBottom ? null : this.scrollAnchorAt(this.scrollTop);
    (Kn(),
      (this.heightMap = this.heightMap.applyChanges(
        this.stateDeco,
        e.startState.doc,
        this.heightOracle.setDoc(this.state.doc),
        n,
      )),
      (this.heightMap.height != s || Zn) && (e.flags |= 2),
      r
        ? ((this.scrollAnchorPos = e.changes.mapPos(r.from, -1)),
          (this.scrollAnchorHeight = r.top))
        : ((this.scrollAnchorPos = -1), (this.scrollAnchorHeight = s)));
    let a = n.length
      ? this.mapViewport(this.viewport, e.changes)
      : this.viewport;
    ((t && (t.range.head < a.from || t.range.head > a.to)) ||
      !this.viewportIsAppropriate(a)) &&
      (a = this.getViewport(0, t));
    let l = a.from != this.viewport.from || a.to != this.viewport.to;
    ((this.viewport = a),
      (e.flags |= this.updateForViewport()),
      (l || !e.changes.empty || 2 & e.flags) && this.updateViewportLines(),
      (this.lineGaps.length || this.viewport.to - this.viewport.from > 4e3) &&
        this.updateLineGaps(
          this.ensureLineGaps(this.mapLineGaps(this.lineGaps, e.changes)),
        ),
      (e.flags |= this.computeVisibleRanges(e.changes)),
      t && (this.scrollTarget = t),
      !this.mustEnforceCursorAssoc &&
        (e.selectionSet || e.focusChanged) &&
        e.view.lineWrapping &&
        e.state.selection.main.empty &&
        e.state.selection.main.assoc &&
        !e.state.facet(eo) &&
        (this.mustEnforceCursorAssoc = !0));
  }
  measure(e) {
    let t = e.contentDOM,
      i = window.getComputedStyle(t),
      o = this.heightOracle,
      n = i.whiteSpace;
    this.defaultTextDirection = "rtl" == i.direction ? Ti.RTL : Ti.LTR;
    let s =
        this.heightOracle.mustRefreshForWrapping(n) || this.mustMeasureContent,
      r = t.getBoundingClientRect(),
      a = s || this.mustMeasureContent || this.contentDOMHeight != r.height;
    ((this.contentDOMHeight = r.height), (this.mustMeasureContent = !1));
    let l = 0,
      c = 0;
    if (r.width && r.height) {
      let { scaleX: e, scaleY: i } = mi(t, r);
      ((e > 0.005 && Math.abs(this.scaleX - e) > 0.005) ||
        (i > 0.005 && Math.abs(this.scaleY - i) > 0.005)) &&
        ((this.scaleX = e), (this.scaleY = i), (l |= 16), (s = a = !0));
    }
    let d = (parseInt(i.paddingTop) || 0) * this.scaleY,
      h = (parseInt(i.paddingBottom) || 0) * this.scaleY;
    ((this.paddingTop == d && this.paddingBottom == h) ||
      ((this.paddingTop = d), (this.paddingBottom = h), (l |= 18)),
      this.editorWidth != e.scrollDOM.clientWidth &&
        (o.lineWrapping && (a = !0),
        (this.editorWidth = e.scrollDOM.clientWidth),
        (l |= 16)));
    let u = e.scrollDOM.scrollTop * this.scaleY;
    (this.scrollTop != u &&
      ((this.scrollAnchorHeight = -1), (this.scrollTop = u)),
      (this.scrolledToBottom = Ci(e.scrollDOM)));
    let p = (this.printing ? ps : us)(t, this.paddingTop),
      m = p.top - this.pixelViewport.top,
      g = p.bottom - this.pixelViewport.bottom;
    this.pixelViewport = p;
    let f =
      this.pixelViewport.bottom > this.pixelViewport.top &&
      this.pixelViewport.right > this.pixelViewport.left;
    if (
      (f != this.inView && ((this.inView = f), f && (a = !0)),
      !this.inView &&
        !this.scrollTarget &&
        !(function (e) {
          let t = e.getBoundingClientRect(),
            i = e.ownerDocument.defaultView || window;
          return (
            t.left < i.innerWidth &&
            t.right > 0 &&
            t.top < i.innerHeight &&
            t.bottom > 0
          );
        })(e.dom))
    )
      return 0;
    let b = r.width;
    if (
      ((this.contentDOMWidth == b &&
        this.editorHeight == e.scrollDOM.clientHeight) ||
        ((this.contentDOMWidth = r.width),
        (this.editorHeight = e.scrollDOM.clientHeight),
        (l |= 16)),
      a)
    ) {
      let t = e.docView.measureVisibleLineHeights(this.viewport);
      if (
        (o.mustRefreshForHeights(t) && (s = !0),
        s ||
          (o.lineWrapping && Math.abs(b - this.contentDOMWidth) > o.charWidth))
      ) {
        let {
          lineHeight: i,
          charWidth: r,
          textHeight: a,
        } = e.docView.measureTextSize();
        ((s = i > 0 && o.refresh(n, i, r, a, Math.max(5, b / r), t)),
          s && ((e.docView.minWidth = 0), (l |= 16)));
      }
      (m > 0 && g > 0
        ? (c = Math.max(m, g))
        : m < 0 && g < 0 && (c = Math.min(m, g)),
        Kn());
      for (let i of this.viewports) {
        let n =
          i.from == this.viewport.from
            ? t
            : e.docView.measureVisibleLineHeights(i);
        this.heightMap = (
          s
            ? is
                .empty()
                .applyChanges(this.stateDeco, $.empty, this.heightOracle, [
                  new ko(0, 0, 0, e.state.doc.length),
                ])
            : this.heightMap
        ).updateHeight(o, 0, s, new Xn(i.from, n));
      }
      Zn && (l |= 2);
    }
    let y =
      !this.viewportIsAppropriate(this.viewport, c) ||
      (this.scrollTarget &&
        (this.scrollTarget.range.head < this.viewport.from ||
          this.scrollTarget.range.head > this.viewport.to));
    return (
      y &&
        (2 & l && (l |= this.updateScaler()),
        (this.viewport = this.getViewport(c, this.scrollTarget)),
        (l |= this.updateForViewport())),
      (2 & l || y) && this.updateViewportLines(),
      (this.lineGaps.length || this.viewport.to - this.viewport.from > 4e3) &&
        this.updateLineGaps(this.ensureLineGaps(s ? [] : this.lineGaps, e)),
      (l |= this.computeVisibleRanges()),
      this.mustEnforceCursorAssoc &&
        ((this.mustEnforceCursorAssoc = !1), e.docView.enforceCursorAssoc()),
      l
    );
  }
  get visibleTop() {
    return this.scaler.fromDOM(this.pixelViewport.top);
  }
  get visibleBottom() {
    return this.scaler.fromDOM(this.pixelViewport.bottom);
  }
  getViewport(e, t) {
    let i = 0.5 - Math.max(-0.5, Math.min(0.5, e / 1e3 / 2)),
      o = this.heightMap,
      n = this.heightOracle,
      { visibleTop: s, visibleBottom: r } = this,
      a = new bs(
        o.lineAt(s - 1e3 * i, es.ByHeight, n, 0, 0).from,
        o.lineAt(r + 1e3 * (1 - i), es.ByHeight, n, 0, 0).to,
      );
    if (t) {
      let { head: e } = t.range;
      if (e < a.from || e > a.to) {
        let i,
          s = Math.min(
            this.editorHeight,
            this.pixelViewport.bottom - this.pixelViewport.top,
          ),
          r = o.lineAt(e, es.ByPos, n, 0, 0);
        ((i =
          "center" == t.y
            ? (r.top + r.bottom) / 2 - s / 2
            : "start" == t.y || ("nearest" == t.y && e < a.from)
              ? r.top
              : r.bottom - s),
          (a = new bs(
            o.lineAt(i - 500, es.ByHeight, n, 0, 0).from,
            o.lineAt(i + s + 500, es.ByHeight, n, 0, 0).to,
          )));
      }
    }
    return a;
  }
  mapViewport(e, t) {
    let i = t.mapPos(e.from, -1),
      o = t.mapPos(e.to, 1);
    return new bs(
      this.heightMap.lineAt(i, es.ByPos, this.heightOracle, 0, 0).from,
      this.heightMap.lineAt(o, es.ByPos, this.heightOracle, 0, 0).to,
    );
  }
  viewportIsAppropriate({ from: e, to: t }, i = 0) {
    if (!this.inView) return !0;
    let { top: o } = this.heightMap.lineAt(
        e,
        es.ByPos,
        this.heightOracle,
        0,
        0,
      ),
      { bottom: n } = this.heightMap.lineAt(
        t,
        es.ByPos,
        this.heightOracle,
        0,
        0,
      ),
      { visibleTop: s, visibleBottom: r } = this;
    return (
      (0 == e || o <= s - Math.max(10, Math.min(-i, 250))) &&
      (t == this.state.doc.length || n >= r + Math.max(10, Math.min(i, 250))) &&
      o > s - 2e3 &&
      n < r + 2e3
    );
  }
  mapLineGaps(e, t) {
    if (!e.length || t.empty) return e;
    let i = [];
    for (let o of e)
      t.touchesRange(o.from, o.to) ||
        i.push(new ms(t.mapPos(o.from), t.mapPos(o.to), o.size, o.displaySize));
    return i;
  }
  ensureLineGaps(e, t) {
    let i = this.heightOracle.lineWrapping,
      o = i ? 1e4 : 2e3,
      n = o >> 1,
      s = o << 1;
    if (this.defaultTextDirection != Ti.LTR && !i) return [];
    let r = [],
      a = (o, s, l, c) => {
        if (s - o < n) return;
        let d = this.state.selection.main,
          h = [d.from];
        d.empty || h.push(d.to);
        for (let e of h)
          if (e > o && e < s)
            return (a(o, e - 10, l, c), void a(e + 10, s, l, c));
        let u = (function (e, t) {
          for (let i of e) if (t(i)) return i;
          return;
        })(
          e,
          (e) =>
            e.from >= l.from &&
            e.to <= l.to &&
            Math.abs(e.from - o) < n &&
            Math.abs(e.to - s) < n &&
            !h.some((t) => e.from < t && e.to > t),
        );
        if (!u) {
          if (
            s < l.to &&
            t &&
            i &&
            t.visibleRanges.some((e) => e.from <= s && e.to >= s)
          ) {
            let e = t.moveToLineBoundary(ue.cursor(s), !1, !0).head;
            e > o && (s = e);
          }
          let e = this.gapSize(l, o, s, c);
          u = new ms(o, s, e, i || e < 2e6 ? e : 2e6);
        }
        r.push(u);
      },
      l = (t) => {
        if (t.length < s || t.type != Zt.Text) return;
        let n = (function (e, t, i) {
          let o = [],
            n = e,
            s = 0;
          (ct.spans(
            i,
            e,
            t,
            {
              span() {},
              point(e, t) {
                (e > n && (o.push({ from: n, to: e }), (s += e - n)), (n = t));
              },
            },
            20,
          ),
            n < t && (o.push({ from: n, to: t }), (s += t - n)));
          return { total: s, ranges: o };
        })(t.from, t.to, this.stateDeco);
        if (n.total < s) return;
        let r,
          l,
          c = this.scrollTarget ? this.scrollTarget.range.head : null;
        if (i) {
          let e,
            i,
            s =
              (o / this.heightOracle.lineLength) * this.heightOracle.lineHeight;
          if (null != c) {
            let o = ws(n, c),
              r = ((this.visibleBottom - this.visibleTop) / 2 + s) / t.height;
            ((e = o - r), (i = o + r));
          } else
            ((e = (this.visibleTop - t.top - s) / t.height),
              (i = (this.visibleBottom - t.top + s) / t.height));
          ((r = ys(n, e)), (l = ys(n, i)));
        } else {
          let i = n.total * this.heightOracle.charWidth,
            s = o * this.heightOracle.charWidth,
            a = 0;
          if (i > 2e6)
            for (let i of e)
              i.from >= t.from &&
                i.from < t.to &&
                i.size != i.displaySize &&
                i.from * this.heightOracle.charWidth + a <
                  this.pixelViewport.left &&
                (a = i.size - i.displaySize);
          let d,
            h,
            u = this.pixelViewport.left + a,
            p = this.pixelViewport.right + a;
          if (null != c) {
            let e = ws(n, c),
              t = ((p - u) / 2 + s) / i;
            ((d = e - t), (h = e + t));
          } else ((d = (u - s) / i), (h = (p + s) / i));
          ((r = ys(n, d)), (l = ys(n, h)));
        }
        (r > t.from && a(t.from, r, t, n), l < t.to && a(l, t.to, t, n));
      };
    for (let e of this.viewportLines)
      Array.isArray(e.type) ? e.type.forEach(l) : l(e);
    return r;
  }
  gapSize(e, t, i, o) {
    let n = ws(o, i) - ws(o, t);
    return this.heightOracle.lineWrapping
      ? e.height * n
      : o.total * this.heightOracle.charWidth * n;
  }
  updateLineGaps(e) {
    ms.same(e, this.lineGaps) ||
      ((this.lineGaps = e),
      (this.lineGapDeco = Kt.set(
        e.map((e) => e.draw(this, this.heightOracle.lineWrapping)),
      )));
  }
  computeVisibleRanges(e) {
    let t = this.stateDeco;
    this.lineGaps.length && (t = t.concat(this.lineGapDeco));
    let i = [];
    ct.spans(
      t,
      this.viewport.from,
      this.viewport.to,
      {
        span(e, t) {
          i.push({ from: e, to: t });
        },
        point() {},
      },
      20,
    );
    let o = 0;
    if (i.length != this.visibleRanges.length) o = 12;
    else
      for (let t = 0; t < i.length && !(8 & o); t++) {
        let n = this.visibleRanges[t],
          s = i[t];
        (n.from == s.from && n.to == s.to) ||
          ((o |= 4),
          (e && e.mapPos(n.from, -1) == s.from && e.mapPos(n.to, 1) == s.to) ||
            (o |= 8));
      }
    return ((this.visibleRanges = i), o);
  }
  lineBlockAt(e) {
    return (
      (e >= this.viewport.from &&
        e <= this.viewport.to &&
        this.viewportLines.find((t) => t.from <= e && t.to >= e)) ||
      ks(
        this.heightMap.lineAt(e, es.ByPos, this.heightOracle, 0, 0),
        this.scaler,
      )
    );
  }
  lineBlockAtHeight(e) {
    return (
      (e >= this.viewportLines[0].top &&
        e <= this.viewportLines[this.viewportLines.length - 1].bottom &&
        this.viewportLines.find((t) => t.top <= e && t.bottom >= e)) ||
      ks(
        this.heightMap.lineAt(
          this.scaler.fromDOM(e),
          es.ByHeight,
          this.heightOracle,
          0,
          0,
        ),
        this.scaler,
      )
    );
  }
  scrollAnchorAt(e) {
    let t = this.lineBlockAtHeight(e + 8);
    return t.from >= this.viewport.from || this.viewportLines[0].top - e > 200
      ? t
      : this.viewportLines[0];
  }
  elementAtHeight(e) {
    return ks(
      this.heightMap.blockAt(this.scaler.fromDOM(e), this.heightOracle, 0, 0),
      this.scaler,
    );
  }
  get docHeight() {
    return this.scaler.toDOM(this.heightMap.height);
  }
  get contentHeight() {
    return this.docHeight + this.paddingTop + this.paddingBottom;
  }
}
class bs {
  constructor(e, t) {
    ((this.from = e), (this.to = t));
  }
}
function ys({ total: e, ranges: t }, i) {
  if (i <= 0) return t[0].from;
  if (i >= 1) return t[t.length - 1].to;
  let o = Math.floor(e * i);
  for (let e = 0; ; e++) {
    let { from: i, to: n } = t[e],
      s = n - i;
    if (o <= s) return i + o;
    o -= s;
  }
}
function ws(e, t) {
  let i = 0;
  for (let { from: o, to: n } of e.ranges) {
    if (t <= n) {
      i += t - o;
      break;
    }
    i += n - o;
  }
  return i / e.total;
}
const vs = {
  toDOM: (e) => e,
  fromDOM: (e) => e,
  scale: 1,
  eq(e) {
    return e == this;
  },
};
function Cs(e) {
  let t = e.facet(mo).filter((e) => "function" != typeof e),
    i = e.facet(fo).filter((e) => "function" != typeof e);
  return (i.length && t.push(ct.join(i)), t);
}
class xs {
  constructor(e, t, i) {
    let o = 0,
      n = 0,
      s = 0;
    ((this.viewports = i.map(({ from: i, to: n }) => {
      let s = t.lineAt(i, es.ByPos, e, 0, 0).top,
        r = t.lineAt(n, es.ByPos, e, 0, 0).bottom;
      return (
        (o += r - s),
        { from: i, to: n, top: s, bottom: r, domTop: 0, domBottom: 0 }
      );
    })),
      (this.scale = (7e6 - o) / (t.height - o)));
    for (let e of this.viewports)
      ((e.domTop = s + (e.top - n) * this.scale),
        (s = e.domBottom = e.domTop + (e.bottom - e.top)),
        (n = e.bottom));
  }
  toDOM(e) {
    for (let t = 0, i = 0, o = 0; ; t++) {
      let n = t < this.viewports.length ? this.viewports[t] : null;
      if (!n || e < n.top) return o + (e - i) * this.scale;
      if (e <= n.bottom) return n.domTop + (e - n.top);
      ((i = n.bottom), (o = n.domBottom));
    }
  }
  fromDOM(e) {
    for (let t = 0, i = 0, o = 0; ; t++) {
      let n = t < this.viewports.length ? this.viewports[t] : null;
      if (!n || e < n.domTop) return i + (e - o) / this.scale;
      if (e <= n.domBottom) return n.top + (e - n.domTop);
      ((i = n.bottom), (o = n.domBottom));
    }
  }
  eq(e) {
    return (
      e instanceof xs &&
      this.scale == e.scale &&
      this.viewports.length == e.viewports.length &&
      this.viewports.every(
        (t, i) => t.from == e.viewports[i].from && t.to == e.viewports[i].to,
      )
    );
  }
}
function ks(e, t) {
  if (1 == t.scale) return e;
  let i = t.toDOM(e.top),
    o = t.toDOM(e.bottom);
  return new Qn(
    e.from,
    e.length,
    i,
    o - i,
    Array.isArray(e._content) ? e._content.map((e) => ks(e, t)) : e._content,
  );
}
const Ss = ge.define({ combine: (e) => e.join(" ") }),
  Ts = ge.define({ combine: (e) => e.indexOf(!0) > -1 }),
  Es = St.newName(),
  Ms = St.newName(),
  As = St.newName(),
  Is = { "&light": "." + Ms, "&dark": "." + As };
function Ds(e, t, i) {
  return new St(t, {
    finish: (t) =>
      /&/.test(t)
        ? t.replace(/&\w*/, (t) => {
            if ("&" == t) return e;
            if (!i || !i[t]) throw new RangeError(`Unsupported selector: ${t}`);
            return i[t];
          })
        : e + " " + t,
  });
}
const Os = Ds(
    "." + Es,
    {
      "&": {
        position: "relative !important",
        boxSizing: "border-box",
        "&.cm-focused": { outline: "1px dotted #212121" },
        display: "flex !important",
        flexDirection: "column",
      },
      ".cm-scroller": {
        display: "flex !important",
        alignItems: "flex-start !important",
        fontFamily: "monospace",
        lineHeight: 1.4,
        height: "100%",
        overflowX: "auto",
        position: "relative",
        zIndex: 0,
        overflowAnchor: "none",
      },
      ".cm-content": {
        margin: 0,
        flexGrow: 2,
        flexShrink: 0,
        display: "block",
        whiteSpace: "pre",
        wordWrap: "normal",
        boxSizing: "border-box",
        minHeight: "100%",
        padding: "4px 0",
        outline: "none",
        "&[contenteditable=true]": {
          WebkitUserModify: "read-write-plaintext-only",
        },
      },
      ".cm-lineWrapping": {
        whiteSpace_fallback: "pre-wrap",
        whiteSpace: "break-spaces",
        wordBreak: "break-word",
        overflowWrap: "anywhere",
        flexShrink: 1,
      },
      "&light .cm-content": { caretColor: "black" },
      "&dark .cm-content": { caretColor: "white" },
      ".cm-line": { display: "block", padding: "0 2px 0 6px" },
      ".cm-layer": {
        position: "absolute",
        left: 0,
        top: 0,
        contain: "size style",
        "& > *": { position: "absolute" },
      },
      "&light .cm-selectionBackground": { background: "#d9d9d9" },
      "&dark .cm-selectionBackground": { background: "#222" },
      "&light.cm-focused > .cm-scroller > .cm-selectionLayer .cm-selectionBackground":
        { background: "#d7d4f0" },
      "&dark.cm-focused > .cm-scroller > .cm-selectionLayer .cm-selectionBackground":
        { background: "#233" },
      ".cm-cursorLayer": { pointerEvents: "none" },
      "&.cm-focused > .cm-scroller > .cm-cursorLayer": {
        animation: "steps(1) cm-blink 1.2s infinite",
      },
      "@keyframes cm-blink": { "0%": {}, "50%": { opacity: 0 }, "100%": {} },
      "@keyframes cm-blink2": { "0%": {}, "50%": { opacity: 0 }, "100%": {} },
      ".cm-cursor, .cm-dropCursor": {
        borderLeft: "1.2px solid black",
        marginLeft: "-0.6px",
        pointerEvents: "none",
      },
      ".cm-cursor": { display: "none" },
      "&dark .cm-cursor": { borderLeftColor: "#ddd" },
      ".cm-dropCursor": { position: "absolute" },
      "&.cm-focused > .cm-scroller > .cm-cursorLayer .cm-cursor": {
        display: "block",
      },
      ".cm-iso": { unicodeBidi: "isolate" },
      ".cm-announced": { position: "fixed", top: "-10000px" },
      "@media print": { ".cm-announced": { display: "none" } },
      "&light .cm-activeLine": { backgroundColor: "#cceeff44" },
      "&dark .cm-activeLine": { backgroundColor: "#99eeff33" },
      "&light .cm-specialChar": { color: "red" },
      "&dark .cm-specialChar": { color: "#f78" },
      ".cm-gutters": {
        flexShrink: 0,
        display: "flex",
        height: "100%",
        boxSizing: "border-box",
        zIndex: 200,
      },
      ".cm-gutters-before": { insetInlineStart: 0 },
      ".cm-gutters-after": { insetInlineEnd: 0 },
      "&light .cm-gutters": {
        backgroundColor: "#f5f5f5",
        color: "#6c6c6c",
        border: "0px solid #ddd",
        "&.cm-gutters-before": { borderRightWidth: "1px" },
        "&.cm-gutters-after": { borderLeftWidth: "1px" },
      },
      "&dark .cm-gutters": { backgroundColor: "#333338", color: "#ccc" },
      ".cm-gutter": {
        display: "flex !important",
        flexDirection: "column",
        flexShrink: 0,
        boxSizing: "border-box",
        minHeight: "100%",
        overflow: "hidden",
      },
      ".cm-gutterElement": { boxSizing: "border-box" },
      ".cm-lineNumbers .cm-gutterElement": {
        padding: "0 3px 0 5px",
        minWidth: "20px",
        textAlign: "right",
        whiteSpace: "nowrap",
      },
      "&light .cm-activeLineGutter": { backgroundColor: "#e2f2ff" },
      "&dark .cm-activeLineGutter": { backgroundColor: "#222227" },
      ".cm-panels": {
        boxSizing: "border-box",
        position: "sticky",
        left: 0,
        right: 0,
        zIndex: 300,
      },
      "&light .cm-panels": { backgroundColor: "#f5f5f5", color: "black" },
      "&light .cm-panels-top": { borderBottom: "1px solid #ddd" },
      "&light .cm-panels-bottom": { borderTop: "1px solid #ddd" },
      "&dark .cm-panels": { backgroundColor: "#333338", color: "white" },
      ".cm-dialog": {
        padding: "2px 19px 4px 6px",
        position: "relative",
        "& label": { fontSize: "80%" },
      },
      ".cm-dialog-close": {
        position: "absolute",
        top: "3px",
        right: "4px",
        backgroundColor: "inherit",
        border: "none",
        font: "inherit",
        fontSize: "14px",
        padding: "0",
      },
      ".cm-tab": {
        display: "inline-block",
        overflow: "hidden",
        verticalAlign: "bottom",
      },
      ".cm-widgetBuffer": {
        verticalAlign: "text-top",
        height: "1em",
        width: 0,
        display: "inline",
      },
      ".cm-placeholder": {
        color: "#888",
        display: "inline-block",
        verticalAlign: "top",
        userSelect: "none",
      },
      ".cm-highlightSpace": {
        backgroundImage:
          "radial-gradient(circle at 50% 55%, #aaa 20%, transparent 5%)",
        backgroundPosition: "center",
      },
      ".cm-highlightTab": {
        backgroundImage:
          'url(\'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="200" height="20"><path stroke="%23888" stroke-width="1" fill="none" d="M1 10H196L190 5M190 15L196 10M197 4L197 16"/></svg>\')',
        backgroundSize: "auto 100%",
        backgroundPosition: "right 90%",
        backgroundRepeat: "no-repeat",
      },
      ".cm-trailingSpace": { backgroundColor: "#ff332255" },
      ".cm-button": {
        verticalAlign: "middle",
        color: "inherit",
        fontSize: "70%",
        padding: ".2em 1em",
        borderRadius: "1px",
      },
      "&light .cm-button": {
        backgroundImage: "linear-gradient(#eff1f5, #d9d9df)",
        border: "1px solid #888",
        "&:active": { backgroundImage: "linear-gradient(#b4b4b4, #d0d3d6)" },
      },
      "&dark .cm-button": {
        backgroundImage: "linear-gradient(#393939, #111)",
        border: "1px solid #888",
        "&:active": { backgroundImage: "linear-gradient(#111, #333)" },
      },
      ".cm-textfield": {
        verticalAlign: "middle",
        color: "inherit",
        fontSize: "70%",
        border: "1px solid silver",
        padding: ".2em .5em",
      },
      "&light .cm-textfield": { backgroundColor: "white" },
      "&dark .cm-textfield": {
        border: "1px solid #555",
        backgroundColor: "inherit",
      },
    },
    Is,
  ),
  Bs = {
    childList: !0,
    characterData: !0,
    subtree: !0,
    attributes: !0,
    characterDataOldValue: !0,
  },
  Ls = Wt.ie && Wt.ie_version <= 11;
class Ps {
  constructor(e) {
    ((this.view = e),
      (this.active = !1),
      (this.editContext = null),
      (this.selectionRange = new gi()),
      (this.selectionChanged = !1),
      (this.delayedFlush = -1),
      (this.resizeTimeout = -1),
      (this.queue = []),
      (this.delayedAndroidKey = null),
      (this.flushingAndroidKey = -1),
      (this.lastChange = 0),
      (this.scrollTargets = []),
      (this.intersection = null),
      (this.resizeScroll = null),
      (this.intersecting = !1),
      (this.gapIntersection = null),
      (this.gaps = []),
      (this.printQuery = null),
      (this.parentCheck = -1),
      (this.dom = e.contentDOM),
      (this.observer = new MutationObserver((t) => {
        for (let e of t) this.queue.push(e);
        ((Wt.ie && Wt.ie_version <= 11) || (Wt.ios && e.composing)) &&
        t.some(
          (e) =>
            ("childList" == e.type && e.removedNodes.length) ||
            ("characterData" == e.type &&
              e.oldValue.length > e.target.nodeValue.length),
        )
          ? this.flushSoon()
          : this.flush();
      })),
      !window.EditContext ||
        !Wt.android ||
        !1 === e.constructor.EDIT_CONTEXT ||
        (Wt.chrome && Wt.chrome_version < 126) ||
        ((this.editContext = new Fs(e)),
        e.state.facet(ro) &&
          (e.contentDOM.editContext = this.editContext.editContext)),
      Ls &&
        (this.onCharData = (e) => {
          (this.queue.push({
            target: e.target,
            type: "characterData",
            oldValue: e.prevValue,
          }),
            this.flushSoon());
        }),
      (this.onSelectionChange = this.onSelectionChange.bind(this)),
      (this.onResize = this.onResize.bind(this)),
      (this.onPrint = this.onPrint.bind(this)),
      (this.onScroll = this.onScroll.bind(this)),
      window.matchMedia && (this.printQuery = window.matchMedia("print")),
      "function" == typeof ResizeObserver &&
        ((this.resizeScroll = new ResizeObserver(() => {
          var e;
          (null === (e = this.view.docView) || void 0 === e
            ? void 0
            : e.lastUpdate) <
            Date.now() - 75 && this.onResize();
        })),
        this.resizeScroll.observe(e.scrollDOM)),
      this.addWindowListeners((this.win = e.win)),
      this.start(),
      "function" == typeof IntersectionObserver &&
        ((this.intersection = new IntersectionObserver(
          (e) => {
            (this.parentCheck < 0 &&
              (this.parentCheck = setTimeout(
                this.listenForScroll.bind(this),
                1e3,
              )),
              e.length > 0 &&
                e[e.length - 1].intersectionRatio > 0 != this.intersecting &&
                ((this.intersecting = !this.intersecting),
                this.intersecting != this.view.inView &&
                  this.onScrollChanged(document.createEvent("Event"))));
          },
          { threshold: [0, 0.001] },
        )),
        this.intersection.observe(this.dom),
        (this.gapIntersection = new IntersectionObserver((e) => {
          e.length > 0 &&
            e[e.length - 1].intersectionRatio > 0 &&
            this.onScrollChanged(document.createEvent("Event"));
        }, {}))),
      this.listenForScroll(),
      this.readSelectionRange());
  }
  onScrollChanged(e) {
    (this.view.inputState.runHandlers("scroll", e),
      this.intersecting && this.view.measure());
  }
  onScroll(e) {
    (this.intersecting && this.flush(!1),
      this.editContext && this.view.requestMeasure(this.editContext.measureReq),
      this.onScrollChanged(e));
  }
  onResize() {
    this.resizeTimeout < 0 &&
      (this.resizeTimeout = setTimeout(() => {
        ((this.resizeTimeout = -1), this.view.requestMeasure());
      }, 50));
  }
  onPrint(e) {
    (("change" != e.type && e.type) || e.matches) &&
      ((this.view.viewState.printing = !0),
      this.view.measure(),
      setTimeout(() => {
        ((this.view.viewState.printing = !1), this.view.requestMeasure());
      }, 500));
  }
  updateGaps(e) {
    if (
      this.gapIntersection &&
      (e.length != this.gaps.length || this.gaps.some((t, i) => t != e[i]))
    ) {
      this.gapIntersection.disconnect();
      for (let t of e) this.gapIntersection.observe(t);
      this.gaps = e;
    }
  }
  onSelectionChange(e) {
    let t = this.selectionChanged;
    if (!this.readSelectionRange() || this.delayedAndroidKey) return;
    let { view: i } = this,
      o = this.selectionRange;
    if (i.state.facet(ro) ? i.root.activeElement != this.dom : !si(this.dom, o))
      return;
    let n = o.anchorNode && i.docView.tile.nearest(o.anchorNode);
    n && n.isWidget() && n.widget.ignoreEvent(e)
      ? t || (this.selectionChanged = !1)
      : ((Wt.ie && Wt.ie_version <= 11) || (Wt.android && Wt.chrome)) &&
          !i.state.selection.main.empty &&
          o.focusNode &&
          ai(o.focusNode, o.focusOffset, o.anchorNode, o.anchorOffset)
        ? this.flushSoon()
        : this.flush(!1);
  }
  readSelectionRange() {
    let { view: e } = this,
      t = oi(e.root);
    if (!t) return !1;
    let i =
      (Wt.safari &&
        11 == e.root.nodeType &&
        e.root.activeElement == this.dom &&
        (function (e, t) {
          if (t.getComposedRanges) {
            let i = t.getComposedRanges(e.root)[0];
            if (i) return Rs(e, i);
          }
          let i = null;
          function o(e) {
            (e.preventDefault(),
              e.stopImmediatePropagation(),
              (i = e.getTargetRanges()[0]));
          }
          return (
            e.contentDOM.addEventListener("beforeinput", o, !0),
            e.dom.ownerDocument.execCommand("indent"),
            e.contentDOM.removeEventListener("beforeinput", o, !0),
            i ? Rs(e, i) : null
          );
        })(this.view, t)) ||
      t;
    if (!i || this.selectionRange.eq(i)) return !1;
    let o = si(this.dom, i);
    return o &&
      !this.selectionChanged &&
      e.inputState.lastFocusTime > Date.now() - 200 &&
      e.inputState.lastTouchTime < Date.now() - 300 &&
      (function (e, t) {
        let i = t.focusNode,
          o = t.focusOffset;
        if (!i || t.anchorNode != i || t.anchorOffset != o) return !1;
        for (o = Math.min(o, hi(i)); ; )
          if (o) {
            if (1 != i.nodeType) return !1;
            let e = i.childNodes[o - 1];
            "false" == e.contentEditable ? o-- : ((i = e), (o = hi(i)));
          } else {
            if (i == e) return !0;
            ((o = li(i)), (i = i.parentNode));
          }
      })(this.dom, i)
      ? ((this.view.inputState.lastFocusTime = 0),
        e.docView.updateSelection(),
        !1)
      : (this.selectionRange.setRange(i),
        o && (this.selectionChanged = !0),
        !0);
  }
  setSelectionRange(e, t) {
    (this.selectionRange.set(e.node, e.offset, t.node, t.offset),
      (this.selectionChanged = !1));
  }
  clearSelectionRange() {
    this.selectionRange.set(null, 0, null, 0);
  }
  listenForScroll() {
    this.parentCheck = -1;
    let e = 0,
      t = null;
    for (let i = this.dom; i; )
      if (1 == i.nodeType)
        (!t && e < this.scrollTargets.length && this.scrollTargets[e] == i
          ? e++
          : t || (t = this.scrollTargets.slice(0, e)),
          t && t.push(i),
          (i = i.assignedSlot || i.parentNode));
      else {
        if (11 != i.nodeType) break;
        i = i.host;
      }
    if (
      (e < this.scrollTargets.length &&
        !t &&
        (t = this.scrollTargets.slice(0, e)),
      t)
    ) {
      for (let e of this.scrollTargets)
        e.removeEventListener("scroll", this.onScroll);
      for (let e of (this.scrollTargets = t))
        e.addEventListener("scroll", this.onScroll);
    }
  }
  ignore(e) {
    if (!this.active) return e();
    try {
      return (this.stop(), e());
    } finally {
      (this.start(), this.clear());
    }
  }
  start() {
    this.active ||
      (this.observer.observe(this.dom, Bs),
      Ls &&
        this.dom.addEventListener("DOMCharacterDataModified", this.onCharData),
      (this.active = !0));
  }
  stop() {
    this.active &&
      ((this.active = !1),
      this.observer.disconnect(),
      Ls &&
        this.dom.removeEventListener(
          "DOMCharacterDataModified",
          this.onCharData,
        ));
  }
  clear() {
    (this.processRecords(),
      (this.queue.length = 0),
      (this.selectionChanged = !1));
  }
  delayAndroidKey(e, t) {
    var i;
    if (!this.delayedAndroidKey) {
      let e = () => {
        let e = this.delayedAndroidKey;
        if (e) {
          (this.clearDelayedAndroidKey(),
            (this.view.inputState.lastKeyCode = e.keyCode),
            (this.view.inputState.lastKeyTime = Date.now()),
            !this.flush() && e.force && vi(this.dom, e.key, e.keyCode));
        }
      };
      this.flushingAndroidKey = this.view.win.requestAnimationFrame(e);
    }
    (this.delayedAndroidKey && "Enter" != e) ||
      (this.delayedAndroidKey = {
        key: e,
        keyCode: t,
        force:
          this.lastChange < Date.now() - 50 ||
          !!(null === (i = this.delayedAndroidKey) || void 0 === i
            ? void 0
            : i.force),
      });
  }
  clearDelayedAndroidKey() {
    (this.win.cancelAnimationFrame(this.flushingAndroidKey),
      (this.delayedAndroidKey = null),
      (this.flushingAndroidKey = -1));
  }
  flushSoon() {
    this.delayedFlush < 0 &&
      (this.delayedFlush = this.view.win.requestAnimationFrame(() => {
        ((this.delayedFlush = -1), this.flush());
      }));
  }
  forceFlush() {
    (this.delayedFlush >= 0 &&
      (this.view.win.cancelAnimationFrame(this.delayedFlush),
      (this.delayedFlush = -1)),
      this.flush());
  }
  pendingRecords() {
    for (let e of this.observer.takeRecords()) this.queue.push(e);
    return this.queue;
  }
  processRecords() {
    let e = this.pendingRecords();
    e.length && (this.queue = []);
    let t = -1,
      i = -1,
      o = !1;
    for (let n of e) {
      let e = this.readMutation(n);
      e &&
        (e.typeOver && (o = !0),
        -1 == t
          ? ({ from: t, to: i } = e)
          : ((t = Math.min(e.from, t)), (i = Math.max(e.to, i))));
    }
    return { from: t, to: i, typeOver: o };
  }
  readChange() {
    let { from: e, to: t, typeOver: i } = this.processRecords(),
      o = this.selectionChanged && si(this.dom, this.selectionRange);
    if (e < 0 && !o) return null;
    (e > -1 && (this.lastChange = Date.now()),
      (this.view.inputState.lastFocusTime = 0),
      (this.selectionChanged = !1));
    let n = new bn(this.view, e, t, i);
    return (
      (this.view.docView.domChanged = {
        newSel: n.newSel ? n.newSel.main : null,
      }),
      n
    );
  }
  flush(e = !0) {
    if (this.delayedFlush >= 0 || this.delayedAndroidKey) return !1;
    e && this.readSelectionRange();
    let t = this.readChange();
    if (!t) return (this.view.requestMeasure(), !1);
    let i = this.view.state,
      o = wn(this.view, t);
    return (
      this.view.state == i &&
        (t.domChanged ||
          (t.newSel && !xn(this.view.state.selection, t.newSel.main))) &&
        this.view.update([]),
      o
    );
  }
  readMutation(e) {
    let t = this.view.docView.tile.nearest(e.target);
    if (!t || t.isWidget()) return null;
    if ((t.markDirty("attributes" == e.type), "childList" == e.type)) {
      let i = Ns(t, e.previousSibling || e.target.previousSibling, -1),
        o = Ns(t, e.nextSibling || e.target.nextSibling, 1);
      return {
        from: i ? t.posAfter(i) : t.posAtStart,
        to: o ? t.posBefore(o) : t.posAtEnd,
        typeOver: !1,
      };
    }
    return "characterData" == e.type
      ? {
          from: t.posAtStart,
          to: t.posAtEnd,
          typeOver: e.target.nodeValue == e.oldValue,
        }
      : null;
  }
  setWindow(e) {
    e != this.win &&
      (this.removeWindowListeners(this.win),
      (this.win = e),
      this.addWindowListeners(this.win));
  }
  addWindowListeners(e) {
    (e.addEventListener("resize", this.onResize),
      this.printQuery
        ? this.printQuery.addEventListener
          ? this.printQuery.addEventListener("change", this.onPrint)
          : this.printQuery.addListener(this.onPrint)
        : e.addEventListener("beforeprint", this.onPrint),
      e.addEventListener("scroll", this.onScroll),
      e.document.addEventListener("selectionchange", this.onSelectionChange));
  }
  removeWindowListeners(e) {
    (e.removeEventListener("scroll", this.onScroll),
      e.removeEventListener("resize", this.onResize),
      this.printQuery
        ? this.printQuery.removeEventListener
          ? this.printQuery.removeEventListener("change", this.onPrint)
          : this.printQuery.removeListener(this.onPrint)
        : e.removeEventListener("beforeprint", this.onPrint),
      e.document.removeEventListener(
        "selectionchange",
        this.onSelectionChange,
      ));
  }
  update(e) {
    this.editContext &&
      (this.editContext.update(e),
      e.startState.facet(ro) != e.state.facet(ro) &&
        (e.view.contentDOM.editContext = e.state.facet(ro)
          ? this.editContext.editContext
          : null));
  }
  destroy() {
    var e, t, i;
    (this.stop(),
      null === (e = this.intersection) || void 0 === e || e.disconnect(),
      null === (t = this.gapIntersection) || void 0 === t || t.disconnect(),
      null === (i = this.resizeScroll) || void 0 === i || i.disconnect());
    for (let e of this.scrollTargets)
      e.removeEventListener("scroll", this.onScroll);
    (this.removeWindowListeners(this.win),
      clearTimeout(this.parentCheck),
      clearTimeout(this.resizeTimeout),
      this.win.cancelAnimationFrame(this.delayedFlush),
      this.win.cancelAnimationFrame(this.flushingAndroidKey),
      this.editContext &&
        ((this.view.contentDOM.editContext = null),
        this.editContext.destroy()));
  }
}
function Ns(e, t, i) {
  for (; t; ) {
    let o = Eo.get(t);
    if (o && o.parent == e) return o;
    let n = t.parentNode;
    t = n != e.dom ? n : i > 0 ? t.nextSibling : t.previousSibling;
  }
  return null;
}
function Rs(e, t) {
  let i = t.startContainer,
    o = t.startOffset,
    n = t.endContainer,
    s = t.endOffset,
    r = e.docView.domAtPos(e.state.selection.main.anchor, 1);
  return (
    ai(r.node, r.offset, n, s) && ([i, o, n, s] = [n, s, i, o]),
    { anchorNode: i, anchorOffset: o, focusNode: n, focusOffset: s }
  );
}
class Fs {
  constructor(e) {
    ((this.from = 0),
      (this.to = 0),
      (this.pendingContextChange = null),
      (this.handlers = Object.create(null)),
      (this.composing = null),
      this.resetRange(e.state));
    let t = (this.editContext = new window.EditContext({
      text: e.state.doc.sliceString(this.from, this.to),
      selectionStart: this.toContextPos(
        Math.max(this.from, Math.min(this.to, e.state.selection.main.anchor)),
      ),
      selectionEnd: this.toContextPos(e.state.selection.main.head),
    }));
    ((this.handlers.textupdate = (i) => {
      let o = e.state.selection.main,
        { anchor: n, head: s } = o,
        r = this.toEditorPos(i.updateRangeStart),
        a = this.toEditorPos(i.updateRangeEnd);
      e.inputState.composing >= 0 &&
        !this.composing &&
        (this.composing = {
          contextBase: i.updateRangeStart,
          editorBase: r,
          drifted: !1,
        });
      let l = a - r > i.text.length;
      r == this.from && n < this.from
        ? (r = n)
        : a == this.to && n > this.to && (a = n);
      let c = Cn(
        e.state.sliceDoc(r, a),
        i.text,
        (l ? o.from : o.to) - r,
        l ? "end" : null,
      );
      if (!c) {
        let t = ue.single(
          this.toEditorPos(i.selectionStart),
          this.toEditorPos(i.selectionEnd),
        );
        return void (
          xn(t, o) || e.dispatch({ selection: t, userEvent: "select" })
        );
      }
      let d = {
        from: c.from + r,
        to: c.toA + r,
        insert: $.of(i.text.slice(c.from, c.toB).split("\n")),
      };
      if (
        ((Wt.mac || Wt.android) &&
          d.from == s - 1 &&
          /^\. ?$/.test(i.text) &&
          "off" == e.contentDOM.getAttribute("autocorrect") &&
          (d = { from: r, to: a, insert: $.of([i.text.replace(".", " ")]) }),
        (this.pendingContextChange = d),
        !e.state.readOnly)
      ) {
        let t = this.to - this.from + (d.to - d.from + d.insert.length);
        vn(
          e,
          d,
          ue.single(
            this.toEditorPos(i.selectionStart, t),
            this.toEditorPos(i.selectionEnd, t),
          ),
        );
      }
      (this.pendingContextChange &&
        (this.revertPending(e.state), this.setSelection(e.state)),
        d.from < d.to &&
          !d.insert.length &&
          e.inputState.composing >= 0 &&
          !/[\\p{Alphabetic}\\p{Number}_]/.test(
            t.text.slice(
              Math.max(0, i.updateRangeStart - 1),
              Math.min(t.text.length, i.updateRangeStart + 1),
            ),
          ) &&
          this.handlers.compositionend(i));
    }),
      (this.handlers.characterboundsupdate = (i) => {
        let o = [],
          n = null;
        for (
          let t = this.toEditorPos(i.rangeStart),
            s = this.toEditorPos(i.rangeEnd);
          t < s;
          t++
        ) {
          let i = e.coordsForChar(t);
          ((n =
            (i &&
              new DOMRect(i.left, i.top, i.right - i.left, i.bottom - i.top)) ||
            n ||
            new DOMRect()),
            o.push(n));
        }
        t.updateCharacterBounds(i.rangeStart, o);
      }),
      (this.handlers.textformatupdate = (t) => {
        let i = [];
        for (let e of t.getTextFormats()) {
          let t = e.underlineStyle,
            o = e.underlineThickness;
          if (!/none/i.test(t) && !/none/i.test(o)) {
            let n = this.toEditorPos(e.rangeStart),
              s = this.toEditorPos(e.rangeEnd);
            if (n < s) {
              let e = `text-decoration: underline ${/^[a-z]/.test(t) ? t + " " : "Dashed" == t ? "dashed " : "Squiggle" == t ? "wavy " : ""}${/thin/i.test(o) ? 1 : 2}px`;
              i.push(Kt.mark({ attributes: { style: e } }).range(n, s));
            }
          }
        }
        e.dispatch({ effects: no.of(Kt.set(i)) });
      }),
      (this.handlers.compositionstart = () => {
        e.inputState.composing < 0 &&
          ((e.inputState.composing = 0),
          (e.inputState.compositionFirstChange = !0));
      }),
      (this.handlers.compositionend = () => {
        if (
          ((e.inputState.composing = -1),
          (e.inputState.compositionFirstChange = null),
          this.composing)
        ) {
          let { drifted: t } = this.composing;
          ((this.composing = null), t && this.reset(e.state));
        }
      }));
    for (let e in this.handlers) t.addEventListener(e, this.handlers[e]);
    this.measureReq = {
      read: (e) => {
        this.editContext.updateControlBounds(
          e.contentDOM.getBoundingClientRect(),
        );
        let t = oi(e.root);
        t &&
          t.rangeCount &&
          this.editContext.updateSelectionBounds(
            t.getRangeAt(0).getBoundingClientRect(),
          );
      },
    };
  }
  applyEdits(e) {
    let t = 0,
      i = !1,
      o = this.pendingContextChange;
    return (
      e.changes.iterChanges((n, s, r, a, l) => {
        if (i) return;
        let c = l.length - (s - n);
        if (o && s >= o.to) {
          if (o.from == n && o.to == s && o.insert.eq(l))
            return (
              (o = this.pendingContextChange = null),
              (t += c),
              void (this.to += c)
            );
          ((o = null), this.revertPending(e.state));
        }
        if (((n += t), (s += t) <= this.from))
          ((this.from += c), (this.to += c));
        else if (n < this.to) {
          if (
            n < this.from ||
            s > this.to ||
            this.to - this.from + l.length > 3e4
          )
            return void (i = !0);
          (this.editContext.updateText(
            this.toContextPos(n),
            this.toContextPos(s),
            l.toString(),
          ),
            (this.to += c));
        }
        t += c;
      }),
      o && !i && this.revertPending(e.state),
      !i
    );
  }
  update(e) {
    let t = this.pendingContextChange,
      i = e.startState.selection.main;
    (this.composing &&
    (this.composing.drifted ||
      (!e.changes.touchesRange(i.from, i.to) &&
        e.transactions.some(
          (e) =>
            !e.isUserEvent("input.type") &&
            e.changes.touchesRange(this.from, this.to),
        )))
      ? ((this.composing.drifted = !0),
        (this.composing.editorBase = e.changes.mapPos(
          this.composing.editorBase,
        )))
      : this.applyEdits(e) && this.rangeIsValid(e.state)
        ? (e.docChanged || e.selectionSet || t) && this.setSelection(e.state)
        : ((this.pendingContextChange = null), this.reset(e.state)),
      (e.geometryChanged || e.docChanged || e.selectionSet) &&
        e.view.requestMeasure(this.measureReq));
  }
  resetRange(e) {
    let { head: t } = e.selection.main;
    ((this.from = Math.max(0, t - 1e4)),
      (this.to = Math.min(e.doc.length, t + 1e4)));
  }
  reset(e) {
    (this.resetRange(e),
      this.editContext.updateText(
        0,
        this.editContext.text.length,
        e.doc.sliceString(this.from, this.to),
      ),
      this.setSelection(e));
  }
  revertPending(e) {
    let t = this.pendingContextChange;
    ((this.pendingContextChange = null),
      this.editContext.updateText(
        this.toContextPos(t.from),
        this.toContextPos(t.from + t.insert.length),
        e.doc.sliceString(t.from, t.to),
      ));
  }
  setSelection(e) {
    let { main: t } = e.selection,
      i = this.toContextPos(Math.max(this.from, Math.min(this.to, t.anchor))),
      o = this.toContextPos(t.head);
    (this.editContext.selectionStart == i &&
      this.editContext.selectionEnd == o) ||
      this.editContext.updateSelection(i, o);
  }
  rangeIsValid(e) {
    let { head: t } = e.selection.main;
    return !(
      (this.from > 0 && t - this.from < 500) ||
      (this.to < e.doc.length && this.to - t < 500) ||
      this.to - this.from > 3e4
    );
  }
  toEditorPos(e, t = this.to - this.from) {
    e = Math.min(e, t);
    let i = this.composing;
    return i && i.drifted ? i.editorBase + (e - i.contextBase) : e + this.from;
  }
  toContextPos(e) {
    let t = this.composing;
    return t && t.drifted ? t.contextBase + (e - t.editorBase) : e - this.from;
  }
  destroy() {
    for (let e in this.handlers)
      this.editContext.removeEventListener(e, this.handlers[e]);
  }
}
class qs {
  get state() {
    return this.viewState.state;
  }
  get viewport() {
    return this.viewState.viewport;
  }
  get visibleRanges() {
    return this.viewState.visibleRanges;
  }
  get inView() {
    return this.viewState.inView;
  }
  get composing() {
    return !!this.inputState && this.inputState.composing > 0;
  }
  get compositionStarted() {
    return !!this.inputState && this.inputState.composing >= 0;
  }
  get root() {
    return this._root;
  }
  get win() {
    return this.dom.ownerDocument.defaultView || window;
  }
  constructor(e = {}) {
    var t;
    ((this.plugins = []),
      (this.pluginMap = new Map()),
      (this.editorAttrs = {}),
      (this.contentAttrs = {}),
      (this.bidiCache = []),
      (this.destroyed = !1),
      (this.updateState = 2),
      (this.measureScheduled = -1),
      (this.measureRequests = []),
      (this.contentDOM = document.createElement("div")),
      (this.scrollDOM = document.createElement("div")),
      (this.scrollDOM.tabIndex = -1),
      (this.scrollDOM.className = "cm-scroller"),
      this.scrollDOM.appendChild(this.contentDOM),
      (this.announceDOM = document.createElement("div")),
      (this.announceDOM.className = "cm-announced"),
      this.announceDOM.setAttribute("aria-live", "polite"),
      (this.dom = document.createElement("div")),
      this.dom.appendChild(this.announceDOM),
      this.dom.appendChild(this.scrollDOM),
      e.parent && e.parent.appendChild(this.dom));
    let { dispatch: i } = e;
    ((this.dispatchTransactions =
      e.dispatchTransactions ||
      (i && ((e) => e.forEach((e) => i(e, this)))) ||
      ((e) => this.update(e))),
      (this.dispatch = this.dispatch.bind(this)),
      (this._root =
        e.root ||
        (function (e) {
          for (; e; ) {
            if (e && (9 == e.nodeType || (11 == e.nodeType && e.host)))
              return e;
            e = e.assignedSlot || e.parentNode;
          }
          return null;
        })(e.parent) ||
        document),
      (this.viewState = new fs(e.state || ot.create(e))),
      e.scrollTo &&
        e.scrollTo.is(oo) &&
        (this.viewState.scrollTarget = e.scrollTo.value.clip(
          this.viewState.state,
        )),
      (this.plugins = this.state.facet(lo).map((e) => new ho(e))));
    for (let e of this.plugins) e.update(this);
    ((this.observer = new Ps(this)),
      (this.inputState = new kn(this)),
      this.inputState.ensureHandlers(this.plugins),
      (this.docView = new Zo(this)),
      this.mountStyles(),
      this.updateAttrs(),
      (this.updateState = 0),
      this.requestMeasure(),
      (null === (t = document.fonts) || void 0 === t ? void 0 : t.ready) &&
        document.fonts.ready.then(() => {
          ((this.viewState.mustMeasureContent = !0), this.requestMeasure());
        }));
  }
  dispatch(...e) {
    let t =
      1 == e.length && e[0] instanceof je
        ? e
        : 1 == e.length && Array.isArray(e[0])
          ? e[0]
          : [this.state.update(...e)];
    this.dispatchTransactions(t, this);
  }
  update(e) {
    if (0 != this.updateState)
      throw new Error(
        "Calls to EditorView.update are not allowed while an update is in progress",
      );
    let t,
      i = !1,
      o = !1,
      n = this.state;
    for (let t of e) {
      if (t.startState != n)
        throw new RangeError(
          "Trying to update state with a transaction that doesn't start from the previous state.",
        );
      n = t.state;
    }
    if (this.destroyed) return void (this.viewState.state = n);
    let s = this.hasFocus,
      r = 0,
      a = null;
    e.some((e) => e.annotation($n))
      ? ((this.inputState.notifiedFocused = s), (r = 1))
      : s != this.inputState.notifiedFocused &&
        ((this.inputState.notifiedFocused = s), (a = Un(n, s)), a || (r = 1));
    let l = this.observer.delayedAndroidKey,
      c = null;
    if (
      (l
        ? (this.observer.clearDelayedAndroidKey(),
          (c = this.observer.readChange()),
          ((c && !this.state.doc.eq(n.doc)) ||
            !this.state.selection.eq(n.selection)) &&
            (c = null))
        : this.observer.clear(),
      n.facet(ot.phrases) != this.state.facet(ot.phrases))
    )
      return this.setState(n);
    ((t = So.create(this, n, e)), (t.flags |= r));
    let d = this.viewState.scrollTarget;
    try {
      this.updateState = 2;
      for (let t of e) {
        if ((d && (d = d.map(t.changes)), t.scrollIntoView)) {
          let { main: e } = t.state.selection;
          d = new io(
            e.empty ? e : ue.cursor(e.head, e.head > e.anchor ? -1 : 1),
          );
        }
        for (let e of t.effects) e.is(oo) && (d = e.value.clip(this.state));
      }
      (this.viewState.update(t, d),
        (this.bidiCache = Vs.update(this.bidiCache, t.changes)),
        t.empty || (this.updatePlugins(t), this.inputState.update(t)),
        (i = this.docView.update(t)),
        this.state.facet(xo) != this.styleModules && this.mountStyles(),
        (o = this.updateAttrs()),
        this.showAnnouncements(e),
        this.docView.updateSelection(
          i,
          e.some((e) => e.isUserEvent("select.pointer")),
        ));
    } finally {
      this.updateState = 0;
    }
    if (
      (t.startState.facet(Ss) != t.state.facet(Ss) &&
        (this.viewState.mustMeasureContent = !0),
      (i ||
        o ||
        d ||
        this.viewState.mustEnforceCursorAssoc ||
        this.viewState.mustMeasureContent) &&
        this.requestMeasure(),
      i && this.docViewUpdate(),
      !t.empty)
    )
      for (let e of this.state.facet(Gi))
        try {
          e(t);
        } catch (e) {
          so(this.state, e, "update listener");
        }
    (a || c) &&
      Promise.resolve().then(() => {
        (a && this.state == a.startState && this.dispatch(a),
          c &&
            !wn(this, c) &&
            l.force &&
            vi(this.contentDOM, l.key, l.keyCode));
      });
  }
  setState(e) {
    if (0 != this.updateState)
      throw new Error(
        "Calls to EditorView.setState are not allowed while an update is in progress",
      );
    if (this.destroyed) return void (this.viewState.state = e);
    this.updateState = 2;
    let t = this.hasFocus;
    try {
      for (let e of this.plugins) e.destroy(this);
      ((this.viewState = new fs(e)),
        (this.plugins = e.facet(lo).map((e) => new ho(e))),
        this.pluginMap.clear());
      for (let e of this.plugins) e.update(this);
      (this.docView.destroy(),
        (this.docView = new Zo(this)),
        this.inputState.ensureHandlers(this.plugins),
        this.mountStyles(),
        this.updateAttrs(),
        (this.bidiCache = []));
    } finally {
      this.updateState = 0;
    }
    (t && this.focus(), this.requestMeasure());
  }
  updatePlugins(e) {
    let t = e.startState.facet(lo),
      i = e.state.facet(lo);
    if (t != i) {
      let o = [];
      for (let n of i) {
        let i = t.indexOf(n);
        if (i < 0) o.push(new ho(n));
        else {
          let t = this.plugins[i];
          ((t.mustUpdate = e), o.push(t));
        }
      }
      for (let t of this.plugins) t.mustUpdate != e && t.destroy(this);
      ((this.plugins = o), this.pluginMap.clear());
    } else for (let t of this.plugins) t.mustUpdate = e;
    for (let e = 0; e < this.plugins.length; e++) this.plugins[e].update(this);
    t != i && this.inputState.ensureHandlers(this.plugins);
  }
  docViewUpdate() {
    for (let e of this.plugins) {
      let t = e.value;
      if (t && t.docViewUpdate)
        try {
          t.docViewUpdate(this);
        } catch (e) {
          so(this.state, e, "doc view update listener");
        }
    }
  }
  measure(e = !0) {
    if (this.destroyed) return;
    if (
      (this.measureScheduled > -1 &&
        this.win.cancelAnimationFrame(this.measureScheduled),
      this.observer.delayedAndroidKey)
    )
      return ((this.measureScheduled = -1), void this.requestMeasure());
    ((this.measureScheduled = 0), e && this.observer.forceFlush());
    let t = null,
      i = this.scrollDOM,
      o = i.scrollTop * this.scaleY,
      { scrollAnchorPos: n, scrollAnchorHeight: s } = this.viewState;
    (Math.abs(o - this.viewState.scrollTop) > 1 && (s = -1),
      (this.viewState.scrollAnchorHeight = -1));
    try {
      for (let e = 0; ; e++) {
        if (s < 0)
          if (Ci(i)) ((n = -1), (s = this.viewState.heightMap.height));
          else {
            let e = this.viewState.scrollAnchorAt(o);
            ((n = e.from), (s = e.top));
          }
        this.updateState = 1;
        let r = this.viewState.measure(this);
        if (
          !r &&
          !this.measureRequests.length &&
          null == this.viewState.scrollTarget
        )
          break;
        if (e > 5) {
          console.warn(
            this.measureRequests.length
              ? "Measure loop restarted more than 5 times"
              : "Viewport failed to stabilize",
          );
          break;
        }
        let a = [];
        4 & r || ([this.measureRequests, a] = [a, this.measureRequests]);
        let l = a.map((e) => {
            try {
              return e.read(this);
            } catch (e) {
              return (so(this.state, e), zs);
            }
          }),
          c = So.create(this, this.state, []),
          d = !1;
        ((c.flags |= r),
          t ? (t.flags |= r) : (t = c),
          (this.updateState = 2),
          c.empty ||
            (this.updatePlugins(c),
            this.inputState.update(c),
            this.updateAttrs(),
            (d = this.docView.update(c)),
            d && this.docViewUpdate()));
        for (let e = 0; e < a.length; e++)
          if (l[e] != zs)
            try {
              let t = a[e];
              t.write && t.write(l[e], this);
            } catch (e) {
              so(this.state, e);
            }
        if (
          (d && this.docView.updateSelection(!0),
          !c.viewportChanged && 0 == this.measureRequests.length)
        ) {
          if (this.viewState.editorHeight) {
            if (this.viewState.scrollTarget) {
              (this.docView.scrollIntoView(this.viewState.scrollTarget),
                (this.viewState.scrollTarget = null),
                (s = -1));
              continue;
            }
            {
              let e =
                (n < 0
                  ? this.viewState.heightMap.height
                  : this.viewState.lineBlockAt(n).top) - s;
              if (e > 1 || e < -1) {
                ((o += e), (i.scrollTop = o / this.scaleY), (s = -1));
                continue;
              }
            }
          }
          break;
        }
      }
    } finally {
      ((this.updateState = 0), (this.measureScheduled = -1));
    }
    if (t && !t.empty) for (let e of this.state.facet(Gi)) e(t);
  }
  get themeClasses() {
    return (
      Es + " " + (this.state.facet(Ts) ? As : Ms) + " " + this.state.facet(Ss)
    );
  }
  updateAttrs() {
    let e = Ws(this, uo, {
        class:
          "cm-editor" +
          (this.hasFocus ? " cm-focused " : " ") +
          this.themeClasses,
      }),
      t = {
        spellcheck: "false",
        autocorrect: "off",
        autocapitalize: "off",
        writingsuggestions: "false",
        translate: "no",
        contenteditable: this.state.facet(ro) ? "true" : "false",
        class: "cm-content",
        style: `${Wt.tabSize}: ${this.state.tabSize}`,
        role: "textbox",
        "aria-multiline": "true",
      };
    (this.state.readOnly && (t["aria-readonly"] = "true"), Ws(this, po, t));
    let i = this.observer.ignore(() => {
      let i = jt(this.contentDOM, this.contentAttrs, t),
        o = jt(this.dom, this.editorAttrs, e);
      return i || o;
    });
    return ((this.editorAttrs = e), (this.contentAttrs = t), i);
  }
  showAnnouncements(e) {
    let t = !0;
    for (let i of e)
      for (let e of i.effects)
        if (e.is(qs.announce)) {
          (t && (this.announceDOM.textContent = ""),
            (t = !1),
            (this.announceDOM.appendChild(
              document.createElement("div"),
            ).textContent = e.value));
        }
  }
  mountStyles() {
    this.styleModules = this.state.facet(xo);
    let e = this.state.facet(qs.cspNonce);
    St.mount(
      this.root,
      this.styleModules.concat(Os).reverse(),
      e ? { nonce: e } : void 0,
    );
  }
  readMeasured() {
    if (2 == this.updateState)
      throw new Error(
        "Reading the editor layout isn't allowed during an update",
      );
    0 == this.updateState && this.measureScheduled > -1 && this.measure(!1);
  }
  requestMeasure(e) {
    if (
      (this.measureScheduled < 0 &&
        (this.measureScheduled = this.win.requestAnimationFrame(() =>
          this.measure(),
        )),
      e)
    ) {
      if (this.measureRequests.indexOf(e) > -1) return;
      if (null != e.key)
        for (let t = 0; t < this.measureRequests.length; t++)
          if (this.measureRequests[t].key === e.key)
            return void (this.measureRequests[t] = e);
      this.measureRequests.push(e);
    }
  }
  plugin(e) {
    let t = this.pluginMap.get(e);
    return (
      (void 0 === t || (t && t.plugin != e)) &&
        this.pluginMap.set(
          e,
          (t = this.plugins.find((t) => t.plugin == e) || null),
        ),
      t && t.update(this).value
    );
  }
  get documentTop() {
    return (
      this.contentDOM.getBoundingClientRect().top + this.viewState.paddingTop
    );
  }
  get documentPadding() {
    return {
      top: this.viewState.paddingTop,
      bottom: this.viewState.paddingBottom,
    };
  }
  get scaleX() {
    return this.viewState.scaleX;
  }
  get scaleY() {
    return this.viewState.scaleY;
  }
  elementAtHeight(e) {
    return (this.readMeasured(), this.viewState.elementAtHeight(e));
  }
  lineBlockAtHeight(e) {
    return (this.readMeasured(), this.viewState.lineBlockAtHeight(e));
  }
  get viewportLineBlocks() {
    return this.viewState.viewportLines;
  }
  lineBlockAt(e) {
    return this.viewState.lineBlockAt(e);
  }
  get contentHeight() {
    return this.viewState.contentHeight;
  }
  moveByChar(e, t, i) {
    return an(this, e, nn(this, e, t, i));
  }
  moveByGroup(e, t) {
    return an(
      this,
      e,
      nn(this, e, t, (t) =>
        (function (e, t, i) {
          let o = e.state.charCategorizer(t),
            n = o(i);
          return (e) => {
            let t = o(e);
            return (n == Qe.Space && (n = t), n == t);
          };
        })(this, e.head, t),
      ),
    );
  }
  visualLineSide(e, t) {
    let i = this.bidiSpans(e),
      o = this.textDirectionAt(e.from),
      n = i[t ? i.length - 1 : 0];
    return ue.cursor(n.side(t, o) + e.from, n.forward(!t, o) ? 1 : -1);
  }
  moveToLineBoundary(e, t, i = !0) {
    return on(this, e, t, i);
  }
  moveVertically(e, t, i) {
    return an(
      this,
      e,
      (function (e, t, i, o) {
        let n = t.head,
          s = i ? 1 : -1;
        if (n == (i ? e.state.doc.length : 0)) return ue.cursor(n, t.assoc);
        let r,
          a = t.goalColumn,
          l = e.contentDOM.getBoundingClientRect(),
          c = e.coordsAtPos(n, t.assoc || -1),
          d = e.documentTop;
        if (c)
          (null == a && (a = c.left - l.left), (r = s < 0 ? c.top : c.bottom));
        else {
          let t = e.viewState.lineBlockAt(n);
          (null == a &&
            (a = Math.min(
              l.right - l.left,
              e.defaultCharacterWidth * (n - t.from),
            )),
            (r = (s < 0 ? t.top : t.bottom) + d));
        }
        let h = cn(
          e,
          {
            x: l.left + a,
            y:
              r +
              (null != o ? o : e.viewState.heightOracle.textHeight >> 1) * s,
          },
          !1,
          s,
        );
        return ue.cursor(h.pos, h.assoc, void 0, a);
      })(this, e, t, i),
    );
  }
  domAtPos(e, t = 1) {
    return this.docView.domAtPos(e, t);
  }
  posAtDOM(e, t = 0) {
    return this.docView.posFromDOM(e, t);
  }
  posAtCoords(e, t = !0) {
    this.readMeasured();
    let i = cn(this, e, t);
    return i && i.pos;
  }
  posAndSideAtCoords(e, t = !0) {
    return (this.readMeasured(), cn(this, e, t));
  }
  coordsAtPos(e, t = 1) {
    this.readMeasured();
    let i = this.docView.coordsAt(e, t);
    if (!i || i.left == i.right) return i;
    let o = this.state.doc.lineAt(e),
      n = this.bidiSpans(o);
    return ui(i, (n[Ni.find(n, e - o.from, -1, t)].dir == Ti.LTR) == t > 0);
  }
  coordsForChar(e) {
    return (this.readMeasured(), this.docView.coordsForChar(e));
  }
  get defaultCharacterWidth() {
    return this.viewState.heightOracle.charWidth;
  }
  get defaultLineHeight() {
    return this.viewState.heightOracle.lineHeight;
  }
  get textDirection() {
    return this.viewState.defaultTextDirection;
  }
  textDirectionAt(e) {
    return !this.state.facet(Qi) ||
      e < this.viewport.from ||
      e > this.viewport.to
      ? this.textDirection
      : (this.readMeasured(), this.docView.textDirectionAt(e));
  }
  get lineWrapping() {
    return this.viewState.heightOracle.lineWrapping;
  }
  bidiSpans(e) {
    if (e.length > _s) return zi(e.length);
    let t,
      i = this.textDirectionAt(e.from);
    for (let o of this.bidiCache)
      if (
        o.from == e.from &&
        o.dir == i &&
        (o.fresh || Ri(o.isolates, (t = wo(this, e))))
      )
        return o.order;
    t || (t = wo(this, e));
    let o = (function (e, t, i) {
      if (!e) return [new Ni(0, 0, t == Mi ? 1 : 0)];
      if (t == Ei && !i.length && !Pi.test(e)) return zi(e.length);
      if (i.length) for (; e.length > Fi.length; ) Fi[Fi.length] = 256;
      let o = [],
        n = t == Ei ? 0 : 1;
      return (_i(e, n, n, i, 0, e.length, o), o);
    })(e.text, i, t);
    return (this.bidiCache.push(new Vs(e.from, e.to, i, t, !0, o)), o);
  }
  get hasFocus() {
    var e;
    return (
      (this.dom.ownerDocument.hasFocus() ||
        (Wt.safari &&
          (null === (e = this.inputState) || void 0 === e
            ? void 0
            : e.lastContextMenu) >
            Date.now() - 3e4)) &&
      this.root.activeElement == this.contentDOM
    );
  }
  focus() {
    this.observer.ignore(() => {
      (yi(this.contentDOM), this.docView.updateSelection());
    });
  }
  setRoot(e) {
    this._root != e &&
      ((this._root = e),
      this.observer.setWindow(
        (9 == e.nodeType ? e : e.ownerDocument).defaultView || window,
      ),
      this.mountStyles());
  }
  destroy() {
    this.root.activeElement == this.contentDOM && this.contentDOM.blur();
    for (let e of this.plugins) e.destroy(this);
    ((this.plugins = []),
      this.inputState.destroy(),
      this.docView.destroy(),
      this.dom.remove(),
      this.observer.destroy(),
      this.measureScheduled > -1 &&
        this.win.cancelAnimationFrame(this.measureScheduled),
      (this.destroyed = !0));
  }
  static scrollIntoView(e, t = {}) {
    return oo.of(
      new io(
        "number" == typeof e ? ue.cursor(e) : e,
        t.y,
        t.x,
        t.yMargin,
        t.xMargin,
      ),
    );
  }
  scrollSnapshot() {
    let { scrollTop: e, scrollLeft: t } = this.scrollDOM,
      i = this.viewState.scrollAnchorAt(e);
    return oo.of(new io(ue.cursor(i.from), "start", "start", i.top - e, t, !0));
  }
  setTabFocusMode(e) {
    null == e
      ? (this.inputState.tabFocusMode =
          this.inputState.tabFocusMode < 0 ? 0 : -1)
      : "boolean" == typeof e
        ? (this.inputState.tabFocusMode = e ? 0 : -1)
        : 0 != this.inputState.tabFocusMode &&
          (this.inputState.tabFocusMode = Date.now() + e);
  }
  static domEventHandlers(e) {
    return co.define(() => ({}), { eventHandlers: e });
  }
  static domEventObservers(e) {
    return co.define(() => ({}), { eventObservers: e });
  }
  static theme(e, t) {
    let i = St.newName(),
      o = [Ss.of(i), xo.of(Ds(`.${i}`, e))];
    return (t && t.dark && o.push(Ts.of(!0)), o);
  }
  static baseTheme(e) {
    return Ae.lowest(xo.of(Ds("." + Es, e, Is)));
  }
  static findFromDOM(e) {
    var t;
    let i = e.querySelector(".cm-content"),
      o = (i && Eo.get(i)) || Eo.get(e);
    return (
      (null === (t = null == o ? void 0 : o.root) || void 0 === t
        ? void 0
        : t.view) || null
    );
  }
}
((qs.styleModule = xo),
  (qs.inputHandler = Zi),
  (qs.clipboardInputFilter = Ji),
  (qs.clipboardOutputFilter = Xi),
  (qs.scrollHandler = to),
  (qs.focusChangeEffect = Ki),
  (qs.perLineTextDirection = Qi),
  (qs.exceptionSink = Yi),
  (qs.updateListener = Gi),
  (qs.editable = ro),
  (qs.mouseSelectionStyle = ji),
  (qs.dragMovesSelection = Ui),
  (qs.clickAddsSelectionRange = $i),
  (qs.decorations = mo),
  (qs.blockWrappers = go),
  (qs.outerDecorations = fo),
  (qs.atomicRanges = bo),
  (qs.bidiIsolatedRanges = yo),
  (qs.scrollMargins = vo),
  (qs.darkTheme = Ts),
  (qs.cspNonce = ge.define({ combine: (e) => (e.length ? e[0] : "") })),
  (qs.contentAttributes = po),
  (qs.editorAttributes = uo),
  (qs.lineWrapping = qs.contentAttributes.of({ class: "cm-lineWrapping" })),
  (qs.announce = Ue.define()));
const _s = 4096,
  zs = {};
class Vs {
  constructor(e, t, i, o, n, s) {
    ((this.from = e),
      (this.to = t),
      (this.dir = i),
      (this.isolates = o),
      (this.fresh = n),
      (this.order = s));
  }
  static update(e, t) {
    if (t.empty && !e.some((e) => e.fresh)) return e;
    let i = [],
      o = e.length ? e[e.length - 1].dir : Ti.LTR;
    for (let n = Math.max(0, e.length - 10); n < e.length; n++) {
      let s = e[n];
      s.dir != o ||
        t.touchesRange(s.from, s.to) ||
        i.push(
          new Vs(
            t.mapPos(s.from, 1),
            t.mapPos(s.to, -1),
            s.dir,
            s.isolates,
            !1,
            s.order,
          ),
        );
    }
    return i;
  }
}
function Ws(e, t, i) {
  for (let o = e.state.facet(t), n = o.length - 1; n >= 0; n--) {
    let t = o[n],
      s = "function" == typeof t ? t(e) : t;
    s && Ht(s, i);
  }
  return i;
}
class Hs extends nt {
  compare(e) {
    return this == e || (this.constructor == e.constructor && this.eq(e));
  }
  eq(e) {
    return !1;
  }
  destroy(e) {}
}
((Hs.prototype.elementClass = ""),
  (Hs.prototype.toDOM = void 0),
  (Hs.prototype.mapMode = ie.TrackBefore),
  (Hs.prototype.startSide = Hs.prototype.endSide = -1),
  (Hs.prototype.point = !0));
let $s = 0;
class Us {
  constructor(e, t, i, o) {
    ((this.name = e),
      (this.set = t),
      (this.base = i),
      (this.modified = o),
      (this.id = $s++));
  }
  toString() {
    let { name: e } = this;
    for (let t of this.modified) t.name && (e = `${t.name}(${e})`);
    return e;
  }
  static define(e, t) {
    let i = "string" == typeof e ? e : "?";
    if ((e instanceof Us && (t = e), null == t ? void 0 : t.base))
      throw new Error("Can not derive from a modified tag");
    let o = new Us(i, [], null, []);
    if ((o.set.push(o), t)) for (let e of t.set) o.set.push(e);
    return o;
  }
  static defineModifier(e) {
    let t = new Ys(e);
    return (e) =>
      e.modified.indexOf(t) > -1
        ? e
        : Ys.get(
            e.base || e,
            e.modified.concat(t).sort((e, t) => e.id - t.id),
          );
  }
}
let js = 0;
class Ys {
  constructor(e) {
    ((this.name = e), (this.instances = []), (this.id = js++));
  }
  static get(e, t) {
    if (!t.length) return e;
    let i = t[0].instances.find((i) => {
      return (
        i.base == e &&
        ((o = t),
        (n = i.modified),
        o.length == n.length && o.every((e, t) => e == n[t]))
      );
      var o, n;
    });
    if (i) return i;
    let o = [],
      n = new Us(e.name, o, e, t);
    for (let e of t) e.instances.push(n);
    let s = (function (e) {
      let t = [[]];
      for (let i = 0; i < e.length; i++)
        for (let o = 0, n = t.length; o < n; o++) t.push(t[o].concat(e[i]));
      return t.sort((e, t) => t.length - e.length);
    })(t);
    for (let t of e.set)
      if (!t.modified.length) for (let e of s) o.push(Ys.get(t, e));
    return n;
  }
}
function Gs(e) {
  let t = Object.create(null);
  for (let i in e) {
    let o = e[i];
    Array.isArray(o) || (o = [o]);
    for (let e of i.split(" "))
      if (e) {
        let i = [],
          n = 2,
          s = e;
        for (let t = 0; ; ) {
          if ("..." == s && t > 0 && t + 3 == e.length) {
            n = 1;
            break;
          }
          let o = /^"(?:[^"\\]|\\.)*?"|[^\/!]+/.exec(s);
          if (!o) throw new RangeError("Invalid path: " + e);
          if (
            (i.push(
              "*" == o[0] ? "" : '"' == o[0][0] ? JSON.parse(o[0]) : o[0],
            ),
            (t += o[0].length),
            t == e.length)
          )
            break;
          let r = e[t++];
          if (t == e.length && "!" == r) {
            n = 0;
            break;
          }
          if ("/" != r) throw new RangeError("Invalid path: " + e);
          s = e.slice(t);
        }
        let r = i.length - 1,
          a = i[r];
        if (!a) throw new RangeError("Invalid path: " + e);
        let l = new Ks(o, n, r > 0 ? i.slice(0, r) : null);
        t[a] = l.sort(t[a]);
      }
  }
  return Zs.add(t);
}
const Zs = new s({
  combine(e, t) {
    let i, o, n;
    for (; e || t; ) {
      if (
        (!e || (t && e.depth >= t.depth)
          ? ((n = t), (t = t.next))
          : ((n = e), (e = e.next)),
        i && i.mode == n.mode && !n.context && !i.context)
      )
        continue;
      let s = new Ks(n.tags, n.mode, n.context);
      (i ? (i.next = s) : (o = s), (i = s));
    }
    return o;
  },
});
class Ks {
  constructor(e, t, i, o) {
    ((this.tags = e), (this.mode = t), (this.context = i), (this.next = o));
  }
  get opaque() {
    return 0 == this.mode;
  }
  get inherit() {
    return 1 == this.mode;
  }
  sort(e) {
    return !e || e.depth < this.depth
      ? ((this.next = e), this)
      : ((e.next = this.sort(e.next)), e);
  }
  get depth() {
    return this.context ? this.context.length : 0;
  }
}
function Js(e, t) {
  let i = Object.create(null);
  for (let t of e)
    if (Array.isArray(t.tag)) for (let e of t.tag) i[e.id] = t.class;
    else i[t.tag.id] = t.class;
  let { scope: o, all: n = null } = t || {};
  return {
    style: (e) => {
      let t = n;
      for (let o of e)
        for (let e of o.set) {
          let o = i[e.id];
          if (o) {
            t = t ? t + " " + o : o;
            break;
          }
        }
      return t;
    },
    scope: o,
  };
}
Ks.empty = new Ks([], 2, null);
const Xs = Us.define,
  Qs = Xs(),
  er = Xs(),
  tr = Xs(er),
  ir = Xs(er),
  or = Xs(),
  nr = Xs(or),
  sr = Xs(or),
  rr = Xs(),
  ar = Xs(rr),
  lr = Xs(),
  cr = Xs(),
  dr = Xs(),
  hr = Xs(dr),
  ur = Xs(),
  pr = {
    comment: Qs,
    lineComment: Xs(Qs),
    blockComment: Xs(Qs),
    docComment: Xs(Qs),
    name: er,
    variableName: Xs(er),
    typeName: tr,
    tagName: Xs(tr),
    propertyName: ir,
    attributeName: Xs(ir),
    className: Xs(er),
    labelName: Xs(er),
    namespace: Xs(er),
    macroName: Xs(er),
    literal: or,
    string: nr,
    docString: Xs(nr),
    character: Xs(nr),
    attributeValue: Xs(nr),
    number: sr,
    integer: Xs(sr),
    float: Xs(sr),
    bool: Xs(or),
    regexp: Xs(or),
    escape: Xs(or),
    color: Xs(or),
    url: Xs(or),
    keyword: lr,
    self: Xs(lr),
    null: Xs(lr),
    atom: Xs(lr),
    unit: Xs(lr),
    modifier: Xs(lr),
    operatorKeyword: Xs(lr),
    controlKeyword: Xs(lr),
    definitionKeyword: Xs(lr),
    moduleKeyword: Xs(lr),
    operator: cr,
    derefOperator: Xs(cr),
    arithmeticOperator: Xs(cr),
    logicOperator: Xs(cr),
    bitwiseOperator: Xs(cr),
    compareOperator: Xs(cr),
    updateOperator: Xs(cr),
    definitionOperator: Xs(cr),
    typeOperator: Xs(cr),
    controlOperator: Xs(cr),
    punctuation: dr,
    separator: Xs(dr),
    bracket: hr,
    angleBracket: Xs(hr),
    squareBracket: Xs(hr),
    paren: Xs(hr),
    brace: Xs(hr),
    content: rr,
    heading: ar,
    heading1: Xs(ar),
    heading2: Xs(ar),
    heading3: Xs(ar),
    heading4: Xs(ar),
    heading5: Xs(ar),
    heading6: Xs(ar),
    contentSeparator: Xs(rr),
    list: Xs(rr),
    quote: Xs(rr),
    emphasis: Xs(rr),
    strong: Xs(rr),
    link: Xs(rr),
    monospace: Xs(rr),
    strikethrough: Xs(rr),
    inserted: Xs(),
    deleted: Xs(),
    changed: Xs(),
    invalid: Xs(),
    meta: ur,
    documentMeta: Xs(ur),
    annotation: Xs(ur),
    processingInstruction: Xs(ur),
    definition: Us.defineModifier("definition"),
    constant: Us.defineModifier("constant"),
    function: Us.defineModifier("function"),
    standard: Us.defineModifier("standard"),
    local: Us.defineModifier("local"),
    special: Us.defineModifier("special"),
  };
for (let e in pr) {
  let t = pr[e];
  t instanceof Us && (t.name = e);
}
var mr;
Js([
  { tag: pr.link, class: "tok-link" },
  { tag: pr.heading, class: "tok-heading" },
  { tag: pr.emphasis, class: "tok-emphasis" },
  { tag: pr.strong, class: "tok-strong" },
  { tag: pr.keyword, class: "tok-keyword" },
  { tag: pr.atom, class: "tok-atom" },
  { tag: pr.bool, class: "tok-bool" },
  { tag: pr.url, class: "tok-url" },
  { tag: pr.labelName, class: "tok-labelName" },
  { tag: pr.inserted, class: "tok-inserted" },
  { tag: pr.deleted, class: "tok-deleted" },
  { tag: pr.literal, class: "tok-literal" },
  { tag: pr.string, class: "tok-string" },
  { tag: pr.number, class: "tok-number" },
  { tag: [pr.regexp, pr.escape, pr.special(pr.string)], class: "tok-string2" },
  { tag: pr.variableName, class: "tok-variableName" },
  { tag: pr.local(pr.variableName), class: "tok-variableName tok-local" },
  {
    tag: pr.definition(pr.variableName),
    class: "tok-variableName tok-definition",
  },
  { tag: pr.special(pr.variableName), class: "tok-variableName2" },
  {
    tag: pr.definition(pr.propertyName),
    class: "tok-propertyName tok-definition",
  },
  { tag: pr.typeName, class: "tok-typeName" },
  { tag: pr.namespace, class: "tok-namespace" },
  { tag: pr.className, class: "tok-className" },
  { tag: pr.macroName, class: "tok-macroName" },
  { tag: pr.propertyName, class: "tok-propertyName" },
  { tag: pr.operator, class: "tok-operator" },
  { tag: pr.comment, class: "tok-comment" },
  { tag: pr.meta, class: "tok-meta" },
  { tag: pr.invalid, class: "tok-invalid" },
  { tag: pr.punctuation, class: "tok-punctuation" },
]);
const gr = new s(),
  fr = new s();
class br {
  constructor(e, t, i = [], o = "") {
    ((this.data = e),
      (this.name = o),
      ot.prototype.hasOwnProperty("tree") ||
        Object.defineProperty(ot.prototype, "tree", {
          get() {
            return wr(this);
          },
        }),
      (this.parser = t),
      (this.extension = [
        Ar.of(this),
        ot.languageData.of((e, t, i) => {
          let o = yr(e, t, i),
            n = o.type.prop(gr);
          if (!n) return [];
          let s = e.facet(n),
            r = o.type.prop(fr);
          if (r) {
            let n = o.resolve(t - o.from, i);
            for (let t of r)
              if (t.test(n, e)) {
                let i = e.facet(t.facet);
                return "replace" == t.type ? i : i.concat(s);
              }
          }
          return s;
        }),
      ].concat(i)));
  }
  isActiveAt(e, t, i = -1) {
    return yr(e, t, i).type.prop(gr) == this.data;
  }
  findRegions(e) {
    let t = e.facet(Ar);
    if ((null == t ? void 0 : t.data) == this.data)
      return [{ from: 0, to: e.doc.length }];
    if (!t || !t.allowsNesting) return [];
    let i = [],
      o = (e, t) => {
        if (e.prop(gr) == this.data)
          return void i.push({ from: t, to: t + e.length });
        let n = e.prop(s.mounted);
        if (n) {
          if (n.tree.prop(gr) == this.data) {
            if (n.overlay)
              for (let e of n.overlay)
                i.push({ from: e.from + t, to: e.to + t });
            else i.push({ from: t, to: t + e.length });
            return;
          }
          if (n.overlay) {
            let e = i.length;
            if ((o(n.tree, n.overlay[0].from + t), i.length > e)) return;
          }
        }
        for (let i = 0; i < e.children.length; i++) {
          let n = e.children[i];
          n instanceof u && o(n, e.positions[i] + t);
        }
      };
    return (o(wr(e), 0), i);
  }
  get allowsNesting() {
    return !0;
  }
}
function yr(e, t, i) {
  let o = e.facet(Ar),
    n = wr(e).topNode;
  if (!o || o.allowsNesting)
    for (let e = n; e; e = e.enter(t, i, h.ExcludeBuffers | h.EnterBracketed))
      e.type.isTop && (n = e);
  return n;
}
function wr(e) {
  let t = e.field(br.state, !1);
  return t ? t.tree : u.empty;
}
br.setState = Ue.define();
class vr {
  constructor(e) {
    ((this.doc = e),
      (this.cursorPos = 0),
      (this.string = ""),
      (this.cursor = e.iter()));
  }
  get length() {
    return this.doc.length;
  }
  syncTo(e) {
    return (
      (this.string = this.cursor.next(e - this.cursorPos).value),
      (this.cursorPos = e + this.string.length),
      this.cursorPos - this.string.length
    );
  }
  chunk(e) {
    return (this.syncTo(e), this.string);
  }
  get lineChunks() {
    return !0;
  }
  read(e, t) {
    let i = this.cursorPos - this.string.length;
    return e < i || t >= this.cursorPos
      ? this.doc.sliceString(e, t)
      : this.string.slice(e - i, t - i);
  }
}
let Cr = null;
class xr {
  constructor(e, t, i = [], o, n, s, r, a) {
    ((this.parser = e),
      (this.state = t),
      (this.fragments = i),
      (this.tree = o),
      (this.treeLen = n),
      (this.viewport = s),
      (this.skipped = r),
      (this.scheduleOn = a),
      (this.parse = null),
      (this.tempSkipped = []));
  }
  static create(e, t, i) {
    return new xr(e, t, [], u.empty, 0, i, [], null);
  }
  startParse() {
    return this.parser.startParse(new vr(this.state.doc), this.fragments);
  }
  work(e, t) {
    return (
      null != t && t >= this.state.doc.length && (t = void 0),
      this.tree != u.empty && this.isDone(null != t ? t : this.state.doc.length)
        ? (this.takeTree(), !0)
        : this.withContext(() => {
            var i;
            if ("number" == typeof e) {
              let t = Date.now() + e;
              e = () => Date.now() > t;
            }
            for (
              this.parse || (this.parse = this.startParse()),
                null != t &&
                  (null == this.parse.stoppedAt || this.parse.stoppedAt > t) &&
                  t < this.state.doc.length &&
                  this.parse.stopAt(t);
              ;
            ) {
              let o = this.parse.advance();
              if (o) {
                if (
                  ((this.fragments = this.withoutTempSkipped(
                    D.addTree(o, this.fragments, null != this.parse.stoppedAt),
                  )),
                  (this.treeLen =
                    null !== (i = this.parse.stoppedAt) && void 0 !== i
                      ? i
                      : this.state.doc.length),
                  (this.tree = o),
                  (this.parse = null),
                  !(this.treeLen < (null != t ? t : this.state.doc.length)))
                )
                  return !0;
                this.parse = this.startParse();
              }
              if (e()) return !1;
            }
          })
    );
  }
  takeTree() {
    let e, t;
    this.parse &&
      (e = this.parse.parsedPos) >= this.treeLen &&
      ((null == this.parse.stoppedAt || this.parse.stoppedAt > e) &&
        this.parse.stopAt(e),
      this.withContext(() => {
        for (; !(t = this.parse.advance()); );
      }),
      (this.treeLen = e),
      (this.tree = t),
      (this.fragments = this.withoutTempSkipped(
        D.addTree(this.tree, this.fragments, !0),
      )),
      (this.parse = null));
  }
  withContext(e) {
    let t = Cr;
    Cr = this;
    try {
      return e();
    } finally {
      Cr = t;
    }
  }
  withoutTempSkipped(e) {
    for (let t; (t = this.tempSkipped.pop()); ) e = kr(e, t.from, t.to);
    return e;
  }
  changes(e, t) {
    let { fragments: i, tree: o, treeLen: n, viewport: s, skipped: r } = this;
    if ((this.takeTree(), !e.empty)) {
      let t = [];
      if (
        (e.iterChangedRanges((e, i, o, n) =>
          t.push({ fromA: e, toA: i, fromB: o, toB: n }),
        ),
        (i = D.applyChanges(i, t)),
        (o = u.empty),
        (n = 0),
        (s = { from: e.mapPos(s.from, -1), to: e.mapPos(s.to, 1) }),
        this.skipped.length)
      ) {
        r = [];
        for (let t of this.skipped) {
          let i = e.mapPos(t.from, 1),
            o = e.mapPos(t.to, -1);
          i < o && r.push({ from: i, to: o });
        }
      }
    }
    return new xr(this.parser, t, i, o, n, s, r, this.scheduleOn);
  }
  updateViewport(e) {
    if (this.viewport.from == e.from && this.viewport.to == e.to) return !1;
    this.viewport = e;
    let t = this.skipped.length;
    for (let t = 0; t < this.skipped.length; t++) {
      let { from: i, to: o } = this.skipped[t];
      i < e.to &&
        o > e.from &&
        ((this.fragments = kr(this.fragments, i, o)),
        this.skipped.splice(t--, 1));
    }
    return !(this.skipped.length >= t) && (this.reset(), !0);
  }
  reset() {
    this.parse && (this.takeTree(), (this.parse = null));
  }
  skipUntilInView(e, t) {
    this.skipped.push({ from: e, to: t });
  }
  static getSkippingParser(e) {
    return new (class extends O {
      createParse(t, i, o) {
        let n = o[0].from,
          s = o[o.length - 1].to;
        return {
          parsedPos: n,
          advance() {
            let t = Cr;
            if (t) {
              for (let e of o) t.tempSkipped.push(e);
              e &&
                (t.scheduleOn = t.scheduleOn
                  ? Promise.all([t.scheduleOn, e])
                  : e);
            }
            return ((this.parsedPos = s), new u(l.none, [], [], s - n));
          },
          stoppedAt: null,
          stopAt() {},
        };
      }
    })();
  }
  isDone(e) {
    e = Math.min(e, this.state.doc.length);
    let t = this.fragments;
    return this.treeLen >= e && t.length && 0 == t[0].from && t[0].to >= e;
  }
  static get() {
    return Cr;
  }
}
function kr(e, t, i) {
  return D.applyChanges(e, [{ fromA: t, toA: i, fromB: t, toB: i }]);
}
class Sr {
  constructor(e) {
    ((this.context = e), (this.tree = e.tree));
  }
  apply(e) {
    if (!e.docChanged && this.tree == this.context.tree) return this;
    let t = this.context.changes(e.changes, e.state),
      i =
        this.context.treeLen == e.startState.doc.length
          ? void 0
          : Math.max(e.changes.mapPos(this.context.treeLen), t.viewport.to);
    return (t.work(20, i) || t.takeTree(), new Sr(t));
  }
  static init(e) {
    let t = Math.min(3e3, e.doc.length),
      i = xr.create(e.facet(Ar).parser, e, { from: 0, to: t });
    return (i.work(20, t) || i.takeTree(), new Sr(i));
  }
}
br.state = xe.define({
  create: Sr.init,
  update(e, t) {
    for (let e of t.effects) if (e.is(br.setState)) return e.value;
    return t.startState.facet(Ar) != t.state.facet(Ar)
      ? Sr.init(t.state)
      : e.apply(t);
  },
});
let Tr = (e) => {
  let t = setTimeout(() => e(), 500);
  return () => clearTimeout(t);
};
"undefined" != typeof requestIdleCallback &&
  (Tr = (e) => {
    let t = -1,
      i = setTimeout(() => {
        t = requestIdleCallback(e, { timeout: 400 });
      }, 100);
    return () => (t < 0 ? clearTimeout(i) : cancelIdleCallback(t));
  });
const Er =
    "undefined" != typeof navigator &&
    (null === (mr = navigator.scheduling) || void 0 === mr
      ? void 0
      : mr.isInputPending)
      ? () => navigator.scheduling.isInputPending()
      : null,
  Mr = co.fromClass(
    class {
      constructor(e) {
        ((this.view = e),
          (this.working = null),
          (this.workScheduled = 0),
          (this.chunkEnd = -1),
          (this.chunkBudget = -1),
          (this.work = this.work.bind(this)),
          this.scheduleWork());
      }
      update(e) {
        let t = this.view.state.field(br.state).context;
        ((t.updateViewport(e.view.viewport) ||
          this.view.viewport.to > t.treeLen) &&
          this.scheduleWork(),
          (e.docChanged || e.selectionSet) &&
            (this.view.hasFocus && (this.chunkBudget += 50),
            this.scheduleWork()),
          this.checkAsyncSchedule(t));
      }
      scheduleWork() {
        if (this.working) return;
        let { state: e } = this.view,
          t = e.field(br.state);
        (t.tree == t.context.tree && t.context.isDone(e.doc.length)) ||
          (this.working = Tr(this.work));
      }
      work(e) {
        this.working = null;
        let t = Date.now();
        if (
          (this.chunkEnd < t &&
            (this.chunkEnd < 0 || this.view.hasFocus) &&
            ((this.chunkEnd = t + 3e4), (this.chunkBudget = 3e3)),
          this.chunkBudget <= 0)
        )
          return;
        let {
            state: i,
            viewport: { to: o },
          } = this.view,
          n = i.field(br.state);
        if (n.tree == n.context.tree && n.context.isDone(o + 1e5)) return;
        let s =
            Date.now() +
            Math.min(
              this.chunkBudget,
              100,
              e && !Er ? Math.max(25, e.timeRemaining() - 5) : 1e9,
            ),
          r = n.context.treeLen < o && i.doc.length > o + 1e3,
          a = n.context.work(
            () => (Er && Er()) || Date.now() > s,
            o + (r ? 0 : 1e5),
          );
        ((this.chunkBudget -= Date.now() - t),
          (a || this.chunkBudget <= 0) &&
            (n.context.takeTree(),
            this.view.dispatch({ effects: br.setState.of(new Sr(n.context)) })),
          this.chunkBudget > 0 && (!a || r) && this.scheduleWork(),
          this.checkAsyncSchedule(n.context));
      }
      checkAsyncSchedule(e) {
        e.scheduleOn &&
          (this.workScheduled++,
          e.scheduleOn
            .then(() => this.scheduleWork())
            .catch((e) => so(this.view.state, e))
            .then(() => this.workScheduled--),
          (e.scheduleOn = null));
      }
      destroy() {
        this.working && this.working();
      }
      isWorking() {
        return !!(this.working || this.workScheduled > 0);
      }
    },
    {
      eventHandlers: {
        focus() {
          this.scheduleWork();
        },
      },
    },
  ),
  Ar = ge.define({
    combine: (e) => (e.length ? e[0] : null),
    enables: (e) => [
      br.state,
      Mr,
      qs.contentAttributes.compute([e], (t) => {
        let i = t.facet(e);
        return i && i.name ? { "data-language": i.name } : {};
      }),
    ],
  });
(pr.meta,
  pr.link,
  pr.heading,
  pr.emphasis,
  pr.strong,
  pr.strikethrough,
  pr.keyword,
  pr.atom,
  pr.bool,
  pr.url,
  pr.contentSeparator,
  pr.labelName,
  pr.literal,
  pr.inserted,
  pr.string,
  pr.deleted,
  pr.regexp,
  pr.escape,
  pr.string,
  pr.variableName,
  pr.variableName,
  pr.typeName,
  pr.namespace,
  pr.className,
  pr.variableName,
  pr.macroName,
  pr.propertyName,
  pr.comment,
  pr.invalid);
const Ir = Object.create(null),
  Dr = [l.none],
  Or = [],
  Br = Object.create(null),
  Lr = Object.create(null);
for (let [e, t] of [
  ["variable", "variableName"],
  ["variable-2", "variableName.special"],
  ["string-2", "string.special"],
  ["def", "variableName.definition"],
  ["tag", "tagName"],
  ["attribute", "attributeName"],
  ["type", "typeName"],
  ["builtin", "variableName.standard"],
  ["qualifier", "modifier"],
  ["error", "invalid"],
  ["header", "heading"],
  ["property", "propertyName"],
])
  Lr[e] = Nr(Ir, t);
function Pr(e, t) {
  Or.indexOf(e) > -1 || (Or.push(e), console.warn(t));
}
function Nr(e, t) {
  let i = [];
  for (let o of t.split(" ")) {
    let t = [];
    for (let i of o.split(".")) {
      let o = e[i] || pr[i];
      o
        ? "function" == typeof o
          ? t.length
            ? (t = t.map(o))
            : Pr(i, `Modifier ${i} used at start of tag`)
          : t.length
            ? Pr(i, `Tag ${i} used as modifier`)
            : (t = Array.isArray(o) ? o : [o])
        : Pr(i, `Unknown highlighting tag ${i}`);
    }
    for (let e of t) i.push(e);
  }
  if (!i.length) return 0;
  let o = t.replace(/ /g, "_"),
    n = o + " " + i.map((e) => e.id),
    s = Br[n];
  if (s) return s.id;
  let r = (Br[n] = l.define({
    id: Dr.length,
    name: o,
    props: [Gs({ [o]: i })],
  }));
  return (Dr.push(r), r.id);
}
function Rr(e) {
  let t = Date.now().toString(36);
  return ((t += Math.random().toString(36).substr(3, e)), t);
}
function Fr(e, t, i, o) {
  let n,
    s = { index: -1, subindex: -1 },
    r = o;
  return (
    i
      ? r.forEach((e, i) => {
          if (
            "SubmenuCommands" in e &&
            ((n = e.SubmenuCommands.findIndex((e) => e.id == t.id)), n >= 0)
          )
            return ((s = { index: i, subindex: n }), s);
        })
      : ((n = r.findIndex((e) => e.id == t.id)),
        (s = { index: n, subindex: -1 })),
    s
  );
}
function qr(e, t) {
  let i,
    o = t.getLine(t.getCursor().line),
    n = "";
  const s = /^(\>*(\[[!\w]+\])?\s*)#+\s/;
  let r;
  const a = o.match(s);
  (a && (r = a[0].trim()),
    e == r || "" == e
      ? (i = o.replace(s, "$1"))
      : ((i = o.replace(/^\s*(#*|\>|\-|\d+\.)\s*/m, "")), (i = e + " " + i)),
    (n =
      "" != i
        ? t.getRange(t.getCursor(), { line: t.getCursor().line, ch: o.length })
        : t.getRange(t.getCursor(), { line: t.getCursor().line, ch: 0 })),
    t.setLine(t.getCursor().line, i),
    t.setCursor({ line: t.getCursor().line, ch: Number(i.length - n.length) }));
}
function _r(e, t) {
  if (!t) return;
  const i = t.getSelection();
  if (!i || "" === i.trim())
    return void this.plugin.setLastExecutedCommand("toolbar:change-font-color");
  const o = /<font\s+color=["']?[^"'>]+["']?>(.*?)<\/font>/gms,
    n = o.test(i);
  if (
    ((s = i),
    new RegExp(`^<font\\s+color=["']?${e}["']?>(.+)<\\/font>$`, "ms").test(
      s.trim(),
    ))
  )
    return;
  var s;
  const r = i.replace(o, (t, i) =>
      i
        .split("\n")
        .map((t) => (t.trim() ? `<font color="${e}">${t}</font>` : t))
        .join("\n"),
    ),
    a =
      r === i
        ? i
            .split("\n")
            .map((t) => (t.trim() ? `<font color="${e}">${t}</font>` : t))
            .join("\n")
        : r,
    l = t.listSelections().map((t) => {
      const i = n ? 0 : `<font color="${e}"></font>`.length;
      return t.anchor.line < t.head.line ||
        (t.anchor.line === t.head.line && t.anchor.ch < t.head.ch)
        ? {
            anchor: { line: t.anchor.line, ch: t.anchor.ch },
            head: { line: t.head.line, ch: t.head.ch + i },
          }
        : {
            anchor: { line: t.anchor.line, ch: t.anchor.ch + i },
            head: { line: t.head.line, ch: t.head.ch },
          };
    });
  (t.replaceSelection(a), t.setSelections(l));
}
function zr(e, t) {
  if (!t) return;
  const i = t.getSelection();
  if (!i || "" === i.trim()) return;
  const o =
    /<mark\s+style=["']?background:(?:#[0-9a-fA-F]{3,6}|rgba?\([^)]+\))["']?>([\s\S]*?)<\/mark>/g.test(
      i,
    );
  if (
    ((e, t) => {
      const i = t.replace(/([()[{*+.$^\\|?])/g, "\\$1");
      return new RegExp(
        `^<mark\\s+style=["']?background:${i}["']?>([sS]+)<\\/mark>$`,
      ).test(e.trim());
    })(i, e)
  )
    return;
  let n;
  n = o
    ? i.replace(/(background:)(?:#[0-9a-fA-F]{3,6}|rgba?\([^)]+\))/gi, `$1${e}`)
    : i
        .split("\n")
        .map((t) =>
          t.trim() ? `<mark style="background:${e}">${t}</mark>` : t,
        )
        .join("\n");
  const s = t.listSelections().map((t) => {
    const i = o ? 0 : `<mark style="background:${e}"></mark>`.length;
    return t.anchor.line < t.head.line ||
      (t.anchor.line === t.head.line && t.anchor.ch < t.head.ch)
      ? {
          anchor: { line: t.anchor.line, ch: t.anchor.ch },
          head: { line: t.head.line, ch: t.head.ch + i },
        }
      : {
          anchor: { line: t.anchor.line, ch: t.anchor.ch + i },
          head: { line: t.head.line, ch: t.head.ch },
        };
  });
  (t.replaceSelection(n), t.setSelections(s));
}
function Vr(e) {
  if (!e.getSelection()) {
    const t = e.getCursor(),
      i = e.getLine(t.line);
    if (/^\s*\d+\.\s/.test(i)) {
      const i = e.getLine(t.line).match(/^\s*/)?.[0].length || 0,
        o = t.line - 1,
        n = o >= 0 ? e.getLine(o).trim() : "";
      if (
        o < 0 ||
        !/^\s*\d+\.\s/.test(n) ||
        (n.match(/^\s*/)?.[0].length || 0) < i
      ) {
        const { startLine: i, endLine: o } = (function (e, t) {
          let i = t,
            o = t;
          for (; i > 0; ) {
            const t = e.getLine(i - 1);
            if (!/^\s*\d+\.\s/.test(t.trim())) break;
            i--;
          }
          for (; o < e.lineCount() - 1; ) {
            const t = e.getLine(o + 1);
            if (!/^\s*\d+\.\s/.test(t.trim())) break;
            o++;
          }
          return { startLine: i, endLine: o };
        })(e, t.line);
        Hr(e, i, o);
      } else {
        const { startLine: i, endLine: o } = (function (e, t) {
          let i = t,
            o = t;
          const n = e.getLine(t).match(/^\s*/)?.[0].length || 0;
          for (; o < e.lineCount() - 1; ) {
            const t = e.getLine(o + 1),
              i = t.match(/^\s*/)?.[0].length || 0;
            if (!/^\s*\d+\.\s/.test(t.trim()) || i < n) break;
            o++;
          }
          return { startLine: i, endLine: o };
        })(e, t.line);
        Hr(e, i, o);
      }
    }
    return;
  }
  const { lines: t, startLine: i } = (function (e) {
    const t = e.getSelection(),
      i = e.getCursor("from");
    return { lines: t.split("\n"), startLine: i.line };
  })(e);
  Wr(t, i, e);
}
function Wr(t, i, o) {
  let n = !1;
  for (const e of t)
    if (/^\s*\d+\.\s/.test(e.trim())) {
      n = !0;
      break;
    }
  if (!n) return;
  const s = app.workspace.getActiveViewOfType(e.MarkdownView)?.editor.cm;
  if (!s) return;
  const r = wr(s.state),
    a = o.posToOffset({ line: i, ch: 0 });
  let l = -1;
  if (
    (r.iterate({
      from: 0,
      to: a,
      enter: (e) => {
        "OrderedList" === e.name && (l = e.to);
      },
    }),
    l >= 0)
  ) {
    const e = o.offsetToPos(l).line + 1;
    e < i &&
      !/^\s*$/.test(o.getLine(e).trim()) &&
      (o.replaceRange("\n", { line: e, ch: 0 }, { line: e, ch: 0 }), i++);
  }
  let c = !0,
    d = [],
    h = -1;
  for (const e of t) {
    const t = e.trim();
    if (/^\d+\.\s/.test(t)) {
      const i = e.match(/^\s*/)?.[0].length || 0,
        o = parseInt(t.match(/^\d+/)[0], 10);
      if (((d[i] = i !== h ? 1 : (d[i] || 1) + 1), o !== d[i])) {
        c = !1;
        break;
      }
      h = i;
    }
  }
  let u = [];
  const p = i - 1,
    m = p >= 0 ? o.getLine(p).trim() : "";
  if (
    (m && !/^\s*$/.test(m) && !m.includes("ㅤ") && (u.push(""), u.push("ㅤ")),
    c)
  )
    u.push(...t);
  else {
    let e = {},
      i = -1;
    for (const o of t) {
      const t = o.trim(),
        n = /^\d+\.\s/.test(t),
        s = o.match(/^\s*/)?.[0] || "";
      if (n) {
        const o = s.length;
        ((e[o] = o !== i ? 1 : (e[o] || 1) + 1),
          u.push(`${s}${e[o]}. ${t.replace(/^\d+\.\s/, "")}`),
          (i = o));
      } else (u.push(o), (i = -1));
    }
  }
  o.replaceRange(
    u.join("\n"),
    { line: i, ch: 0 },
    { line: i + t.length - 1, ch: o.getLine(i + t.length - 1).length },
  );
}
function Hr(e, t, i) {
  const o = [];
  for (let n = t; n <= i; n++) o.push(e.getLine(n));
  Wr(o, t, e);
}
let $r;
(Ti.RTL, Ti.LTR);
const Ur = (t) => {
    $r = e.requireApiVersion("0.15.0")
      ? activeWindow.document
      : window.document;
    ["top", "following", "fixed"].forEach((e) => {
      $r.querySelectorAll(
        `.editingToolbarModalBar[data-toolbar-style="${e}"]`,
      ).forEach((e) => {
        t
          ? ((e.style.display = ""), (e.style.visibility = "visible"))
          : (e.style.display = "none");
      });
    });
    const i = $r.getElementById("editingToolbarModalBar");
    i &&
      (t
        ? ((i.style.display = ""), (i.style.visibility = "visible"))
        : (i.style.display = "none"));
  },
  jr = (t) => {
    (($r = e.requireApiVersion("0.15.0")
      ? activeWindow.document
      : window.document),
      $r.documentElement.style.setProperty(
        "--toolbar-vertical-offset",
        `${t.verticalPosition}px`,
      ));
  },
  Yr = (t) => {
    (($r = e.requireApiVersion("0.15.0")
      ? activeWindow.document
      : window.document),
      $r.documentElement.style.setProperty(
        "--toolbar-horizontal-offset",
        `${t.horizontalPosition}px`,
      ));
  };
var Gr = {
    "Toolbar Append Method": "Toolbar Append Method",
    "Choose where Toolbar will append upon regeneration. To see the change, hit the refresh button below, or in the status bar menu.":
      "Choose where Toolbar will append upon regeneration. To see the change, hit the refresh button below, or in the status bar menu.",
    "Toolbar aesthetic": "Toolbar aesthetic",
    "Choose between a glass morphism, tiny and default style for Toolbar. To see the change, hit the refresh button below, or in the status bar menu.":
      "Choose between a glass morphism, tiny and default style for Toolbar. To see the change, hit the refresh button below, or in the status bar menu.",
    "Toolbar position": "Toolbar position",
    "Choose between fixed position or cursor following mode.":
      "Choose between fixed position, cursor following or Top mode.",
    "Toolbar Columns": "Toolbar Columns",
    "Choose the number of columns per row to display on Toolbar.":
      "Choose the number of columns per row to display on Toolbar.",
    "Toolbar refresh": "Toolbar refresh",
    "Toolbar Commands": "Toolbar Commands",
    "Add a command onto Toolbar from Obsidian's commands library. To reorder the commands, drag and drop the command items. To delete them, use the delete buttom to the right of the command item. Toolbar will not automaticaly refresh after reordering commands. Use the refresh button above.":
      "Add a command onto Toolbar from Obsidian's commands library. To reorder the commands, drag and drop the command items. To delete them, use the delete buttom to the right of the command item. Toolbar will not automaticaly refresh after reordering commands. Use the refresh button above.",
    "Format Brush Off!": "Format Brush Off!",
    "Hide & Show": "Hide & Show",
    "Toolbar will only refresh automatically after you have either added or deleted a command from it. To see UI changes to editingToolbar (above settings changes) use the refresh button. If you forget to refresh in settings, no worries. There is also a refresh button in the editingToolbar status bar menu.":
      "Toolbar will only refresh automatically after you have either added or deleted a command from it. To see UI changes to editingToolbar (above settings changes) use the refresh button. If you forget to refresh in settings, no worries. There is also a refresh button in the editingToolbar status bar menu.",
    "Font-Color formatting brush ON!": "Font-Color formatting brush ON!",
    More: "More",
    "Font Colors": "Font Colors",
    "Format Brush": "Format Brush",
    "Background Color": "Background color",
    Refresh: "Refresh",
    Add: "Add",
    Delete: "Delete",
    "Change Command Name": "Change Command Name",
    "Change Submenu Name": "Change Submenu Name",
    "Button Submenu": "Button Submenu",
    "Dropdown Menu": "Dropdown Menu",
    "Menu type changed to": "Menu type changed to",
    "Add Submenu": "Add Submenu",
    "Add Separator": "Add Separator",
    "Enter the icon code, it looks like <svg>.... </svg> format":
      "Enter the icon code, it looks like <svg>.... </svg> format",
    "Please enter a new name: ": "Please enter a new name: ",
    "Drag the slider to move the position":
      "Drag the slider to move the position",
    "Plugin Settings": "Plugin Settings",
    "Background-color formatting brush ON!":
      "Background-color formatting brush ON!\nClick the mouse middle or right key to close the formatting-brush",
    "Clear formatting brush ON!": "Clear formatting brush ON!",
    "Clear formatting brush ON!\nClick the mouse middle or right key to close the formatting-brush":
      "Clear formatting brush ON!\nClick the mouse middle or right key to close the formatting-brush",
    "The toolbar is displayed when the mouse moves over it, otherwise it is automatically hidden":
      "The toolbar is displayed when the mouse moves over it, otherwise it is automatically hidden",
    "Toolbar Auto-hide": "Toolbar Auto-hide",
    "Toolbar Centred Display": "Toolbar Centred Display",
    "Whether the toolbar is centred or full-width, the default is full-width.":
      "Whether the toolbar is centred or full-width, the default is full-width.",
    "Custom Backgroud Color": "Custom Backgroud Color",
    "Custom Font Color": "Custom Font Color",
    "🎨 Set Custom Background": "🎨 Set Custom Background",
    "🖌️ Set Custom Font Color": "🖌️ Set Custom Font Color",
    "Click on the picker to adjust the color":
      "Click on the picker to adjust the color",
    "Mobile Enabled or Not": "Mobile Enabled or Not",
    "Whether to enable the plugin for the mobile client, the default is enabled.":
      "Whether to enable the plugin for the mobile client, the default is enabled.",
    "Whether to enable on mobile devices with device width less than 768px.":
      "Whether to enable on mobile devices with device width less than 768px, the default is disable.",
    Reset: "Reset",
    Fix: "Fix",
    "Fix Toolbar": "Fix Toolbar",
    General: "General",
    Appearance: "Appearance",
    Commands: "Commands",
    "Choose between fixed position or cursor following mode":
      "Choose between fixed position, cursor following or Top mode.",
    "Add and manage commands": "Add and manage commands",
    "Choose where Toolbar will append upon regeneration.":
      "Choose where Toolbar will append upon regeneration.",
    "Whether to enable on mobile devices with device width less than 768px":
      "Whether to enable on mobile devices with device width less than 768px",
    "Choose between a glass morphism, tiny and default style.":
      "Choose between a glass morphism, tiny and default style.",
    "Refresh Toolbar": "Refresh Toolbar",
    "Add Command": "Add Command",
    Settings: "Settings",
    "Position Style": "Position Style",
    Columns: "Columns",
    "Drag to Adjust Position": "Drag to Adjust Position",
    "Vertical Position": "Vertical Position",
    "Horizontal Position": "Horizontal Position",
    "Toolbar Position": "Toolbar Position",
    "Choose an icon": "Choose an icon",
    "Search for an icon...": "Search for an icon...",
    All: "All",
    Obsidian: "Obsidian",
    Glyph: "Glyph",
    Custom: "Custom",
    "Choose a command": "Choose a command",
    "The command": "The command",
    "already exists": "already exists",
    "Enter the icon code, format as <svg>.... </svg>":
      "Enter the icon code, format as <svg>.... </svg>",
    "No matching icons found": "No matching icons found",
    "Custom Commands": "Custom Commands",
    "Toolbar Commands": "Toolbar Commands",
    ID: "ID",
    Prefix: "Prefix",
    Suffix: "Suffix",
    Pattern: "Pattern",
    "Custom Format Commands": "Custom Format Commands",
    "Add, edit or delete custom format commands.":
      "Add, edit or delete custom format commands.",
    Edit: "Edit",
    "Command ID": "Command ID",
    'Unique identifier, no spaces, e.g.: "my-custom-format"':
      'Unique identifier, no spaces, e.g.: "my-custom-format"',
    "Displayed name in toolbar and menu": "Displayed name in toolbar and menu",
    "Add content before selected text": "Add content before selected text",
    "Add content after selected text": "Add content after selected text",
    "Character offset of cursor after formatting":
      "Character offset of cursor after formatting",
    "Line offset of cursor after formatting":
      "Line offset of cursor after formatting",
    "Whether to insert at the beginning of the next line":
      "Whether to insert at the beginning of the next line",
    "Command icon (click to select)": "Command icon (click to select)",
    "Choose Icon": "Choose Icon",
    Save: "Save",
    Cancel: "Cancel",
    "Edit Custom Command": "Edit Custom Command",
    "Add Custom Command": "Add Custom Command",
    "Command ID and command name cannot be empty":
      "Command ID and command name cannot be empty",
    "Command ID cannot contain spaces": "Command ID cannot contain spaces",
    'Command ID "${this.commandId}" already exists':
      'Command ID "${this.commandId}" already exists',
    "Cursor Position Offset": "Cursor Position Offset",
    "Line Offset": "Line Offset",
    "Line Head Format": "Line Head Format",
    Icon: "Icon",
    "Command Name": "Command Name",
    "Are you sure you want to restore all settings to default? This will lose all your custom configurations.":
      "Are you sure you want to restore all settings to default? This will lose all your custom configurations.",
    "Restore default": "Restore default",
    "Restore default settings": "Restore default settings",
    "🔄Restore default settings": "🔄Restore default settings",
    "🔧Data repair": "🔧Data repair",
    "Command IDs have been successfully repaired!":
      "Command IDs have been successfully repaired!",
    "No command IDs need to be repaired": "No command IDs need to be repaired",
    "Error repairing command IDs, please check the console for details":
      "Error repairing command IDs, please check the console for details",
    "Error restoring default settings, please check the console for details":
      "Error restoring default settings, please check the console for details",
    "Successfully restored default settings!":
      "Successfully restored default settings!",
    Close: "Close",
    Tips: "Tips",
    "This update changed the ID of some commands, please click this button to repair the commands to ensure the toolbar works properly":
      "This update changed the ID of some commands, please click this button to repair the commands to ensure the toolbar works properly",
    "Repair command ID": "Repair command ID",
    "This will reset all your custom configurations":
      "This will reset all your custom configurations",
    "Notice:": "Notice:",
    "This update rebuilds the entire code, reducing resource consumption":
      "This update rebuilds the entire code, reducing resource consumption",
    "Optimized mobile usage, added canvas support, and added custom commands":
      "Optimized mobile usage, added canvas support, and added custom commands",
    "⚠️This update is not compatible with 2.x version command ids, please click [Repair command] to be compatible":
      "⚠️This update is not compatible with 2.x version command ids, please click [Repair command] to be compatible",
    "⚠️If you want to restore the default settings, please click [Restore default settings]":
      "⚠️If you want to restore the default settings, please click [Restore default settings]",
    "Please execute a editingToolbar format command first, then enable the format brush":
      "Please execute a editingToolbar format command first, then enable the format brush",
    "Format brush ON! Select text to apply【":
      "Format brush ON! Select text to apply【",
    "】format":
      "】format\nClick the mouse right key to close the formatting-brush",
    "Add to Toolbar": "Add to Toolbar",
    "This command is already in the toolbar.":
      "This command is already in the toolbar.",
    "Command added to toolbar": "Command added to toolbar",
    "Add this command to the toolbar.": "Add this command to the toolbar.",
    "Callout Type": "Callout Type",
    Title: "Title",
    "Optional, leave blank for default title":
      "Optional, leave blank for default title",
    "Input title": "Input title",
    "Collapse State": "Collapse State",
    Open: "Open",
    Closed: "Closed",
    Content: "Content",
    Insert: "Insert",
    Default: "Default",
    "Input content": "Input content",
    "Link Text": "Link Text",
    "Link Alias": "Link Alias",
    "Link URL": "Link URL",
    "Embed Content": "Embed Content",
    "Image Size": "Image Size",
    "Insert New Line": "Insert New Line",
    "Paste and Parse": "Paste and Parse",
    "URL Format Error": "URL Format Error",
    "Image Width": "Image Width",
    "Image Height": "Image Height",
    "If it is an image, turn on": "If it is an image, turn on",
    "Insert a link on the next line": "Insert a link on the next line",
    "Link Title(optional)": "Link Title(optional)",
    Alias: "Alias",
    Optional: "Optional",
    "Default 0, format will keep the text selected":
      "Default 0, format will keep the text selected",
    "to insert": "to insert",
    "Latest Changes": "Latest Changes",
    "📋View full changelog": "📋View full changelog",
    "Open changelog": "Open changelog",
    "Loading changelog...": "Loading changelog...",
    "Open the complete changelog in your browser":
      "Open the complete changelog in your browser",
    "Enable Multiple Configurations": "Enable Multiple Configurations",
    "Enable different command configurations for each position style (following, top, fixed).":
      "Enable different command configurations for each position style (following, top, fixed).",
    "Currently editing commands for": "Currently editing commands for",
    "position style": "position style",
    "Current Configuration": "Current Configuration",
    "Switch between different command configurations.":
      "Switch between different command configurations.",
    "Following Style": "Following Style",
    "Top Style": "Top Style",
    "Fixed Style": "Fixed Style",
    "Mobile Style": "Mobile Style",
    configuration: "configuration",
    "Deploy command to configurations": "Deploy command to configurations",
    "All Configurations": "All Configurations",
    Deploy: "Deploy",
    "Command deployed to selected configurations":
      "Command deployed to selected configurations",
    "No configuration selected for deployment":
      "No configuration selected for deployment",
    "Command already exists in selected configurations":
      "Command already exists in selected configurations",
    "Command deployed to: ": "Command deployed to: ",
    "Command Deleted": "Command Deleted",
    "Confirm Delete?": "Confirm Delete?",
    Confirm: "Confirm",
    "Are you sure you want to restore all settings to default? But custom commands will be preserved.":
      "Are you sure you want to restore all settings to default? But custom commands will be preserved.",
    "Successfully restored default settings! (Custom commands preserved)":
      "Successfully restored default settings! (Custom commands preserved)",
    "This will reset all your custom configurations, but custom commands will be preserved":
      "This will reset all your custom configurations, but custom commands will be preserved",
    "Import/Export": "Import/Export",
    "Export Configuration": "Export Configuration",
    "Export your toolbar configuration to share with others.":
      "Export your toolbar configuration to share with others.",
    Export: "Export",
    "Import Configuration": "Import Configuration",
    "Import toolbar configuration from JSON.":
      "Import toolbar configuration from JSON.",
    Import: "Import",
    "Usage Instructions": "Usage Instructions",
    "Export: Generate a JSON configuration that you can save or share.":
      "Export: Generate a JSON configuration that you can save or share.",
    "Import: Paste a previously exported JSON configuration.":
      "Import: Paste a previously exported JSON configuration.",
    "You can choose to export all settings, only toolbar commands, or only custom commands":
      "You can choose to export all settings, only toolbar commands, or only custom commands",
    "When importing, the plugin will only update the settings included in the import data":
      "When importing, the plugin will only update the settings included in the import data",
    "Warning: Importing configuration will overwrite your current settings. Consider exporting your current configuration first as a backup.":
      "Warning: Importing configuration will overwrite your current settings. Consider exporting your current configuration first as a backup.",
    "Export Type": "Export Type",
    "Choose what to export": "Choose what to export",
    "All Settings": "All Settings",
    "Toolbar Commands Only": "Toolbar Commands Only",
    "Custom Commands Only": "Custom Commands Only",
    "Export Content": "Export Content",
    "Copy this content to share with others":
      "Copy this content to share with others",
    "Loading...": "Loading...",
    "Copy to Clipboard": "Copy to Clipboard",
    "Configuration copied to clipboard": "Configuration copied to clipboard",
    "Failed to copy configuration": "Failed to copy configuration",
    "Paste the configuration JSON here": "Paste the configuration JSON here",
    "Paste configuration here...": "Paste configuration here...",
    "Invalid import data": "Invalid import data",
    "Configuration imported successfully":
      "Configuration imported successfully",
    "No valid configuration found in import data":
      "No valid configuration found in import data",
    "Failed to import configuration. Invalid format.":
      "Failed to import configuration. Invalid format.",
    "Import Mode": "Import Mode",
    "Choose how to import the configuration":
      "Choose how to import the configuration",
    "Update Mode (Add new items and update existing ones)":
      "Update Mode (Add new items and update existing ones)",
    "Overwrite Mode (Replace all settings with imported ones)":
      "Overwrite Mode (Replace all settings with imported ones)",
    "Configuration imported successfully (Overwrite mode)":
      "Configuration imported successfully (Overwrite mode)",
    "Configuration imported successfully (Update mode)":
      "Configuration imported successfully (Update mode)",
    "Warning: Overwrite mode will completely replace your current settings with the imported ones. Consider exporting your current configuration first as a backup.":
      "Warning: Overwrite mode will completely replace your current settings with the imported ones. Consider exporting your current configuration first as a backup.",
    "Warning: Update mode will add new items and update existing ones based on the imported configuration.":
      "Warning: Update mode will add new items and update existing ones based on the imported configuration.",
    "Add Format Command": "Add Format Command",
    Regex: "Regex",
    "Prefix/Suffix": "Prefix/Suffix",
    "Insert Special Char": "Insert Special Char",
    "Add Regex Command": "Add Regex Command",
    "Switch Regex Command Window": "Switch Regex Command Window",
    "Please select text first": "Please select text first",
    "Current line is empty, please select text or move to a non-empty line":
      "Current line is empty, please select text or move to a non-empty line",
    "Use current line for regex commands":
      "Use current line for regex commands",
    "When no text is selected, regex commands will use the current line instead of clipboard content":
      "When no text is selected, regex commands will use the current line instead of clipboard content",
    "The selected text does not meet the condition requirements":
      "The selected text does not meet the condition requirements",
    "Regex command execution error: ": "Regex command execution error: ",
    "Copy code": "Copy code",
    "Copied!": "Copied!",
    "Explain the syntax of JavaScript regular expressions":
      "Explain the syntax of JavaScript regular expressions",
    "Apply regular expression replacement":
      "Apply regular expression replacement",
    "Conditional matching": "Conditional matching",
    "Complete regular expression code (copy to AI for explanation)":
      "Complete regular expression code (copy to AI for explanation)",
    "Error: ": "Error: ",
    "Regex pattern cannot be empty": "Regex pattern cannot be empty",
    "Command already exists": "Command already exists",
    "Choose icon": "Choose icon",
    "URL to Markdown link": "URL to Markdown link",
    "Convert MM/DD/YYYY to YYYY-MM-DD": "Convert MM/DD/YYYY to YYYY-MM-DD",
    "Add bold to keywords": "Add bold to keywords",
    "Format phone number": "Format phone number",
    "Remove extra spaces": "Remove extra spaces",
    "Convert HTML bold tags to Markdown format":
      "Convert HTML bold tags to Markdown format",
    "Convert quoted text to quote block": "Convert quoted text to quote block",
    "Convert CSV to Markdown table row": "Convert CSV to Markdown table row",
    "Add uniform alias to Markdown links":
      "Add uniform alias to Markdown links",
    "Delete empty lines (multiline mode)":
      "Delete empty lines (multiline mode)",
    "Add list symbol to each line (multiline mode)":
      "Add list symbol to each line (multiline mode)",
    "If the text contains important, set the text highlight (conditional format)":
      "If the text contains important, set the text highlight (conditional format)",
    "Matching pattern": "Matching pattern",
    "Regex pattern to match": "Regex pattern to match",
    "Replacement pattern (use $1, $2, etc. to reference capture groups)":
      "Replacement pattern (use $1, $2, etc. to reference capture groups)",
    "Ignore case": "Ignore case",
    "Global replace": "Global replace",
    "Multiline mode": "Multiline mode",
    "Use condition": "Use condition",
    "Condition pattern": "Condition pattern",
    "Only apply custom command when text matches the condition":
      "Only apply custom command when text matches the condition",
    "Must exist regular expression or text":
      "Must exist regular expression or text",
    "Replacement pattern": "Replacement pattern",
    "Match case-insensitive": "Match case-insensitive",
    "^ and $ match the start and end of each line":
      "^ and $ match the start and end of each line",
    "Replace all matches": "Replace all matches",
    Command: "Command",
    "Input example text to view the formatting effect of the command...":
      "Input example text to view the formatting effect of the command...",
    Description: "Description",
    "[Example]": "[Example]",
    "[Requirements]": "[Requirements]",
    "[Output]": "[Output]",
    "AI question template:": "AI question template:",
    "I need to convert the url to a markdown format link":
      "I need to convert the url to a markdown format link",
    "For example, convert https://example.com to [https://example.com](https://example.com)":
      "For example, convert https://example.com to [https://example.com](https://example.com)",
    "Use js regular expression to implement, and output the parameters in the following format (the result does not need to be escaped with json)":
      "Use js regular expression to implement, and output the parameters in the following format (the result does not need to be escaped with json)",
    "[Description]": "[Description]",
    "How to use AI to get regular expressions?":
      "How to use AI to get regular expressions?",
    "Regular expression examples": "Regular expression examples",
    "Edit regular expression command": "Edit regular expression command",
    "Add regular expression command": "Add regular expression command",
    "Result: ": "Result: ",
    "Example text:": "Example text:",
    Preview: "Preview",
    Result: "Result",
    "Please select text or copy text to clipboard first":
      "Please select text or copy text to clipboard first",
    "Overwrite Import": "Overwrite Import",
    "Update Import": "Update Import",
    "Importing configuration...": "Importing configuration...",
    "Following Style Only": "Following Style Only",
    "Top Style Only": "Top Style Only",
    "Fixed Style Only": "Fixed Style Only",
    "Mobile Style Only": "Mobile Style Only",
    "Unknown import type": "Unknown import type",
    "All Toolbar Commands": "All Toolbar Commands",
    "Initialize Commands": "Initialize Commands",
    "Copy commands from the main menu configuration":
      "Copy commands from the main menu configuration",
    "Initialize commands to default settings":
      "Initialize commands to default settings",
    "Reset Commands": "Reset Commands",
    "Commands reset successfully": "Commands reset successfully",
    "Following style commands initialized from current menu commands":
      "Following style commands initialized from current menu commands",
    "Commands initialized successfully": "Commands initialized successfully",
    "Reset to Menu Commands": "Reset to Menu Commands",
    "Are you sure you want to reset the current configuration?":
      "Are you sure you want to reset the current configuration?",
    "Following style commands successfully initialized":
      "Following style commands successfully initialized",
    "Top style commands successfully initialized":
      "Top style commands successfully initialized",
    "Fixed style commands successfully initialized":
      "Fixed style commands successfully initialized",
    "Mobile style commands successfully initialized":
      "Mobile style commands successfully initialized",
    "Reset commands to default settings": "Reset commands to default settings",
    Clear: "Clear",
    "Remove all commands from this configuration.":
      "Remove all commands from this configuration.",
    "Are you sure you want to clear all commands under the current style?":
      "Are you sure you want to clear all commands under the current style?",
    "Current style commands have been cleared":
      "Current style commands have been cleared",
    "Manage Commands": "Manage Commands",
    "Reset or clear all commands in this configuration":
      "Reset or clear all commands in this configuration",
    "One-click Clear": "One-click Clear",
    "Import Commands from Other Styles": "Import Commands from Other Styles",
    "Copy commands from another style configuration.":
      "Copy commands from another style configuration.",
    "Main menu only": "Main menu only",
    "This import will update:": "This import will update:",
    "Custom commands": "Custom commands",
    "Toolbar commands": "Toolbar commands",
    "General settings": "General settings",
    "Please paste configuration data first":
      "Please paste configuration data first",
    "Invalid import data format": "Invalid import data format",
    "Import From": "Import From",
    "This import will:": "This import will:",
    "Update general settings": "Update general settings",
    "Update Main Menu Commands": "Update Main Menu Commands",
    "Update Custom Commands": "Update Custom Commands",
    "Update Following Style Commands": "Update Following Style Commands",
    "Update Top Style Commands": "Update Top Style Commands",
    "Update Fixed Style Commands": "Update Fixed Style Commands",
    "Update Mobile Style Commands": "Update Mobile Style Commands",
    "Clear all Main Menu Commands": "Clear all Main Menu Commands",
    "Clear all Custom Commands": "Clear all Custom Commands",
    "Clear all Following Style Commands": "Clear all Following Style Commands",
    "Clear all Top Style Commands": "Clear all Top Style Commands",
    "Clear all Fixed Style Commands": "Clear all Fixed Style Commands",
    "Clear all Mobile Style Commands": "Clear all Mobile Style Commands",
    "Overwrite Mode (Replace settings with imported ones)":
      "Overwrite Mode (Replace settings with imported ones)",
    "Warning: Overwrite mode will replace existing settings with imported ones.":
      "Warning: Overwrite mode will replace existing settings with imported ones.",
    "Warning: Update mode will add new items and update existing ones.":
      "Warning: Update mode will add new items and update existing ones.",
    "Enable Multiple Config": "Enable Multiple Config",
    "Set Multiple Config to:": "Set Multiple Config to:",
    Enable: "Enable",
    Disable: "Disable",
    "Set Position Style to:": "Set Position Style to:",
    Following: "Following",
    Top: "Top",
    Fixed: "Fixed",
    Mobile: "Mobile",
    "All commands": "All commands",
    "⚠️ Overwrite mode will replace existing settings with imported ones.":
      "⚠️ Overwrite mode will replace existing settings with imported ones.",
    "ℹ️ Update mode will merge imported settings with existing ones.":
      "ℹ️ Update mode will merge imported settings with existing ones.",
    "Do you want to continue?": "Do you want to continue?",
    "Imported settings:": "Imported settings:",
    "Imported commands:": "Imported commands:",
    "Disable toolbar for this view": "Disable toolbar for this view",
    "Enable toolbar for this view": "Enable toolbar for this view",
    "Manage all view types": "Manage all view types",
    "Current View: ": "Current View: ",
    "Appearance Style": "Appearance Style",
    "Position Settings": "Position Settings",
    "All commands have been removed.": "All commands have been removed.",
    "Join the Community": "Join the Community",
    "Share your toolbar settings and styles in our":
      "Share your toolbar settings and styles in our",
    "Get inspired by what others have created or showcase your own customizations.":
      "Get inspired by what others have created or showcase your own customizations.",
    "Toolbar Preview (With a hypothetical command configuration.)":
      "Toolbar Preview (With a hypothetical command configuration.)",
    "Toolbar Theme": "Toolbar Theme",
    "Select a preset toolbar theme, automatically setting the background color, icon color, and size for the selected style.":
      "Select a preset toolbar theme, automatically setting the background color, icon color, and size for the selected style.",
    "Toolbar Background Color": "Toolbar Background Color",
    "Set the background color of the toolbar.":
      "Set the background color of the toolbar.",
    "Toolbar Icon Color": "Toolbar Icon Color",
    "Set the color of the toolbar icon.": "Set the color of the toolbar icon.",
    "Toolbar Icon Size": "Toolbar Icon Size",
    "Set the size of the toolbar icon (px); default: 18px":
      "Set the size of the toolbar icon (px); default: 18px",
    "Custom Theme": "Custom Theme",
    "Fixed Position Offset": "Fixed Position Offset",
    "Choose the offset of the Toolbar in the fixed position.":
      "Choose the offset of the Toolbar in the fixed position.",
    "Renumber List": "Renumber List",
    "Fetch Remote Title": "Fetch Remote Title",
    "Please enter a URL first": "Please enter a URL first",
    "Failed to fetch title for": "Failed to fetch title for",
    "Link Title (optional)": "Link Title (optional)",
    "Unable to detect editor width": "Unable to detect editor width",
    "Fit Editor Width": "Fit Editor Width",
    "Please execute a format command or select format text first, then enable the format brush":
      "Please execute a format command or select format text first, then enable the format brush",
    "Use \\n to represent line breaks": "Use \\n to represent line breaks",
    "Use ↵ to represent line breaks": "Use ↵ to represent line breaks",
    "Top Toolbar": "Top Toolbar",
    "Enable the toolbar positioned at the top.":
      "Enable the toolbar positioned at the top.",
    "Following Toolbar": "Following Toolbar",
    "Enable the toolbar that appears upon text selection.":
      "Enable the toolbar that appears upon text selection.",
    "Fixed Toolbar": "Fixed Toolbar",
    "Enable the toolbar whose position may be fixed where you please.":
      "Enable the toolbar whose position may be fixed where you please.",
    "Toolbar Settings": "Toolbar Settings",
    "Choose which toolbar style's appearance you want to edit.":
      "Choose which toolbar style's appearance you want to edit.",
    "Vertical Split": "Vertical Split",
    "Text Enhancement Tools": "Text Enhancement Tools",
    "Get Plain Text": "Get Plain Text",
    "Full Half Converter": "Full Half Converter",
    "Insert Blank Lines": "Insert Blank Lines",
    "Remove Blank Lines": "Remove Blank Lines",
    "Split Lines": "Split Lines",
    "Dedupe Lines": "Dedupe Lines",
    "Add Prefix/Suffix": "Add Prefix/Suffix",
    "Number Lines (Custom)": "Number Lines (Custom)",
    "Trim Line Ends": "Trim Line Ends",
    "Shrink Extra Spaces": "Shrink Extra Spaces",
    "Remove All Whitespace": "Remove All Whitespace",
    "Extract Between Strings": "Extract Between Strings",
    "Merge Lines": "Merge Lines",
    "List to Table": "List to Table",
    "Table to List": "Table to List",
    "Line Operations": "Line Operations",
    "Text Processing": "Text Processing",
    "Advanced Tools": "Advanced Tools",
    "Enter prefix": "Enter prefix",
    "Enter suffix": "Enter suffix",
    Delimiter: "Delimiter",
    "Enter delimiter (e.g., comma, tab)": "Enter delimiter (e.g., comma, tab)",
    "Column Number": "Column Number",
    "Enter column number (starting from 1)":
      "Enter column number (starting from 1)",
    "Start String": "Start String",
    "Enter start string": "Enter start string",
    "End String": "End String",
    "Enter end string": "Enter end string",
    "Number Lines Configuration": "Number Lines Configuration",
    "Start Number": "Start Number",
    Step: "Step",
    Separator: "Separator",
    "Merge Lines Settings": "Merge Lines Settings",
    "Separator (leave empty for smart spacing)":
      "Separator (leave empty for smart spacing)",
    "e.g., comma, pipe, arrow": "e.g., comma, pipe, arrow",
    "Plain text copied to clipboard": "Plain text copied to clipboard",
    "Whitespace cleaning completed": "Whitespace cleaning completed",
    "List pattern detected, auto-split": "List pattern detected, auto-split",
    "No obvious separator or list pattern detected":
      "No obvious separator or list pattern detected",
    "Paste failed": "Paste failed",
    "Detected Chinese context: converted to full-width symbols":
      "Detected Chinese context: converted to full-width symbols",
    "Detected code/English context: converted to half-width symbols":
      "Detected code/English context: converted to half-width symbols",
    "Please select text to dedupe first": "Please select text to dedupe first",
    "Deduplication completed, remaining": "Deduplication completed, remaining",
    lines: "lines",
    "Prefix/suffix added": "Prefix/suffix added",
    "Please select text to number first": "Please select text to number first",
    "Numbering completed: starting from": "Numbering completed: starting from",
    "Please specify start or end string": "Please specify start or end string",
    Extracted: "Extracted",
    matches: "matches",
    "No matches found": "No matches found",
    "Extraction failed": "Extraction failed",
    "Please select lines to merge first": "Please select lines to merge first",
    "Merged with": "Merged with",
    "Merge completed": "Merge completed",
    Item: "Item",
    "Super conversion completed: context preserved and layout optimized":
      "Super conversion completed: context preserved and layout optimized",
    "Please select a valid Markdown table":
      "Please select a valid Markdown table",
    "Table converted to multi-level list":
      "Table converted to multi-level list",
  },
  Zr = {
    "Toolbar Append Method": "工具栏的附加方法。",
    "Choose where Toolbar will append upon regeneration. To see the change, hit the refresh button below, or in the status bar menu.":
      "工具栏在Obsidian中的追加的位置，只对固定和跟随模式有效。如果你遇到工具栏显示问题，可以选择body试试。请点击下面或者状态栏菜单中的刷新按钮生效。",
    "Toolbar aesthetic": "工具栏样式",
    "Choose between a glass morphism, tiny and default style for Toolbar. To see the change, hit the refresh button below, or in the status bar menu.":
      "样式有毛玻璃,简约和默认风格选择。请点击下面或者状态栏菜单中的刷新按钮生效。",
    "Toolbar position": "工具栏位置",
    "Choose between fixed position or cursor following mode.":
      "在固定位置,光标跟随模式或者置顶模式之间进行选择。",
    "Toolbar Columns": "工具栏栏目数",
    "Choose the number of columns per row to display on Toolbar.":
      "选择在Toolbar上显示的每行的列数。",
    "Toolbar refresh": "刷新工具栏",
    "Toolbar Commands": "在工具栏中添加命令",
    "Add a command onto Toolbar from Obsidian's commands library. To reorder the commands, drag and drop the command items. To delete them, use the delete buttom to the right of the command item. Toolbar will not automaticaly refresh after reordering commands. Use the refresh button above.":
      "从Obsidian的命令库中添加一个命令到工具栏。要重新排列命令，可以拖放命令项。要删除它们，请使用命令项右边的删除按钮。图标选择Custom可以自定义图标",
    "Format Brush Off!": "关闭格式刷！",
    "Hide & Show": "隐藏 & 显示",
    "Toolbar will only refresh automatically after you have either added or deleted a command from it. To see UI changes to editingToolbar (above settings changes) use the refresh button. If you forget to refresh in settings, no worries. There is also a refresh button in the editingToolbar status bar menu.":
      "对外观的更改生效需要使用刷新按钮。如果你忘记在设置中刷新，在状态栏菜单中也有一个刷新按钮。",
    "Font-Color formatting brush ON!":
      "字体颜色格式刷开启\n点击鼠标中键或者右键关闭格式刷",
    More: "更多",
    "Font Colors": "字体颜色",
    "Format Brush": "格式刷",
    "Background Color": "背景颜色",
    Refresh: "刷新",
    Add: "添加",
    Delete: "删除",
    "Change Command Name": "更改命令名称",
    "Change Submenu Name": "更改子菜单名称",
    "Button Submenu": "按钮子菜单",
    "Dropdown Menu": "下拉菜单",
    "Menu type changed to": "菜单类型已更改为",
    "Add Submenu": "添加子菜单",
    "Add Separator": "添加分割线",
    "Enter the icon code, it looks like <svg>.... </svg> format":
      "输入图标代码，类似<svg>.... </svg>格式",
    "Please enter a new name: ": "请输入新名称：",
    "Drag the slider to move the position": "拖动滑块来移动位置",
    "Plugin Settings": "插件设置",
    "Background-color formatting brush ON!": "开启背景色格式刷",
    "Clear formatting brush ON!": "清除格式刷已开启",
    "Clear formatting brush ON!\nClick the mouse middle or right key to close the formatting-brush":
      "清除格式刷已开启\n点击鼠标中键或者右键关闭格式刷",
    "The toolbar is displayed when the mouse moves over it, otherwise it is automatically hidden":
      "当鼠标移到工具栏上方时，工具栏显示，否则自动隐藏",
    "Toolbar Auto-hide": "工具栏是否自动隐藏",
    "Toolbar Centred Display": "工具栏是否居中显示",
    "Whether the toolbar is centred or full-width, the default is full-width.":
      "工具栏居中还是全宽显示，默认全宽显示",
    "Custom Backgroud Color": "设置自定义背景色",
    "Custom Font Color": "设置自定义字体颜色",
    "🎨 Set Custom Background": "🎨 设置自定义背景",
    "🖌️ Set Custom Font Color": "🖌️ 设置自定义字体颜色",
    "Click on the picker to adjust the color": "点击选取器来调整颜色",
    "Mobile Enabled or Not": "是否在移动端启用",
    "Whether to enable on mobile devices with device width less than 768px.":
      "是否在设备宽度小于768的移动设备启用。默认不启用",
    Reset: "重置",
    Fix: "修复",
    "Fix Toolbar": "修复工具栏",
    General: "常规",
    Appearance: "外观",
    Commands: "命令",
    "Choose between fixed position or cursor following mode":
      "选择固定位置或者光标跟随模式",
    "Add and manage commands": "添加和管理命令",
    "Choose where Toolbar will append upon regeneration.":
      "选择工具栏在Obsidian中的追加的位置。",
    "Whether to enable on mobile devices with device width less than 768px":
      "是否在移动设备中启用。默认不启用",
    "Choose between a glass morphism, tiny and default style":
      "选择毛玻璃,简约和默认风格",
    "Refresh Toolbar": "刷新工具栏",
    "Add Command": "添加命令",
    Settings: "设置",
    "Adjust Toolbar Position[Fixed mode]": "调整工具栏位置[固定模式]",
    "Position Style": "位置样式",
    Columns: "列数",
    "Drag to Adjust Position": "拖动调整位置",
    "Vertical Position": "垂直位置",
    "Horizontal Position": "水平位置",
    "Toolbar Position": "工具栏位置",
    "Choose an icon": "选择一个图标",
    "Search for an icon...": "搜索图标...",
    All: "全部",
    Obsidian: "Obsidian",
    Glyph: "Glyph",
    Custom: "自定义",
    "Choose a command": "选择一个命令",
    "The command": "命令",
    "already exists": "已存在",
    "Enter the icon code, format as <svg>.... </svg>":
      "输入图标代码，格式为 <svg>.... </svg>",
    "No matching icons found": "没有找到匹配的图标",
    "Custom Commands": "自定义命令",
    "Toolbar Commands": "工具栏命令",
    ID: "ID",
    Prefix: "前缀",
    Suffix: "后缀",
    "Custom Format Commands": "自定义格式命令",
    "Add, edit or delete custom format commands.":
      "添加、编辑或删除自定义格式命令",
    Edit: "编辑",
    "Command ID": "命令ID",
    'Unique identifier, no spaces, e.g.: "my-custom-format"':
      '唯一标识符，不包含空格，例如："my-custom-format"',
    "Displayed name in toolbar and menu": "在工具栏和菜单中显示的名称",
    "Add content before selected text": "在选中的文本前添加内容",
    "Add content after selected text": "在选中的文本后添加内容",
    "Character offset of cursor after formatting": "格式化后光标的字符偏移量",
    "Line offset of cursor after formatting": "格式化后光标的行偏移量",
    "Whether to insert at the beginning of the next line": "是否在下一行首插入",
    "Command icon (click to select)": "命令图标（点击选择）",
    "Choose Icon": "选择图标",
    Save: "保存",
    Cancel: "取消",
    "Edit Custom Command": "编辑自定义命令",
    "Add Custom Command": "添加自定义命令",
    "Command ID and command name cannot be empty": "命令ID和命令名称不能为空",
    "Command ID cannot contain spaces": "命令ID不能包含空格",
    'Command ID "${this.commandId}" already exists':
      '命令ID "${this.commandId}" 已存在',
    "Command Name": "命令名称",
    "Cursor Position Offset": "光标位置偏移量",
    "Line Offset": "行偏移量",
    "Line Head Format": "行首格式",
    Icon: "图标",
    "Are you sure you want to restore all settings to default? This will lose all your custom configurations.":
      "确定要恢复所有设置为默认值吗？这将丢失您的所有自定义配置。",
    "Restore default": "恢复默认值",
    "Restore default settings": "恢复默认设置",
    "🔄Restore default settings": "🔄恢复默认设置",
    "🔧Data repair": "🔧数据修复",
    "Command IDs have been successfully repaired!": "命令ID已成功修复！",
    "No command IDs need to be repaired": "没有命令ID需要修复",
    "Error repairing command IDs, please check the console for details":
      "修复命令ID时出错，请查看控制台了解详情",
    "Error restoring default settings, please check the console for details":
      "恢复默认设置时出错，请查看控制台了解详情",
    "Successfully restored default settings!": "已成功恢复默认设置！",
    Close: "关闭",
    Tips: "提示",
    "This update changed the ID of some commands, please click this button to repair the commands to ensure the toolbar works properly":
      "此次更新更改了部分命令的ID，请点击此按钮修复命令以确保工具栏正常工作",
    "Repair command ID": "修复命令ID",
    "This will reset all your custom configurations":
      "这将重置您的所有自定义配置",
    "Notice:": "注意",
    "This update rebuilds the entire code, reducing resource consumption":
      "此次更新重构了全部代码，降低了资源占用",
    "Optimized mobile usage, added canvas support, and added custom commands":
      "优化了移动端，增加了对canvas支持，增加了自定义命令",
    "⚠️This update is not compatible with 2.x version command ids, please click [Repair command] to be compatible":
      "⚠️此次更新不兼容2.x旧版本命令id，请点击【修复命令】进行兼容",
    "⚠️If you want to restore the default settings, please click [Restore default settings]":
      "⚠️如果想恢复默认设置，请点击【恢复默认设置】",
    "Please execute a editingToolbar format command first, then enable the format brush":
      "请先执行一个格式命令，然后再启用格式刷",
    "Format brush ON! Select text to apply【": "格式刷已开启\n选中文本应用【",
    "】format": "】格式\n点击鼠标右键关闭格式刷",
    "Add to Toolbar": "添加到工具栏",
    "This command is already in the toolbar.": "该命令已存在于工具栏中",
    "Command added to toolbar": "命令已添加到工具栏",
    "Add this command to the toolbar.": "添加该命令到工具栏",
    "Callout Type": "Callout 类型",
    Title: "标题",
    "Optional, leave blank for default title": "可选，留空则使用默认标题",
    "Input title": "输入标题",
    "Collapse State": "折叠状态",
    Open: "展开",
    Closed: "折叠",
    Content: "内容",
    Insert: "插入",
    Default: "默认",
    "Input content": "输入内容",
    "Link Text": "链接文本",
    "Link Alias": "链接别名",
    "Link URL": "链接地址",
    "Embed Content": "嵌入内容",
    "Image Size": "图片尺寸",
    "Insert New Line": "插入新行",
    "Paste and Parse": "粘贴并解析",
    "URL Format Error": "URL格式错误",
    "Image Width": "图片宽度",
    "Image Height": "图片高度",
    "Insert a link on the next line": "在下一行插入链接",
    "If it is an image, turn on": "如果是图片，请开启",
    "Link Title(optional)": "链接标题(可选)",
    Alias: "别名",
    Optional: "可选",
    "Default 0, format will keep the text selected":
      "默认0，格式化将保持文本选中",
    "to insert": "插入",
    "Latest Changes": "最新更新",
    "📋View full changelog": "📋查看完整更新日志",
    "Open changelog": "打开更新日志",
    "Loading changelog...": "加载更新日志...",
    "Open the complete changelog in your browser": "在浏览器中打开完整更新日志",
    "Enable Multiple Configurations": "启用多配置",
    "Enable different command configurations for each position style (following, top, fixed).":
      "启用每个位置样式的不同命令配置（following，top，fixed）",
    "Currently editing commands for": "当前编辑的命令配置为：",
    "position style": "样式",
    "Current Configuration": "当前配置",
    "Switch between different command configurations.": "切换不同的命令配置",
    "Following Style": "跟随样式",
    "Top Style": "顶部样式",
    "Fixed Style": "固定样式",
    "Mobile Style": "移动端样式",
    configuration: "配置",
    "Deploy command to configurations": "部署命令到配置",
    "All Configurations": "所有配置",
    Deploy: "部署",
    "Command deployed to selected configurations": "命令已部署到选中的配置",
    "No configuration selected for deployment": "没有选中的配置",
    "Command already exists in selected configurations":
      "命令已存在于选中的配置",
    "Command deployed to: ": "命令已部署到：",
    "Command Deleted": "命令已删除",
    "Confirm Delete?": "确认删除？",
    "Are you sure you want to restore all settings to default? But custom commands will be preserved.":
      "您确定要将所有设置恢复为默认值吗？但自定义命令将被保留。",
    "Successfully restored default settings! (Custom commands preserved)":
      "成功恢复默认设置！（自定义命令已保留）",
    "This will reset all your custom configurations, but custom commands will be preserved":
      "这将重置您的所有自定义配置，但自定义命令将被保留",
    "Import/Export": "导入/导出",
    "Export Configuration": "导出配置",
    "Export your toolbar configuration to share with others.":
      "导出您的工具栏配置以与他人共享",
    Export: "导出",
    "Import Configuration": "导入配置",
    "Import toolbar configuration from JSON.": "从JSON导入工具栏配置",
    Import: "导入",
    "Usage Instructions": "使用说明",
    "Export: Generate a JSON configuration that you can save or share.":
      "导出：生成可保存或共享的JSON配置",
    "Import: Paste a previously exported JSON configuration.":
      "导入：粘贴先前导出的JSON配置",
    "You can choose to export all settings, only toolbar commands, or only custom commands":
      "您可以选择导出所有设置、仅工具栏命令或仅自定义命令",
    "When importing, the plugin will only update the settings included in the import data":
      "导入时，插件将仅更新导入数据中包含的设置",
    "Warning: Importing configuration will overwrite your current settings. Consider exporting your current configuration first as a backup.":
      "警告：导入配置将覆盖您当前的设置。建议先导出当前配置作为备份。",
    "Export Type": "导出类型",
    "Choose what to export": "选择要导出的内容",
    "All Settings": "所有设置",
    "Toolbar Commands Only": "仅工具栏命令",
    "Custom Commands Only": "仅自定义命令",
    "Export Content": "导出内容",
    "Copy this content to share with others": "复制此内容以与他人共享",
    "Loading...": "加载中...",
    "Copy to Clipboard": "复制到剪贴板",
    "Configuration copied to clipboard": "配置已复制到剪贴板",
    "Failed to copy configuration": "复制配置失败",
    "Paste the configuration JSON here": "在此处粘贴配置JSON",
    "Paste configuration here...": "在此处粘贴配置...",
    "Invalid import data": "无效的导入数据",
    "Configuration imported successfully": "配置导入成功",
    "No valid configuration found in import data": "导入数据中未找到有效配置",
    "Failed to import configuration. Invalid format.":
      "导入配置失败。格式无效。",
    "Import Mode": "导入模式",
    "Choose how to import the configuration": "选择如何导入配置",
    "Update Mode (Add new items and update existing ones)":
      "更新模式（添加新项目并更新现有项目）",
    "Overwrite Mode (Replace all settings with imported ones)":
      "覆盖模式（用导入的配置替换所有设置）",
    "Configuration imported successfully (Overwrite mode)":
      "配置导入成功（覆盖模式）",
    "Configuration imported successfully (Update mode)":
      "配置导入成功（更新模式）",
    "Warning: Overwrite mode will completely replace your current settings with the imported ones. Consider exporting your current configuration first as a backup.":
      "警告：覆盖模式将完全替换您当前的设置与导入的设置。建议先导出当前配置作为备份。",
    "Warning: Update mode will add new items and update existing ones based on the imported configuration.":
      "警告：更新模式将根据导入的配置添加新项目并更新现有项目。",
    "Add Format Command": "添加格式命令",
    Regex: "正则",
    "Prefix/Suffix": "前缀/后缀",
    "Insert Special Char": "增加特殊符号",
    "Add Regex Command": "添加正则表达式命令",
    "Switch Regex Command Window": "切换到正则命令窗口",
    "Please select text first": "请先选中文本",
    "Current line is empty, please select text or move to a non-empty line":
      "当前行为空，请选中文本或移动到非空行",
    "Use current line for regex commands": "正则命令使用当前行",
    "When no text is selected, regex commands will use the current line instead of clipboard content":
      "当没有选中文本时，正则命令将使用当前行内容而不是剪贴板内容",
    "The selected text does not meet the condition requirements":
      "选中的文本不满足条件要求",
    "Regex command execution error: ": "正则表达式命令执行错误：",
    "Copy code": "复制代码",
    "Copied!": "已复制！",
    "Explain the syntax of JavaScript regular expressions":
      "解释JavaScript正则表达式的语法",
    "Apply regular expression replacement": "应用正则表达式替换",
    "Conditional matching": "条件匹配",
    "Complete regular expression code (copy to AI for explanation)":
      "完整正则表达式代码（复制到AI解释）",
    "Error: ": "错误：",
    "Regex pattern cannot be empty": "正则表达式不能为空",
    "Command already exists": "命令已存在",
    "Choose icon": "选择图标",
    "URL to Markdown link": "URL转Markdown链接",
    "Convert MM/DD/YYYY to YYYY-MM-DD": "将MM/DD/YYYY日期格式转换为YYYY-MM-DD",
    "Add bold to keywords": "添加粗体到关键词",
    "Format phone number": "格式化电话号码",
    "Remove extra spaces": "删除多余空格",
    "Convert HTML bold tags to Markdown format":
      "将HTML粗体标签转换为Markdown格式",
    "Convert quoted text to quote block": "将引用的文本转换为引用块",
    "Convert CSV to Markdown table row": "将CSV转换为Markdown表格行",
    "Add uniform alias to Markdown links": "添加统一别名到Markdown链接",
    "Delete empty lines (multiline mode)": "删除空行（多行模式）",
    "Add list symbol to each line (multiline mode)":
      "添加列表符号到每行（多行模式）",
    "If the text contains important, set the text highlight (conditional format)":
      "如果文本包含重要内容，设置文本高亮（条件格式）",
    "Matching pattern": "匹配模式",
    "Regex pattern to match": "正则表达式匹配",
    "Replacement pattern (use $1, $2, etc. to reference capture groups)":
      "替换模式（使用$1, $2等引用捕获组）",
    "Ignore case": "忽略大小写",
    "Global replace": "全局替换",
    "Multiline mode": "多行模式",
    "Use condition": "使用条件",
    "Condition pattern": "条件模式",
    "Only apply custom command when text matches the condition":
      "仅在文本匹配条件时应用自定义命令",
    "Must exist regular expression or text": "必须存在正则表达式或文本",
    "Replacement pattern": "替换模式",
    "Match case-insensitive": "匹配不区分大小写",
    "^ and $ match the start and end of each line":
      "^ 和 $ 匹配每行的开始和结束",
    "Replace all matches": "替换所有匹配",
    Command: "命令",
    "Input example text to view the formatting effect of the command...":
      "输入示例文本以查看命令的格式化效果...",
    Description: "描述",
    "[Example]": "[示例]",
    "[Requirements]": "[要求]",
    "[Output]": "[输出]",
    "AI question template:": "AI问题模板：",
    "I need to convert the url to a markdown format link":
      "我需要将URL转换为Markdown格式链接",
    "For example, convert https://example.com to [https://example.com](https://example.com)":
      "例如，将https://example.com转换为[https://example.com](https://example.com)",
    "Use js regular expression to implement, and output the parameters in the following format (the result does not need to be escaped with json)":
      "使用js正则表达式实现，并输出以下格式的参数（结果不需要用json转义）",
    "[Description]": "[描述]",
    "How to use AI to get regular expressions?": "如何使用AI获取正则表达式？",
    "Regular expression examples": "正则表达式示例",
    "Edit regular expression command": "编辑正则表达式命令",
    "Add regular expression command": "添加正则表达式命令",
    "Result:": "结果：",
    "Example text:": "示例文本：",
    Preview: "预览",
    Result: "结果",
    "Update Import": "增量导入",
    "Overwrite Import": "覆盖导入",
    "Importing configuration...": "正在导入配置...",
    "Following Style Only": "仅Following样式",
    "Top Style Only": "仅Top样式",
    "Fixed Style Only": "仅Fixed样式",
    "Mobile Style Only": "仅Mobile样式",
    "Unknown import type": "未知导入类型",
    "All Toolbar Commands": "所有工具栏命令",
    "Following style commands successfully initialized":
      "Following样式初始化成功",
    "Top style commands successfully initialized": "Top样式初始化成功",
    "Fixed style commands successfully initialized": "Fixed样式初始化成功",
    "Mobile style commands successfully initialized": "Mobile样式初始化成功",
    "Commands initialized successfully": "命令初始化成功",
    "Reset Commands": "重置命令",
    "Are you sure you want to reset the current configuration?":
      "您确定要将当前配置进行重置吗？",
    "Commands reset successfully": "命令重置成功",
    "Initialize Commands": "初始化命令",
    "Initialize commands to default settings": "初始化命令到默认设置",
    "Reset commands to default settings": "重置命令到默认设置",
    Clear: "清除",
    "Remove all commands from this configuration.": "清除当前样式下的所有命令",
    "Are you sure you want to clear all commands under the current style?":
      "您确定要清除当前样式下的所有命令吗？",
    "Current style commands have been cleared": "当前样式下的命令已清除",
    "Manage Commands": "管理命令",
    "Reset or clear all commands in this configuration":
      "重置或清除当前样式下的所有命令",
    "Import Commands from Other Styles": "从其他样式导入命令",
    "Copy commands from another style configuration.":
      "从另一个样式配置复制命令",
    "Main menu only": "Main menu only",
    "This import will update:": "此次导入将更新：",
    "Custom commands": "自定义命令",
    "Toolbar commands": "工具栏命令",
    "All settings": "所有设置",
    "Following style only": "跟随样式",
    "Top style only": "顶部样式",
    "Fixed style only": "固定样式",
    "Mobile style only": "移动端样式",
    "Main Menu Commands": "主菜单命令",
    "Following Style Commands": "跟随样式命令",
    "Top Style Commands": "顶部样式命令",
    "Fixed Style Commands": "固定样式命令",
    "Mobile Style Commands": "移动端样式命令",
    "General settings": "常规设置",
    "Please paste configuration data first": "请先粘贴配置数据",
    "Invalid import data format": "无效的导入数据格式",
    "Do you want to continue?": "您确定要继续吗？",
    "Warning: Update mode will add new items and update existing ones.":
      "警告：更新模式将添加新项目并更新现有项目。",
    "Warning: Overwrite mode will completely replace your current settings with the imported ones.":
      "警告：覆盖模式将完全替换您当前的设置与导入的设置。",
    "Overwrite Mode (Replace settings with imported ones)":
      "覆盖模式（用导入的配置替换所有设置）",
    "Warning: Overwrite mode will replace existing settings with imported ones.":
      "警告：覆盖模式将用导入的配置替换所有设置。",
    "Enable Multiple Config": "启用多配置",
    "One-click Clear": "一键清除",
    "This import will:": "此次导入将：",
    "Update general settings": "更新常规设置",
    "Update Main Menu Commands": "更新主菜单命令",
    "Update Custom Commands": "更新自定义命令",
    "Update Following Style Commands": "更新跟随样式命令",
    "Update Top Style Commands": "更新顶部样式命令",
    "Update Fixed Style Commands": "更新固定样式命令",
    "Clear all Main Menu Commands": "清除所有主菜单命令",
    "Clear all Custom Commands": "清除所有自定义命令",
    "Clear all Following Style Commands": "清除所有跟随样式命令",
    "Clear all Top Style Commands": "清除所有顶部样式命令",
    "Clear all Fixed Style Commands": "清除所有固定样式命令",
    "Clear all Mobile Style Commands": "清除所有移动端样式命令",
    "Set Multiple Config to:": "设置多配置为：",
    Enable: "启用",
    Disable: "禁用",
    "Set Position Style to:": "设置位置样式为：",
    Following: "跟随",
    Top: "顶部",
    Fixed: "固定",
    Mobile: "移动端",
    "All commands": "所有命令",
    "⚠️ Overwrite mode will replace existing settings with imported ones.":
      "⚠️ 覆盖模式将用导入的配置替换所有设置。",
    "ℹ️ Update mode will merge imported settings with existing ones.":
      "ℹ️ 更新模式将合并导入的设置与现有的设置。",
    "Imported settings:": "导入的设置：",
    "Imported commands:": "导入的命令：",
    "Disable toolbar for this view": "禁用此视图的工具栏",
    "Enable toolbar for this view": "启用此视图的工具栏",
    "Manage all view types": "管理所有视图类型",
    "Current View: ": "当前视图：",
    "Appearance Style": "外观样式",
    "Position Settings": "位置设置",
    "Join the Community": "加入社区",
    "Share your toolbar settings and styles in our":
      "分享您的工具栏设置和样式：",
    "section!": "社区！",
    "Get inspired by what others have created or showcase your own customizations.":
      "获取灵感或展示您的自定义设置。",
    "Toolbar Preview (With a hypothetical command configuration.)":
      "工具栏预览（按钮仅供参考）",
    "Toolbar Theme": "工具栏主题",
    "Select a preset toolbar theme, automatically setting the background color, icon color, and size for the selected style.":
      "选择预设的工具栏主题，自动设置背景颜色、图标颜色和大小",
    "Toolbar Background Color": "工具栏背景颜色",
    "Set the background color of the toolbar.": "设置工具栏的背景颜色",
    "Toolbar Icon Color": "工具栏图标颜色",
    "Set the color of the toolbar icon.": "设置工具栏图标颜色",
    "Toolbar Icon Size": "工具栏图标大小",
    "Set the size of the toolbar icon (px); default: 18px":
      "设置工具栏图标大小（px）默认18px",
    "Custom theme": "自定义主题",
    "Fixed Position Offset": "固定位置偏移",
    "Choose the offset of the Toolbar in the fixed position.":
      "选择固定位置工具栏的偏移量。",
    "Renumber List": "列表重新编号",
    "Insert link": "插入链接",
    "Please enter a URL first": "请先输入一个URL",
    "Failed to fetch title for": "获取标题失败",
    "Link Title (optional)": "链接标题（可选）",
    "Unable to detect editor width": "无法检测编辑器宽度",
    "Fit Editor Width": "自适应宽度",
    "Fetch Remote Title": "获取URL标题",
    "Please execute a format command or select format text first, then enable the format brush":
      "请先执行一个格式命令或选中带格式的文本，然后启用格式刷",
    Confirm: "确认",
    "Use \\n to represent line breaks": "使用\\n表示换行符",
    "Use ↵ to represent line breaks": "使用↵表示换行符",
    "All commands have been removed.": "所有命令已被清除。",
    "Top Toolbar": "顶部工具栏",
    "Enable the toolbar positioned at the top.": "启用位于顶部的工具栏。",
    "Following Toolbar": "跟随工具栏",
    "Enable the toolbar that appears upon text selection.":
      "启用在选中文本时出现的工具栏。",
    "Fixed Toolbar": "固定工具栏",
    "Enable the toolbar whose position may be fixed where you please.":
      "启用可以固定在任意位置的工具栏。",
    "Toolbar Settings": "工具栏设置",
    "Choose which toolbar style's appearance you want to edit.":
      "选择要编辑外观的工具栏样式。",
    "Vertical Split": "垂直分割",
    "Text Enhancement Tools": "文本增强工具",
    "Get Plain Text": "获取无语法文本",
    "Full Half Converter": "全角半角转换",
    "Insert Blank Lines": "插入空行",
    "Remove Blank Lines": "删除空行",
    "Split Lines": "拆分行",
    "Dedupe Lines": "去除重复行",
    "Add Prefix/Suffix": "添加前后缀",
    "Number Lines (Custom)": "添加行号（自定义）",
    "Trim Line Ends": "去除行首尾空格",
    "Shrink Extra Spaces": "压缩多余空格",
    "Remove All Whitespace": "移除所有空白",
    "Extract Between Strings": "提取字符串之间内容",
    "Merge Lines": "合并行",
    "List to Table": "多级列表转表格",
    "Table to List": "表格转多级列表",
    "Line Operations": "行操作",
    "Text Processing": "文本处理",
    "Advanced Tools": "高级工具",
    "Enter prefix": "输入前缀",
    "Enter suffix": "输入后缀",
    Delimiter: "分隔符",
    "Enter delimiter (e.g., comma, tab)": "输入分隔符（例如：逗号、制表符）",
    "Column Number": "列号",
    "Enter column number (starting from 1)": "输入列号（从1开始）",
    "Start String": "起始字符串",
    "Enter start string": "输入起始字符串",
    "End String": "结束字符串",
    "Enter end string": "输入结束字符串",
    "Number Lines Configuration": "行号配置",
    "Start Number": "起始数字",
    Step: "步长",
    Separator: "分隔符",
    "Merge Lines Settings": "合并行设置",
    "Separator (leave empty for smart spacing)":
      "分隔符 (留空则开启智能中英间距)",
    "e.g., comma, pipe, arrow": "例如: , 或 | 或 →",
    "Plain text copied to clipboard": "无语法文本已复制到剪贴板",
    "Whitespace cleaning completed": "空白字符清洗完成",
    "List pattern detected, auto-split": "检测到列表模式，已自动拆分",
    "No obvious separator or list pattern detected":
      "未识别到明显的分隔符或列表模式",
    "Paste failed": "粘贴失败",
    "Detected Chinese context: converted to full-width symbols":
      "检测为中文语境：已转换为全角符号",
    "Detected code/English context: converted to half-width symbols":
      "检测为代码/英文语境：已转换为半角符号",
    "Please select text to dedupe first": "请先选择要去重的文本",
    "Deduplication completed, remaining": "去重完成，剩余",
    lines: "行",
    "Prefix/suffix added": "添加前后缀完成",
    "Please select text to number first": "请先选择要编号的文本",
    "Numbering completed: starting from": "已完成编号：从",
    "Please specify start or end string": "请指定起始或结束字符串",
    Extracted: "提取了",
    matches: "个匹配项",
    "No matches found": "未找到匹配项",
    "Extraction failed": "提取失败",
    "Please select lines to merge first": "请先选择要合并的行",
    "Merged with": "已按",
    "Merge completed": "已完成合并",
    Item: "项目",
    "Super conversion completed: context preserved and layout optimized":
      "超级转换完成：已保留上下文并优化排版",
    "Please select a valid Markdown table": "请先选择有效的 Markdown 表格",
    "Table converted to multi-level list": "表格已还原为多级列表",
  },
  Kr = { ...Zr };
const Jr = {
  ar: {},
  cs: {},
  da: {},
  de: {},
  en: Gr,
  "en-gb": {
    "Toolbar Append Method": "Toolbar Append Method",
    "Choose where Toolbar will append upon regeneration. To see the change, hit the refresh button below, or in the status bar menu.":
      "Choose where Toolbar will append upon regeneration. To see the change, hit the refresh button below, or in the status bar menu.",
    "Toolbar aesthetic": "Toolbar aesthetic",
    "Choose between a glass morphism, tiny and default style for Toolbar. To see the change, hit the refresh button below, or in the status bar menu.":
      "Choose between a glass morphism, tiny and default style for Toolbar. To see the change, hit the refresh button below, or in the status bar menu.",
    "Toolbar position": "Toolbar position",
    "Choose between fixed position or cursor following mode.":
      "Choose between fixed position, cursor following or Top mode.",
    "Toolbar Columns": "Toolbar Columns",
    "Choose the number of columns per row to display on Toolbar.":
      "Choose the number of columns per row to display on Toolbar.",
    "Toolbar refresh": "Toolbar refresh",
    "Toolbar Commands": "Toolbar Commands",
    "Add a command onto Toolbar from Obsidian's commands library. To reorder the commands, drag and drop the command items. To delete them, use the delete buttom to the right of the command item. Toolbar will not automaticaly refresh after reordering commands. Use the refresh button above.":
      "Add a command onto Toolbar from Obsidian's commands library. To reorder the commands, drag and drop the command items. To delete them, use the delete buttom to the right of the command item. Toolbar will not automaticaly refresh after reordering commands. Use the refresh button above.",
    "Format Brush Off!": "Format Brush Off!",
    "Hide & Show": "Hide & Show",
    "Toolbar will only refresh automatically after you have either added or deleted a command from it. To see UI changes to editingToolbar (above settings changes) use the refresh button. If you forget to refresh in settings, no worries. There is also a refresh button in the editingToolbar status bar menu.":
      "Toolbar will only refresh automatically after you have either added or deleted a command from it. To see UI changes to editingToolbar (above settings changes) use the refresh button. If you forget to refresh in settings, no worries. There is also a refresh button in the editingToolbar status bar menu.",
    "Font-Color formatting brush ON!": "Font-Colour formatting brush ON!",
    More: "More",
    "Font Colors": "Font Colours",
    "Format Brush": "Format Brush",
    "Background color": "Background colour",
    Refresh: "Refresh",
    Add: "Add",
    Delete: "Delete",
    "Change Command Name": "Change Command Name",
    "Add Submenu": "Add Submenu",
    "Add Separator": "Add Separator",
    "Enter the icon code, it looks like <svg>.... </svg> format":
      "Enter the icon code, it looks like <svg>.... </svg> format",
    "Please enter a new name: ": "Please enter a new name: ",
    "Drag the slider to move the position":
      "Drag the slider to move the position",
    "Plugin Settings": "Plugin Settings",
    "Background-color formatting brush ON!":
      "Background-colour formatting brush ON!\nClick the mouse middle or right key to close the formatting-brush",
    "Clear formatting brush ON!": "Clear formatting brush ON!",
    "Clear formatting brush ON!\nClick the mouse middle or right key to close the formatting-brush":
      "Clear formatting brush ON!\nClick the mouse middle or right key to close the formatting-brush",
    "The toolbar is displayed when the mouse moves over it, otherwise it is automatically hidden":
      "The toolbar is displayed when the mouse moves over it, otherwise it is automatically hidden",
    "Toolbar Auto-hide": "Toolbar Auto-hide",
    "Toolbar Centred Display": "Toolbar Centred Display",
    "Whether the toolbar is centred or full-width, the default is full-width.":
      "Whether the toolbar is centred or full-width, the default is full-width.",
    "Custom Backgroud Color": "Custom Backgroud Colour",
    "Custom Font Color": "Custom Font Colour",
    "🎨 Set Custom Background": "🎨 Set Custom Background",
    "🖌️ Set Custom Font Color": "🖌️ Set Custom Font Colour",
    "Click on the picker to adjust the color":
      "Click on the picker to adjust the colour",
    "Mobile Enabled or Not": "Mobile Enabled or Not",
    "Whether to enable the plugin for the mobile client, the default is enabled.":
      "Whether to enable the plugin for the mobile client, the default is enabled.",
    "Whether to enable on mobile devices with device width less than 768px.":
      "Whether to enable on mobile devices with device width less than 768px, the default is disable.",
    Reset: "Reset",
    Fix: "Fix",
    "Fix Toolbar": "Fix Toolbar",
    General: "General",
    Appearance: "Appearance",
    Commands: "Commands",
    "Choose between fixed position or cursor following mode":
      "Choose between fixed position, cursor following or Top mode.",
    "Add and manage commands": "Add and manage commands",
    "Choose where Toolbar will append upon regeneration.":
      "Choose where Toolbar will append upon regeneration.",
    "Whether to enable on mobile devices with device width less than 768px":
      "Whether to enable on mobile devices with device width less than 768px",
    "Choose between a glass morphism, tiny and default style.":
      "Choose between a glass morphism, tiny and default style.",
    "Refresh Toolbar": "Refresh Toolbar",
    "Add Command": "Add Command",
    Settings: "Settings",
    "Position Style": "Position Style",
    Columns: "Columns",
    "Drag to Adjust Position": "Drag to Adjust Position",
    "Vertical Position": "Vertical Position",
    "Horizontal Position": "Horizontal Position",
    "Toolbar Position": "Toolbar Position",
    "Choose an icon": "Choose an icon",
    "Search for an icon...": "Search for an icon...",
    All: "All",
    Obsidian: "Obsidian",
    Glyph: "Glyph",
    Custom: "Custom",
    "Choose a command": "Choose a command",
    "The command": "The command",
    "already exists": "already exists",
    "Enter the icon code, format as <svg>.... </svg>":
      "Enter the icon code, format as <svg>.... </svg>",
    "No matching icons found": "No matching icons found",
    "Custom Commands": "Custom Commands",
    "Toolbar Commands": "Toolbar Commands",
    ID: "ID",
    Prefix: "Prefix",
    Suffix: "Suffix",
    Pattern: "Pattern",
    "Custom Format Commands": "Custom Format Commands",
    "Add, edit or delete custom format commands.":
      "Add, edit or delete custom format commands.",
    Edit: "Edit",
    "Command ID": "Command ID",
    'Unique identifier, no spaces, e.g.: "my-custom-format"':
      'Unique identifier, no spaces, e.g.: "my-custom-format"',
    "Displayed name in toolbar and menu": "Displayed name in toolbar and menu",
    "Add content before selected text": "Add content before selected text",
    "Add content after selected text": "Add content after selected text",
    "Character offset of cursor after formatting":
      "Character offset of cursor after formatting",
    "Line offset of cursor after formatting":
      "Line offset of cursor after formatting",
    "Whether to insert at the beginning of the next line":
      "Whether to insert at the beginning of the next line",
    "Command icon (click to select)": "Command icon (click to select)",
    "Choose Icon": "Choose Icon",
    Save: "Save",
    Cancel: "Cancel",
    "Edit Custom Command": "Edit Custom Command",
    "Add Custom Command": "Add Custom Command",
    "Command ID and command name cannot be empty":
      "Command ID and command name cannot be empty",
    "Command ID cannot contain spaces": "Command ID cannot contain spaces",
    'Command ID "${this.commandId}" already exists':
      'Command ID "${this.commandId}" already exists',
    "Cursor Position Offset": "Cursor Position Offset",
    "Line Offset": "Line Offset",
    "Line Head Format": "Line Head Format",
    Icon: "Icon",
    "Command Name": "Command Name",
    "Are you sure you want to restore all settings to default? This will lose all your custom configurations.":
      "Are you sure you want to restore all settings to default? This will lose all your custom configurations.",
    "Restore default": "Restore default",
    "Restore default settings": "Restore default settings",
    "🔄Restore default settings": "🔄Restore default settings",
    "🔧Data repair": "🔧Data repair",
    "Command IDs have been successfully repaired!":
      "Command IDs have been successfully repaired!",
    "No command IDs need to be repaired": "No command IDs need to be repaired",
    "Error repairing command IDs, please check the console for details":
      "Error repairing command IDs, please check the console for details",
    "Error restoring default settings, please check the console for details":
      "Error restoring default settings, please check the console for details",
    "Successfully restored default settings!":
      "Successfully restored default settings!",
    Close: "Close",
    Tips: "Tips",
    "This update changed the ID of some commands, please click this button to repair the commands to ensure the toolbar works properly":
      "This update changed the ID of some commands, please click this button to repair the commands to ensure the toolbar works properly",
    "Repair command ID": "Repair command ID",
    "This will reset all your custom configurations":
      "This will reset all your custom configurations",
    "Notice:": "Notice:",
    "This update rebuilds the entire code, reducing resource consumption":
      "This update rebuilds the entire code, reducing resource consumption",
    "Optimized mobile usage, added canvas support, and added custom commands":
      "Optimized mobile usage, added canvas support, and added custom commands",
    "⚠️This update is not compatible with 2.x version command ids, please click [Repair command] to be compatible":
      "⚠️This update is not compatible with 2.x version command ids, please click [Repair command] to be compatible",
    "⚠️If you want to restore the default settings, please click [Restore default settings]":
      "⚠️If you want to restore the default settings, please click [Restore default settings]",
    "Please execute a editingToolbar format command first, then enable the format brush":
      "Please execute a editingToolbar format command first, then enable the format brush",
    "Format brush ON! Select text to apply【":
      "Format brush ON! Select text to apply【",
    "】format":
      "】format\nClick the mouse middle or right key to close the formatting-brush",
    "Add to Toolbar": "Add to Toolbar",
    "This command is already in the toolbar.":
      "This command is already in the toolbar.",
    "Command added to toolbar": "Command added to toolbar",
    "Add this command to the toolbar.": "Add this command to the toolbar.",
    "Callout Type": "Callout Type",
    Title: "Title",
    "Optional, leave blank for default title":
      "Optional, leave blank for default title",
    "Input title": "Input title",
    "Collapse State": "Collapse State",
    Open: "Open",
    Closed: "Closed",
    Content: "Content",
    Insert: "Insert",
    Default: "Default",
    "Input content": "Input content",
    "Link Text": "Link Text",
    "Link Alias": "Link Alias",
    "Link URL": "Link URL",
    "Embed Content": "Embed Content",
    "Image Size": "Image Size",
    "Insert New Line": "Insert New Line",
    "Paste and Parse": "Paste and Parse",
    "URL Format Error": "URL Format Error",
    "Image Width": "Image Width",
    "Image Height": "Image Height",
    "If it is an image, turn on": "If it is an image, turn on",
    "Insert a link on the next line": "Insert a link on the next line",
    "Link Title(optional)": "Link Title(optional)",
    Alias: "Alias",
    Optional: "Optional",
    "Default 0, format will keep the text selected":
      "Default 0, format will keep the text selected",
    "to insert": "to insert",
    "Latest Changes": "Latest Changes",
    "📋View full changelog": "📋View full changelog",
    "Open changelog": "Open changelog",
    "Loading changelog...": "Loading changelog...",
    "Open the complete changelog in your browser":
      "Open the complete changelog in your browser",
    "Enable Multiple Configurations": "Enable Multiple Configurations",
    "Enable different command configurations for each position style (following, top, fixed).":
      "Enable different command configurations for each position style (following, top, fixed).",
    "Currently editing commands for": "Currently editing commands for",
    "position style": "position style",
    "Current Configuration": "Current Configuration",
    "Switch between different command configurations.":
      "Switch between different command configurations.",
    "Following Style": "Following Style",
    "Top Style": "Top Style",
    "Fixed Style": "Fixed Style",
    "Mobile Style": "Mobile Style",
    configuration: "configuration",
    "Deploy command to configurations": "Deploy command to configurations",
    "All Configurations": "All Configurations",
    Deploy: "Deploy",
    "Command deployed to selected configurations":
      "Command deployed to selected configurations",
    "No configuration selected for deployment":
      "No configuration selected for deployment",
    "Command already exists in selected configurations":
      "Command already exists in selected configurations",
    "Command deployed to: ": "Command deployed to: ",
    "Command Deleted.": "Command Deleted.",
    "Confirm Delete?": "Confirm Delete?",
    Confirm: "Confirm",
    "Are you sure you want to restore all settings to default? But custom commands will be preserved.":
      "Are you sure you want to restore all settings to default? But custom commands will be preserved.",
    "Successfully restored default settings! (Custom commands preserved)":
      "Successfully restored default settings! (Custom commands preserved)",
    "This will reset all your custom configurations, but custom commands will be preserved":
      "This will reset all your custom configurations, but custom commands will be preserved",
    "Import/Export": "Import/Export",
    "Export Configuration": "Export Configuration",
    "Export your toolbar configuration to share with others.":
      "Export your toolbar configuration to share with others.",
    Export: "Export",
    "Import Configuration": "Import Configuration",
    "Import toolbar configuration from JSON.":
      "Import toolbar configuration from JSON.",
    Import: "Import",
    "Usage Instructions": "Usage Instructions",
    "Export: Generate a JSON configuration that you can save or share.":
      "Export: Generate a JSON configuration that you can save or share.",
    "Import: Paste a previously exported JSON configuration.":
      "Import: Paste a previously exported JSON configuration.",
    "You can choose to export all settings, only toolbar commands, or only custom commands":
      "You can choose to export all settings, only toolbar commands, or only custom commands",
    "When importing, the plugin will only update the settings included in the import data":
      "When importing, the plugin will only update the settings included in the import data",
    "Warning: Importing configuration will overwrite your current settings. Consider exporting your current configuration first as a backup.":
      "Warning: Importing configuration will overwrite your current settings. Consider exporting your current configuration first as a backup.",
    "Export Type": "Export Type",
    "Choose what to export": "Choose what to export",
    "All Settings": "All Settings",
    "Toolbar Commands Only": "Toolbar Commands Only",
    "Custom Commands Only": "Custom Commands Only",
    "Export Content": "Export Content",
    "Copy this content to share with others":
      "Copy this content to share with others",
    "Loading...": "Loading...",
    "Copy to Clipboard": "Copy to Clipboard",
    "Configuration copied to clipboard": "Configuration copied to clipboard",
    "Failed to copy configuration": "Failed to copy configuration",
    "Paste the configuration JSON here": "Paste the configuration JSON here",
    "Paste configuration here...": "Paste configuration here...",
    "Invalid import data": "Invalid import data",
    "Configuration imported successfully":
      "Configuration imported successfully",
    "No valid configuration found in import data":
      "No valid configuration found in import data",
    "Failed to import configuration. Invalid format.":
      "Failed to import configuration. Invalid format.",
    "Import Mode": "Import Mode",
    "Choose how to import the configuration":
      "Choose how to import the configuration",
    "Update Mode (Add new items and update existing ones)":
      "Update Mode (Add new items and update existing ones)",
    "Overwrite Mode (Replace all settings with imported ones)":
      "Overwrite Mode (Replace all settings with imported ones)",
    "Configuration imported successfully (Overwrite mode)":
      "Configuration imported successfully (Overwrite mode)",
    "Configuration imported successfully (Update mode)":
      "Configuration imported successfully (Update mode)",
    "Warning: Overwrite mode will completely replace your current settings with the imported ones. Consider exporting your current configuration first as a backup.":
      "Warning: Overwrite mode will completely replace your current settings with the imported ones. Consider exporting your current configuration first as a backup.",
    "Warning: Update mode will add new items and update existing ones based on the imported configuration.":
      "Warning: Update mode will add new items and update existing ones based on the imported configuration.",
    "Add Format Command": "Add Format Command",
    Regex: "Regex",
    "Prefix/Suffix": "Prefix/Suffix",
    "Insert Special Char": "Insert Special Char",
    "Add Regex Command": "Add Regex Command",
    "Switch Regex Command Window": "Switch Regex Command Window",
    "Please select text first": "Please select text first",
    "The selected text does not meet the condition requirements":
      "The selected text does not meet the condition requirements",
    "Regex command execution error: ": "Regex command execution error: ",
    "Copy code": "Copy code",
    "Copied!": "Copied!",
    "Explain the syntax of JavaScript regular expressions":
      "Explain the syntax of JavaScript regular expressions",
    "Apply regular expression replacement":
      "Apply regular expression replacement",
    "Conditional matching": "Conditional matching",
    "Complete regular expression code (copy to AI for explanation)":
      "Complete regular expression code (copy to AI for explanation)",
    "Error: ": "Error: ",
    "Regex pattern cannot be empty": "Regex pattern cannot be empty",
    "Command already exists": "Command already exists",
    "Choose icon": "Choose icon",
    "URL to Markdown link": "URL to Markdown link",
    "Convert MM/DD/YYYY to YYYY-MM-DD": "Convert MM/DD/YYYY to YYYY-MM-DD",
    "Add bold to keywords": "Add bold to keywords",
    "Format phone number": "Format phone number",
    "Remove extra spaces": "Remove extra spaces",
    "Convert HTML bold tags to Markdown format":
      "Convert HTML bold tags to Markdown format",
    "Convert quoted text to quote block": "Convert quoted text to quote block",
    "Convert CSV to Markdown table row": "Convert CSV to Markdown table row",
    "Add uniform alias to Markdown links":
      "Add uniform alias to Markdown links",
    "Delete empty lines (multiline mode)":
      "Delete empty lines (multiline mode)",
    "Add list symbol to each line (multiline mode)":
      "Add list symbol to each line (multiline mode)",
    "If the text contains important, set the text highlight (conditional format)":
      "If the text contains important, set the text highlight (conditional format)",
    "Matching pattern": "Matching pattern",
    "Regex pattern to match": "Regex pattern to match",
    "Replacement pattern (use $1, $2, etc. to reference capture groups)":
      "Replacement pattern (use $1, $2, etc. to reference capture groups)",
    "Ignore case": "Ignore case",
    "Global replace": "Global replace",
    "Multiline mode": "Multiline mode",
    "Use condition": "Use condition",
    "Condition pattern": "Condition pattern",
    "Only apply custom command when text matches the condition":
      "Only apply custom command when text matches the condition",
    "Must exist regular expression or text":
      "Must exist regular expression or text",
    "Replacement pattern": "Replacement pattern",
    "Match case-insensitive": "Match case-insensitive",
    "^ and $ match the start and end of each line":
      "^ and $ match the start and end of each line",
    "Replace all matches": "Replace all matches",
    Command: "Command",
    "Input example text to view the formatting effect of the command...":
      "Input example text to view the formatting effect of the command...",
    Description: "Description",
    "[Example]": "[Example]",
    "[Requirements]": "[Requirements]",
    "[Output]": "[Output]",
    "AI question template:": "AI question template:",
    "I need to convert the url to a markdown format link":
      "I need to convert the url to a markdown format link",
    "For example, convert https://example.com to [https://example.com](https://example.com)":
      "For example, convert https://example.com to [https://example.com](https://example.com)",
    "Use js regular expression to implement, and output the parameters in the following format (the result does not need to be escaped with json)":
      "Use js regular expression to implement, and output the parameters in the following format (the result does not need to be escaped with json)",
    "[Description]": "[Description]",
    "How to use AI to get regular expressions?":
      "How to use AI to get regular expressions?",
    "Regular expression examples": "Regular expression examples",
    "Edit regular expression command": "Edit regular expression command",
    "Add regular expression command": "Add regular expression command",
    "Result: ": "Result: ",
    "Example text:": "Example text:",
    Preview: "Preview",
    Result: "Result",
    "Please select text or copy text to clipboard first":
      "Please select text or copy text to clipboard first",
    "Overwrite Import": "Overwrite Import",
    "Update Import": "Update Import",
    "Importing configuration...": "Importing configuration...",
    "Following Style Only": "Following Style Only",
    "Top Style Only": "Top Style Only",
    "Fixed Style Only": "Fixed Style Only",
    "Mobile Style Only": "Mobile Style Only",
    "Unknown import type": "Unknown import type",
    "All Toolbar Commands": "All Toolbar Commands",
    "Initialize Commands": "Initialize Commands",
    "Copy commands from the main menu configuration":
      "Copy commands from the main menu configuration",
    "Initialize commands to default settings":
      "Initialize commands to default settings",
    "Reset Commands": "Reset Commands",
    "Commands reset successfully": "Commands reset successfully",
    "Following style commands initialized from current menu commands":
      "Following style commands initialized from current menu commands",
    "Commands initialized successfully": "Commands initialized successfully",
    "Reset to Menu Commands": "Reset to Menu Commands",
    "Are you sure you want to reset the current configuration?":
      "Are you sure you want to reset the current configuration?",
    "Following style commands successfully initialized":
      "Following style commands successfully initialized",
    "Top style commands successfully initialized":
      "Top style commands successfully initialized",
    "Fixed style commands successfully initialized":
      "Fixed style commands successfully initialized",
    "Mobile style commands successfully initialized":
      "Mobile style commands successfully initialized",
    "Reset commands to default settings": "Reset commands to default settings",
    Clear: "Clear",
    "Remove all commands from this configuration.":
      "Remove all commands from this configuration.",
    "Are you sure you want to clear all commands under the current style?":
      "Are you sure you want to clear all commands under the current style?",
    "Current style commands have been cleared":
      "Current style commands have been cleared",
    "Manage Commands": "Manage Commands",
    "Reset or clear all commands in this configuration":
      "Reset or clear all commands in this configuration",
    "One-click Clear": "One-click Clear",
    "Import Commands from Other Styles": "Import Commands from Other Styles",
    "Copy commands from another style configuration.":
      "Copy commands from another style configuration.",
    "Main menu only": "Main menu only",
    "This import will update:": "This import will update:",
    "Custom commands": "Custom commands",
    "Toolbar commands": "Toolbar commands",
    "General settings": "General settings",
    "Please paste configuration data first":
      "Please paste configuration data first",
    "Invalid import data format": "Invalid import data format",
    "Import From": "Import From",
    "This import will:": "This import will:",
    "Update general settings": "Update general settings",
    "Update Main Menu Commands": "Update Main Menu Commands",
    "Update Custom Commands": "Update Custom Commands",
    "Update Following Style Commands": "Update Following Style Commands",
    "Update Top Style Commands": "Update Top Style Commands",
    "Update Fixed Style Commands": "Update Fixed Style Commands",
    "Update Mobile Style Commands": "Update Mobile Style Commands",
    "Clear all Main Menu Commands": "Clear all Main Menu Commands",
    "Clear all Custom Commands": "Clear all Custom Commands",
    "Clear all Following Style Commands": "Clear all Following Style Commands",
    "Clear all Top Style Commands": "Clear all Top Style Commands",
    "Clear all Fixed Style Commands": "Clear all Fixed Style Commands",
    "Clear all Mobile Style Commands": "Clear all Mobile Style Commands",
    "Overwrite Mode (Replace settings with imported ones)":
      "Overwrite Mode (Replace settings with imported ones)",
    "Warning: Overwrite mode will replace existing settings with imported ones.":
      "Warning: Overwrite mode will replace existing settings with imported ones.",
    "Warning: Update mode will add new items and update existing ones.":
      "Warning: Update mode will add new items and update existing ones.",
    "Enable Multiple Config": "Enable Multiple Config",
    "Set Multiple Config to:": "Set Multiple Config to:",
    Enable: "Enable",
    Disable: "Disable",
    "Set Position Style to:": "Set Position Style to:",
    Following: "Following",
    Top: "Top",
    Fixed: "Fixed",
    Mobile: "Mobile",
    "All commands": "All commands",
    "⚠️ Overwrite mode will replace existing settings with imported ones.":
      "⚠️ Overwrite mode will replace existing settings with imported ones.",
    "ℹ️ Update mode will merge imported settings with existing ones.":
      "ℹ️ Update mode will merge imported settings with existing ones.",
    "Do you want to continue?": "Do you want to continue?",
    "Imported settings:": "Imported settings:",
    "Imported commands:": "Imported commands:",
    "Disable toolbar for this view": "Disable toolbar for this view",
    "Enable toolbar for this view": "Enable toolbar for this view",
    "Manage all view types": "Manage all view types",
    "Current View: ": "Current View: ",
    "Appearance Style": "Appearance Style",
    "Position Settings": "Position Settings",
    "All commands have been removed.": "All commands have been removed.",
    "Join the Community": "Join the Community",
    "Share your toolbar settings and styles in our":
      "Share your toolbar settings and styles in our",
    "Get inspired by what others have created or showcase your own customizations.":
      "Get inspired by what others have created or showcase your own customisations.",
    "Toolbar Preview (With a hypothetical command configuration.)":
      "Toolbar Preview (With a hypothetical command configuration.)",
    "Toolbar Theme": "Toolbar Theme",
    "Select a preset toolbar theme, automatically setting the background color, icon color, and size for the selected style.":
      "Select a preset toolbar theme, automatically setting the background colour, icon colour, and size for the selected style.",
    "Toolbar Background Color": "Toolbar Background Colour",
    "Set the background color of the toolbar.":
      "Set the background colour of the toolbar.",
    "Toolbar Icon Color": "Toolbar Icon Colour",
    "Set the color of the toolbar icon.": "Set the colour of the toolbar icon.",
    "Toolbar Icon Size": "Toolbar Icon Size",
    "Set the size of the toolbar icon (px); default: 18px":
      "Set the size of the toolbar icon (px); default: 18px",
    "Custom Theme": "Custom Theme",
    "Fixed Position Offset": "Fixed Position Offset",
    "Choose the offset of the Toolbar in the fixed position.":
      "Choose the offset of the Toolbar in the fixed position.",
    "Renumber List": "Renumber List",
    "Fetch Remote Title": "Fetch Remote Title",
    "Please enter a URL first": "Please enter a URL first",
    "Failed to fetch title for": "Failed to fetch title for",
    "Link Title (optional)": "Link Title (optional)",
    "Unable to detect editor width": "Unable to detect editor width",
    "Fit Editor Width": "Fit Editor Width",
    "Please execute a format command or select format text first, then enable the format brush":
      "Please execute a format command or select format text first, then enable the format brush",
    "Use \\n to represent line breaks": "Use \\n to represent line breaks",
    "Use ↵ to represent line breaks": "Use ↵ to represent line breaks",
    "Top Toolbar": "Top Toolbar",
    "Enable the toolbar positioned at the top.":
      "Enable the toolbar positioned at the top.",
    "Following Toolbar": "Following Toolbar",
    "Enable the toolbar that appears upon text selection.":
      "Enable the toolbar that appears upon text selection.",
    "Fixed Toolbar": "Fixed Toolbar",
    "Enable the toolbar whose position may be fixed where you please.":
      "Enable the toolbar whose position may be fixed where you please.",
    "Toolbar Settings": "Toolbar Settings",
    "Choose which toolbar style's appearance you want to edit.":
      "Choose which toolbar style's appearance you want to edit.",
    "Vertical Split": "Vertical Split",
  },
  es: {},
  fr: {},
  hi: {},
  id: {},
  it: {},
  ja: {},
  ko: {},
  nl: {},
  nn: {},
  pl: {},
  pt: {},
  "pt-br": {
    "Toolbar Append Method": "Método de Inserção da Barra de Ferramentas",
    "Choose where Toolbar will append upon regeneration. To see the change, hit the refresh button below, or in the status bar menu.":
      "Escolha onde a Barra de Ferramentas será inserida ao regenerar. Para ver a alteração, clique no botão de atualização abaixo, ou no menu da barra de status.",
    "Toolbar aesthetic": "Estilo da Barra de Ferramentas",
    "Choose between a glass morphism, tiny and default style for Toolbar. To see the change, hit the refresh button below, or in the status bar menu.":
      "Escolha entre um estilo de vidro, pequeno e padrão para a Barra de Ferramentas. Para ver a alteração, clique no botão de atualização abaixo, ou no menu da barra de status.",
    "Toolbar position": "Posição da Barra de Ferramentas",
    "Choose between fixed position or cursor following mode.":
      "Escolha entre posição fixa ou modo contextual.",
    "Toolbar Columns": "Colunas da Barra de Ferramentas",
    "Choose the number of columns per row to display on Toolbar.":
      "Escolha o número de colunas por linha para exibir na Barra de Ferramentas.",
    "Toolbar refresh": "Atualizar Barra de Ferramentas",
    "Toolbar Commands": "Comandos da Barra de Ferramentas",
    "Add a command onto Toolbar from Obsidian's commands library. To reorder the commands, drag and drop the command items. To delete them, use the delete buttom to the right of the command item. Toolbar will not automaticaly refresh after reordering commands. Use the refresh button above.":
      "Adicione um comando na Barra de Ferramentas a partir da biblioteca de comandos do Obsidian. Para reordenar os comandos, arraste e solte os itens do comando. Para deletar, use o botão de deletar à direita do item do comando. A Barra de Ferramentas não atualizará automaticamente após reordenar os comandos. Use o botão de atualização acima.",
    "Format Brush Off!": "Pincel de formatação desligado!",
    "Hide & Show": "Ocultar & Mostrar",
    "Toolbar will only refresh automatically after you have either added or deleted a command from it. To see UI changes to editingToolbar (above settings changes) use the refresh button. If you forget to refresh in settings, no worries. There is also a refresh button in the editingToolbar status bar menu.":
      "A barra de edição só atualizará automaticamente após você ter adicionado ou deletado um comando dela. Para ver as alterações na interface do editingToolbar (alterações acima das configurações) use o botão de atualização. Se você esquecer de atualizar nas configurações, não se preocupe. Também há um botão de atualização na barra de status da Barra de Edição.",
    "Font-Color formatting brush ON!": "Pincel de cor da fonte ativado!",
    More: "Mais",
    "Font Colors": "Cores de Texto",
    "Format Brush": "Pincel de formatação",
    "Background Color": "Cor de Fundo",
    Refresh: "Atualizar",
    Add: "Adicionar",
    Delete: "Deletar",
    "Change Command Name": "Alterar Nome do Comando",
    "Add Submenu": "Adicionar Submenu",
    "Add Separator": "Adicionar Separador",
    "Enter the icon code, it looks like <svg>.... </svg> format":
      "Digite o código do ícone, parece com o formato <svg>.... </svg>",
    "Please enter a new name: ": "Por favor, digite um novo nome: ",
    "Drag the slider to move the position":
      "Arraste o slider para mover a posição",
    "Plugin Settings": "Configurações do Plugin",
    "Background-color formatting brush ON!":
      "Pincel de cor de fundo ativado!\nClique com o botão do meio ou direito do mouse para sair do modo.",
    "Clear formatting brush ON!": "Pincel de formatação ativado!",
    "Clear formatting brush ON!\nClick the mouse middle or right key to close the formatting-brush":
      "Pincel de formatação ativado!\nClique com o botão do meio ou direito do mouse para sair do modo de formatação.",
    "The toolbar is displayed when the mouse moves over it, otherwise it is automatically hidden":
      "A barra de ferramentas é exibida quando o mouse passa por cima dela, caso contrário, ela é automaticamente oculta.",
    "Toolbar Auto-hide": "Auto-ocultação da Barra de Ferramentas",
    "Toolbar Centred Display": "Exibição Centralizada da Barra de Ferramentas",
    "Whether the toolbar is centred or full-width, the default is full-width.":
      "Define se a barra de ferramentas é centralizada ou ocupa toda a largura. O padrão é largura completa.",
    "Custom Backgroud Color": "Cor de Fundo Personalizada",
    "Custom Font Color": "Cor de Texto Personalizada",
    "🎨 Set Custom Background": "🎨 Definir Cor de Fundo Personalizada",
    "🖌️ Set Custom Font Color": "🖌️ Definir Cor de Texto Personalizada",
    "Click on the picker to adjust the color":
      "Clique no seletor para ajustar a cor",
    "Mobile Enabled or Not": "Habilitar em dispositivos móveis",
    "Whether to enable the plugin for the mobile client, the default is enabled.":
      "Habilitar o plugin para dispositivos móveis, o padrão é habilitado.",
    "Whether to enable on mobile devices with device width less than 768px.":
      "Habilitar o plugin para dispositivos móveis com largura de dispositivo menor que 768px, o padrão é desabilitado.",
    Reset: "Reiniciar",
    Fix: "Ajustar",
    "Fix Toolbar": "Ajustar Barra de Ferramentas",
    General: "Geral",
    Appearance: "Aparência",
    Commands: "Comandos",
    "Choose between fixed position or cursor following mode":
      "Escolha entre posição fixa ou modo contextual.",
    "Add and manage commands": "Adicionar e gerenciar comandos",
    "Choose where Toolbar will append upon regeneration.":
      "Escolha onde a Barra de Ferramentas será inserida ao regenerar.",
    "Whether to enable on mobile devices with device width less than 768px":
      "Habilitar o plugin para dispositivos móveis com largura de dispositivo menor que 768px",
    "Choose between a glass morphism, tiny and default style.":
      "Escolha entre um estilo de vidro, pequeno e padrão.",
    "Refresh Toolbar": "Atualizar Barra de Ferramentas",
    "Add Command": "Adicionar Comando",
    Settings: "Configurações",
    "Position Style": "Estilo de Posição",
    Columns: "Colunas",
    "Drag to Adjust Position": "Arraste para ajustar a posição",
    "Vertical Position": "Posição Vertical",
    "Horizontal Position": "Posição Horizontal",
    "Toolbar Position": "Posição da Barra de Ferramentas",
    "Choose an icon": "Escolha um ícone",
    "Search for an icon...": "Pesquisar por um ícone...",
    All: "Todos",
    Obsidian: "Obsidian",
    Glyph: "Ícone",
    Custom: "Personalizado",
    "Choose a command": "Escolha um comando",
    "The command": "O comando",
    "already exists": "já existe",
    "Enter the icon code, format as <svg>.... </svg>":
      "Digite o código do ícone, formato como <svg>.... </svg>",
    "No matching icons found": "Nenhum ícone correspondente encontrado",
    "Custom Commands": "Comandos Personalizados",
    "Toolbar Commands": "Comandos da Barra de Ferramentas",
    ID: "ID",
    Prefix: "Prefixo",
    Suffix: "Sufixo",
    Pattern: "Padrão",
    "Custom Format Commands": "Comandos de Formatação Personalizados",
    "Add, edit or delete custom format commands.":
      "Adicionar, editar ou deletar comandos de formatação personalizados.",
    Edit: "Editar",
    "Command ID": "ID do Comando",
    'Unique identifier, no spaces, e.g.: "my-custom-format"':
      'Identificador único, sem espaços, exemplo: "meu-comando-personalizado"',
    "Displayed name in toolbar and menu":
      "Nome exibido na barra de ferramentas e menu",
    "Add content before selected text":
      "Adicionar conteúdo antes do texto selecionado",
    "Add content after selected text":
      "Adicionar conteúdo depois do texto selecionado",
    "Character offset of cursor after formatting":
      "Deslocamento do cursor após a formatação",
    "Line offset of cursor after formatting":
      "Deslocamento da linha do cursor após a formatação",
    "Whether to insert at the beginning of the next line":
      "Inserir no início da próxima linha",
    "Command icon (click to select)":
      "Ícone do comando (clique para selecionar)",
    "Choose Icon": "Escolha um ícone",
    Save: "Salvar",
    Cancel: "Cancelar",
    "Edit Custom Command": "Editar Comando Personalizado",
    "Add Custom Command": "Adicionar Comando Personalizado",
    "Command ID and command name cannot be empty":
      "ID do Comando e nome do comando não podem ser vazios",
    "Command ID cannot contain spaces": "ID do Comando não pode conter espaços",
    'Command ID "${this.commandId}" already exists':
      'ID do Comando "${this.commandId}" já existe',
    "Cursor Position Offset": "Deslocamento do cursor",
    "Line Offset": "Deslocamento da linha",
    "Line Head Format": "Formatação de linha inicial",
    Icon: "Ícone",
    "Command Name": "Nome do Comando",
    "Are you sure you want to restore all settings to default? This will lose all your custom configurations.":
      "Tem certeza que deseja restaurar todas as configurações para a configuração padrão? Isso irá apagar todas as suas configurações personalizadas.",
    "Restore default": "Restaurar padrão",
    "Restore default settings": "Restaurar configurações padrão",
    "🔄Restore default settings": "🔄Restaurar configurações padrão",
    "🔧Data repair": "🔧Reparar dados",
    "Command IDs have been successfully repaired!":
      "IDs de comando foram reparadas com sucesso!",
    "No command IDs need to be repaired":
      "Nenhuma ID de comando precisa ser reparada",
    "Error repairing command IDs, please check the console for details":
      "Erro ao reparar IDs de comando, por favor verifique o console para mais detalhes",
    "Error restoring default settings, please check the console for details":
      "Erro ao restaurar configurações padrão, por favor verifique o console para mais detalhes",
    "Successfully restored default settings!":
      "Configurações padrão restauradas com sucesso!",
    Close: "Fechar",
    Tips: "Dicas",
    "This update changed the ID of some commands, please click this button to repair the commands to ensure the toolbar works properly":
      "Esta atualização alterou o ID de alguns comandos. Clique neste botão para repará-los e garantir que a barra de ferramentas funcione corretamente.",
    "Repair command ID": "Reparar ID do Comando",
    "This will reset all your custom configurations":
      "Isso irá resetar todas as suas configurações personalizadas",
    "Notice:": "Nota:",
    "This update rebuilds the entire code, reducing resource consumption":
      "Esta atualização recompila todo o código, reduzindo o consumo de recursos",
    "Optimized mobile usage, added canvas support, and added custom commands":
      "Otimizado para uso em dispositivos móveis, adicionando suporte para o canvas e adicionado comandos personalizados",
    "⚠️This update is not compatible with 2.x version command ids, please click [Repair command] to be compatible":
      "⚠️Esta atualização não é compatível com IDs de comando da versão 2.x. Clique em [Reparar comando] para corrigir a compatibilidade.",
    "⚠️If you want to restore the default settings, please click [Restore default settings]":
      "⚠️Se você quiser restaurar as configurações padrão, por favor clique em [Restaurar configurações padrão].",
    "Please execute a editingToolbar format command first, then enable the format brush":
      "Execute um comando de formatação da barra de edição antes de ativar o pincel de formatação.",
    "Format brush ON! Select text to apply【":
      "Pincel de formatação ativado! Selecione o texto para aplicar【",
    "】format":
      "】\nClique com o botão do meio ou direito do mouse para sair do modo de formatação.",
    "Add to Toolbar": "Adicionar à Barra de Edição",
    "This command is already in the toolbar.":
      "Este comando já está na barra de ferramentas.",
    "Command added to toolbar": "Comando adicionado à barra de ferramentas",
    "Add this command to the toolbar.":
      "Adicionar este comando à barra de ferramentas.",
    "Callout Type": "Tipo de Callout",
    Title: "Título",
    "Optional, leave blank for default title":
      "Opcional, deixe em branco para o título padrão",
    "Input title": "Digite o título",
    "Collapse State": "Estado de Colapso",
    Open: "Abrir",
    Closed: "Fechado",
    Content: "Conteúdo",
    Insert: "Inserir",
    Default: "Padrão",
    "Input content": "Digite o conteúdo",
    "Link Text": "Texto do Link",
    "Link Alias": "Alias do Link",
    "Link URL": "URL do Link",
    "Embed Content": "Conteúdo Embutido",
    "Image Size": "Tamanho da Imagem",
    "Insert New Line": "Inserir Nova Linha",
    "Paste and Parse": "Colar e Analisar",
    "URL Format Error": "Erro de Formato de URL",
    "Image Width": "Largura da Imagem",
    "Image Height": "Altura da Imagem",
    "If it is an image, turn on": "Se for uma imagem, ative",
    "Insert a link on the next line": "Inserir um link na próxima linha",
    "Link Title(optional)": "Título do Link(opcional)",
    Alias: "Alias",
    Optional: "Opcional",
    "Default 0, format will keep the text selected":
      "Padrão 0, o formato manterá o texto selecionado",
    "to insert": "para inserir",
    "Latest Changes": "Últimas Alterações",
    "📋View full changelog": "📋Ver o registro de alterações completo",
    "Open changelog": "Abrir registro de alterações",
    "Loading changelog...": "Carregando registro de alterações...",
    "Open the complete changelog in your browser":
      "Abrir o registro de alterações completo no seu navegador",
    "Enable Multiple Configurations": "Habilitar Múltiplas Configurações",
    "Enable different command configurations for each position style (following, top, fixed).":
      "Habilitar configurações de comandos diferentes para cada modo de posição (following, top, fixed).",
    "Currently editing commands for": "Atualmente editando comandos para",
    "position style": "estilo de posição",
    "Current Configuration": "Configuração Atual",
    "Switch between different command configurations.":
      "Trocar entre configurações de comando diferentes.",
    "Following Style": "Estilo Contextual",
    "Top Style": "Estilo de Topo",
    "Fixed Style": "Estilo Fixo",
    "Mobile Style": "Estilo Mobile",
    configuration: "configuração",
    "Deploy command to configurations": "Implantar comando para configurações",
    "All Configurations": "Todas as Configurações",
    Deploy: "Implantar",
    "Command deployed to selected configurations":
      "Comando implantado para configurações selecionadas",
    "No configuration selected for deployment":
      "Nenhuma configuração selecionada para implantação",
    "Command already exists in selected configurations":
      "Comando já existe nas configurações selecionadas",
    "Command deployed to: ": "Comando implantado para: ",
    "Command Deleted": "Comando Deletado",
    "Confirm Delete?": "Confirmar Deleção?",
    Confirm: "Confirmar",
    "Are you sure you want to restore all settings to default? But custom commands will be preserved.":
      "Tem certeza que deseja restaurar todas as configurações para a configuração padrão? Mas os comandos personalizados serão preservados.",
    "Successfully restored default settings! (Custom commands preserved)":
      "Configurações padrão restauradas com sucesso! (Comandos personalizados preservados)",
    "This will reset all your custom configurations, but custom commands will be preserved":
      "Isso redefinirá todas as suas configurações personalizadas, mas os comandos personalizados serão preservados.",
    "Import/Export": "Importar/Exportar",
    "Export Configuration": "Exportar Configuração",
    "Export your toolbar configuration to share with others.":
      "Exportar sua configuração da barra de ferramentas para compartilhar com outros.",
    Export: "Exportar",
    "Import Configuration": "Configuração de Importação",
    "Import toolbar configuration from JSON.":
      "Importar configuração da barra de ferramentas em formato JSON.",
    Import: "Importar",
    "Usage Instructions": "Instruções de Uso",
    "Export: Generate a JSON configuration that you can save or share.":
      "Exportar: Gerar uma configuração em formato JSON para salvar ou compartilhar.",
    "Import: Paste a previously exported JSON configuration.":
      "Importar: Colar uma configuração em formato JSON exportada anteriormente.",
    "You can choose to export all settings, only toolbar commands, or only custom commands":
      "Você pode escolher exportar todas as configurações, apenas comandos da barra de ferramentas, ou apenas comandos personalizados",
    "When importing, the plugin will only update the settings included in the import data":
      "Ao importar, o plugin irá atualizar apenas as configurações incluídas nos dados de importação",
    "Warning: Importing configuration will overwrite your current settings. Consider exporting your current configuration first as a backup.":
      "Aviso: A importação de configuração irá sobrescrever suas configurações atuais. Considere exportar sua configuração atual primeiro como backup.",
    "Export Type": "Tipo de Exportação",
    "Choose what to export": "Escolha o que exportar",
    "All Settings": "Todas as Configurações",
    "Toolbar Commands Only": "Apenas Comandos da Barra de Ferramentas",
    "Custom Commands Only": "Apenas Comandos Personalizados",
    "Export Content": "Conteúdo de Exportação",
    "Copy this content to share with others":
      "Copiar este conteúdo para compartilhar com outros",
    "Loading...": "Carregando...",
    "Copy to Clipboard": "Copiar para a área de transferência",
    "Configuration copied to clipboard":
      "Configuração copiada para a área de transferência",
    "Failed to copy configuration": "Falha ao copiar configuração",
    "Paste the configuration JSON here": "Colar a configuração JSON aqui",
    "Paste configuration here...": "Colar configuração aqui...",
    "Invalid import data": "Dados de importação inválidos",
    "Configuration imported successfully": "Configuração importada com sucesso",
    "No valid configuration found in import data":
      "Nenhuma configuração válida encontrada nos dados de importação",
    "Failed to import configuration. Invalid format.":
      "Falha ao importar configuração. Formato inválido.",
    "Import Mode": "Modo de Importação",
    "Choose how to import the configuration":
      "Escolha como importar a configuração",
    "Update Mode (Add new items and update existing ones)":
      "Modo de Atualização (Adicionar novos itens e atualizar os existentes)",
    "Overwrite Mode (Replace all settings with imported ones)":
      "Modo de Sobrescrever (Substituir todas as configurações com as importadas)",
    "Configuration imported successfully (Overwrite mode)":
      "Configuração importada com sucesso (Modo de Sobrescrever)",
    "Configuration imported successfully (Update mode)":
      "Configuração importada com sucesso (Modo de Atualização)",
    "Warning: Overwrite mode will completely replace your current settings with the imported ones. Consider exporting your current configuration first as a backup.":
      "Aviso: O modo de sobrescrever irá substituir todas as suas configurações atuais com as importadas. Considere exportar sua configuração atual primeiro como backup.",
    "Warning: Update mode will add new items and update existing ones based on the imported configuration.":
      "Aviso: O modo de atualização irá adicionar novos itens e atualizar os existentes com base na configuração importada.",
    "Add Format Command": "Adicionar formatação",
    Regex: "Regex",
    "Prefix/Suffix": "Prefixo/Sufixo",
    "Insert Special Char": "Inserir Caractere Especial",
    "Add Regex Command": "Adicionar regex",
    "Switch Regex Command Window": "Trocar para Janela de Comando de Regex",
    "Please select text first": "Por favor selecione o texto primeiro",
    "Current line is empty, please select text or move to a non-empty line":
      "A linha atual está vazia, por favor selecione o texto ou mova para uma linha não vazia",
    "Use current line for regex commands":
      "Usar a linha atual para comandos de regex",
    "When no text is selected, regex commands will use the current line instead of clipboard content":
      "Quando não houver texto selecionado, comandos de regex usarão a linha atual em vez do conteúdo da área de transferência",
    "The selected text does not meet the condition requirements":
      "O texto selecionado não atende aos requisitos da condição",
    "Regex command execution error: ": "Erro ao executar comando de regex: ",
    "Copy code": "Copiar código",
    "Copied!": "Copiado!",
    "Explain the syntax of JavaScript regular expressions":
      "Explicar a sintaxe das expressões regulares em JavaScript",
    "Apply regular expression replacement":
      "Aplicar substituição de expressão regular",
    "Conditional matching": "Ocorrência Condicional",
    "Complete regular expression code (copy to AI for explanation)":
      "Código de expressão regular completo (copiar para explicação com IA)",
    "Error: ": "Erro: ",
    "Regex pattern cannot be empty": "Padrão de regex não pode estar vazio",
    "Command already exists": "Comando já existe",
    "Choose icon": "Escolha um ícone",
    "URL to Markdown link": "URL para Link Markdown",
    "Convert MM/DD/YYYY to YYYY-MM-DD": "Converter MM/DD/YYYY para YYYY-MM-DD",
    "Add bold to keywords": "Adicionar negrito a palavras-chave",
    "Format phone number": "Formatar número de telefone",
    "Remove extra spaces": "Remover espaços extra",
    "Convert HTML bold tags to Markdown format":
      "Converter tags HTML de negrito para negrito em Markdown",
    "Convert quoted text to quote block":
      "Converter texto citado para bloco de citação",
    "Convert CSV to Markdown table row":
      "Converter CSV para linha de tabela Markdown",
    "Add uniform alias to Markdown links":
      "Adicionar um alias uniforme aos links Markdown",
    "Delete empty lines (multiline mode)":
      "Deletar linhas vazias (modo multilinha)",
    "Add list symbol to each line (multiline mode)":
      "Adicionar símbolo de lista a cada linha (modo multilinha)",
    "If the text contains important, set the text highlight (conditional format)":
      'Se o texto contiver "importante", aplicar destaque ao texto (formatação condicional)',
    "Matching pattern": "Padrão de correspondência",
    "Regex pattern to match": "Padrão de regex a ser correspondido",
    "Replacement pattern (use $1, $2, etc. to reference capture groups)":
      "Padrão de substituição (use $1, $2, etc. para referenciar grupos de captura)",
    "Ignore case": "Ignorar maiúsculas e minúsculas",
    "Global replace": "Substituir globalmente",
    "Multiline mode": "Modo multilinha",
    "Use condition": "Usar condição",
    "Condition pattern": "Padrão de condição",
    "Only apply custom command when text matches the condition":
      "Aplicar o comando personalizado apenas quando o texto corresponder à condição",
    "Must exist regular expression or text":
      "Deve existir expressão regular ou texto",
    "Replacement pattern": "Padrão de substituição",
    "Match case-insensitive": "Ignorar maiúsculas e minúsculas",
    "^ and $ match the start and end of each line":
      "^ e $ correspondem ao início e ao fim de cada linha",
    "Replace all matches": "Substituir todas as ocorrências",
    Command: "Comando",
    "Input example text to view the formatting effect of the command...":
      "Digite um texto de exemplo para visualizar o efeito do comando...",
    Description: "Descrição",
    "[Example]": "[Exemplo]",
    "[Requirements]": "[Requisitos]",
    "[Output]": "[Saída]",
    "AI question template:": "Modelo de pergunta para IA:",
    "I need to convert the url to a markdown format link":
      "Preciso converter a URL para um link no formato Markdown",
    "For example, convert https://example.com to [https://example.com](https://example.com)":
      "Por exemplo, converter https://exemplo.com para [https://exemplo.com](https://exemplo.com)",
    "Use js regular expression to implement, and output the parameters in the following format (the result does not need to be escaped with json)":
      "Usar expressões regulares em JavaScript para implementar e gerar os parâmetros no formato abaixo (o resultado não precisa ser escapado em JSON).",
    "[Description]": "[Descrição]",
    "How to use AI to get regular expressions?":
      "Como usar IA para obter expressões regulares?",
    "Regular expression examples": "Exemplos de expressões regulares",
    "Edit regular expression command": "Editar comando de expressão regular",
    "Add regular expression command": "Adicionar comando de expressão regular",
    "Result: ": "Resultado: ",
    "Example text:": "Texto de exemplo:",
    Preview: "Visualizar",
    Result: "Resultado",
    "Please select text or copy text to clipboard first":
      "Por favor selecione o texto ou copie o texto para a área de transferência primeiro",
    "Overwrite Import": "Sobrescrever Importação",
    "Update Import": "Atualizar Importação",
    "Importing configuration...": "Importando configuração...",
    "Following Style Only": "Disponível apenas no modo contextual",
    "Top Style Only": "Disponível apenas no modo de topo",
    "Fixed Style Only": "Disponível apenas no modo fixo",
    "Mobile Style Only": "Disponível apenas no modo mobile",
    "Unknown import type": "Tipo de importação desconhecido",
    "All Toolbar Commands": "Todos os Comandos da Barra de Ferramentas",
    "Initialize Commands": "Inicializar Comandos",
    "Copy commands from the main menu configuration":
      "Copiar comandos do menu principal",
    "Initialize commands to default settings":
      "Inicializar comandos para configurações padrão",
    "Reset Commands": "Resetar Comandos",
    "Commands reset successfully": "Comandos resetados com sucesso",
    "Following style commands initialized from current menu commands":
      "Comandos de estilo contextual inicializados a partir dos comandos do menu principal",
    "Commands initialized successfully": "Comandos inicializados com sucesso",
    "Reset to Menu Commands": "Resetar para Comandos do Menu",
    "Are you sure you want to reset the current configuration?":
      "Tem certeza que deseja resetar a configuração atual?",
    "Following style commands successfully initialized":
      "Comandos de estilo contextual inicializados com sucesso",
    "Top style commands successfully initialized":
      "Comandos de estilo de topo inicializados com sucesso",
    "Fixed style commands successfully initialized":
      "Comandos de estilo fixo inicializados com sucesso",
    "Mobile style commands successfully initialized":
      "Comandos de estilo mobile inicializados com sucesso",
    "Reset commands to default settings":
      "Resetar comandos para configurações padrão",
    Clear: "Limpar",
    "Remove all commands from this configuration.":
      "Remover todos os comandos desta configuração.",
    "Are you sure you want to clear all commands under the current style?":
      "Tem certeza que deseja limpar todos os comandos sob o estilo atual?",
    "Current style commands have been cleared":
      "Comandos do estilo atual foram limpos",
    "Manage Commands": "Gerenciar Comandos",
    "Reset or clear all commands in this configuration":
      "Resetar ou limpar todos os comandos nesta configuração",
    "One-click Clear": "Limpar com um clique",
    "Import Commands from Other Styles": "Importar Comandos de Outros Estilos",
    "Copy commands from another style configuration.":
      "Copiar comandos de outra configuração de estilo.",
    "Main menu only": "Apenas para o menu principal",
    "This import will update:": "Esta importação irá atualizar:",
    "Custom commands": "Comandos Personalizados",
    "Toolbar commands": "Comandos da Barra de Ferramentas",
    "General settings": "Configurações Gerais",
    "Please paste configuration data first":
      "Por favor coloque os dados da configuração primeiro",
    "Invalid import data format": "Formato de dados de importação inválido",
    "Import From": "Importar de",
    "This import will:": "Esta importação irá:",
    "Update general settings": "Atualizar configurações gerais",
    "Update Main Menu Commands": "Atualizar Comandos do Menu Principal",
    "Update Custom Commands": "Atualizar Comandos Personalizados",
    "Update Following Style Commands":
      "Atualizar Comandos de Estilo Contextual",
    "Update Top Style Commands": "Atualizar Comandos de Estilo de Topo",
    "Update Fixed Style Commands": "Atualizar Comandos de Estilo Fixo",
    "Update Mobile Style Commands": "Atualizar Comandos de Estilo Mobile",
    "Clear all Main Menu Commands":
      "Limpar todos os Comandos do Menu Principal",
    "Clear all Custom Commands": "Limpar todos os Comandos Personalizados",
    "Clear all Following Style Commands":
      "Limpar todos os Comandos de Estilo Contextual",
    "Clear all Top Style Commands":
      "Limpar todos os Comandos de Estilo de Topo",
    "Clear all Fixed Style Commands": "Limpar todos os Comandos de Estilo Fixo",
    "Clear all Mobile Style Commands":
      "Limpar todos os Comandos de Estilo Mobile",
    "Overwrite Mode (Replace settings with imported ones)":
      "Modo de Sobrescrever (Substituir configurações com as importadas)",
    "Warning: Overwrite mode will replace existing settings with imported ones.":
      "Aviso: O modo de sobrescrever irá substituir todas as suas configurações atuais com as importadas.",
    "Warning: Update mode will add new items and update existing ones.":
      "Aviso: O modo de atualização irá adicionar novos itens e atualizar os existentes com base na configuração importada.",
    "Enable Multiple Config": "Habilitar Múltiplas Configurações",
    "Set Multiple Config to:": "Definir Múltiplas Configurações para:",
    Enable: "Habilitar",
    Disable: "Desabilitar",
    "Set Position Style to:": "Definir Estilo de Posição para:",
    Following: "Contextual",
    Top: "Topo",
    Fixed: "Fixo",
    Mobile: "Mobile",
    "All commands": "Todos os Comandos",
    "⚠️ Overwrite mode will replace existing settings with imported ones.":
      "⚠️ O modo de sobrescrever irá substituir todas as suas configurações atuais com as importadas.",
    "ℹ️ Update mode will merge imported settings with existing ones.":
      "ℹ️ O modo de atualização irá adicionar novos itens e atualizar os existentes com base na configuração importada.",
    "Do you want to continue?": "Deseja continuar?",
    "Imported settings:": "Configurações importadas:",
    "Imported commands:": "Comandos importados:",
    "Disable toolbar for this view":
      "Desabilitar barra de ferramentas para esta visualização",
    "Enable toolbar for this view":
      "Habilitar barra de ferramentas para esta visualização",
    "Manage all view types": "Gerenciar todos os tipos de visualização",
    "Current View: ": "Visualização Atual: ",
    "Appearance Style": "Estilo de Aparência",
    "Position Settings": "Configurações de Posição",
    "All commands have been removed.": "Todos os comandos foram removidos.",
    "Join the Community": "Juntar-se à Comunidade",
    "Share your toolbar settings and styles in our":
      "Compartilhe suas configurações e estilos da barra de ferramentas em nossa",
    "Get inspired by what others have created or showcase your own customizations.":
      "Inspire-se com o que outros criaram ou mostre suas próprias personalizações.",
    "Toolbar Preview (With a hypothetical command configuration.)":
      "Visualização da barra de ferramentas (com uma configuração de comandos hipotética).",
    "Toolbar Theme": "Estilo da Barra de Ferramentas",
    "Select a preset toolbar theme, automatically setting the background color, icon color, and size for the selected style.":
      "Selecione um estilo de barra de ferramentas pré-definido, automaticamente definindo a cor de fundo, cor do ícone e tamanho para o estilo selecionado.",
    "Toolbar Background Color": "Cor de Fundo da Barra de Ferramentas",
    "Set the background color of the toolbar.":
      "Definir a cor de fundo da barra de ferramentas.",
    "Toolbar Icon Color": "Cor do Ícone da Barra de Ferramentas",
    "Set the color of the toolbar icon.":
      "Definir a cor do ícone da barra de ferramentas.",
    "Toolbar Icon Size": "Tamanho do Ícone da Barra de Ferramentas",
    "Set the size of the toolbar icon (px); default: 18px":
      "Definir o tamanho do ícone da barra de ferramentas (px); padrão: 18px",
    "Custom Theme": "Estilo Personalizado",
    "Fixed Position Offset": "Deslocamento Fixo",
    "Choose the offset of the Toolbar in the fixed position.":
      "Escolha o deslocamento da Barra de Edição na posição fixa.",
    "Renumber List": "Renumerar Lista",
    "Fetch Remote Title": "Obter Título Remoto",
    "Please enter a URL first": "Por favor digite uma URL primeiro",
    "Failed to fetch title for": "Falha ao obter título para",
    "Link Title (optional)": "Título do Link (opcional)",
    "Unable to detect editor width":
      "Não foi possível detectar a largura do editor",
    "Fit Editor Width": "Ajustar Largura do Editor",
    "Please execute a format command or select format text first, then enable the format brush":
      "Execute um comando de formatação ou selecione um texto já formatado antes de ativar o pincel de formatação.",
    "Use \\n to represent line breaks":
      "Use \\n para representar quebras de linha",
    "Use ↵ to represent line breaks": "Use ↵ para representar quebras de linha",
    "Top Toolbar": "Barra de Ferramentas de Topo",
    "Enable the toolbar positioned at the top.":
      "Habilitar a barra de ferramentas posicionada no topo.",
    "Following Toolbar": "Barra de Ferramentas Contextual",
    "Enable the toolbar that appears upon text selection.":
      "Habilitar a barra de ferramentas que aparece ao selecionar texto.",
    "Fixed Toolbar": "Barra de Ferramentas Fixa",
    "Enable the toolbar whose position may be fixed where you please.":
      "Habilitar a barra de ferramentas cuja posição pode ser fixa onde você preferir.",
    "Toolbar Settings": "Configurações da Barra de Ferramentas",
    "Choose which toolbar style's appearance you want to edit.":
      "Escolha qual estilo de barra de ferramentas você deseja editar.",
    "Vertical Split": "Divisão Vertical",
  },
  ro: {},
  ru: {},
  tr: {},
  "zh-cn": Zr,
  "zh-tw": Kr,
}[e.moment.locale()];
function Xr(e) {
  return (Jr && Jr[e]) || Gr[e];
}
class Qr extends e.FuzzySuggestModal {
  constructor(e, t, i = !1, o, n) {
    (super(e.app),
      (this.customCallback = null),
      (this.plugin = e),
      (this.command = t),
      (this.issub = i),
      (this.customCallback = o || null),
      this.setPlaceholder(Xr("Choose an icon")),
      (this.currentEditingConfig = n || ""));
  }
  capitalJoin(e) {
    return e
      .split(" ")
      .map((e) => e[0].toUpperCase() + e.substring(1))
      .join(" ");
  }
  getItems() {
    return t;
  }
  getItemText(e) {
    return this.capitalJoin(
      e
        .replace("feather-", "")
        .replace("remix-", "")
        .replace("bx-", "")
        .replace(/([A-Z])/g, " $1")
        .trim()
        .replace(/-/gi, " "),
    );
  }
  renderSuggestion(t, i) {
    const o = createSpan({ cls: "editingToolbarIconPick" });
    (i.appendChild(o), e.setIcon(o, t.item), super.renderSuggestion(t, i));
  }
  async onChooseItem(e) {
    if ("Custom" === e)
      return this.customCallback
        ? void new ea(
            this.app,
            this.plugin,
            { id: this.command.id, name: this.command.name, icon: "" },
            this.issub,
            (e) => {
              this.customCallback(e);
            },
          ).open()
        : void new ea(
            this.app,
            this.plugin,
            this.command,
            this.issub,
            null,
            this.currentEditingConfig,
          ).open();
    if (this.customCallback) return void this.customCallback(e);
    const t = this.plugin.getCurrentCommands(this.currentEditingConfig);
    if (this.command.icon) {
      let i = Fr(this.plugin, this.command, this.issub, t);
      (this.issub
        ? (t[i.index].SubmenuCommands[i.subindex].icon = e)
        : (t[i.index].icon = e),
        this.plugin.updateCurrentCommands(t, this.currentEditingConfig));
    } else
      ((this.command.icon = e),
        t.push(this.command),
        this.plugin.updateCurrentCommands(t, this.currentEditingConfig));
    (await this.plugin.saveSettings(),
      setTimeout(() => {
        dispatchEvent(new Event("editingToolbar-NewCommand"));
      }, 100),
      console.log(
        `%c命令 '${this.command.name}' 已添加到编辑工具栏`,
        "color: Violet",
      ));
  }
}
class ea extends e.Modal {
  constructor(e, t, i, o, n, s) {
    (super(e),
      (this.customCallback = null),
      (this.plugin = t),
      (this.item = i),
      (this.issub = o),
      (this.customCallback = n || null),
      (this.currentEditingConfig = s || ""),
      this.containerEl.addClass("editingToolbar-Modal"),
      this.containerEl.addClass("customicon"));
  }
  onOpen() {
    const { contentEl: e } = this;
    e.createEl("b", {
      text: Xr("Enter the icon code, format as <svg>.... </svg>"),
    });
    const t = document.createElement("textarea");
    ((t.className = "wideInputPromptInputEl"),
      (t.placeholder = ""),
      (t.value = this.item.icon || ""),
      (t.style.width = "100%"),
      (t.style.height = "200px"),
      e.appendChild(t),
      t.addEventListener("input", async () => {
        const e = t.value;
        if (this.customCallback) return void (this.item.icon = e);
        this.item.icon = e;
        const i = this.plugin.getCurrentCommands(this.currentEditingConfig),
          o = Fr(this.plugin, this.item, this.issub, i);
        if (this.issub) {
          let t = o.subindex;
          -1 === t
            ? this.plugin.settings.menuCommands[o.index].SubmenuCommands.push(
                this.item,
              )
            : (this.plugin.settings.menuCommands[o.index].SubmenuCommands[
                t
              ].icon = e);
        } else {
          let e = o.index;
          -1 === e
            ? this.plugin.settings.menuCommands.push(this.item)
            : (this.plugin.settings.menuCommands[e].icon = this.item.icon);
        }
        await this.plugin.saveSettings();
      }),
      this.submitEnterCallback &&
        t.addEventListener("keydown", this.submitEnterCallback));
  }
  onClose() {
    const { contentEl: e } = this;
    (e.empty(),
      this.customCallback
        ? this.customCallback(this.item.icon || "")
        : setTimeout(() => {
            dispatchEvent(new Event("editingToolbar-NewCommand"));
          }, 100));
  }
}
class ta extends e.FuzzySuggestModal {
  constructor(e, t) {
    (super(e.app),
      (this.plugin = e),
      this.app,
      this.setPlaceholder(Xr("Choose a command")),
      (this.currentEditingConfig = t || ""));
  }
  getItems() {
    return app.commands.listCommands();
  }
  getItemText(e) {
    return e.name;
  }
  async onChooseItem(t) {
    const i = this.plugin.getCurrentCommands(this.currentEditingConfig);
    i.findIndex((e) => e.id == t.id) > -1
      ? new e.Notice(Xr("The command") + t.name + Xr("already exists"), 3e3)
      : t.icon
        ? (i.push(t),
          this.plugin.updateCurrentCommands(i, this.currentEditingConfig),
          await this.plugin.saveSettings(),
          setTimeout(() => {
            dispatchEvent(new Event("editingToolbar-NewCommand"));
          }, 100),
          console.log(`%c命令 '${t.name}' 已添加到编辑工具栏`, "color: Violet"))
        : new Qr(this.plugin, t, !1, null, this.currentEditingConfig).open();
  }
}
class ia extends e.Modal {
  constructor(e, t, i, o, n) {
    (super(t.app),
      (this.plugin = t),
      (this.item = i),
      (this.issub = o),
      (this.currentEditingConfig = n || ""),
      this.containerEl.addClass("editingToolbar-Modal"),
      this.containerEl.addClass("changename"));
  }
  onOpen() {
    const { contentEl: t } = this;
    t.createEl("b", { text: Xr("Please enter a new name: ") });
    const i = new e.TextComponent(t);
    (i.inputEl.classList.add("InputPromptInputEl"),
      i
        .setPlaceholder("")
        .setValue(this.item.name ?? "")
        .onChange(
          e.debounce(
            async (e) => {
              const t = this.plugin.getCurrentCommands(
                this.currentEditingConfig,
              );
              let i = Fr(this.plugin, this.item, this.issub, t);
              if (((this.item.name = e), this.issub)) {
                let o = i.subindex;
                -1 === o
                  ? t[i.index].SubmenuCommands.push(this.item)
                  : (t[i.index].SubmenuCommands[o].name = e);
              } else {
                let e = i.index;
                -1 === e ? t.push(this.item) : (t[e].name = this.item.name);
              }
              (this.plugin.updateCurrentCommands(t),
                await this.plugin.saveSettings());
            },
            100,
            !0,
          ),
        )
        .inputEl.addEventListener("keydown", this.submitEnterCallback));
  }
  onClose() {
    const { contentEl: e } = this;
    (e.empty(),
      setTimeout(() => {
        dispatchEvent(new Event("editingToolbar-NewCommand"));
      }, 100));
  }
}
class oa extends e.Modal {
  constructor(e, t) {
    (super(t.app),
      (this.needSave = !1),
      (this.plugin = t),
      this.containerEl.addClass("editingToolbar-Modal"));
  }
  onOpen() {
    const { contentEl: t } = this;
    t.createEl("p", { text: Xr("Drag the slider to move the position") });
    const i = t.createDiv({ cls: "slider-container" }),
      o = i.createDiv({ cls: "vertical-slider-container" });
    o.createEl("p", { text: Xr("Vertical Position") });
    const n = i.createDiv({ cls: "horizontal-slider-container" });
    n.createEl("p", { text: Xr("Horizontal Position") });
    const s = i.createDiv({ cls: "columns-slider-container" });
    s.createEl("p", { text: Xr("Toolbar Columns") });
    const r = document.body.clientHeight,
      a = document.body.clientWidth,
      l = Math.floor(r / 3),
      c = -Math.floor(r),
      d = Math.floor(a / 2),
      h = -Math.floor(a / 2),
      u = new e.SliderComponent(o)
        .setLimits(c, l, 5)
        .setValue(this.plugin.settings.verticalPosition || 0)
        .onChange(
          e.debounce(
            (e) => {
              ((this.needSave = !0),
                (this.plugin.settings.verticalPosition = e),
                jr(this.plugin.settings));
            },
            100,
            !0,
          ),
        )
        .setDynamicTooltip(),
      p = new e.SliderComponent(n)
        .setLimits(h, d, 10)
        .setValue(this.plugin.settings.horizontalPosition || 0)
        .onChange(
          e.debounce(
            (e) => {
              ((this.needSave = !0),
                (this.plugin.settings.horizontalPosition = e),
                Yr(this.plugin.settings));
            },
            100,
            !0,
          ),
        )
        .setDynamicTooltip(),
      m = new e.SliderComponent(s)
        .setLimits(1, 32, 1)
        .setValue(this.plugin.settings.cMenuNumRows || 12)
        .onChange(
          e.debounce(
            async (e) => {
              ((this.needSave = !0),
                (this.plugin.settings.cMenuNumRows = e),
                await this.plugin.saveSettings(),
                setTimeout(() => {
                  dispatchEvent(new Event("editingToolbar-NewCommand"));
                }, 100));
            },
            100,
            !0,
          ),
        )
        .setDynamicTooltip();
    i.createDiv({ cls: "reset-container" })
      .createEl("button", { text: Xr("Reset"), cls: "reset-button" })
      .addEventListener("click", () => {
        ((this.needSave = !0),
          u.setValue(0),
          p.setValue(0),
          m.setValue(12),
          (this.plugin.settings.verticalPosition = 0),
          (this.plugin.settings.horizontalPosition = 0),
          (this.plugin.settings.cMenuNumRows = 12),
          jr(this.plugin.settings),
          Yr(this.plugin.settings));
      });
  }
  async onClose() {
    const { contentEl: e } = this;
    (e.empty(), this.needSave && (await this.plugin.saveSettings()));
  }
}
const na = ["body", "workspace"],
  sa = ["default", "tiny", "glass", "custom"],
  ra = ["following", "top", "fixed"],
  aa = {
    lastVersion: "0.0.0",
    aestheticStyle: "default",
    positionStyle: "top",
    menuCommands: [
      { id: "toolbar:editor-undo", name: "Undo Edit", icon: "undo-glyph" },
      { id: "toolbar:editor-redo", name: "Redo Edit", icon: "redo-glyph" },
      {
        id: "toolbar:toggle-format-brush",
        name: "Format Brush",
        icon: "paintbrush",
      },
      {
        id: "toolbar:format-eraser",
        name: "Clear Text Formatting",
        icon: "eraser",
      },
      { id: "toolbar:header2-text", name: "Header 2", icon: "header-2" },
      { id: "toolbar:header3-text", name: "Header 3", icon: "header-3" },
      {
        id: "SubmenuCommands-header",
        name: "submenu",
        icon: "header-n",
        SubmenuCommands: [
          { id: "toolbar:header1-text", name: "Header 1", icon: "header-1" },
          { id: "toolbar:header4-text", name: "Header 4", icon: "header-4" },
          { id: "toolbar:header5-text", name: "Header 5", icon: "header-5" },
          { id: "toolbar:header6-text", name: "Header 6", icon: "header-6" },
        ],
      },
      { id: "toolbar:toggle-bold", name: "Bold", icon: "bold-glyph" },
      { id: "toolbar:toggle-italics", name: "Italic", icon: "italic-glyph" },
      {
        id: "toolbar:toggle-strikethrough",
        name: "Strikethrough",
        icon: "strikethrough-glyph",
      },
      { id: "toolbar:underline", name: "Underline", icon: "underline-glyph" },
      {
        id: "toolbar:toggle-highlight",
        name: "Highlight",
        icon: "highlight-glyph",
      },
      {
        id: "SubmenuCommands-text-tools",
        name: "Text Tools",
        icon: "box",
        menuType: "dropdown",
        SubmenuCommands: [
          {
            id: "toolbar:get-plain-text",
            name: "Get Plain Text",
            icon: "lucide-file-text",
          },
          {
            id: "toolbar:smart-symbols",
            name: "Full Half Converter",
            icon: "lucide-at-sign",
          },
          {
            id: "editingToolbar-Divider-Line",
            name: "Line Operations",
            icon: "vertical-split",
          },
          {
            id: "toolbar:insert-blank-lines",
            name: "Insert Blank Lines",
            icon: "lucide-space",
          },
          {
            id: "toolbar:remove-blank-lines",
            name: "Remove Blank Lines",
            icon: "lucide-minimize-2",
          },
          {
            id: "toolbar:split-lines",
            name: "Split Lines",
            icon: "lucide-split",
          },
          {
            id: "toolbar:merge-lines",
            name: "Merge Lines",
            icon: "lucide-merge",
          },
          {
            id: "toolbar:dedupe-lines",
            name: "Dedupe Lines",
            icon: "lucide-filter",
          },
          {
            id: "editingToolbar-Divider-Line",
            name: "Text Processing",
            icon: "vertical-split",
          },
          {
            id: "toolbar:add-wrap",
            name: "Add Prefix/Suffix",
            icon: "lucide-wrap-text",
          },
          {
            id: "toolbar:number-lines",
            name: "Number Lines (Custom)",
            icon: "lucide-list-ordered",
          },
          {
            id: "toolbar:remove-whitespace-trim",
            name: "Trim Line Ends",
            icon: "lucide-scissors",
          },
          {
            id: "toolbar:remove-whitespace-compress",
            name: "Shrink Extra Spaces",
            icon: "lucide-minimize",
          },
          {
            id: "toolbar:remove-whitespace-all",
            name: "Remove All Whitespace",
            icon: "lucide-eraser",
          },
          {
            id: "editingToolbar-Divider-Line",
            name: "Advanced Tools",
            icon: "vertical-split",
          },
          {
            id: "toolbar:list-to-table",
            name: "List to Table",
            icon: "lucide-table",
          },
          {
            id: "toolbar:table-to-list",
            name: "Table to List",
            icon: "lucide-list",
          },
          {
            id: "toolbar:extract-between",
            name: "Extract Between Strings",
            icon: "lucide-brackets",
          },
        ],
      },
      {
        id: "SubmenuCommands-lucdf3en5",
        name: "submenu",
        icon: "edit",
        SubmenuCommands: [
          { id: "toolbar:editor-cut", name: "Cut", icon: "lucide-scissors" },
          { id: "toolbar:editor-copy", name: "Copy", icon: "lucide-copy" },
          {
            id: "toolbar:editor-paste",
            name: "Paste",
            icon: "lucide-clipboard-type",
          },
          {
            id: "toolbar:editor:swap-line-down",
            name: "Swap Line Down",
            icon: "lucide-corner-right-down",
          },
          {
            id: "toolbar:editor:swap-line-up",
            name: "Swap Line Up",
            icon: "lucide-corner-right-up",
          },
        ],
      },
      {
        id: "toolbar:editor:attach-file",
        name: "Attach File",
        icon: "lucide-paperclip",
      },
      {
        id: "toolbar:editor:insert-table",
        name: "Insert Table",
        icon: "lucide-table",
      },
      {
        id: "toolbar:editor:cycle-list-checklist",
        name: "Cycle List and Checklist",
        icon: "check-circle",
      },
      {
        id: "SubmenuCommands-luc8efull",
        name: "submenu",
        icon: "message-square",
        SubmenuCommands: [
          {
            id: "toolbar:editor:toggle-blockquote",
            name: "Blockquote",
            icon: "lucide-text-quote",
          },
          {
            id: "toolbar:insert-callout",
            name: "Callout",
            icon: "lucide-quote",
          },
        ],
      },
      {
        id: "SubmenuCommands-mdcmder",
        name: "submenu",
        icon: '<svg width="18" height="18" focusable="false" fill="currentColor"  viewBox="0 0 1024 1024"><g transform="scale(1, -1) translate(0, -896) scale(0.9, 0.9) "><path class="path" d="M464 608 l0 -568 q0 -3 -2.5 -5.5 q-2.5 -2.5 -5.5 -2.5 l-80 0 q-3 0 -5.5 2.5 q-2.5 2.5 -2.5 5.5 l0 568 l-232 0 q-3 0 -5.5 2.5 q-2.5 2.5 -2.5 5.5 l0 80 q0 3 2.5 5.5 q2.5 2.5 5.5 2.5 l560 0 q3 0 5.5 -2.5 q2.5 -2.5 2.5 -5.5 l0 -80 q0 -3 -2.5 -5.5 q-2.5 -2.5 -5.5 -2.5 l-232 0 ZM864 696 q17 0 28.5 11.5 q11.5 11.5 11.5 28.5 q0 17 -11.5 28.5 q-11.5 11.5 -28.5 11.5 q-17 0 -28.5 -11.5 q-11.5 -11.5 -11.5 -28.5 q0 -17 11.5 -28.5 q11.5 -11.5 28.5 -11.5 ZM864 640 q-40 0 -68 28 q-28 28 -28 68 q0 40 28 68 q28 28 68 28 q40 0 68 -28 q28 -28 28 -68 q0 -40 -28 -68 q-28 -28 -68 -28 ZM576 322 l0 -63 q0 -3 2 -5 l89 -70 l-89 -70 q-2 -2 -2 -5 l0 -63 q0 -4 3.5 -5.5 q3.5 -1.5 6.5 0.5 l170 133 q4 3 4.5 8.5 q0.5 5.5 -2.5 9.5 l-2 2 l-170 133 q-3 2 -6.5 0.5 q-3.5 -1.5 -3.5 -5.5 ZM256 322 l0 -63 q0 -3 -2 -5 l-89 -70 l89 -70 q2 -2 2 -5 l0 -63 q0 -4 -3.5 -5.5 q-3.5 -1.5 -6.5 0.5 l-170 133 q-4 3 -4.5 8.5 q-0.5 5.5 2.5 9.5 l2 2 l170 133 q3 2 6.5 0.5 q3.5 -1.5 3.5 -5.5 Z"></path></g></svg>',
        SubmenuCommands: [
          {
            id: "toolbar:superscript",
            name: "Superscript",
            icon: "superscript-glyph",
          },
          {
            id: "toolbar:subscript",
            name: "Subscript",
            icon: "subscript-glyph",
          },
          {
            id: "toolbar:editor:toggle-code",
            name: "Inline Code",
            icon: "code-glyph",
          },
          {
            id: "toolbar:codeblock",
            name: "Code Block",
            icon: "codeblock-glyph",
          },
          {
            id: "toolbar:editor:insert-wikilink",
            name: "Wikilink",
            icon: '<svg width="15" height="15" focusable="false" fill="currentColor"  viewBox="0 0 1024 1024"><g transform="scale(1, -1) translate(0, -896) scale(0.9, 0.9) "><path class="path" d="M306 134 l91 0 q1 0 1 -8 l0 -80 q0 -8 -1 -8 l-91 0 q-1 0 -1 7 q0 -8 -5 -8 l-45 0 q-5 0 -5 8 l0 784 q0 8 5 8 l45 0 q5 0 5 -8 q0 8 1 8 l91 0 q1 0 1 -8 l0 -80 q0 -8 -1 -8 l-91 0 q-1 0 -1 8 l0 -623 q0 8 1 8 ZM139 134 l91 0 q1 0 1 -8 l0 -80 q0 -8 -1 -8 l-91 0 q-1 0 -1 7 q0 -8 -5 -8 l-45 0 q-5 0 -5 8 l0 784 q0 8 5 8 l45 0 q5 0 5 -8 q0 8 1 8 l91 0 q1 0 1 -8 l0 -80 q0 -8 -1 -8 l-91 0 q-1 0 -1 8 l0 -623 q0 8 1 8 ZM711 134 q1 0 1 -8 l0 623 q0 -8 -1 -8 l-91 0 q-1 0 -1 8 l0 80 q0 8 1 8 l91 0 q1 0 1 -8 q0 8 4 8 l46 0 q4 0 4 -8 l0 -784 q0 -8 -4 -8 l-46 0 q-4 0 -4 8 q0 -7 -1 -7 l-91 0 q-1 0 -1 8 l0 80 q0 8 1 8 l91 0 ZM878 134 q1 0 1 -8 l0 623 q0 -8 -1 -8 l-91 0 q-1 0 -1 8 l0 80 q0 8 1 8 l91 0 q1 0 1 -8 q0 8 5 8 l45 0 q4 0 4 -8 l0 -784 q0 -8 -4 -8 l-45 0 q-5 0 -5 8 q0 -7 -1 -7 l-91 0 q-1 0 -1 8 l0 80 q0 8 1 8 l91 0 Z"></path></g></svg>',
          },
          {
            id: "toolbar:editor:insert-embed",
            name: "Embed",
            icon: "note-glyph",
          },
          { id: "toolbar:insert-link", name: "Link", icon: "link-glyph" },
          {
            id: "toolbar:hrline",
            name: "Horizontal Divider",
            icon: '<svg width="18" height="18" focusable="false" fill="currentColor"  viewBox="0 0 1024 1024"><g transform="scale(1, -1) translate(0, -896) scale(0.9, 0.9) "><path class="path" d="M912 424 l0 -80 q0 -3 -2.5 -5.5 q-2.5 -2.5 -5.5 -2.5 l-784 0 q-3 0 -5.5 2.5 q-2.5 2.5 -2.5 5.5 l0 80 q0 3 2.5 5.5 q2.5 2.5 5.5 2.5 l784 0 q3 0 5.5 -2.5 q2.5 -2.5 2.5 -5.5 Z"></path></g></svg>',
          },
          {
            id: "toolbar:toggle-inline-math",
            name: "Inline Math",
            icon: "lucide-sigma",
          },
          {
            id: "toolbar:editor:insert-mathblock",
            name: "MathBlock",
            icon: "lucide-sigma-square",
          },
        ],
      },
      {
        id: "SubmenuCommands-list",
        name: "submenu-list",
        icon: "bullet-list-glyph",
        SubmenuCommands: [
          {
            id: "toolbar:editor:toggle-checklist-status",
            name: "Checklist",
            icon: "checkbox-glyph",
          },
          {
            id: "toolbar:renumber-ordered-list",
            name: "Renumber Ordered List",
            icon: "list-restart",
          },
          {
            id: "toolbar:toggle-numbered-list",
            name: "Ordered List",
            icon: '<svg width="18" height="18" focusable="false" fill="currentColor"  viewBox="0 0 1024 1024"><g transform="scale(1, -1) translate(0, -896) scale(0.9, 0.9) "><path class="path" d="M860 424 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-457 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l457 0 ZM860 756 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-457 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l457 0 ZM860 92 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-457 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l457 0 ZM264 136 l-3 -3 l-51 -57 l56 0 q14 0 24.5 -10 q10.5 -10 11.5 -25 l0 -1 q0 -15 -10.5 -25.5 q-10.5 -10.5 -24.5 -10.5 l-137 0 q-15 0 -25 10 q-10 10 -11 24.5 q-1 14.5 9 25.5 l63 70 l49 54 q7 7 7 16.5 q0 9.5 -7.5 16.5 q-7.5 7 -18.5 7 q-11 0 -18.5 -6.5 q-7.5 -6.5 -8.5 -16.5 l0 0 q0 -15 -10.5 -25.5 q-10.5 -10.5 -25.5 -10.5 q-15 0 -25.5 10.5 q-10.5 10.5 -10.5 25.5 q0 26 13.5 47.5 q13.5 21.5 36 34.5 q22.5 13 49 13 q26.5 0 49.5 -13 q23 -13 36 -34.5 q13 -21.5 13 -47.5 q0 -20 -7.5 -37.5 q-7.5 -17.5 -21.5 -30.5 l-1 -1 ZM173 794 q11 11 25 10.5 q14 -0.5 24.5 -10.5 q10.5 -10 10.5 -25 l0 -293 q0 -15 -10 -25.5 q-10 -10.5 -25 -10.5 q-15 0 -25.5 10 q-10.5 10 -11.5 25 l0 211 q-10 -8 -23.5 -7 q-13.5 1 -22.5 11 l-1 0 q-10 11 -9.5 25.5 q0.5 14.5 10.5 24.5 l58 54 Z"></path></g></svg>',
          },
          {
            id: "toolbar:toggle-bullet-list",
            name: "Unordered List",
            icon: '<svg width="18" height="18" focusable="false" fill="currentColor"  viewBox="0 0 1024 1024"><g transform="scale(1, -1) translate(0, -896) scale(0.9, 0.9) "><path class="path" d="M860 424 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-477 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l477 0 ZM860 756 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-477 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l477 0 ZM860 92 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-477 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l477 0 ZM176 716 l0 0 ZM112 716 q0 -27 18.5 -45.5 q18.5 -18.5 45.5 -18.5 q27 0 45.5 18.5 q18.5 18.5 18.5 45.5 q0 27 -18.5 45.5 q-18.5 18.5 -45.5 18.5 q-27 0 -45.5 -18.5 q-18.5 -18.5 -18.5 -45.5 ZM176 384 l0 0 ZM112 384 q0 -27 18.5 -45.5 q18.5 -18.5 45.5 -18.5 q27 0 45.5 18.5 q18.5 18.5 18.5 45.5 q0 27 -18.5 45.5 q-18.5 18.5 -45.5 18.5 q-27 0 -45.5 -18.5 q-18.5 -18.5 -18.5 -45.5 ZM176 52 l0 0 ZM112 52 q0 -27 18.5 -45.5 q18.5 -18.5 45.5 -18.5 q27 0 45.5 18.5 q18.5 18.5 18.5 45.5 q0 27 -18.5 45.5 q-18.5 18.5 -45.5 18.5 q-27 0 -45.5 -18.5 q-18.5 -18.5 -18.5 -45.5 Z"></path></g></svg>',
          },
          {
            id: "toolbar:undent-list",
            name: "Unindent List",
            icon: '<svg width="18" height="18" focusable="false" fill="currentColor"  viewBox="0 0 1024 1024"><g transform="scale(1, -1) translate(0, -896) scale(0.9, 0.9) "><path class="path" d="M872 302 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-429 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l429 0 ZM872 542 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-429 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l429 0 ZM872 784 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-721 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l721 0 ZM872 62 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-721 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l721 0 ZM244 534 l-123 -122 q-8 -7 -8 -18 q0 -11 8 -18 l123 -122 q8 -7 19 -7 q11 0 18.5 7.5 q7.5 7.5 7.5 18.5 l0 242 q0 11 -7.5 18.5 q-7.5 7.5 -18.5 7.5 q-11 0 -19 -7 Z"></path></g></svg>',
          },
          {
            id: "toolbar:indent-list",
            name: "Indent list",
            icon: '<svg width="18" height="18" focusable="false" fill="currentColor"  viewBox="0 0 1024 1024"><g transform="scale(1, -1) translate(0, -896) scale(0.9, 0.9) "><path class="path" d="M872 302 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-429 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l429 0 ZM872 542 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-429 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l429 0 ZM872 784 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-721 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l721 0 ZM872 62 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-721 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l721 0 ZM158 534 l124 -122 q7 -7 7 -18 q0 -11 -7 -18 l-124 -122 q-7 -7 -18 -7 q-11 0 -19 7.5 q-8 7.5 -8 18.5 l0 242 q0 11 8 18.5 q8 7.5 19 7.5 q11 0 18 -7 Z"></path></g></svg>',
          },
        ],
      },
      {
        id: "SubmenuCommands-aligin",
        name: "submenu-aligin",
        icon: '<svg width="18" height="18" focusable="false" fill="currentColor"  viewBox="0 0 1024 1024"><g transform="scale(1, -1) translate(0, -896) scale(0.9, 0.9) "><path class="path" d="M724 304 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-421 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l421 0 ZM872 540 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-721 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l721 0 ZM724 776 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-421 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l421 0 ZM872 68 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-721 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l721 0 Z"></path></g></svg>',
        SubmenuCommands: [
          {
            id: "toolbar:justify",
            name: "Justify Text",
            icon: '<svg width="18" height="18" focusable="false" fill="currentColor"  viewBox="0 0 1024 1024"><g transform="scale(1, -1) translate(0, -896) scale(0.9, 0.9) "><path class="path" d="M112 736 l0 0 ZM120 736 l784 0 q8 0 8 -8 l0 -80 q0 -8 -8 -8 l-784 0 q-8 0 -8 8 l0 80 q0 8 8 8 ZM112 331 l0 0 ZM120 331 l784 0 q8 0 8 -8 l0 -80 q0 -8 -8 -8 l-784 0 q-8 0 -8 8 l0 80 q0 8 8 8 ZM112 128 l0 0 ZM120 128 l784 0 q8 0 8 -8 l0 -80 q0 -8 -8 -8 l-784 0 q-8 0 -8 8 l0 80 q0 8 8 8 ZM112 533 l0 0 ZM120 533 l784 0 q8 0 8 -8 l0 -80 q0 -8 -8 -8 l-784 0 q-8 0 -8 8 l0 80 q0 8 8 8 Z"></path></g></svg>',
          },
          {
            id: "toolbar:left",
            name: "Align Text Left",
            icon: '<svg width="18" height="18" focusable="false" fill="currentColor"  viewBox="0 0 1024 1024"><g transform="scale(1, -1) translate(0, -896) scale(0.9, 0.9) "><path class="path" d="M572 304 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-421 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l421 0 ZM872 540 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-721 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l721 0 ZM572 776 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-421 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l421 0 ZM872 68 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-721 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l721 0 Z"></path></g></svg>',
          },
          {
            id: "toolbar:center",
            name: "Center Text",
            icon: '<svg width="18" height="18" focusable="false" fill="currentColor"  viewBox="0 0 1024 1024"><g transform="scale(1, -1) translate(0, -896) scale(0.9, 0.9) "><path class="path" d="M724 304 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-421 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l421 0 ZM872 540 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-721 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l721 0 ZM724 776 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-421 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l421 0 ZM872 68 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-721 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l721 0 Z"></path></g></svg>',
          },
          {
            id: "toolbar:right",
            name: "Align Text Right",
            icon: '<svg width="18" height="18" focusable="false" fill="currentColor"  viewBox="0 0 1024 1024"><g transform="scale(1, -1) translate(0, -896) scale(0.9, 0.9) "><path class="path" d="M872 304 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-421 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l421 0 ZM872 540 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-721 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l721 0 ZM872 776 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-421 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l421 0 ZM872 68 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-721 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l721 0 Z"></path></g></svg>',
          },
        ],
      },
      {
        id: "toolbar:change-font-color",
        name: "Change Font Color",
        icon: '<svg width="24" height="24" viewBox="0 0 24 24" focusable="false" fill="currentColor"><g fill-rule="evenodd"><path id="change-font-color-icon" d="M3 18h18v3H3z" style="fill:#2DC26B"></path><path d="M8.7 16h-.8a.5.5 0 01-.5-.6l2.7-9c.1-.3.3-.4.5-.4h2.8c.2 0 .4.1.5.4l2.7 9a.5.5 0 01-.5.6h-.8a.5.5 0 01-.4-.4l-.7-2.2c0-.3-.3-.4-.5-.4h-3.4c-.2 0-.4.1-.5.4l-.7 2.2c0 .3-.2.4-.4.4zm2.6-7.6l-.6 2a.5.5 0 00.5.6h1.6a.5.5 0 00.5-.6l-.6-2c0-.3-.3-.4-.5-.4h-.4c-.2 0-.4.1-.5.4z"></path></g></svg>',
      },
      {
        id: "toolbar:change-background-color",
        name: "Change Background Color",
        icon: '<svg width="18" height="24" viewBox="0 0 256 256" version="1.1" xmlns="http://www.w3.org/2000/svg"><g   stroke="none" stroke-width="1" fill="currentColor" fill-rule="evenodd"><g  ><g fill="currentColor"><g transform="translate(119.502295, 137.878331) rotate(-135.000000) translate(-119.502295, -137.878331) translate(48.002295, 31.757731)" ><path d="M100.946943,60.8084699 L43.7469427,60.8084699 C37.2852111,60.8084699 32.0469427,66.0467383 32.0469427,72.5084699 L32.0469427,118.70847 C32.0469427,125.170201 37.2852111,130.40847 43.7469427,130.40847 L100.946943,130.40847 C107.408674,130.40847 112.646943,125.170201 112.646943,118.70847 L112.646943,72.5084699 C112.646943,66.0467383 107.408674,60.8084699 100.946943,60.8084699 Z M93.646,79.808 L93.646,111.408 L51.046,111.408 L51.046,79.808 L93.646,79.808 Z" fill-rule="nonzero"></path><path d="M87.9366521,16.90916 L87.9194966,68.2000001 C87.9183543,69.4147389 86.9334998,70.399264 85.7187607,70.4 L56.9423078,70.4 C55.7272813,70.4 54.7423078,69.4150264 54.7423078,68.2 L54.7423078,39.4621057 C54.7423078,37.2523513 55.5736632,35.1234748 57.0711706,33.4985176 L76.4832996,12.4342613 C78.9534987,9.75382857 83.1289108,9.5834005 85.8093436,12.0535996 C87.1658473,13.303709 87.9372691,15.0644715 87.9366521,16.90916 Z" fill-rule="evenodd"></path><path d="M131.3,111.241199 L11.7,111.241199 C5.23826843,111.241199 0,116.479467 0,122.941199 L0,200.541199 C0,207.002931 5.23826843,212.241199 11.7,212.241199 L131.3,212.241199 C137.761732,212.241199 143,207.002931 143,200.541199 L143,122.941199 C143,116.479467 137.761732,111.241199 131.3,111.241199 Z M124,130.241 L124,193.241 L19,193.241 L19,130.241 L124,130.241 Z" fill-rule="nonzero"></path></g></g><path d="M51,218 L205,218 C211.075132,218 216,222.924868 216,229 C216,235.075132 211.075132,240 205,240 L51,240 C44.9248678,240 40,235.075132 40,229 C40,222.924868 44.9248678,218 51,218 Z" id="change-background-color-icon" style="fill:#FA541C"></path></g></g></svg>',
      },
      {
        id: "toolbar:fullscreen-focus",
        name: "Fullscreen Focus Mode",
        icon: "fullscreen",
      },
      {
        id: "toolbar:workplace-fullscreen-focus",
        name: "Workplace Fullscreen",
        icon: "exit-fullscreen",
      },
    ],
    followingCommands: [],
    topCommands: [],
    fixedCommands: [],
    mobileCommands: [],
    enableMultipleConfig: !1,
    enableTopToolbar: !1,
    enableFollowingToolbar: !1,
    enableFixedToolbar: !1,
    appendMethod: "workspace",
    shouldShowMenuOnSelect: !1,
    cMenuVisibility: !0,
    cMenuBottomValue: 4.25,
    cMenuNumRows: 12,
    cMenuWidth: 610,
    cMenuFontColor: "#2DC26B",
    cMenuBackgroundColor: "#d3f8b6",
    autohide: !1,
    Iscentered: !1,
    custom_bg1: "#FFB78B8C",
    custom_bg2: "#CDF4698C",
    custom_bg3: "#A0CCF68C",
    custom_bg4: "#F0A7D88C",
    custom_bg5: "#ADEFEF8C",
    custom_fc1: "#D83931",
    custom_fc2: "#DE7802",
    custom_fc3: "#245BDB",
    custom_fc4: "#6425D0",
    custom_fc5: "#646A73",
    isLoadOnMobile: !1,
    horizontalPosition: 0,
    verticalPosition: 0,
    formatBrushes: {},
    customCommands: [],
    viewTypeSettings: {},
    appearanceByStyle: {
      top: {
        toolbarBackgroundColor: "rgba(var(--background-secondary-rgb), 0.7)",
        toolbarIconColor: "var(--text-normal)",
        toolbarIconSize: 18,
        aestheticStyle: "default",
      },
      following: {
        toolbarBackgroundColor: "rgba(var(--background-secondary-rgb), 0.7)",
        toolbarIconColor: "var(--text-normal)",
        toolbarIconSize: 18,
        aestheticStyle: "default",
      },
      fixed: {
        toolbarBackgroundColor: "rgba(var(--background-secondary-rgb), 0.7)",
        toolbarIconColor: "var(--text-normal)",
        toolbarIconSize: 18,
        aestheticStyle: "default",
      },
      mobile: {
        toolbarBackgroundColor: "rgba(var(--background-secondary-rgb), 0.7)",
        toolbarIconColor: "var(--text-normal)",
        toolbarIconSize: 18,
        aestheticStyle: "default",
      },
    },
    toolbarBackgroundColor: "rgba(var(--background-secondary-rgb), 0.7)",
    toolbarIconColor: "var(--text-normal)",
    toolbarIconSize: 18,
    useCurrentLineForRegex: !1,
  };
class la {
  static isAllowedViewType(e, t) {
    if (!e) return !1;
    const i = e.getViewType(),
      o = window.app?.plugins?.plugins?.["toolbar"];
    if (
      o?.settings?.viewTypeSettings &&
      void 0 !== o.settings.viewTypeSettings[i]
    )
      return o.settings.viewTypeSettings[i];
    return (
      t || ["markdown", "canvas", "thino_view", "meld-encrypted-view"]
    ).includes(i);
  }
  static isSourceMode(e) {
    return !!e && "source" === e.getMode?.();
  }
}
let ca;
const da = {
  markdown: ".markdown-source-view",
  thino_view: ".markdown-source-view",
  canvas: ".canvas-wrapper",
  excalidraw: ".view-header",
  image: ".image-container",
  pdf: ".view-content",
  meld_encrypted_view: ".markdown-source-view",
};
function ha(t) {
  ca = e.requireApiVersion("0.15.0") ? activeWindow.document : window.document;
  const i = (function () {
      const t = [];
      t.push(app.workspace.rootSplit);
      const i = app.workspace.floatingSplit;
      return (
        i?.children.forEach((i) => {
          i instanceof e.WorkspaceWindow && t.push(i);
        }),
        t
      );
    })(),
    o = (e) => {
      const t = e.querySelectorAll(".editingToolbarModalBar"),
        i = e.querySelectorAll(".editingToolbarPopoverBar");
      (t.forEach((e) => {
        (e.firstChild && e.removeChild(e.firstChild), e.remove());
      }),
        i.forEach((e) => {
          (e.firstChild && e.removeChild(e.firstChild), e.remove());
        }));
    };
  (o(ca),
    i &&
      i.forEach((e) => {
        e?.containerEl && o(e.containerEl);
      }),
    t && t.clearToolbarCache());
}
function ua(t, i, o) {
  ca = e.requireApiVersion("0.15.0") ? activeWindow.document : window.document;
  const n = o || i.positionStyle || i.settings.positionStyle || "top";
  if ("top" !== n) {
    const e = i.getCachedToolbar(n);
    if (e) return e;
  }
  const s = `.editingToolbarModalBar[data-toolbar-style="${n}"]`;
  let r = null;
  return (
    (r =
      "top" === n
        ? t.workspace.activeLeaf?.view.containerEl?.querySelector(s) || null
        : ca.querySelector(s)),
    r && "top" !== n && i.setCachedToolbar(n, r),
    r || null
  );
}
const pa = (e, t) =>
  t.reduce((e, t) => (e && "undefined" !== e[t] ? e[t] : void 0), e);
function ma(e, t) {
  return e && void 0 !== e[1][0]
    ? t + e.flat(2).join("+").replace("Mod", "Ctrl") + t
    : t + "–" + t;
}
function ga(e, t, i = !0) {
  let o = e.commands.findCommand(t),
    n = i ? "*" : "";
  if (o) {
    let t = o.hotkeys
        ? [[pa(o.hotkeys, [0, "modifiers"])], [pa(o.hotkeys, [0, "key"])]]
        : void 0,
      i = e.hotkeyManager.customKeys[o.id];
    var s = i ? [[pa(i, [0, "modifiers"])], [pa(i, [0, "key"])]] : void 0;
    return s ? ma(s, n) : ma(t, "");
  }
  return "–";
}
function fa(e) {
  return /<[^>]+>/g.test(e);
}
function ba(t, i, o) {
  ca = e.requireApiVersion("0.15.0") ? activeWindow.document : window.document;
  const n = i.commandsManager.getActiveEditor();
  let s = ua(t, i),
    r = s?.querySelector("#" + o);
  if (r) {
    let e = r.rows,
      t = e.length;
    for (let s = 1; s < t; s++) {
      let t = e[s].cells;
      for (let e = 0; e < t.length; e++)
        t[e].onclick = function () {
          let e = this.style.backgroundColor;
          if ("" != e) {
            if (((e = ya(e)), "x-color-picker-table" == o)) {
              ((i.settings.cMenuFontColor = e),
                _r(e, n),
                ca.querySelectorAll("#change-font-color-icon").forEach((t) => {
                  t.style.fill = e;
                }));
            } else if ("x-backgroundcolor-picker-table" == o) {
              ((i.settings.cMenuBackgroundColor = e),
                zr(e, n),
                ca
                  .querySelectorAll("#change-background-color-icon")
                  .forEach((t) => {
                    t.style.fill = e;
                  }));
            }
            i.saveSettings();
          }
        };
    }
  }
}
const ya = function (e) {
  let t = e;
  if (/^(rgb|RGB)/.test(t)) {
    let e = t.replace(/(?:\(|\)|rgb|RGB)*/g, "").split(","),
      i = "#";
    for (let t = 0; t < e.length; t++) {
      let o = Number(e[t]).toString(16);
      ("0" === o && (o += o), 1 == o.length && (o = "0" + o), (i += o));
    }
    return (7 !== i.length && (i = t), i);
  }
  if (!/^#([0-9a-fA-f]{3}|[0-9a-fA-f]{6})$/.test(t)) return t;
  {
    let e = t.replace(/#/, "").split("");
    if (6 === e.length) return t;
    if (3 === e.length) {
      let t = "#";
      for (let i = 0; i < e.length; i += 1) t += e[i] + e[i];
      return t;
    }
  }
};
function wa(e) {
  e.quiteAllFormatBrushes();
}
function va(e, t) {
  let i = t.getSelection();
  if (!i || "" === i.trim()) return;
  if (i.match(/^>\s*\[\![\w\s]*\]/m)) {
    let e = i.split("\n"),
      o = [],
      n = !1,
      s = 0,
      r = !1;
    for (let t = 0; t < e.length; t++) {
      let i = e[t],
        a = i.match(/^(>+)\s*\[\!([\w\s]*)\]\s*(.*?)$/);
      if (!a || r)
        if (n) {
          let e = i.match(/^(>+)\s*/);
          if (e && e[1].length >= s) {
            let e = i.replace(new RegExp(`^>{${s}}\\s*`), "");
            o.push(e);
          } else ((n = !1), o.push(i));
        } else o.push(i);
      else
        ((s = a[1].length),
          (r = !0),
          a[3].trim() && o.push(a[3].trim()),
          (n = !0));
    }
    return void t.replaceSelection(o.join("\n"));
  }
  ((i = i.replace(
    /(^#+\s|^#(?=\s)|^\>|^\- \[( |x)\]|^\+ |\<[^\<\>]+?\>|^1\. |^\s*\- |^\-+$|^\*+$)/gm,
    "",
  )),
    (i = i.replace(/^[ ]+|[ ]+$/gm, "")),
    (i = i.replace(/\!?\[\[([^\[\]\|]*\|)*([^\(\)\[\]]+)\]\]/g, "$2")),
    (i = i.replace(/\!?\[+([^\[\]\(\)]+)\]+\(([^\(\)]+)\)/g, "$1")),
    (i = i.replace(/`([^`]+)`/g, "$1")),
    (i = i.replace(/_([^_]+)_/g, "$1")),
    (i = i.replace(/==([^=]+)==/g, "$1")),
    (i = i.replace(/\*\*\*([^\*]+)\*\*\*/g, "$1")),
    (i = i.replace(/\*\*?([^\*]+)\*\*?/g, "$1")),
    (i = i.replace(/~~([^~]+)~~/g, "$1")),
    t.replaceSelection(i));
}
function Ca(t, i, o, n, s = !1) {
  let r = ua(t, o, "following");
  const a = t.workspace.getActiveViewOfType(e.ItemView);
  if (!la.isAllowedViewType(a))
    return void (r && (r.style.visibility = "hidden"));
  if (
    !(
      o.settings.enableFollowingToolbar ||
      (!o.settings.enableTopToolbar &&
        !o.settings.enableFixedToolbar &&
        "following" === o.positionStyle)
    )
  )
    return;
  const l = a?.getViewType(),
    c = "markdown" === l;
  let d = 30;
  if (((d = "tiny" === o.settings.aestheticStyle ? 30 : i + 14), c))
    if (la.isSourceMode(a)) {
      if (r) {
        const e = s || n.somethingSelected();
        ((r.style.visibility = e ? "visible" : "hidden"),
          "visible" === r.style.visibility &&
            ((r.style.height = d + "px"),
            r.addClass("editingToolbarFlex"),
            r.removeClass("editingToolbarGrid"),
            (function (e, t) {
              const i = t.containerEl.getBoundingClientRect(),
                o = e.offsetWidth,
                n = e.offsetHeight,
                s = 12,
                r = window.innerWidth,
                a = t.getCursor("from");
              t.getCursor("to");
              const l = t.coordsAtPos(a),
                c =
                  ca.getElementsByClassName("mod-left-split")[0]?.clientWidth ??
                  0,
                d =
                  ca.getElementsByClassName("side-dock-ribbon mod-left")[0]
                    ?.clientWidth ?? 0,
                h = c + d;
              let u = l.left - h - 28;
              u + o > r - h && (u = r - h - o - s);
              u = Math.max(0, u);
              let p = (function (e, t, i, o) {
                const n = e.getCursor("from"),
                  s = e.getCursor("to"),
                  r = e.coordsAtPos(s),
                  a = n.line === s.line;
                let l = t.top - o - 10;
                if (a) l <= i.top && (l = r.bottom + 10);
                else {
                  if (e.getCursor("head").ch == e.getCursor("from").ch)
                    ((l = t.top - o - 10), l <= i.top && (l = i.top + 2 * o));
                  else {
                    const t = ((e) => {
                      let t,
                        i = e.getCursor("head");
                      if (
                        (e.getCursor("head").ch !== e.getCursor("from").ch &&
                          (i.ch = Math.max(0, i.ch - 1)),
                        e.cursorCoords)
                      )
                        t = e.cursorCoords(!0, "window");
                      else {
                        if (!e.coordsAtPos) return;
                        {
                          const o = e.posToOffset(i);
                          t = e.cm.coordsAtPos?.(o) ?? e.coordsAtPos(o);
                        }
                      }
                      return t;
                    })(e);
                    ((l = t.bottom + 10),
                      l >= i.bottom - o && (l = i.bottom - 2 * o));
                  }
                }
                return l;
              })(t, l, i, n);
              ((p = Math.max(0, p)),
                (e.style.left = `${u}px`),
                (e.style.top = `${p}px`));
            })(r, n)));
      }
    } else r && (r.style.visibility = "hidden");
  else
    r &&
      ((r.style.visibility = "visible"),
      (r.style.height = d + "px"),
      r.addClass("editingToolbarFlex"),
      r.removeClass("editingToolbarGrid"));
}
function xa(t, i, o) {
  const n = i.settings;
  if (
    ((ca = e.requireApiVersion("0.15.0")
      ? activeWindow.document
      : window.document),
    !o)
  ) {
    const e = [];
    if (
      (n.enableTopToolbar && e.push("top"),
      n.enableFollowingToolbar && e.push("following"),
      n.enableFixedToolbar && e.push("fixed"),
      0 === e.length)
    ) {
      const t = i.positionStyle || i.settings.positionStyle || "top";
      e.push(t);
    }
    return void e.forEach((e) => {
      xa(t, i, e);
    });
  }
  const s = o;
  if (!n.cMenuVisibility) {
    const e = ua(t, i, s);
    return void (e && (e.style.display = "none"));
  }
  const r = (n.appearanceByStyle || {})[s] || {},
    a = r.toolbarIconSize ?? i.toolbarIconSize ?? 18,
    l = r.aestheticStyle ?? n.aestheticStyle ?? "default",
    c =
      "custom" === l
        ? (r.toolbarBackgroundColor ?? n.toolbarBackgroundColor)
        : void 0,
    d = "custom" === l ? (r.toolbarIconColor ?? n.toolbarIconColor) : void 0,
    h = {
      default: "editingToolbarDefaultAesthetic",
      tiny: "editingToolbarTinyAesthetic",
      glass: "editingToolbarGlassAesthetic",
      custom: "editingToolbarCustomAesthetic",
    };
  !(function () {
    function o(e, t) {
      Object.values(h).forEach((t) => {
        e.removeClass(t);
      });
      const i = h[t] || h.default;
      e.addClass(i);
    }
    const r = () => {
      let r = 0,
        h = 0,
        u = a + 8,
        p = createEl("div");
      if (p)
        if (
          (p.addClass("editingToolbarModalBar"),
          p.setAttribute("data-toolbar-style", s),
          "top" === s)
        )
          ((p.className += " top"),
            n.autohide && (p.className += " autohide"),
            n.Iscentered && (p.className += " centered"));
        else if ("following" === s) p.style.visibility = "hidden";
        else if ("fixed" === s) {
          const e = a || 18,
            t = `left: calc(50% - calc(${n.cMenuNumRows * (e + 10)}px / 2));\n           bottom: 4.25em; \n           grid-template-columns: repeat(${n.cMenuNumRows}, ${e + 10}px);\n           gap: ${(e - 18) / 4}px`;
          p.setAttribute("style", t);
        }
      p.setAttribute("id", "editingToolbarModalBar");
      let m = createEl("div");
      if (
        (m.addClass("editingToolbarpopover"),
        m.addClass("editingToolbarTinyAesthetic"),
        m.addClass("editingToolbarPopoverBar"),
        m.setAttribute("data-toolbar-style", s),
        m.setAttribute("id", "editingToolbarPopoverBar"),
        (m.style.visibility = "hidden"),
        (m.style.height = "0"),
        o(p, l),
        o(m, l),
        c &&
          (p.style.setProperty("--toolbar-background-color", c),
          m.style.setProperty("--toolbar-background-color", c)),
        d &&
          (p.style.setProperty("--toolbar-icon-color", d),
          m.style.setProperty("--toolbar-icon-color", d)),
        a &&
          (p.style.setProperty("--toolbar-icon-size", `${a}px`),
          m.style.setProperty("--toolbar-icon-size", `${a}px`)),
        "top" === s)
      ) {
        let e = t.workspace.activeLeaf.view.containerEl,
          i = null;
        const o = t.workspace.activeLeaf.view.getViewType(),
          n = da[o];
        if ((n && (i = e?.querySelector(n)), !i)) {
          const t = e?.querySelector(".view-content");
          if (t) {
            const e = t.querySelectorAll(":scope > div");
            i = e.length > 0 ? e[0] : t;
          }
        }
        if (!i)
          return void console.log(
            "Toolbar: Failed to find target DOM element for toolbar insertion",
          );
        (e?.querySelector("#editingToolbarPopoverBar") ||
          ("excalidraw" == o
            ? i.insertAdjacentElement("afterend", m)
            : i.insertAdjacentElement("afterbegin", m)),
          "excalidraw" == o
            ? i.insertAdjacentElement("afterend", p)
            : i.insertAdjacentElement("afterbegin", p),
          (h = i?.offsetWidth));
      } else
        "body" == n.appendMethod
          ? ca.body.appendChild(p)
          : "workspace" == n.appendMethod &&
            ca.body
              ?.querySelector(".mod-vertical.mod-root")
              .insertAdjacentElement("afterbegin", p);
      let g = t.workspace.activeLeaf.view.containerEl?.querySelector(
        "#editingToolbarPopoverBar",
      );
      (i.getCurrentCommands(s).forEach((o, a) => {
        let l;
        if ("SubmenuCommands" in o) {
          let c;
          (r >= h - 7 * u && h > 100
            ? (i.setIS_MORE_Button(!0), (c = new e.ButtonComponent(g)))
            : (c = new e.ButtonComponent(p)),
            c.setClass("editingToolbarCommandsubItem" + a),
            a >= n.cMenuNumRows
              ? c.setClass("editingToolbarSecond")
              : "top" !== s &&
                c.buttonEl.setAttribute("aria-label-position", "top"),
            fa(o.icon) ? (c.buttonEl.innerHTML = o.icon) : c.setIcon(o.icon),
            (r += u + 2));
          if ("dropdown" === (o.menuType || "submenu")) {
            c.setClass("editingToolbarDropdownButton");
            let r = ga(t, o.id);
            ((l = "–" == r ? o.name : o.name + "(" + r + ")"),
              c.setTooltip(l),
              c.onClick((r) => {
                const a = new e.Menu();
                (o.SubmenuCommands.forEach((e) => {
                  "editingToolbar-Divider-Line" === e.id
                    ? (a.addSeparator(),
                      a.addItem((t) => {
                        t.setTitle(Xr(e.name)).setIcon("").setDisabled(!0);
                      }))
                    : a.addItem((o) => {
                        const r = ga(t, e.id, !1),
                          a = Xr(e.name),
                          l = "–" !== r ? `${a}` : a;
                        if (
                          (o
                            .setTitle(l)
                            .setIcon(e.icon)
                            .onClick(() => {
                              t.commands.executeCommandById(e.id);
                              const o = i.commandsManager.getActiveEditor(),
                                r = o && o.somethingSelected();
                              0 == n.cMenuVisibility
                                ? (p.style.visibility = "hidden")
                                : "following" === s
                                  ? r || (p.style.visibility = "hidden")
                                  : (p.style.visibility = "visible");
                            }),
                          "–" !== r)
                        ) {
                          o.dom
                            .createSpan({ cls: "menu-item-hotkey" })
                            .setText(r);
                        }
                      });
                }),
                  a.dom.addClass("toolbar-dropdown-menu"),
                  a.showAtMouseEvent(r));
              }));
          } else {
            let r = (function (e) {
              let t = createEl("div");
              return (t.addClass(e), t);
            })("subitem");
            r &&
              o.SubmenuCommands.forEach((o) => {
                let d = ga(t, o.id);
                l = "–" == d ? o.name : o.name + "(" + d + ")";
                let h = new e.ButtonComponent(r)
                  .setTooltip(l)
                  .setClass("menu-item")
                  .onClick(() => {
                    t.commands.executeCommandById(o.id);
                    const e = i.commandsManager.getActiveEditor(),
                      r = e && e.somethingSelected();
                    0 == n.cMenuVisibility
                      ? (p.style.visibility = "hidden")
                      : "following" === s
                        ? r || (p.style.visibility = "hidden")
                        : (p.style.visibility = "visible");
                  });
                (a < n.cMenuNumRows &&
                  "top" !== s &&
                  h.buttonEl.setAttribute("aria-label-position", "top"),
                  "editingToolbar-Divider-Line" == o.id &&
                    (h.setClass("editingToolbar-Divider-Line"),
                    h.buttonEl.setAttribute("aria-label", o.name)),
                  fa(o.icon)
                    ? (h.buttonEl.innerHTML = o.icon)
                    : h.setIcon(o.icon),
                  c.buttonEl.insertAdjacentElement("afterbegin", r));
              });
          }
        } else if ("toolbar:change-font-color" == o.id) {
          let a = new e.ButtonComponent(p);
          (a
            .setClass("editingToolbarCommandsubItem-font-color")
            .setTooltip(Xr("Font Colors"))
            .onClick(() => {
              t.commands.executeCommandById(o.id);
              const e = i.commandsManager.getActiveEditor(),
                r = e && e.somethingSelected();
              0 == n.cMenuVisibility
                ? (p.style.visibility = "hidden")
                : "following" === s
                  ? r || (p.style.visibility = "hidden")
                  : (p.style.visibility = "visible");
            }),
            fa(o.icon) ? (a.buttonEl.innerHTML = o.icon) : a.setIcon(o.icon),
            (r += u));
          let l = createEl("div");
          if ((l.addClass("subitem"), l)) {
            ((l.innerHTML = (function (e) {
              return `<div class='x-color-picker-wrapper'>\n<div class='x-color-picker' >\n  <table class="x-color-picker-table" id='x-color-picker-table'>\n    <tbody>\n      <tr>\n        <th colspan="10" class="ui-widget-content">Theme Colors</th>\n      </tr>\n      <tr>\n        <td style="background-color:#ffffff"><span></span></td>\n        <td style="background-color:#000000"><span></span></td>\n        <td style="background-color:#eeece1"><span></span></td>\n        <td style="background-color:#1f497d"><span></span></td>\n        <td style="background-color:#4f81bd"><span></span></td>\n        <td style="background-color:#c0504d"><span></span></td>\n        <td style="background-color:#9bbb59"><span></span></td>\n        <td style="background-color:#8064a2"><span></span></td>\n        <td style="background-color:#4bacc6"><span></span></td>\n        <td style="background-color:#f79646"><span></span></td>\n      </tr>\n      <tr>\n        <th colspan="10"></th>\n      </tr>\n      <tr class="top">\n        <td style="background-color:#f2f2f2"><span></span></td>\n        <td style="background-color:#7f7f7f"><span></span></td>\n        <td style="background-color:#ddd9c3"><span></span></td>\n        <td style="background-color:#c6d9f0"><span></span></td>\n        <td style="background-color:#dbe5f1"><span></span></td>\n        <td style="background-color:#f2dcdb"><span></span></td>\n        <td style="background-color:#ebf1dd"><span></span></td>\n        <td style="background-color:#e5e0ec"><span></span></td>\n        <td style="background-color:#dbeef3"><span></span></td>\n        <td style="background-color:#fdeada"><span></span></td>\n      </tr>\n      <tr class="in">\n        <td style="background-color:#d8d8d8"><span></span></td>\n        <td style="background-color:#595959"><span></span></td>\n        <td style="background-color:#c4bd97"><span></span></td>\n        <td style="background-color:#8db3e2"><span></span></td>\n        <td style="background-color:#b8cce4"><span></span></td>\n        <td style="background-color:#e5b9b7"><span></span></td>\n        <td style="background-color:#d7e3bc"><span></span></td>\n        <td style="background-color:#ccc1d9"><span></span></td>\n        <td style="background-color:#b7dde8"><span></span></td>\n        <td style="background-color:#fbd5b5"><span></span></td>\n      </tr>\n      <tr class="in">\n        <td style="background-color:#bfbfbf"><span></span></td>\n        <td style="background-color:#3f3f3f"><span></span></td>\n        <td style="background-color:#938953"><span></span></td>\n        <td style="background-color:#548dd4"><span></span></td>\n        <td style="background-color:#95b3d7"><span></span></td>\n        <td style="background-color:#d99694"><span></span></td>\n        <td style="background-color:#c3d69b"><span></span></td>\n        <td style="background-color:#b2a2c7"><span></span></td>\n        <td style="background-color:#92cddc"><span></span></td>\n        <td style="background-color:#fac08f"><span></span></td>\n      </tr>\n      <tr class="in">\n        <td style="background-color:#a5a5a5"><span></span></td>\n        <td style="background-color:#262626"><span></span></td>\n        <td style="background-color:#494429"><span></span></td>\n        <td style="background-color:#17365d"><span></span></td>\n        <td style="background-color:#366092"><span></span></td>\n        <td style="background-color:#953734"><span></span></td>\n        <td style="background-color:#76923c"><span></span></td>\n        <td style="background-color:#5f497a"><span></span></td>\n        <td style="background-color:#31859b"><span></span></td>\n        <td style="background-color:#e36c09"><span></span></td>\n      </tr>\n      <tr class="bottom">\n        <td style="background-color:#7f7f7f"><span></span></td>\n        <td style="background-color:#0c0c0c"><span></span></td>\n        <td style="background-color:#1d1b10"><span></span></td>\n        <td style="background-color:#0f243e"><span></span></td>\n        <td style="background-color:#244061"><span></span></td>\n        <td style="background-color:#632423"><span></span></td>\n        <td style="background-color:#4f6128"><span></span></td>\n        <td style="background-color:#3f3151"><span></span></td>\n        <td style="background-color:#205867"><span></span></td>\n        <td style="background-color:#974806"><span></span></td>\n      </tr>\n       <tr>\n        <th colspan="10"></th>\n      </tr>\n      <tr>\n        <th colspan="10" class="ui-widget-content">Standard Colors</th>\n      </tr>\n      <tr>\n        <td style="background-color:#c00000"><span></span></td>\n        <td style="background-color:#ff0000"><span></span></td>\n        <td style="background-color:#ffc000"><span></span></td>\n        <td style="background-color:#ffff00"><span></span></td>\n        <td style="background-color:#92d050"><span></span></td>\n        <td style="background-color:#00b050"><span></span></td>\n        <td style="background-color:#00b0f0"><span></span></td>\n        <td style="background-color:#0070c0"><span></span></td>\n        <td style="background-color:#002060"><span></span></td>\n        <td style="background-color:#7030a0"><span></span></td>\n      </tr>\n      <tr>\n      <th colspan="10" class="ui-widget-content">Custom Font Colors</th>\n    </tr>\n    <tr>\n      <td style="background-color:${e.settings.custom_fc1}"><span></span></td>\n      <td style="background-color:${e.settings.custom_fc2}"><span></span></td>\n      <td style="background-color:${e.settings.custom_fc3}"><span></span></td>\n      <td style="background-color:${e.settings.custom_fc4}"><span></span></td>\n      <td style="background-color:${e.settings.custom_fc5}"><span></span></td>\n    </tr>\n    </tbody>\n  </table>\n</div>\n</div>`;
            })(i)),
              a.buttonEl.insertAdjacentElement("afterbegin", l),
              ba(t, i, "x-color-picker-table"));
            let o = l.querySelector(".x-color-picker-wrapper");
            (new e.ButtonComponent(o)
              .setIcon("paintbrush")
              .setTooltip(Xr("Format Brush"))
              .onClick(() => {
                (wa(i),
                  i.setEN_FontColor_Format_Brush(!0),
                  (i.Temp_Notice = new e.Notice(
                    Xr("Font-Color formatting brush ON!"),
                    0,
                  )));
              }),
              new e.ButtonComponent(o)
                .setIcon("palette")
                .setTooltip(Xr("Custom Font Color"))
                .onClick(() => {
                  (t.setting.open(),
                    t.setting.openTabById("toolbar"),
                    setTimeout(() => {
                      const e =
                        t.setting.activeTab.containerEl.querySelector(
                          ".toolbar-tabs",
                        );
                      if (e) {
                        const i = e.children[1];
                        (i?.click(),
                          setTimeout(() => {
                            let e =
                              t.setting.activeTab.containerEl.querySelector(
                                ".custom_font",
                              );
                            e && e.addClass?.("toolbar-cta");
                          }, 100));
                      }
                    }, 200));
                }));
          }
        } else if ("toolbar:change-background-color" == o.id) {
          let a = new e.ButtonComponent(p);
          (a
            .setClass("editingToolbarCommandsubItem-font-color")
            .setTooltip(Xr("Background Color"))
            .onClick(() => {
              t.commands.executeCommandById(o.id);
              const e = i.commandsManager.getActiveEditor(),
                r = e && e.somethingSelected();
              0 == n.cMenuVisibility
                ? (p.style.visibility = "hidden")
                : "following" === s
                  ? r || (p.style.visibility = "hidden")
                  : (p.style.visibility = "visible");
            }),
            fa(o.icon) ? (a.buttonEl.innerHTML = o.icon) : a.setIcon(o.icon),
            (r += u));
          let l = createEl("div");
          if ((l.addClass("subitem"), l)) {
            ((l.innerHTML = (function (e) {
              return `<div class='x-color-picker-wrapper'>\n<div class='x-color-picker' >\n  <table class="x-color-picker-table" id='x-backgroundcolor-picker-table'>\n    <tbody>\n      <tr>\n        <th colspan="5" class="ui-widget-content">Translucent Colors</th>\n      </tr>\n      <tr class="top">\n        <td style="background-color:rgba(140, 140, 140, 0.12)"><span></span></td>\n        <td style="background-color:rgba(92, 92, 92, 0.2)"><span></span></td>\n        <td style="background-color:rgba(163, 67, 31, 0.2)"><span></span></td>\n        <td style="background-color:rgba(240, 107, 5, 0.2)"><span></span></td>\n        <td style="background-color:rgba(240, 200, 0, 0.2)"><span></span></td>\n        </tr>\n        <tr class="bottom">\n        <td style="background-color:rgba(3, 135, 102, 0.2)"><span></span></td>\n        <td style="background-color:rgba(3, 135, 102, 0.2)"><span></span></td>\n        <td style="background-color:rgba(5, 117, 197, 0.2)"><span></span></td>\n        <td style="background-color:rgba(74, 82, 199, 0.2)"><span></span></td>\n        <td style="background-color:rgba(136, 49, 204, 0.2)"><span></span></td>\n      </tr>\n\n      <tr>\n      <th colspan="5" class="ui-widget-content">Highlighter Colors</th>\n    </tr>\n    \n    <tr class="top">\n      <td style="background-color:rgb(255, 248, 143)"><span></span></td>\n      <td style="background-color:rgb(211, 248, 182)"><span></span></td>\n      <td style="background-color:rgb(175, 250, 209)"><span></span></td>\n      <td style="background-color:rgb(177, 255, 255)"><span></span></td>\n      <td style="background-color:rgb(253, 191, 255)"><span></span></td>\n      </tr>\n      <tr class="bottom">\n      <td style="background-color:rgb(210, 203, 255);"><span></span></td>\n      <td style="background-color:rgb(64, 169, 255);"><span></span></td>\n      <td style="background-color:rgb(255, 77, 79);"><span></span></td>\n      <td style="background-color:rgb(212, 177, 6);"><span></span></td>\n      <td style="background-color:rgb(146, 84, 222);"><span></span></td>\n    </tr>\n    <tr>\n    <th colspan="5" class="ui-widget-content">Custom Colors</th>\n  </tr>\n    <tr class="bottom">\n    <td style="background-color: ${e.settings.custom_bg1};"><span></span></td>\n    <td style="background-color:${e.settings.custom_bg2};"><span></span></td>\n    <td style="background-color:${e.settings.custom_bg3};"><span></span></td>\n    <td style="background-color:${e.settings.custom_bg4};"><span></span></td>\n    <td style="background-color:${e.settings.custom_bg5};"><span></span></td>\n  </tr>\n    </tbody>\n  </table>\n</div>\n</div>`;
            })(i)),
              a.buttonEl.insertAdjacentElement("afterbegin", l),
              ba(t, i, "x-backgroundcolor-picker-table"));
            let o = l.querySelector(".x-color-picker-wrapper");
            (new e.ButtonComponent(o)
              .setIcon("paintbrush")
              .setTooltip(Xr("Format Brush"))
              .onClick(() => {
                (wa(i),
                  i.setEN_BG_Format_Brush(!0),
                  (i.Temp_Notice = new e.Notice(
                    Xr("Font-Color formatting brush ON!"),
                    0,
                  )));
              }),
              new e.ButtonComponent(o)
                .setIcon("palette")
                .setTooltip(Xr("Custom Backgroud Color"))
                .onClick(() => {
                  (t.setting.open(),
                    t.setting.openTabById("toolbar"),
                    setTimeout(() => {
                      const e =
                        t.setting.activeTab.containerEl.querySelector(
                          ".toolbar-tabs",
                        );
                      if (e) {
                        const i = e.children[1];
                        (i?.click(),
                          setTimeout(() => {
                            let e =
                              t.setting.activeTab.containerEl.querySelector(
                                ".custom_bg",
                              );
                            e && e.addClass?.("toolbar-cta");
                          }, 100));
                      }
                    }, 200));
                }));
          }
        } else {
          let c;
          r >= h - 7 * u && h > 100
            ? (i.setIS_MORE_Button(!0), (c = new e.ButtonComponent(g)))
            : (c = new e.ButtonComponent(p));
          let d = ga(t, o.id);
          ((l = "–" == d ? o.name : o.name + "(" + d + ")"),
            c.setTooltip(l).onClick(() => {
              t.commands.executeCommandById(o.id);
              const e = i.commandsManager.getActiveEditor(),
                r = e && e.somethingSelected();
              0 == n.cMenuVisibility
                ? (p.style.visibility = "hidden")
                : "following" === s
                  ? r || (p.style.visibility = "hidden")
                  : (p.style.visibility = "visible");
            }),
            c.setClass("editingToolbarCommandItem"),
            a >= n.cMenuNumRows
              ? c.setClass("editingToolbarSecond")
              : "top" !== s &&
                c.buttonEl.setAttribute("aria-label-position", "top"),
            "editingToolbar-Divider-Line" == o.id &&
              c.setClass("editingToolbar-Divider-Line"),
            fa(o.icon) ? (c.buttonEl.innerHTML = o.icon) : c.setIcon(o.icon),
            (r += u));
        }
      }),
        (function (t, i, o) {
          const n = t.workspace.getActiveViewOfType(e.ItemView);
          if (!la.isAllowedViewType(n)) return;
          let s = n.containerEl.querySelector("#editingToolbarPopoverBar");
          if (!i.IS_MORE_Button) return;
          let r = o.createEl("span");
          r.addClass("more-menu");
          let a = new e.ButtonComponent(r);
          (a
            .setClass("editingToolbarCommandItem")
            .setTooltip(Xr("More"))
            .onClick(() => {
              "hidden" == s.style.visibility
                ? ((s.style.visibility = "visible"), (s.style.height = "32px"))
                : ((s.style.visibility = "hidden"), (s.style.height = "0"));
            }),
            (a.buttonEl.innerHTML =
              '<svg  width="14" height="14"  version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" enable-background="new 0 0 1024 1024" xml:space="preserve"><path fill="#666" d="M510.29 14.13 q17.09 -15.07 40.2 -14.07 q23.12 1 39.2 18.08 l334.66 385.92 q25.12 30.15 34.16 66.83 q9.04 36.68 0.5 73.87 q-8.54 37.19 -32.66 67.34 l-335.67 390.94 q-15.07 18.09 -38.69 20.1 q-23.62 2.01 -41.71 -13.07 q-18.08 -15.08 -20.09 -38.19 q-2.01 -23.12 13.06 -41.21 l334.66 -390.94 q11.06 -13.06 11.56 -29.65 q0.5 -16.58 -10.55 -29.64 l-334.67 -386.92 q-15.07 -17.09 -13.56 -40.7 q1.51 -23.62 19.59 -38.7 ZM81.17 14.13 q17.08 -15.07 40.19 -14.07 q23.11 1 39.2 18.08 l334.66 385.92 q25.12 30.15 34.16 66.83 q9.04 36.68 0.5 73.87 q-8.54 37.19 -32.66 67.34 l-335.67 390.94 q-15.07 18.09 -38.69 20.6 q-23.61 2.51 -41.7 -12.57 q-18.09 -15.08 -20.1 -38.69 q-2.01 -23.62 13.06 -41.71 l334.66 -390.94 q11.06 -13.06 11.56 -29.65 q0.5 -16.58 -10.55 -29.64 l-334.66 -386.92 q-15.08 -17.09 -13.57 -40.7 q1.51 -23.62 19.6 -38.7 Z"/></svg>'),
            i.setIS_MORE_Button(!1));
        })(t, i, p),
        Math.abs(i.settings.cMenuWidth - Number(r)) > r + 4 &&
          ((i.settings.cMenuWidth = Number(r)),
          setTimeout(() => {
            i.saveSettings();
          }, 100)));
    };
    if (!i.isLoadMobile()) return;
    const u = t.workspace.getActiveViewOfType(e.ItemView);
    if (la.isAllowedViewType(u)) {
      const o = ua(t, i, s);
      if (o && "top" !== s)
        return (
          n.cMenuVisibility
            ? "following" === s
              ? ((o.style.visibility = "hidden"), (o.style.display = ""))
              : ((o.style.visibility = "visible"), (o.style.display = ""))
            : (o.style.display = "none"),
          c && o.style.setProperty("--toolbar-background-color", c),
          d && o.style.setProperty("--toolbar-icon-color", d),
          void (a && o.style.setProperty("--toolbar-icon-size", `${a}px`))
        );
      if ((r(), "top" !== s)) {
        const e = ua(t, i, s);
        e && i.setCachedToolbar(s, e);
      }
      (Yr(i.settings),
        jr(i.settings),
        (function (t, i) {
          ca = e.requireApiVersion("0.15.0")
            ? activeWindow.document
            : window.document;
          const o = ca.querySelectorAll("#change-font-color-icon"),
            n = ca.querySelectorAll("#change-background-color-icon");
          o.length > 0 &&
            o.forEach((e) => {
              e.style.fill = t;
            });
          n.length > 0 &&
            n.forEach((e) => {
              e.style.fill = i;
            });
        })(
          /**!
           * Sortable 1.15.6
           * @author	RubaXa   <trash@rubaxa.org>
           * @author	owenm    <owen23355@gmail.com>
           * @license MIT
           */ n.cMenuFontColor,
          n.cMenuBackgroundColor,
        ));
    }
  })();
}
function ka(e, t) {
  var i = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var o = Object.getOwnPropertySymbols(e);
    (t &&
      (o = o.filter(function (t) {
        return Object.getOwnPropertyDescriptor(e, t).enumerable;
      })),
      i.push.apply(i, o));
  }
  return i;
}
function Sa(e) {
  for (var t = 1; t < arguments.length; t++) {
    var i = null != arguments[t] ? arguments[t] : {};
    t % 2
      ? ka(Object(i), !0).forEach(function (t) {
          Ea(e, t, i[t]);
        })
      : Object.getOwnPropertyDescriptors
        ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(i))
        : ka(Object(i)).forEach(function (t) {
            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(i, t));
          });
  }
  return e;
}
function Ta(e) {
  return (
    (Ta =
      "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
        ? function (e) {
            return typeof e;
          }
        : function (e) {
            return e &&
              "function" == typeof Symbol &&
              e.constructor === Symbol &&
              e !== Symbol.prototype
              ? "symbol"
              : typeof e;
          }),
    Ta(e)
  );
}
function Ea(e, t, i) {
  return (
    t in e
      ? Object.defineProperty(e, t, {
          value: i,
          enumerable: !0,
          configurable: !0,
          writable: !0,
        })
      : (e[t] = i),
    e
  );
}
function Ma() {
  return (
    (Ma =
      Object.assign ||
      function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var i = arguments[t];
          for (var o in i)
            Object.prototype.hasOwnProperty.call(i, o) && (e[o] = i[o]);
        }
        return e;
      }),
    Ma.apply(this, arguments)
  );
}
function Aa(e, t) {
  if (null == e) return {};
  var i,
    o,
    n = (function (e, t) {
      if (null == e) return {};
      var i,
        o,
        n = {},
        s = Object.keys(e);
      for (o = 0; o < s.length; o++)
        ((i = s[o]), t.indexOf(i) >= 0 || (n[i] = e[i]));
      return n;
    })(e, t);
  if (Object.getOwnPropertySymbols) {
    var s = Object.getOwnPropertySymbols(e);
    for (o = 0; o < s.length; o++)
      ((i = s[o]),
        t.indexOf(i) >= 0 ||
          (Object.prototype.propertyIsEnumerable.call(e, i) && (n[i] = e[i])));
  }
  return n;
}
function Ia(e) {
  if ("undefined" != typeof window && window.navigator)
    return !!navigator.userAgent.match(e);
}
var Da = Ia(/(?:Trident.*rv[ :]?11\.|msie|iemobile|Windows Phone)/i),
  Oa = Ia(/Edge/i),
  Ba = Ia(/firefox/i),
  La = Ia(/safari/i) && !Ia(/chrome/i) && !Ia(/android/i),
  Pa = Ia(/iP(ad|od|hone)/i),
  Na = Ia(/chrome/i) && Ia(/android/i),
  Ra = { capture: !1, passive: !1 };
function Fa(e, t, i) {
  e.addEventListener(t, i, !Da && Ra);
}
function qa(e, t, i) {
  e.removeEventListener(t, i, !Da && Ra);
}
function _a(e, t) {
  if (t) {
    if ((">" === t[0] && (t = t.substring(1)), e))
      try {
        if (e.matches) return e.matches(t);
        if (e.msMatchesSelector) return e.msMatchesSelector(t);
        if (e.webkitMatchesSelector) return e.webkitMatchesSelector(t);
      } catch (e) {
        return !1;
      }
    return !1;
  }
}
function za(e) {
  return e.host && e !== document && e.host.nodeType ? e.host : e.parentNode;
}
function Va(e, t, i, o) {
  if (e) {
    i = i || document;
    do {
      if (
        (null != t &&
          (">" === t[0] ? e.parentNode === i && _a(e, t) : _a(e, t))) ||
        (o && e === i)
      )
        return e;
      if (e === i) break;
    } while ((e = za(e)));
  }
  return null;
}
var Wa,
  Ha = /\s+/g;
function $a(e, t, i) {
  if (e && t)
    if (e.classList) e.classList[i ? "add" : "remove"](t);
    else {
      var o = (" " + e.className + " ")
        .replace(Ha, " ")
        .replace(" " + t + " ", " ");
      e.className = (o + (i ? " " + t : "")).replace(Ha, " ");
    }
}
function Ua(e, t, i) {
  var o = e && e.style;
  if (o) {
    if (void 0 === i)
      return (
        document.defaultView && document.defaultView.getComputedStyle
          ? (i = document.defaultView.getComputedStyle(e, ""))
          : e.currentStyle && (i = e.currentStyle),
        void 0 === t ? i : i[t]
      );
    (t in o || -1 !== t.indexOf("webkit") || (t = "-webkit-" + t),
      (o[t] = i + ("string" == typeof i ? "" : "px")));
  }
}
function ja(e, t) {
  var i = "";
  if ("string" == typeof e) i = e;
  else
    do {
      var o = Ua(e, "transform");
      o && "none" !== o && (i = o + " " + i);
    } while (!t && (e = e.parentNode));
  var n =
    window.DOMMatrix ||
    window.WebKitCSSMatrix ||
    window.CSSMatrix ||
    window.MSCSSMatrix;
  return n && new n(i);
}
function Ya(e, t, i) {
  if (e) {
    var o = e.getElementsByTagName(t),
      n = 0,
      s = o.length;
    if (i) for (; n < s; n++) i(o[n], n);
    return o;
  }
  return [];
}
function Ga() {
  var e = document.scrollingElement;
  return e || document.documentElement;
}
function Za(e, t, i, o, n) {
  if (e.getBoundingClientRect || e === window) {
    var s, r, a, l, c, d, h;
    if (
      (e !== window && e.parentNode && e !== Ga()
        ? ((r = (s = e.getBoundingClientRect()).top),
          (a = s.left),
          (l = s.bottom),
          (c = s.right),
          (d = s.height),
          (h = s.width))
        : ((r = 0),
          (a = 0),
          (l = window.innerHeight),
          (c = window.innerWidth),
          (d = window.innerHeight),
          (h = window.innerWidth)),
      (t || i) && e !== window && ((n = n || e.parentNode), !Da))
    )
      do {
        if (
          n &&
          n.getBoundingClientRect &&
          ("none" !== Ua(n, "transform") ||
            (i && "static" !== Ua(n, "position")))
        ) {
          var u = n.getBoundingClientRect();
          ((r -= u.top + parseInt(Ua(n, "border-top-width"))),
            (a -= u.left + parseInt(Ua(n, "border-left-width"))),
            (l = r + s.height),
            (c = a + s.width));
          break;
        }
      } while ((n = n.parentNode));
    if (o && e !== window) {
      var p = ja(n || e),
        m = p && p.a,
        g = p && p.d;
      p && ((l = (r /= g) + (d /= g)), (c = (a /= m) + (h /= m)));
    }
    return { top: r, left: a, bottom: l, right: c, width: h, height: d };
  }
}
function Ka(e, t, i) {
  for (var o = tl(e, !0), n = Za(e)[t]; o; ) {
    var s = Za(o)[i];
    if (!("top" === i || "left" === i ? n >= s : n <= s)) return o;
    if (o === Ga()) break;
    o = tl(o, !1);
  }
  return !1;
}
function Ja(e, t, i, o) {
  for (var n = 0, s = 0, r = e.children; s < r.length; ) {
    if (
      "none" !== r[s].style.display &&
      r[s] !== sc.ghost &&
      (o || r[s] !== sc.dragged) &&
      Va(r[s], i.draggable, e, !1)
    ) {
      if (n === t) return r[s];
      n++;
    }
    s++;
  }
  return null;
}
function Xa(e, t) {
  for (
    var i = e.lastElementChild;
    i && (i === sc.ghost || "none" === Ua(i, "display") || (t && !_a(i, t)));
  )
    i = i.previousElementSibling;
  return i || null;
}
function Qa(e, t) {
  var i = 0;
  if (!e || !e.parentNode) return -1;
  for (; (e = e.previousElementSibling); )
    "TEMPLATE" === e.nodeName.toUpperCase() ||
      e === sc.clone ||
      (t && !_a(e, t)) ||
      i++;
  return i;
}
function el(e) {
  var t = 0,
    i = 0,
    o = Ga();
  if (e)
    do {
      var n = ja(e),
        s = n.a,
        r = n.d;
      ((t += e.scrollLeft * s), (i += e.scrollTop * r));
    } while (e !== o && (e = e.parentNode));
  return [t, i];
}
function tl(e, t) {
  if (!e || !e.getBoundingClientRect) return Ga();
  var i = e,
    o = !1;
  do {
    if (i.clientWidth < i.scrollWidth || i.clientHeight < i.scrollHeight) {
      var n = Ua(i);
      if (
        (i.clientWidth < i.scrollWidth &&
          ("auto" == n.overflowX || "scroll" == n.overflowX)) ||
        (i.clientHeight < i.scrollHeight &&
          ("auto" == n.overflowY || "scroll" == n.overflowY))
      ) {
        if (!i.getBoundingClientRect || i === document.body) return Ga();
        if (o || t) return i;
        o = !0;
      }
    }
  } while ((i = i.parentNode));
  return Ga();
}
function il(e, t) {
  return (
    Math.round(e.top) === Math.round(t.top) &&
    Math.round(e.left) === Math.round(t.left) &&
    Math.round(e.height) === Math.round(t.height) &&
    Math.round(e.width) === Math.round(t.width)
  );
}
function ol(e, t) {
  return function () {
    if (!Wa) {
      var i = arguments;
      (1 === i.length ? e.call(this, i[0]) : e.apply(this, i),
        (Wa = setTimeout(function () {
          Wa = void 0;
        }, t)));
    }
  };
}
function nl(e, t, i) {
  ((e.scrollLeft += t), (e.scrollTop += i));
}
function sl(e) {
  var t = window.Polymer,
    i = window.jQuery || window.Zepto;
  return t && t.dom
    ? t.dom(e).cloneNode(!0)
    : i
      ? i(e).clone(!0)[0]
      : e.cloneNode(!0);
}
function rl(e, t, i) {
  var o = {};
  return (
    Array.from(e.children).forEach(function (n) {
      var s, r, a, l;
      if (Va(n, t.draggable, e, !1) && !n.animated && n !== i) {
        var c = Za(n);
        ((o.left = Math.min(
          null !== (s = o.left) && void 0 !== s ? s : 1 / 0,
          c.left,
        )),
          (o.top = Math.min(
            null !== (r = o.top) && void 0 !== r ? r : 1 / 0,
            c.top,
          )),
          (o.right = Math.max(
            null !== (a = o.right) && void 0 !== a ? a : -1 / 0,
            c.right,
          )),
          (o.bottom = Math.max(
            null !== (l = o.bottom) && void 0 !== l ? l : -1 / 0,
            c.bottom,
          )));
      }
    }),
    (o.width = o.right - o.left),
    (o.height = o.bottom - o.top),
    (o.x = o.left),
    (o.y = o.top),
    o
  );
}
var al = "Sortable" + new Date().getTime();
function ll() {
  var e,
    t = [];
  return {
    captureAnimationState: function () {
      ((t = []), this.options.animation) &&
        [].slice.call(this.el.children).forEach(function (e) {
          if ("none" !== Ua(e, "display") && e !== sc.ghost) {
            t.push({ target: e, rect: Za(e) });
            var i = Sa({}, t[t.length - 1].rect);
            if (e.thisAnimationDuration) {
              var o = ja(e, !0);
              o && ((i.top -= o.f), (i.left -= o.e));
            }
            e.fromRect = i;
          }
        });
    },
    addAnimationState: function (e) {
      t.push(e);
    },
    removeAnimationState: function (e) {
      t.splice(
        (function (e, t) {
          for (var i in e)
            if (e.hasOwnProperty(i))
              for (var o in t)
                if (t.hasOwnProperty(o) && t[o] === e[i][o]) return Number(i);
          return -1;
        })(t, { target: e }),
        1,
      );
    },
    animateAll: function (i) {
      var o = this;
      if (!this.options.animation)
        return (clearTimeout(e), void ("function" == typeof i && i()));
      var n = !1,
        s = 0;
      (t.forEach(function (e) {
        var t = 0,
          i = e.target,
          r = i.fromRect,
          a = Za(i),
          l = i.prevFromRect,
          c = i.prevToRect,
          d = e.rect,
          h = ja(i, !0);
        (h && ((a.top -= h.f), (a.left -= h.e)),
          (i.toRect = a),
          i.thisAnimationDuration &&
            il(l, a) &&
            !il(r, a) &&
            (d.top - a.top) / (d.left - a.left) ===
              (r.top - a.top) / (r.left - a.left) &&
            (t = (function (e, t, i, o) {
              return (
                (Math.sqrt(
                  Math.pow(t.top - e.top, 2) + Math.pow(t.left - e.left, 2),
                ) /
                  Math.sqrt(
                    Math.pow(t.top - i.top, 2) + Math.pow(t.left - i.left, 2),
                  )) *
                o.animation
              );
            })(d, l, c, o.options)),
          il(a, r) ||
            ((i.prevFromRect = r),
            (i.prevToRect = a),
            t || (t = o.options.animation),
            o.animate(i, d, a, t)),
          t &&
            ((n = !0),
            (s = Math.max(s, t)),
            clearTimeout(i.animationResetTimer),
            (i.animationResetTimer = setTimeout(function () {
              ((i.animationTime = 0),
                (i.prevFromRect = null),
                (i.fromRect = null),
                (i.prevToRect = null),
                (i.thisAnimationDuration = null));
            }, t)),
            (i.thisAnimationDuration = t)));
      }),
        clearTimeout(e),
        n
          ? (e = setTimeout(function () {
              "function" == typeof i && i();
            }, s))
          : "function" == typeof i && i(),
        (t = []));
    },
    animate: function (e, t, i, o) {
      if (o) {
        (Ua(e, "transition", ""), Ua(e, "transform", ""));
        var n = ja(this.el),
          s = n && n.a,
          r = n && n.d,
          a = (t.left - i.left) / (s || 1),
          l = (t.top - i.top) / (r || 1);
        ((e.animatingX = !!a),
          (e.animatingY = !!l),
          Ua(e, "transform", "translate3d(" + a + "px," + l + "px,0)"),
          (this.forRepaintDummy = (function (e) {
            return e.offsetWidth;
          })(e)),
          Ua(
            e,
            "transition",
            "transform " +
              o +
              "ms" +
              (this.options.easing ? " " + this.options.easing : ""),
          ),
          Ua(e, "transform", "translate3d(0,0,0)"),
          "number" == typeof e.animated && clearTimeout(e.animated),
          (e.animated = setTimeout(function () {
            (Ua(e, "transition", ""),
              Ua(e, "transform", ""),
              (e.animated = !1),
              (e.animatingX = !1),
              (e.animatingY = !1));
          }, o)));
      }
    },
  };
}
var cl = [],
  dl = { initializeByDefault: !0 },
  hl = {
    mount: function (e) {
      for (var t in dl) dl.hasOwnProperty(t) && !(t in e) && (e[t] = dl[t]);
      (cl.forEach(function (t) {
        if (t.pluginName === e.pluginName)
          throw "Sortable: Cannot mount plugin ".concat(
            e.pluginName,
            " more than once",
          );
      }),
        cl.push(e));
    },
    pluginEvent: function (e, t, i) {
      var o = this;
      ((this.eventCanceled = !1),
        (i.cancel = function () {
          o.eventCanceled = !0;
        }));
      var n = e + "Global";
      cl.forEach(function (o) {
        t[o.pluginName] &&
          (t[o.pluginName][n] && t[o.pluginName][n](Sa({ sortable: t }, i)),
          t.options[o.pluginName] &&
            t[o.pluginName][e] &&
            t[o.pluginName][e](Sa({ sortable: t }, i)));
      });
    },
    initializePlugins: function (e, t, i, o) {
      for (var n in (cl.forEach(function (o) {
        var n = o.pluginName;
        if (e.options[n] || o.initializeByDefault) {
          var s = new o(e, t, e.options);
          ((s.sortable = e),
            (s.options = e.options),
            (e[n] = s),
            Ma(i, s.defaults));
        }
      }),
      e.options))
        if (e.options.hasOwnProperty(n)) {
          var s = this.modifyOption(e, n, e.options[n]);
          void 0 !== s && (e.options[n] = s);
        }
    },
    getEventProperties: function (e, t) {
      var i = {};
      return (
        cl.forEach(function (o) {
          "function" == typeof o.eventProperties &&
            Ma(i, o.eventProperties.call(t[o.pluginName], e));
        }),
        i
      );
    },
    modifyOption: function (e, t, i) {
      var o;
      return (
        cl.forEach(function (n) {
          e[n.pluginName] &&
            n.optionListeners &&
            "function" == typeof n.optionListeners[t] &&
            (o = n.optionListeners[t].call(e[n.pluginName], i));
        }),
        o
      );
    },
  };
var ul = ["evt"],
  pl = function (e, t) {
    var i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
      o = i.evt,
      n = Aa(i, ul);
    hl.pluginEvent.bind(sc)(
      e,
      t,
      Sa(
        {
          dragEl: gl,
          parentEl: fl,
          ghostEl: bl,
          rootEl: yl,
          nextEl: wl,
          lastDownEl: vl,
          cloneEl: Cl,
          cloneHidden: xl,
          dragStarted: Nl,
          putSortable: Al,
          activeSortable: sc.active,
          originalEvent: o,
          oldIndex: kl,
          oldDraggableIndex: Tl,
          newIndex: Sl,
          newDraggableIndex: El,
          hideGhostForTarget: tc,
          unhideGhostForTarget: ic,
          cloneNowHidden: function () {
            xl = !0;
          },
          cloneNowShown: function () {
            xl = !1;
          },
          dispatchSortableEvent: function (e) {
            ml({ sortable: t, name: e, originalEvent: o });
          },
        },
        n,
      ),
    );
  };
function ml(e) {
  !(function (e) {
    var t = e.sortable,
      i = e.rootEl,
      o = e.name,
      n = e.targetEl,
      s = e.cloneEl,
      r = e.toEl,
      a = e.fromEl,
      l = e.oldIndex,
      c = e.newIndex,
      d = e.oldDraggableIndex,
      h = e.newDraggableIndex,
      u = e.originalEvent,
      p = e.putSortable,
      m = e.extraEventProperties;
    if ((t = t || (i && i[al]))) {
      var g,
        f = t.options,
        b = "on" + o.charAt(0).toUpperCase() + o.substr(1);
      (!window.CustomEvent || Da || Oa
        ? (g = document.createEvent("Event")).initEvent(o, !0, !0)
        : (g = new CustomEvent(o, { bubbles: !0, cancelable: !0 })),
        (g.to = r || i),
        (g.from = a || i),
        (g.item = n || i),
        (g.clone = s),
        (g.oldIndex = l),
        (g.newIndex = c),
        (g.oldDraggableIndex = d),
        (g.newDraggableIndex = h),
        (g.originalEvent = u),
        (g.pullMode = p ? p.lastPutMode : void 0));
      var y = Sa(Sa({}, m), hl.getEventProperties(o, t));
      for (var w in y) g[w] = y[w];
      (i && i.dispatchEvent(g), f[b] && f[b].call(t, g));
    }
  })(
    Sa(
      {
        putSortable: Al,
        cloneEl: Cl,
        targetEl: gl,
        rootEl: yl,
        oldIndex: kl,
        oldDraggableIndex: Tl,
        newIndex: Sl,
        newDraggableIndex: El,
      },
      e,
    ),
  );
}
var gl,
  fl,
  bl,
  yl,
  wl,
  vl,
  Cl,
  xl,
  kl,
  Sl,
  Tl,
  El,
  Ml,
  Al,
  Il,
  Dl,
  Ol,
  Bl,
  Ll,
  Pl,
  Nl,
  Rl,
  Fl,
  ql,
  _l,
  zl = !1,
  Vl = !1,
  Wl = [],
  Hl = !1,
  $l = !1,
  Ul = [],
  jl = !1,
  Yl = [],
  Gl = "undefined" != typeof document,
  Zl = Pa,
  Kl = Oa || Da ? "cssFloat" : "float",
  Jl = Gl && !Na && !Pa && "draggable" in document.createElement("div"),
  Xl = (function () {
    if (Gl) {
      if (Da) return !1;
      var e = document.createElement("x");
      return (
        (e.style.cssText = "pointer-events:auto"),
        "auto" === e.style.pointerEvents
      );
    }
  })(),
  Ql = function (e, t) {
    var i = Ua(e),
      o =
        parseInt(i.width) -
        parseInt(i.paddingLeft) -
        parseInt(i.paddingRight) -
        parseInt(i.borderLeftWidth) -
        parseInt(i.borderRightWidth),
      n = Ja(e, 0, t),
      s = Ja(e, 1, t),
      r = n && Ua(n),
      a = s && Ua(s),
      l = r && parseInt(r.marginLeft) + parseInt(r.marginRight) + Za(n).width,
      c = a && parseInt(a.marginLeft) + parseInt(a.marginRight) + Za(s).width;
    if ("flex" === i.display)
      return "column" === i.flexDirection ||
        "column-reverse" === i.flexDirection
        ? "vertical"
        : "horizontal";
    if ("grid" === i.display)
      return i.gridTemplateColumns.split(" ").length <= 1
        ? "vertical"
        : "horizontal";
    if (n && r.float && "none" !== r.float) {
      var d = "left" === r.float ? "left" : "right";
      return !s || ("both" !== a.clear && a.clear !== d)
        ? "horizontal"
        : "vertical";
    }
    return n &&
      ("block" === r.display ||
        "flex" === r.display ||
        "table" === r.display ||
        "grid" === r.display ||
        (l >= o && "none" === i[Kl]) ||
        (s && "none" === i[Kl] && l + c > o))
      ? "vertical"
      : "horizontal";
  },
  ec = function (e) {
    function t(e, i) {
      return function (o, n, s, r) {
        var a =
          o.options.group.name &&
          n.options.group.name &&
          o.options.group.name === n.options.group.name;
        if (null == e && (i || a)) return !0;
        if (null == e || !1 === e) return !1;
        if (i && "clone" === e) return e;
        if ("function" == typeof e) return t(e(o, n, s, r), i)(o, n, s, r);
        var l = (i ? o : n).options.group.name;
        return (
          !0 === e ||
          ("string" == typeof e && e === l) ||
          (e.join && e.indexOf(l) > -1)
        );
      };
    }
    var i = {},
      o = e.group;
    ((o && "object" == Ta(o)) || (o = { name: o }),
      (i.name = o.name),
      (i.checkPull = t(o.pull, !0)),
      (i.checkPut = t(o.put)),
      (i.revertClone = o.revertClone),
      (e.group = i));
  },
  tc = function () {
    !Xl && bl && Ua(bl, "display", "none");
  },
  ic = function () {
    !Xl && bl && Ua(bl, "display", "");
  };
Gl &&
  !Na &&
  document.addEventListener(
    "click",
    function (e) {
      if (Vl)
        return (
          e.preventDefault(),
          e.stopPropagation && e.stopPropagation(),
          e.stopImmediatePropagation && e.stopImmediatePropagation(),
          (Vl = !1),
          !1
        );
    },
    !0,
  );
var oc = function (e) {
    if (gl) {
      e = e.touches ? e.touches[0] : e;
      var t =
        ((n = e.clientX),
        (s = e.clientY),
        Wl.some(function (e) {
          var t = e[al].options.emptyInsertThreshold;
          if (t && !Xa(e)) {
            var i = Za(e),
              o = n >= i.left - t && n <= i.right + t,
              a = s >= i.top - t && s <= i.bottom + t;
            return o && a ? (r = e) : void 0;
          }
        }),
        r);
      if (t) {
        var i = {};
        for (var o in e) e.hasOwnProperty(o) && (i[o] = e[o]);
        ((i.target = i.rootEl = t),
          (i.preventDefault = void 0),
          (i.stopPropagation = void 0),
          t[al]._onDragOver(i));
      }
    }
    var n, s, r;
  },
  nc = function (e) {
    gl && gl.parentNode[al]._isOutsideThisEl(e.target);
  };
function sc(e, t) {
  if (!e || !e.nodeType || 1 !== e.nodeType)
    throw "Sortable: `el` must be an HTMLElement, not ".concat(
      {}.toString.call(e),
    );
  ((this.el = e), (this.options = t = Ma({}, t)), (e[al] = this));
  var i = {
    group: null,
    sort: !0,
    disabled: !1,
    store: null,
    handle: null,
    draggable: /^[uo]l$/i.test(e.nodeName) ? ">li" : ">*",
    swapThreshold: 1,
    invertSwap: !1,
    invertedSwapThreshold: null,
    removeCloneOnHide: !0,
    direction: function () {
      return Ql(e, this.options);
    },
    ghostClass: "sortable-ghost",
    chosenClass: "sortable-chosen",
    dragClass: "sortable-drag",
    ignore: "a, img",
    filter: null,
    preventOnFilter: !0,
    animation: 0,
    easing: null,
    setData: function (e, t) {
      e.setData("Text", t.textContent);
    },
    dropBubble: !1,
    dragoverBubble: !1,
    dataIdAttr: "data-id",
    delay: 0,
    delayOnTouchOnly: !1,
    touchStartThreshold:
      (Number.parseInt ? Number : window).parseInt(
        window.devicePixelRatio,
        10,
      ) || 1,
    forceFallback: !1,
    fallbackClass: "sortable-fallback",
    fallbackOnBody: !1,
    fallbackTolerance: 0,
    fallbackOffset: { x: 0, y: 0 },
    supportPointer:
      !1 !== sc.supportPointer && "PointerEvent" in window && (!La || Pa),
    emptyInsertThreshold: 5,
  };
  for (var o in (hl.initializePlugins(this, e, i), i))
    !(o in t) && (t[o] = i[o]);
  for (var n in (ec(t), this))
    "_" === n.charAt(0) &&
      "function" == typeof this[n] &&
      (this[n] = this[n].bind(this));
  ((this.nativeDraggable = !t.forceFallback && Jl),
    this.nativeDraggable && (this.options.touchStartThreshold = 1),
    t.supportPointer
      ? Fa(e, "pointerdown", this._onTapStart)
      : (Fa(e, "mousedown", this._onTapStart),
        Fa(e, "touchstart", this._onTapStart)),
    this.nativeDraggable && (Fa(e, "dragover", this), Fa(e, "dragenter", this)),
    Wl.push(this.el),
    t.store && t.store.get && this.sort(t.store.get(this) || []),
    Ma(this, ll()));
}
function rc(e, t, i, o, n, s, r, a) {
  var l,
    c,
    d = e[al],
    h = d.options.onMove;
  return (
    !window.CustomEvent || Da || Oa
      ? (l = document.createEvent("Event")).initEvent("move", !0, !0)
      : (l = new CustomEvent("move", { bubbles: !0, cancelable: !0 })),
    (l.to = t),
    (l.from = e),
    (l.dragged = i),
    (l.draggedRect = o),
    (l.related = n || t),
    (l.relatedRect = s || Za(t)),
    (l.willInsertAfter = a),
    (l.originalEvent = r),
    e.dispatchEvent(l),
    h && (c = h.call(d, l, r)),
    c
  );
}
function ac(e) {
  e.draggable = !1;
}
function lc() {
  jl = !1;
}
function cc(e) {
  for (
    var t = e.tagName + e.className + e.src + e.href + e.textContent,
      i = t.length,
      o = 0;
    i--;
  )
    o += t.charCodeAt(i);
  return o.toString(36);
}
function dc(e) {
  return setTimeout(e, 0);
}
function hc(e) {
  return clearTimeout(e);
}
((sc.prototype = {
  constructor: sc,
  _isOutsideThisEl: function (e) {
    this.el.contains(e) || e === this.el || (Rl = null);
  },
  _getDirection: function (e, t) {
    return "function" == typeof this.options.direction
      ? this.options.direction.call(this, e, t, gl)
      : this.options.direction;
  },
  _onTapStart: function (e) {
    if (e.cancelable) {
      var t = this,
        i = this.el,
        o = this.options,
        n = o.preventOnFilter,
        s = e.type,
        r =
          (e.touches && e.touches[0]) ||
          (e.pointerType && "touch" === e.pointerType && e),
        a = (r || e).target,
        l =
          (e.target.shadowRoot &&
            ((e.path && e.path[0]) ||
              (e.composedPath && e.composedPath()[0]))) ||
          a,
        c = o.filter;
      if (
        ((function (e) {
          Yl.length = 0;
          var t = e.getElementsByTagName("input"),
            i = t.length;
          for (; i--; ) {
            var o = t[i];
            o.checked && Yl.push(o);
          }
        })(i),
        !gl &&
          !(
            (/mousedown|pointerdown/.test(s) && 0 !== e.button) ||
            o.disabled
          ) &&
          !l.isContentEditable &&
          (this.nativeDraggable ||
            !La ||
            !a ||
            "SELECT" !== a.tagName.toUpperCase()) &&
          !(((a = Va(a, o.draggable, i, !1)) && a.animated) || vl === a))
      ) {
        if (((kl = Qa(a)), (Tl = Qa(a, o.draggable)), "function" == typeof c)) {
          if (c.call(this, e, a, this))
            return (
              ml({
                sortable: t,
                rootEl: l,
                name: "filter",
                targetEl: a,
                toEl: i,
                fromEl: i,
              }),
              pl("filter", t, { evt: e }),
              void (n && e.preventDefault())
            );
        } else if (
          c &&
          (c = c.split(",").some(function (o) {
            if ((o = Va(l, o.trim(), i, !1)))
              return (
                ml({
                  sortable: t,
                  rootEl: o,
                  name: "filter",
                  targetEl: a,
                  fromEl: i,
                  toEl: i,
                }),
                pl("filter", t, { evt: e }),
                !0
              );
          }))
        )
          return void (n && e.preventDefault());
        (o.handle && !Va(l, o.handle, i, !1)) ||
          this._prepareDragStart(e, r, a);
      }
    }
  },
  _prepareDragStart: function (e, t, i) {
    var o,
      n = this,
      s = n.el,
      r = n.options,
      a = s.ownerDocument;
    if (i && !gl && i.parentNode === s) {
      var l = Za(i);
      if (
        ((yl = s),
        (fl = (gl = i).parentNode),
        (wl = gl.nextSibling),
        (vl = i),
        (Ml = r.group),
        (sc.dragged = gl),
        (Il = {
          target: gl,
          clientX: (t || e).clientX,
          clientY: (t || e).clientY,
        }),
        (Ll = Il.clientX - l.left),
        (Pl = Il.clientY - l.top),
        (this._lastX = (t || e).clientX),
        (this._lastY = (t || e).clientY),
        (gl.style["will-change"] = "all"),
        (o = function () {
          (pl("delayEnded", n, { evt: e }),
            sc.eventCanceled
              ? n._onDrop()
              : (n._disableDelayedDragEvents(),
                !Ba && n.nativeDraggable && (gl.draggable = !0),
                n._triggerDragStart(e, t),
                ml({ sortable: n, name: "choose", originalEvent: e }),
                $a(gl, r.chosenClass, !0)));
        }),
        r.ignore.split(",").forEach(function (e) {
          Ya(gl, e.trim(), ac);
        }),
        Fa(a, "dragover", oc),
        Fa(a, "mousemove", oc),
        Fa(a, "touchmove", oc),
        r.supportPointer
          ? (Fa(a, "pointerup", n._onDrop),
            !this.nativeDraggable && Fa(a, "pointercancel", n._onDrop))
          : (Fa(a, "mouseup", n._onDrop),
            Fa(a, "touchend", n._onDrop),
            Fa(a, "touchcancel", n._onDrop)),
        Ba &&
          this.nativeDraggable &&
          ((this.options.touchStartThreshold = 4), (gl.draggable = !0)),
        pl("delayStart", this, { evt: e }),
        !r.delay ||
          (r.delayOnTouchOnly && !t) ||
          (this.nativeDraggable && (Oa || Da)))
      )
        o();
      else {
        if (sc.eventCanceled) return void this._onDrop();
        (r.supportPointer
          ? (Fa(a, "pointerup", n._disableDelayedDrag),
            Fa(a, "pointercancel", n._disableDelayedDrag))
          : (Fa(a, "mouseup", n._disableDelayedDrag),
            Fa(a, "touchend", n._disableDelayedDrag),
            Fa(a, "touchcancel", n._disableDelayedDrag)),
          Fa(a, "mousemove", n._delayedDragTouchMoveHandler),
          Fa(a, "touchmove", n._delayedDragTouchMoveHandler),
          r.supportPointer &&
            Fa(a, "pointermove", n._delayedDragTouchMoveHandler),
          (n._dragStartTimer = setTimeout(o, r.delay)));
      }
    }
  },
  _delayedDragTouchMoveHandler: function (e) {
    var t = e.touches ? e.touches[0] : e;
    Math.max(
      Math.abs(t.clientX - this._lastX),
      Math.abs(t.clientY - this._lastY),
    ) >=
      Math.floor(
        this.options.touchStartThreshold /
          ((this.nativeDraggable && window.devicePixelRatio) || 1),
      ) && this._disableDelayedDrag();
  },
  _disableDelayedDrag: function () {
    (gl && ac(gl),
      clearTimeout(this._dragStartTimer),
      this._disableDelayedDragEvents());
  },
  _disableDelayedDragEvents: function () {
    var e = this.el.ownerDocument;
    (qa(e, "mouseup", this._disableDelayedDrag),
      qa(e, "touchend", this._disableDelayedDrag),
      qa(e, "touchcancel", this._disableDelayedDrag),
      qa(e, "pointerup", this._disableDelayedDrag),
      qa(e, "pointercancel", this._disableDelayedDrag),
      qa(e, "mousemove", this._delayedDragTouchMoveHandler),
      qa(e, "touchmove", this._delayedDragTouchMoveHandler),
      qa(e, "pointermove", this._delayedDragTouchMoveHandler));
  },
  _triggerDragStart: function (e, t) {
    ((t = t || ("touch" == e.pointerType && e)),
      !this.nativeDraggable || t
        ? this.options.supportPointer
          ? Fa(document, "pointermove", this._onTouchMove)
          : Fa(document, t ? "touchmove" : "mousemove", this._onTouchMove)
        : (Fa(gl, "dragend", this), Fa(yl, "dragstart", this._onDragStart)));
    try {
      document.selection
        ? dc(function () {
            document.selection.empty();
          })
        : window.getSelection().removeAllRanges();
    } catch (e) {}
  },
  _dragStarted: function (e, t) {
    if (((zl = !1), yl && gl)) {
      (pl("dragStarted", this, { evt: t }),
        this.nativeDraggable && Fa(document, "dragover", nc));
      var i = this.options;
      (!e && $a(gl, i.dragClass, !1),
        $a(gl, i.ghostClass, !0),
        (sc.active = this),
        e && this._appendGhost(),
        ml({ sortable: this, name: "start", originalEvent: t }));
    } else this._nulling();
  },
  _emulateDragOver: function () {
    if (Dl) {
      ((this._lastX = Dl.clientX), (this._lastY = Dl.clientY), tc());
      for (
        var e = document.elementFromPoint(Dl.clientX, Dl.clientY), t = e;
        e &&
        e.shadowRoot &&
        (e = e.shadowRoot.elementFromPoint(Dl.clientX, Dl.clientY)) !== t;
      )
        t = e;
      if ((gl.parentNode[al]._isOutsideThisEl(e), t))
        do {
          if (t[al]) {
            if (
              t[al]._onDragOver({
                clientX: Dl.clientX,
                clientY: Dl.clientY,
                target: e,
                rootEl: t,
              }) &&
              !this.options.dragoverBubble
            )
              break;
          }
          e = t;
        } while ((t = za(t)));
      ic();
    }
  },
  _onTouchMove: function (e) {
    if (Il) {
      var t = this.options,
        i = t.fallbackTolerance,
        o = t.fallbackOffset,
        n = e.touches ? e.touches[0] : e,
        s = bl && ja(bl, !0),
        r = bl && s && s.a,
        a = bl && s && s.d,
        l = Zl && _l && el(_l),
        c =
          (n.clientX - Il.clientX + o.x) / (r || 1) +
          (l ? l[0] - Ul[0] : 0) / (r || 1),
        d =
          (n.clientY - Il.clientY + o.y) / (a || 1) +
          (l ? l[1] - Ul[1] : 0) / (a || 1);
      if (!sc.active && !zl) {
        if (
          i &&
          Math.max(
            Math.abs(n.clientX - this._lastX),
            Math.abs(n.clientY - this._lastY),
          ) < i
        )
          return;
        this._onDragStart(e, !0);
      }
      if (bl) {
        s
          ? ((s.e += c - (Ol || 0)), (s.f += d - (Bl || 0)))
          : (s = { a: 1, b: 0, c: 0, d: 1, e: c, f: d });
        var h = "matrix("
          .concat(s.a, ",")
          .concat(s.b, ",")
          .concat(s.c, ",")
          .concat(s.d, ",")
          .concat(s.e, ",")
          .concat(s.f, ")");
        (Ua(bl, "webkitTransform", h),
          Ua(bl, "mozTransform", h),
          Ua(bl, "msTransform", h),
          Ua(bl, "transform", h),
          (Ol = c),
          (Bl = d),
          (Dl = n));
      }
      e.cancelable && e.preventDefault();
    }
  },
  _appendGhost: function () {
    if (!bl) {
      var e = this.options.fallbackOnBody ? document.body : yl,
        t = Za(gl, !0, Zl, !0, e),
        i = this.options;
      if (Zl) {
        for (
          _l = e;
          "static" === Ua(_l, "position") &&
          "none" === Ua(_l, "transform") &&
          _l !== document;
        )
          _l = _l.parentNode;
        (_l !== document.body && _l !== document.documentElement
          ? (_l === document && (_l = Ga()),
            (t.top += _l.scrollTop),
            (t.left += _l.scrollLeft))
          : (_l = Ga()),
          (Ul = el(_l)));
      }
      ($a((bl = gl.cloneNode(!0)), i.ghostClass, !1),
        $a(bl, i.fallbackClass, !0),
        $a(bl, i.dragClass, !0),
        Ua(bl, "transition", ""),
        Ua(bl, "transform", ""),
        Ua(bl, "box-sizing", "border-box"),
        Ua(bl, "margin", 0),
        Ua(bl, "top", t.top),
        Ua(bl, "left", t.left),
        Ua(bl, "width", t.width),
        Ua(bl, "height", t.height),
        Ua(bl, "opacity", "0.8"),
        Ua(bl, "position", Zl ? "absolute" : "fixed"),
        Ua(bl, "zIndex", "100000"),
        Ua(bl, "pointerEvents", "none"),
        (sc.ghost = bl),
        e.appendChild(bl),
        Ua(
          bl,
          "transform-origin",
          (Ll / parseInt(bl.style.width)) * 100 +
            "% " +
            (Pl / parseInt(bl.style.height)) * 100 +
            "%",
        ));
    }
  },
  _onDragStart: function (e, t) {
    var i = this,
      o = e.dataTransfer,
      n = i.options;
    (pl("dragStart", this, { evt: e }),
      sc.eventCanceled
        ? this._onDrop()
        : (pl("setupClone", this),
          sc.eventCanceled ||
            ((Cl = sl(gl)).removeAttribute("id"),
            (Cl.draggable = !1),
            (Cl.style["will-change"] = ""),
            this._hideClone(),
            $a(Cl, this.options.chosenClass, !1),
            (sc.clone = Cl)),
          (i.cloneId = dc(function () {
            (pl("clone", i),
              sc.eventCanceled ||
                (i.options.removeCloneOnHide || yl.insertBefore(Cl, gl),
                i._hideClone(),
                ml({ sortable: i, name: "clone" })));
          })),
          !t && $a(gl, n.dragClass, !0),
          t
            ? ((Vl = !0), (i._loopId = setInterval(i._emulateDragOver, 50)))
            : (qa(document, "mouseup", i._onDrop),
              qa(document, "touchend", i._onDrop),
              qa(document, "touchcancel", i._onDrop),
              o &&
                ((o.effectAllowed = "move"),
                n.setData && n.setData.call(i, o, gl)),
              Fa(document, "drop", i),
              Ua(gl, "transform", "translateZ(0)")),
          (zl = !0),
          (i._dragStartId = dc(i._dragStarted.bind(i, t, e))),
          Fa(document, "selectstart", i),
          (Nl = !0),
          window.getSelection().removeAllRanges(),
          La && Ua(document.body, "user-select", "none")));
  },
  _onDragOver: function (e) {
    var t,
      i,
      o,
      n,
      s = this.el,
      r = e.target,
      a = this.options,
      l = a.group,
      c = sc.active,
      d = Ml === l,
      h = a.sort,
      u = Al || c,
      p = this,
      m = !1;
    if (!jl) {
      if (
        (void 0 !== e.preventDefault && e.cancelable && e.preventDefault(),
        (r = Va(r, a.draggable, s, !0)),
        I("dragOver"),
        sc.eventCanceled)
      )
        return m;
      if (
        gl.contains(e.target) ||
        (r.animated && r.animatingX && r.animatingY) ||
        p._ignoreWhileAnimating === r
      )
        return O(!1);
      if (
        ((Vl = !1),
        c &&
          !a.disabled &&
          (d
            ? h || (o = fl !== yl)
            : Al === this ||
              ((this.lastPutMode = Ml.checkPull(this, c, gl, e)) &&
                l.checkPut(this, c, gl, e))))
      ) {
        if (
          ((n = "vertical" === this._getDirection(e, r)),
          (t = Za(gl)),
          I("dragOverValid"),
          sc.eventCanceled)
        )
          return m;
        if (o)
          return (
            (fl = yl),
            D(),
            this._hideClone(),
            I("revert"),
            sc.eventCanceled ||
              (wl ? yl.insertBefore(gl, wl) : yl.appendChild(gl)),
            O(!0)
          );
        var g = Xa(s, a.draggable);
        if (
          !g ||
          ((function (e, t, i) {
            var o = Za(Xa(i.el, i.options.draggable)),
              n = rl(i.el, i.options, bl),
              s = 10;
            return t
              ? e.clientX > n.right + s ||
                  (e.clientY > o.bottom && e.clientX > o.left)
              : e.clientY > n.bottom + s ||
                  (e.clientX > o.right && e.clientY > o.top);
          })(e, n, this) &&
            !g.animated)
        ) {
          if (g === gl) return O(!1);
          if (
            (g && s === e.target && (r = g),
            r && (i = Za(r)),
            !1 !== rc(yl, s, gl, t, r, i, e, !!r))
          )
            return (
              D(),
              g && g.nextSibling
                ? s.insertBefore(gl, g.nextSibling)
                : s.appendChild(gl),
              (fl = s),
              B(),
              O(!0)
            );
        } else if (
          g &&
          (function (e, t, i) {
            var o = Za(Ja(i.el, 0, i.options, !0)),
              n = rl(i.el, i.options, bl),
              s = 10;
            return t
              ? e.clientX < n.left - s ||
                  (e.clientY < o.top && e.clientX < o.right)
              : e.clientY < n.top - s ||
                  (e.clientY < o.bottom && e.clientX < o.left);
          })(e, n, this)
        ) {
          var f = Ja(s, 0, a, !0);
          if (f === gl) return O(!1);
          if (((i = Za((r = f))), !1 !== rc(yl, s, gl, t, r, i, e, !1)))
            return (D(), s.insertBefore(gl, f), (fl = s), B(), O(!0));
        } else if (r.parentNode === s) {
          i = Za(r);
          var b,
            y,
            w,
            v = gl.parentNode !== s,
            C = !(function (e, t, i) {
              var o = i ? e.left : e.top,
                n = i ? e.right : e.bottom,
                s = i ? e.width : e.height,
                r = i ? t.left : t.top,
                a = i ? t.right : t.bottom,
                l = i ? t.width : t.height;
              return o === r || n === a || o + s / 2 === r + l / 2;
            })(
              (gl.animated && gl.toRect) || t,
              (r.animated && r.toRect) || i,
              n,
            ),
            x = n ? "top" : "left",
            k = Ka(r, "top", "top") || Ka(gl, "top", "top"),
            S = k ? k.scrollTop : void 0;
          if (
            (Rl !== r &&
              ((y = i[x]), (Hl = !1), ($l = (!C && a.invertSwap) || v)),
            (b = (function (e, t, i, o, n, s, r, a) {
              var l = o ? e.clientY : e.clientX,
                c = o ? i.height : i.width,
                d = o ? i.top : i.left,
                h = o ? i.bottom : i.right,
                u = !1;
              if (!r)
                if (a && ql < c * n) {
                  if (
                    (!Hl &&
                      (1 === Fl ? l > d + (c * s) / 2 : l < h - (c * s) / 2) &&
                      (Hl = !0),
                    Hl)
                  )
                    u = !0;
                  else if (1 === Fl ? l < d + ql : l > h - ql) return -Fl;
                } else if (
                  l > d + (c * (1 - n)) / 2 &&
                  l < h - (c * (1 - n)) / 2
                )
                  return (function (e) {
                    return Qa(gl) < Qa(e) ? 1 : -1;
                  })(t);
              if ((u = u || r) && (l < d + (c * s) / 2 || l > h - (c * s) / 2))
                return l > d + c / 2 ? 1 : -1;
              return 0;
            })(
              e,
              r,
              i,
              n,
              C ? 1 : a.swapThreshold,
              null == a.invertedSwapThreshold
                ? a.swapThreshold
                : a.invertedSwapThreshold,
              $l,
              Rl === r,
            )),
            0 !== b)
          ) {
            var T = Qa(gl);
            do {
              ((T -= b), (w = fl.children[T]));
            } while (w && ("none" === Ua(w, "display") || w === bl));
          }
          if (0 === b || w === r) return O(!1);
          ((Rl = r), (Fl = b));
          var E = r.nextElementSibling,
            M = !1,
            A = rc(yl, s, gl, t, r, i, e, (M = 1 === b));
          if (!1 !== A)
            return (
              (1 !== A && -1 !== A) || (M = 1 === A),
              (jl = !0),
              setTimeout(lc, 30),
              D(),
              M && !E
                ? s.appendChild(gl)
                : r.parentNode.insertBefore(gl, M ? E : r),
              k && nl(k, 0, S - k.scrollTop),
              (fl = gl.parentNode),
              void 0 === y || $l || (ql = Math.abs(y - Za(r)[x])),
              B(),
              O(!0)
            );
        }
        if (s.contains(gl)) return O(!1);
      }
      return !1;
    }
    function I(a, l) {
      pl(
        a,
        p,
        Sa(
          {
            evt: e,
            isOwner: d,
            axis: n ? "vertical" : "horizontal",
            revert: o,
            dragRect: t,
            targetRect: i,
            canSort: h,
            fromSortable: u,
            target: r,
            completed: O,
            onMove: function (i, o) {
              return rc(yl, s, gl, t, i, Za(i), e, o);
            },
            changed: B,
          },
          l,
        ),
      );
    }
    function D() {
      (I("dragOverAnimationCapture"),
        p.captureAnimationState(),
        p !== u && u.captureAnimationState());
    }
    function O(t) {
      return (
        I("dragOverCompleted", { insertion: t }),
        t &&
          (d ? c._hideClone() : c._showClone(p),
          p !== u &&
            ($a(gl, Al ? Al.options.ghostClass : c.options.ghostClass, !1),
            $a(gl, a.ghostClass, !0)),
          Al !== p && p !== sc.active
            ? (Al = p)
            : p === sc.active && Al && (Al = null),
          u === p && (p._ignoreWhileAnimating = r),
          p.animateAll(function () {
            (I("dragOverAnimationComplete"), (p._ignoreWhileAnimating = null));
          }),
          p !== u && (u.animateAll(), (u._ignoreWhileAnimating = null))),
        ((r === gl && !gl.animated) || (r === s && !r.animated)) && (Rl = null),
        a.dragoverBubble ||
          e.rootEl ||
          r === document ||
          (gl.parentNode[al]._isOutsideThisEl(e.target), !t && oc(e)),
        !a.dragoverBubble && e.stopPropagation && e.stopPropagation(),
        (m = !0)
      );
    }
    function B() {
      ((Sl = Qa(gl)),
        (El = Qa(gl, a.draggable)),
        ml({
          sortable: p,
          name: "change",
          toEl: s,
          newIndex: Sl,
          newDraggableIndex: El,
          originalEvent: e,
        }));
    }
  },
  _ignoreWhileAnimating: null,
  _offMoveEvents: function () {
    (qa(document, "mousemove", this._onTouchMove),
      qa(document, "touchmove", this._onTouchMove),
      qa(document, "pointermove", this._onTouchMove),
      qa(document, "dragover", oc),
      qa(document, "mousemove", oc),
      qa(document, "touchmove", oc));
  },
  _offUpEvents: function () {
    var e = this.el.ownerDocument;
    (qa(e, "mouseup", this._onDrop),
      qa(e, "touchend", this._onDrop),
      qa(e, "pointerup", this._onDrop),
      qa(e, "pointercancel", this._onDrop),
      qa(e, "touchcancel", this._onDrop),
      qa(document, "selectstart", this));
  },
  _onDrop: function (e) {
    var t = this.el,
      i = this.options;
    ((Sl = Qa(gl)),
      (El = Qa(gl, i.draggable)),
      pl("drop", this, { evt: e }),
      (fl = gl && gl.parentNode),
      (Sl = Qa(gl)),
      (El = Qa(gl, i.draggable)),
      sc.eventCanceled ||
        ((zl = !1),
        ($l = !1),
        (Hl = !1),
        clearInterval(this._loopId),
        clearTimeout(this._dragStartTimer),
        hc(this.cloneId),
        hc(this._dragStartId),
        this.nativeDraggable &&
          (qa(document, "drop", this), qa(t, "dragstart", this._onDragStart)),
        this._offMoveEvents(),
        this._offUpEvents(),
        La && Ua(document.body, "user-select", ""),
        Ua(gl, "transform", ""),
        e &&
          (Nl &&
            (e.cancelable && e.preventDefault(),
            !i.dropBubble && e.stopPropagation()),
          bl && bl.parentNode && bl.parentNode.removeChild(bl),
          (yl === fl || (Al && "clone" !== Al.lastPutMode)) &&
            Cl &&
            Cl.parentNode &&
            Cl.parentNode.removeChild(Cl),
          gl &&
            (this.nativeDraggable && qa(gl, "dragend", this),
            ac(gl),
            (gl.style["will-change"] = ""),
            Nl &&
              !zl &&
              $a(gl, Al ? Al.options.ghostClass : this.options.ghostClass, !1),
            $a(gl, this.options.chosenClass, !1),
            ml({
              sortable: this,
              name: "unchoose",
              toEl: fl,
              newIndex: null,
              newDraggableIndex: null,
              originalEvent: e,
            }),
            yl !== fl
              ? (Sl >= 0 &&
                  (ml({
                    rootEl: fl,
                    name: "add",
                    toEl: fl,
                    fromEl: yl,
                    originalEvent: e,
                  }),
                  ml({
                    sortable: this,
                    name: "remove",
                    toEl: fl,
                    originalEvent: e,
                  }),
                  ml({
                    rootEl: fl,
                    name: "sort",
                    toEl: fl,
                    fromEl: yl,
                    originalEvent: e,
                  }),
                  ml({
                    sortable: this,
                    name: "sort",
                    toEl: fl,
                    originalEvent: e,
                  })),
                Al && Al.save())
              : Sl !== kl &&
                Sl >= 0 &&
                (ml({
                  sortable: this,
                  name: "update",
                  toEl: fl,
                  originalEvent: e,
                }),
                ml({
                  sortable: this,
                  name: "sort",
                  toEl: fl,
                  originalEvent: e,
                })),
            sc.active &&
              ((null != Sl && -1 !== Sl) || ((Sl = kl), (El = Tl)),
              ml({ sortable: this, name: "end", toEl: fl, originalEvent: e }),
              this.save())))),
      this._nulling());
  },
  _nulling: function () {
    (pl("nulling", this),
      (yl =
        gl =
        fl =
        bl =
        wl =
        Cl =
        vl =
        xl =
        Il =
        Dl =
        Nl =
        Sl =
        El =
        kl =
        Tl =
        Rl =
        Fl =
        Al =
        Ml =
        sc.dragged =
        sc.ghost =
        sc.clone =
        sc.active =
          null),
      Yl.forEach(function (e) {
        e.checked = !0;
      }),
      (Yl.length = Ol = Bl = 0));
  },
  handleEvent: function (e) {
    switch (e.type) {
      case "drop":
      case "dragend":
        this._onDrop(e);
        break;
      case "dragenter":
      case "dragover":
        gl &&
          (this._onDragOver(e),
          (function (e) {
            e.dataTransfer && (e.dataTransfer.dropEffect = "move");
            e.cancelable && e.preventDefault();
          })(e));
        break;
      case "selectstart":
        e.preventDefault();
    }
  },
  toArray: function () {
    for (
      var e,
        t = [],
        i = this.el.children,
        o = 0,
        n = i.length,
        s = this.options;
      o < n;
      o++
    )
      Va((e = i[o]), s.draggable, this.el, !1) &&
        t.push(e.getAttribute(s.dataIdAttr) || cc(e));
    return t;
  },
  sort: function (e, t) {
    var i = {},
      o = this.el;
    (this.toArray().forEach(function (e, t) {
      var n = o.children[t];
      Va(n, this.options.draggable, o, !1) && (i[e] = n);
    }, this),
      t && this.captureAnimationState(),
      e.forEach(function (e) {
        i[e] && (o.removeChild(i[e]), o.appendChild(i[e]));
      }),
      t && this.animateAll());
  },
  save: function () {
    var e = this.options.store;
    e && e.set && e.set(this);
  },
  closest: function (e, t) {
    return Va(e, t || this.options.draggable, this.el, !1);
  },
  option: function (e, t) {
    var i = this.options;
    if (void 0 === t) return i[e];
    var o = hl.modifyOption(this, e, t);
    ((i[e] = void 0 !== o ? o : t), "group" === e && ec(i));
  },
  destroy: function () {
    pl("destroy", this);
    var e = this.el;
    ((e[al] = null),
      qa(e, "mousedown", this._onTapStart),
      qa(e, "touchstart", this._onTapStart),
      qa(e, "pointerdown", this._onTapStart),
      this.nativeDraggable &&
        (qa(e, "dragover", this), qa(e, "dragenter", this)),
      Array.prototype.forEach.call(
        e.querySelectorAll("[draggable]"),
        function (e) {
          e.removeAttribute("draggable");
        },
      ),
      this._onDrop(),
      this._disableDelayedDragEvents(),
      Wl.splice(Wl.indexOf(this.el), 1),
      (this.el = e = null));
  },
  _hideClone: function () {
    if (!xl) {
      if ((pl("hideClone", this), sc.eventCanceled)) return;
      (Ua(Cl, "display", "none"),
        this.options.removeCloneOnHide &&
          Cl.parentNode &&
          Cl.parentNode.removeChild(Cl),
        (xl = !0));
    }
  },
  _showClone: function (e) {
    if ("clone" === e.lastPutMode) {
      if (xl) {
        if ((pl("showClone", this), sc.eventCanceled)) return;
        (gl.parentNode != yl || this.options.group.revertClone
          ? wl
            ? yl.insertBefore(Cl, wl)
            : yl.appendChild(Cl)
          : yl.insertBefore(Cl, gl),
          this.options.group.revertClone && this.animate(gl, Cl),
          Ua(Cl, "display", ""),
          (xl = !1));
      }
    } else this._hideClone();
  },
}),
  Gl &&
    Fa(document, "touchmove", function (e) {
      (sc.active || zl) && e.cancelable && e.preventDefault();
    }),
  (sc.utils = {
    on: Fa,
    off: qa,
    css: Ua,
    find: Ya,
    is: function (e, t) {
      return !!Va(e, t, e, !1);
    },
    extend: function (e, t) {
      if (e && t) for (var i in t) t.hasOwnProperty(i) && (e[i] = t[i]);
      return e;
    },
    throttle: ol,
    closest: Va,
    toggleClass: $a,
    clone: sl,
    index: Qa,
    nextTick: dc,
    cancelNextTick: hc,
    detectDirection: Ql,
    getChild: Ja,
    expando: al,
  }),
  (sc.get = function (e) {
    return e[al];
  }),
  (sc.mount = function () {
    for (var e = arguments.length, t = new Array(e), i = 0; i < e; i++)
      t[i] = arguments[i];
    (t[0].constructor === Array && (t = t[0]),
      t.forEach(function (e) {
        if (!e.prototype || !e.prototype.constructor)
          throw "Sortable: Mounted plugin must be a constructor function, not ".concat(
            {}.toString.call(e),
          );
        (e.utils && (sc.utils = Sa(Sa({}, sc.utils), e.utils)), hl.mount(e));
      }));
  }),
  (sc.create = function (e, t) {
    return new sc(e, t);
  }),
  (sc.version = "1.15.6"));
var uc,
  pc,
  mc,
  gc,
  fc,
  bc,
  yc = [],
  wc = !1;
function vc() {
  (yc.forEach(function (e) {
    clearInterval(e.pid);
  }),
    (yc = []));
}
function Cc() {
  clearInterval(bc);
}
var xc = ol(function (e, t, i, o) {
    if (t.scroll) {
      var n,
        s = (e.touches ? e.touches[0] : e).clientX,
        r = (e.touches ? e.touches[0] : e).clientY,
        a = t.scrollSensitivity,
        l = t.scrollSpeed,
        c = Ga(),
        d = !1;
      pc !== i &&
        ((pc = i),
        vc(),
        (uc = t.scroll),
        (n = t.scrollFn),
        !0 === uc && (uc = tl(i, !0)));
      var h = 0,
        u = uc;
      do {
        var p = u,
          m = Za(p),
          g = m.top,
          f = m.bottom,
          b = m.left,
          y = m.right,
          w = m.width,
          v = m.height,
          C = void 0,
          x = void 0,
          k = p.scrollWidth,
          S = p.scrollHeight,
          T = Ua(p),
          E = p.scrollLeft,
          M = p.scrollTop;
        p === c
          ? ((C =
              w < k &&
              ("auto" === T.overflowX ||
                "scroll" === T.overflowX ||
                "visible" === T.overflowX)),
            (x =
              v < S &&
              ("auto" === T.overflowY ||
                "scroll" === T.overflowY ||
                "visible" === T.overflowY)))
          : ((C =
              w < k && ("auto" === T.overflowX || "scroll" === T.overflowX)),
            (x =
              v < S && ("auto" === T.overflowY || "scroll" === T.overflowY)));
        var A =
            C &&
            (Math.abs(y - s) <= a && E + w < k) - (Math.abs(b - s) <= a && !!E),
          I =
            x &&
            (Math.abs(f - r) <= a && M + v < S) - (Math.abs(g - r) <= a && !!M);
        if (!yc[h]) for (var D = 0; D <= h; D++) yc[D] || (yc[D] = {});
        ((yc[h].vx == A && yc[h].vy == I && yc[h].el === p) ||
          ((yc[h].el = p),
          (yc[h].vx = A),
          (yc[h].vy = I),
          clearInterval(yc[h].pid),
          (0 == A && 0 == I) ||
            ((d = !0),
            (yc[h].pid = setInterval(
              function () {
                o && 0 === this.layer && sc.active._onTouchMove(fc);
                var t = yc[this.layer].vy ? yc[this.layer].vy * l : 0,
                  i = yc[this.layer].vx ? yc[this.layer].vx * l : 0;
                ("function" == typeof n &&
                  "continue" !==
                    n.call(
                      sc.dragged.parentNode[al],
                      i,
                      t,
                      e,
                      fc,
                      yc[this.layer].el,
                    )) ||
                  nl(yc[this.layer].el, i, t);
              }.bind({ layer: h }),
              24,
            )))),
          h++);
      } while (t.bubbleScroll && u !== c && (u = tl(u, !1)));
      wc = d;
    }
  }, 30),
  kc = function (e) {
    var t = e.originalEvent,
      i = e.putSortable,
      o = e.dragEl,
      n = e.activeSortable,
      s = e.dispatchSortableEvent,
      r = e.hideGhostForTarget,
      a = e.unhideGhostForTarget;
    if (t) {
      var l = i || n;
      r();
      var c =
          t.changedTouches && t.changedTouches.length ? t.changedTouches[0] : t,
        d = document.elementFromPoint(c.clientX, c.clientY);
      (a(),
        l &&
          !l.el.contains(d) &&
          (s("spill"), this.onSpill({ dragEl: o, putSortable: i })));
    }
  };
function Sc() {}
function Tc() {}
((Sc.prototype = {
  startIndex: null,
  dragStart: function (e) {
    var t = e.oldDraggableIndex;
    this.startIndex = t;
  },
  onSpill: function (e) {
    var t = e.dragEl,
      i = e.putSortable;
    (this.sortable.captureAnimationState(), i && i.captureAnimationState());
    var o = Ja(this.sortable.el, this.startIndex, this.options);
    (o ? this.sortable.el.insertBefore(t, o) : this.sortable.el.appendChild(t),
      this.sortable.animateAll(),
      i && i.animateAll());
  },
  drop: kc,
}),
  Ma(Sc, { pluginName: "revertOnSpill" }),
  (Tc.prototype = {
    onSpill: function (e) {
      var t = e.dragEl,
        i = e.putSortable || this.sortable;
      (i.captureAnimationState(),
        t.parentNode && t.parentNode.removeChild(t),
        i.animateAll());
    },
    drop: kc,
  }),
  Ma(Tc, { pluginName: "removeOnSpill" }),
  sc.mount(
    new (function () {
      function e() {
        for (var e in ((this.defaults = {
          scroll: !0,
          forceAutoScrollFallback: !1,
          scrollSensitivity: 30,
          scrollSpeed: 10,
          bubbleScroll: !0,
        }),
        this))
          "_" === e.charAt(0) &&
            "function" == typeof this[e] &&
            (this[e] = this[e].bind(this));
      }
      return (
        (e.prototype = {
          dragStarted: function (e) {
            var t = e.originalEvent;
            this.sortable.nativeDraggable
              ? Fa(document, "dragover", this._handleAutoScroll)
              : this.options.supportPointer
                ? Fa(document, "pointermove", this._handleFallbackAutoScroll)
                : t.touches
                  ? Fa(document, "touchmove", this._handleFallbackAutoScroll)
                  : Fa(document, "mousemove", this._handleFallbackAutoScroll);
          },
          dragOverCompleted: function (e) {
            var t = e.originalEvent;
            this.options.dragOverBubble ||
              t.rootEl ||
              this._handleAutoScroll(t);
          },
          drop: function () {
            (this.sortable.nativeDraggable
              ? qa(document, "dragover", this._handleAutoScroll)
              : (qa(document, "pointermove", this._handleFallbackAutoScroll),
                qa(document, "touchmove", this._handleFallbackAutoScroll),
                qa(document, "mousemove", this._handleFallbackAutoScroll)),
              Cc(),
              vc(),
              clearTimeout(Wa),
              (Wa = void 0));
          },
          nulling: function () {
            ((fc = pc = uc = wc = bc = mc = gc = null), (yc.length = 0));
          },
          _handleFallbackAutoScroll: function (e) {
            this._handleAutoScroll(e, !0);
          },
          _handleAutoScroll: function (e, t) {
            var i = this,
              o = (e.touches ? e.touches[0] : e).clientX,
              n = (e.touches ? e.touches[0] : e).clientY,
              s = document.elementFromPoint(o, n);
            if (
              ((fc = e),
              t || this.options.forceAutoScrollFallback || Oa || Da || La)
            ) {
              xc(e, this.options, s, t);
              var r = tl(s, !0);
              !wc ||
                (bc && o === mc && n === gc) ||
                (bc && Cc(),
                (bc = setInterval(function () {
                  var s = tl(document.elementFromPoint(o, n), !0);
                  (s !== r && ((r = s), vc()), xc(e, i.options, s, t));
                }, 10)),
                (mc = o),
                (gc = n));
            } else {
              if (!this.options.bubbleScroll || tl(s, !0) === Ga())
                return void vc();
              xc(e, this.options, tl(s, !1), !1);
            }
          },
        }),
        Ma(e, { pluginName: "scroll", initializeByDefault: !0 })
      );
    })(),
  ),
  sc.mount(Tc, Sc));
class Ec extends e.Modal {
  constructor(e, t) {
    (super(e),
      (this.options = {
        title: Xr("Confirm"),
        confirmText: Xr("Confirm"),
        cancelText: Xr("Cancel"),
        ...t,
      }));
  }
  onOpen() {
    const { contentEl: t } = this;
    (t.addClass("confirm-modal"),
      t.createEl("h2", { text: this.options.title }),
      this.options.message.split("\n").forEach((e) => {
        t.createEl("p", { text: e });
      }));
    const i = t.createDiv("confirm-modal-buttons");
    (new e.ButtonComponent(i)
      .setButtonText(this.options.cancelText)
      .onClick(() => this.close()),
      new e.ButtonComponent(i)
        .setButtonText(this.options.confirmText)
        .setCta()
        .onClick(async () => {
          (await this.options.onConfirm(), this.close());
        }));
  }
  onClose() {
    const { contentEl: e } = this;
    e.empty();
  }
  static show(e, t) {
    new Ec(e, t).open();
  }
}
class Mc extends e.Modal {
  constructor(e, t) {
    (super(e),
      (this.changelogContent = ""),
      (this.changelogLoaded = !1),
      (this.plugin = t));
  }
  async loadChangelog() {
    try {
      const t = await e.request({
        url: "https://raw.githubusercontent.com/PKM-er/obsidian-toolbar/master/CHANGELOG.md",
        method: "GET",
      });
      if (!t) throw new Error("无法获取 Changelog 内容");
      {
        const e = t.split("\n");
        let i = "",
          o = [],
          n = !1;
        for (const t of e)
          if (t.startsWith("## ") && !i)
            ((i = t.substring(3).trim()), (n = !0), o.push(t));
          else {
            if (t.startsWith("## ") && n) break;
            n && o.push(t);
          }
        this.changelogContent = o.join("\n");
      }
    } catch (e) {
      (console.error("加载 Changelog 时出错:", e),
        (this.changelogContent =
          "### 无法加载更新说明\n\n请[点击此处查看最新更新说明](https://github.com/PKM-er/obsidian-toolbar/blob/master/CHANGELOG.md)"));
    }
    ((this.changelogLoaded = !0), this.updateChangelogDisplay());
  }
  updateChangelogDisplay() {
    this.changelogContainer &&
      this.changelogContentEl &&
      this.changelogLoaded &&
      (this.changelogContentEl.empty(),
      e.MarkdownRenderer.renderMarkdown(
        this.changelogContent,
        this.changelogContentEl,
        "",
        this.plugin,
      ));
  }
  async fixCommandIds() {
    try {
      const t = {
        "editor:toggle-numbered-list": "toolbar:toggle-numbered-list",
        "editor:toggle-bullet-list": "toolbar:toggle-bullet-list",
        "editor:toggle-highlight": "toolbar:toggle-highlight",
        "toggle-highlight": "toolbar:toggle-highlight",
        "toolbar:editor:toggle-bold": "toolbar:toggle-bold",
        "toolbar:editor:toggle-italics": "toolbar:toggle-italics",
        "toolbar:editor:toggle-strikethrough": "toolbar:toggle-strikethrough",
        "toolbar:editor:toggle-inline-math": "toolbar:toggle-inline-math",
        "toolbar:editor:insert-callout": "toolbar:insert-callout",
        "toolbar:editor:insert-link": "toolbar:insert-link",
        "cMenuToolbar-Divider-Line": "editingToolbar-Divider-Line",
      };
      let i = !1;
      const o = this.plugin.settings,
        n = (e) => {
          e &&
            Array.isArray(e) &&
            e.forEach((e) => {
              (e.id && t[e.id] && ((e.id = t[e.id]), (i = !0)),
                "toolbar:format-eraser" === e.id &&
                  ((e.icon = "eraser"), (i = !0)),
                "toolbar:change-font-color" === e.id &&
                  ((e.icon =
                    '<svg width="24" height="24" viewBox="0 0 24 24" focusable="false" fill="currentColor"><g fill-rule="evenodd"><path id="change-font-color-icon" d="M3 18h18v3H3z" style="fill:#2DC26B"></path><path d="M8.7 16h-.8a.5.5 0 01-.5-.6l2.7-9c.1-.3.3-.4.5-.4h2.8c.2 0 .4.1.5.4l2.7 9a.5.5 0 01-.5.6h-.8a.5.5 0 01-.4-.4l-.7-2.2c0-.3-.3-.4-.5-.4h-3.4c-.2 0-.4.1-.5.4l-.7 2.2c0 .3-.2.4-.4.4zm2.6-7.6l-.6 2a.5.5 0 00.5.6h1.6a.5.5 0 00.5-.6l-.6-2c0-.3-.3-.4-.5-.4h-.4c-.2 0-.4.1-.5.4z"></path></g></svg>'),
                  (i = !0)),
                e.SubmenuCommands && n(e.SubmenuCommands));
            });
        },
        s = (e) => {
          if (!e || !Array.isArray(e)) return !1;
          for (const t of e) {
            if ("toolbar:toggle-format-brush" === t.id) return !0;
            if (t.SubmenuCommands) {
              if (s(t.SubmenuCommands)) return !0;
            }
          }
          return !1;
        },
        r = (e) => {
          if (!e || !Array.isArray(e)) return !1;
          if (!s(e) && e.length >= 2) {
            const t = {
              id: "toolbar:toggle-format-brush",
              name: "Format Brush",
              icon: "paintbrush",
            };
            return (e.splice(2, 0, t), !0);
          }
          return !1;
        },
        a = (e) => {
          if (!e || !Array.isArray(e)) return !1;
          for (const t of e)
            if ("SubmenuCommands-text-tools" === t.id) return !0;
          return !1;
        },
        l = (e) => {
          if (!e || !Array.isArray(e)) return !1;
          if (!a(e)) {
            const t = aa.menuCommands.find(
              (e) => "SubmenuCommands-text-tools" === e.id,
            );
            if (t) {
              const i = 11;
              return (e.length >= i ? e.splice(i, 0, t) : e.push(t), !0);
            }
          }
          return !1;
        };
      (o.menuCommands &&
        (n(o.menuCommands),
        r(o.menuCommands) && (i = !0),
        l(o.menuCommands) && (i = !0)),
        o.enableMultipleConfig &&
          (o.followingCommands &&
            (n(o.followingCommands), r(o.followingCommands) && (i = !0)),
          o.topCommands &&
            (n(o.topCommands),
            r(o.topCommands) && (i = !0),
            l(o.topCommands) && (i = !0)),
          o.fixedCommands &&
            (n(o.fixedCommands), r(o.fixedCommands) && (i = !0)),
          o.mobileCommands &&
            (n(o.mobileCommands), r(o.mobileCommands) && (i = !0))),
        i
          ? (await this.plugin.saveSettings(),
            new e.Notice(Xr("Command IDs have been successfully repaired!")),
            dispatchEvent(new Event("editingToolbar-NewCommand")))
          : new e.Notice(Xr("No command IDs need to be repaired")));
    } catch (t) {
      (console.error("修复命令ID时出错:", t),
        new e.Notice(
          Xr(
            "Error repairing command IDs, please check the console for details",
          ),
        ));
    }
  }
  async reloadPlugin(e) {
    const { plugins: t } = this.app;
    try {
      (await t.disablePlugin(e), await t.enablePlugin(e));
    } catch (e) {
      console.error(e);
    }
  }
  async restoreDefaultSettings() {
    try {
      const t = this.plugin.settings.lastVersion,
        i = this.plugin.settings.customCommands;
      ((this.plugin.settings = { ...aa, lastVersion: t, customCommands: i }),
        await this.plugin.saveSettings(),
        new e.Notice(
          Xr(
            "Successfully restored default settings! (Custom commands preserved)",
          ),
        ),
        this.reloadPlugin(this.plugin.manifest.id),
        this.close());
    } catch (t) {
      (console.error("恢复默认设置时出错:", t),
        new e.Notice(
          Xr(
            "Error restoring default settings, please check the console for details",
          ),
        ));
    }
  }
  onOpen() {
    const { contentEl: t } = this;
    (t.createEl("h2", { text: this.plugin.manifest.version + "⚡Tips" }),
      t.createEl("p", { text: Xr("Notice:") }));
    const i = t.createEl("ul");
    (i.createEl("li", {
      text: Xr(
        "⚠️This update is not compatible with 2.x version command ids, please click [Repair command] to be compatible",
      ),
    }),
      i.createEl("li", {
        text: Xr(
          "⚠️If you want to restore the default settings, please click [Restore default settings]",
        ),
      }),
      (this.changelogContainer = t.createDiv({ cls: "changelog-container" })),
      this.changelogContainer.createEl("h3", { text: Xr("Latest Changes") }),
      (this.changelogContentEl = this.changelogContainer.createDiv({
        cls: "changelog-content",
      })),
      this.changelogContentEl.setText(Xr("Loading changelog...")),
      setTimeout(() => {
        this.loadChangelog();
      }, 100),
      new e.Setting(t)
        .setName(Xr("🔧Data repair"))
        .setDesc(
          Xr(
            "This update changed the ID of some commands, please click this button to repair the commands to ensure the toolbar works properly",
          ),
        )
        .addButton((e) =>
          e.setButtonText(Xr("Repair command ID")).onClick(async () => {
            await this.fixCommandIds();
          }),
        ),
      new e.Setting(t)
        .setName(Xr("🔄Restore default settings"))
        .setDesc(
          Xr(
            "This will reset all your custom configurations, but custom commands will be preserved",
          ),
        )
        .addButton((e) =>
          e.setButtonText(Xr("Restore default")).onClick(async () => {
            Ec.show(this.app, {
              message: Xr(
                "Are you sure you want to restore all settings to default? But custom commands will be preserved.",
              ),
              onConfirm: async () => {
                await this.restoreDefaultSettings();
              },
            });
          }),
        ),
      new e.Setting(t)
        .setName(Xr("📋View full changelog"))
        .setDesc(Xr("Open the complete changelog in your browser"))
        .addButton((e) =>
          e.setButtonText(Xr("Open changelog")).onClick(() => {
            window.open(
              "https://github.com/PKM-er/obsidian-toolbar/blob/master/CHANGELOG.md",
              "_blank",
            );
          }),
        ),
      new e.Setting(t).addButton((e) =>
        e.setButtonText(Xr("Close")).onClick(() => {
          this.close();
        }),
      ),
      t.createEl("style", {
        text: "\n            .changelog-container {\n                margin-top: 20px;\n                margin-bottom: 20px;\n                padding: 10px;\n                border: 1px solid var(--background-modifier-border);\n                border-radius: 5px;\n                max-height: 200px;\n                overflow-y: auto;\n            }\n            .changelog-content {\n                padding: 0 10px;\n            }\n            .changelog-content a {\n                text-decoration: underline;\n            }\n            ",
      }));
  }
  onClose() {
    const { contentEl: e } = this;
    e.empty();
  }
}
function Ac(e) {
  return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default")
    ? e.default
    : e;
}
/*! Pickr 1.8.4 MIT | https://github.com/Simonwep/pickr */
var Ic = (function (e) {
    var t = { exports: {} };
    return (e(t, t.exports), t.exports);
  })(function (e, t) {
    (self,
      (e.exports = (() => {
        var e = {
            d: (t, i) => {
              for (var o in i)
                e.o(i, o) &&
                  !e.o(t, o) &&
                  Object.defineProperty(t, o, { enumerable: !0, get: i[o] });
            },
            o: (e, t) => Object.prototype.hasOwnProperty.call(e, t),
            r: (e) => {
              ("undefined" != typeof Symbol &&
                Symbol.toStringTag &&
                Object.defineProperty(e, Symbol.toStringTag, {
                  value: "Module",
                }),
                Object.defineProperty(e, "__esModule", { value: !0 }));
            },
          },
          t = {};
        e.d(t, { default: () => O });
        var i = {};
        function o(e, t, i, o) {
          let n =
            arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : {};
          (t instanceof HTMLCollection || t instanceof NodeList
            ? (t = Array.from(t))
            : Array.isArray(t) || (t = [t]),
            Array.isArray(i) || (i = [i]));
          for (const s of t)
            for (const t of i) s[e](t, o, { capture: !1, ...n });
          return Array.prototype.slice.call(arguments, 1);
        }
        (e.r(i),
          e.d(i, {
            adjustableInputNumbers: () => d,
            createElementFromString: () => r,
            createFromTemplate: () => a,
            eventPath: () => l,
            off: () => s,
            on: () => n,
            resolveElement: () => c,
          }));
        const n = o.bind(null, "addEventListener"),
          s = o.bind(null, "removeEventListener");
        function r(e) {
          const t = document.createElement("div");
          return ((t.innerHTML = e.trim()), t.firstElementChild);
        }
        function a(e) {
          const t = (e, t) => {
              const i = e.getAttribute(t);
              return (e.removeAttribute(t), i);
            },
            i = function (e) {
              let o =
                arguments.length > 1 && void 0 !== arguments[1]
                  ? arguments[1]
                  : {};
              const n = t(e, ":obj"),
                s = t(e, ":ref"),
                r = n ? (o[n] = {}) : o;
              s && (o[s] = e);
              for (const o of Array.from(e.children)) {
                const e = t(o, ":arr"),
                  n = i(o, e ? {} : r);
                e && (r[e] || (r[e] = [])).push(Object.keys(n).length ? n : o);
              }
              return o;
            };
          return i(r(e));
        }
        function l(e) {
          let t = e.path || (e.composedPath && e.composedPath());
          if (t) return t;
          let i = e.target.parentElement;
          for (t = [e.target, i]; (i = i.parentElement); ) t.push(i);
          return (t.push(document, window), t);
        }
        function c(e) {
          return e instanceof Element
            ? e
            : "string" == typeof e
              ? e
                  .split(/>>/g)
                  .reduce(
                    (e, t, i, o) => (
                      (e = e.querySelector(t)),
                      i < o.length - 1 ? e.shadowRoot : e
                    ),
                    document,
                  )
              : null;
        }
        function d(e) {
          let t =
            arguments.length > 1 && void 0 !== arguments[1]
              ? arguments[1]
              : (e) => e;
          function i(i) {
            const o =
              [0.001, 0.01, 0.1][Number(i.shiftKey || 2 * i.ctrlKey)] *
              (i.deltaY < 0 ? 1 : -1);
            let n = 0,
              s = e.selectionStart;
            ((e.value = e.value.replace(/[\d.]+/g, (e, i) =>
              i <= s && i + e.length >= s
                ? ((s = i), t(Number(e), o, n))
                : (n++, e),
            )),
              e.focus(),
              e.setSelectionRange(s, s),
              i.preventDefault(),
              e.dispatchEvent(new Event("input")));
          }
          (n(e, "focus", () => n(window, "wheel", i, { passive: !1 })),
            n(e, "blur", () => s(window, "wheel", i)));
        }
        const { min: h, max: u, floor: p, round: m } = Math;
        function g(e, t, i) {
          ((t /= 100), (i /= 100));
          const o = p((e = (e / 360) * 6)),
            n = e - o,
            s = i * (1 - t),
            r = i * (1 - n * t),
            a = i * (1 - (1 - n) * t),
            l = o % 6;
          return [
            255 * [i, r, s, s, a, i][l],
            255 * [a, i, i, r, s, s][l],
            255 * [s, s, a, i, i, r][l],
          ];
        }
        function f(e, t, i) {
          return g(e, t, i).map((e) => m(e).toString(16).padStart(2, "0"));
        }
        function b(e, t, i) {
          const o = g(e, t, i),
            n = o[0] / 255,
            s = o[1] / 255,
            r = o[2] / 255,
            a = h(1 - n, 1 - s, 1 - r);
          return [
            100 * (1 === a ? 0 : (1 - n - a) / (1 - a)),
            100 * (1 === a ? 0 : (1 - s - a) / (1 - a)),
            100 * (1 === a ? 0 : (1 - r - a) / (1 - a)),
            100 * a,
          ];
        }
        function y(e, t, i) {
          const o = ((2 - (t /= 100)) * (i /= 100)) / 2;
          return (
            0 !== o &&
              (t =
                1 === o
                  ? 0
                  : o < 0.5
                    ? (t * i) / (2 * o)
                    : (t * i) / (2 - 2 * o)),
            [e, 100 * t, 100 * o]
          );
        }
        function w(e, t, i) {
          const o = h((e /= 255), (t /= 255), (i /= 255)),
            n = u(e, t, i),
            s = n - o;
          let r, a;
          if (0 === s) r = a = 0;
          else {
            a = s / n;
            const o = ((n - e) / 6 + s / 2) / s,
              l = ((n - t) / 6 + s / 2) / s,
              c = ((n - i) / 6 + s / 2) / s;
            (e === n
              ? (r = c - l)
              : t === n
                ? (r = 1 / 3 + o - c)
                : i === n && (r = 2 / 3 + l - o),
              r < 0 ? (r += 1) : r > 1 && (r -= 1));
          }
          return [360 * r, 100 * a, 100 * n];
        }
        function v(e, t, i, o) {
          return (
            (t /= 100),
            (i /= 100),
            [
              ...w(
                255 * (1 - h(1, (e /= 100) * (1 - (o /= 100)) + o)),
                255 * (1 - h(1, t * (1 - o) + o)),
                255 * (1 - h(1, i * (1 - o) + o)),
              ),
            ]
          );
        }
        function C(e, t, i) {
          t /= 100;
          const o = ((2 * (t *= (i /= 100) < 0.5 ? i : 1 - i)) / (i + t)) * 100,
            n = 100 * (i + t);
          return [e, isNaN(o) ? 0 : o, n];
        }
        function x(e) {
          return w(...e.match(/.{2}/g).map((e) => parseInt(e, 16)));
        }
        function k(e) {
          e = e.match(/^[a-zA-Z]+$/)
            ? (function (e) {
                if ("black" === e.toLowerCase()) return "#000";
                const t = document.createElement("canvas").getContext("2d");
                return (
                  (t.fillStyle = e),
                  "#000" === t.fillStyle ? null : t.fillStyle
                );
              })(e)
            : e;
          const t = {
              cmyk: /^cmyk[\D]+([\d.]+)[\D]+([\d.]+)[\D]+([\d.]+)[\D]+([\d.]+)/i,
              rgba: /^((rgba)|rgb)[\D]+([\d.]+)[\D]+([\d.]+)[\D]+([\d.]+)[\D]*?([\d.]+|$)/i,
              hsla: /^((hsla)|hsl)[\D]+([\d.]+)[\D]+([\d.]+)[\D]+([\d.]+)[\D]*?([\d.]+|$)/i,
              hsva: /^((hsva)|hsv)[\D]+([\d.]+)[\D]+([\d.]+)[\D]+([\d.]+)[\D]*?([\d.]+|$)/i,
              hexa: /^#?(([\dA-Fa-f]{3,4})|([\dA-Fa-f]{6})|([\dA-Fa-f]{8}))$/i,
            },
            i = (e) =>
              e.map((e) => (/^(|\d+)\.\d+|\d+$/.test(e) ? Number(e) : void 0));
          let o;
          e: for (const n in t) {
            if (!(o = t[n].exec(e))) continue;
            const s = (e) => !!o[2] == ("number" == typeof e);
            switch (n) {
              case "cmyk": {
                const [, e, t, s, r] = i(o);
                if (e > 100 || t > 100 || s > 100 || r > 100) break e;
                return { values: v(e, t, s, r), type: n };
              }
              case "rgba": {
                const [, , , e, t, r, a] = i(o);
                if (e > 255 || t > 255 || r > 255 || a < 0 || a > 1 || !s(a))
                  break e;
                return { values: [...w(e, t, r), a], a: a, type: n };
              }
              case "hexa": {
                let [, e] = o;
                (4 !== e.length && 3 !== e.length) ||
                  (e = e
                    .split("")
                    .map((e) => e + e)
                    .join(""));
                const t = e.substring(0, 6);
                let i = e.substring(6);
                return (
                  (i = i ? parseInt(i, 16) / 255 : void 0),
                  { values: [...x(t), i], a: i, type: n }
                );
              }
              case "hsla": {
                const [, , , e, t, r, a] = i(o);
                if (e > 360 || t > 100 || r > 100 || a < 0 || a > 1 || !s(a))
                  break e;
                return { values: [...C(e, t, r), a], a: a, type: n };
              }
              case "hsva": {
                const [, , , e, t, r, a] = i(o);
                if (e > 360 || t > 100 || r > 100 || a < 0 || a > 1 || !s(a))
                  break e;
                return { values: [e, t, r, a], a: a, type: n };
              }
            }
          }
          return { values: null, type: null };
        }
        function S() {
          const e = (e, t) =>
              function () {
                let i =
                  arguments.length > 0 && void 0 !== arguments[0]
                    ? arguments[0]
                    : -1;
                return t(~i ? e.map((e) => Number(e.toFixed(i))) : e);
              },
            t = {
              h:
                arguments.length > 0 && void 0 !== arguments[0]
                  ? arguments[0]
                  : 0,
              s:
                arguments.length > 1 && void 0 !== arguments[1]
                  ? arguments[1]
                  : 0,
              v:
                arguments.length > 2 && void 0 !== arguments[2]
                  ? arguments[2]
                  : 0,
              a:
                arguments.length > 3 && void 0 !== arguments[3]
                  ? arguments[3]
                  : 1,
              toHSVA() {
                const i = [t.h, t.s, t.v, t.a];
                return (
                  (i.toString = e(
                    i,
                    (e) => `hsva(${e[0]}, ${e[1]}%, ${e[2]}%, ${t.a})`,
                  )),
                  i
                );
              },
              toHSLA() {
                const i = [...y(t.h, t.s, t.v), t.a];
                return (
                  (i.toString = e(
                    i,
                    (e) => `hsla(${e[0]}, ${e[1]}%, ${e[2]}%, ${t.a})`,
                  )),
                  i
                );
              },
              toRGBA() {
                const i = [...g(t.h, t.s, t.v), t.a];
                return (
                  (i.toString = e(
                    i,
                    (e) => `rgba(${e[0]}, ${e[1]}, ${e[2]}, ${t.a})`,
                  )),
                  i
                );
              },
              toCMYK() {
                const i = b(t.h, t.s, t.v);
                return (
                  (i.toString = e(
                    i,
                    (e) => `cmyk(${e[0]}%, ${e[1]}%, ${e[2]}%, ${e[3]}%)`,
                  )),
                  i
                );
              },
              toHEXA() {
                const e = f(t.h, t.s, t.v),
                  i =
                    t.a >= 1
                      ? ""
                      : Number((255 * t.a).toFixed(0))
                          .toString(16)
                          .toUpperCase()
                          .padStart(2, "0");
                return (
                  i && e.push(i),
                  (e.toString = () => `#${e.join("").toUpperCase()}`),
                  e
                );
              },
              clone: () => S(t.h, t.s, t.v, t.a),
            };
          return t;
        }
        const T = (e) => Math.max(Math.min(e, 1), 0);
        function E(e) {
          const t = {
              options: Object.assign(
                { lock: null, onchange: () => 0, onstop: () => 0 },
                e,
              ),
              _keyboard(e) {
                const { options: i } = t,
                  { type: o, key: n } = e;
                if (document.activeElement === i.wrapper) {
                  const { lock: i } = t.options,
                    s = "ArrowUp" === n,
                    r = "ArrowRight" === n,
                    a = "ArrowDown" === n,
                    l = "ArrowLeft" === n;
                  if ("keydown" === o && (s || r || a || l)) {
                    let o = 0,
                      n = 0;
                    ("v" === i
                      ? (o = s || r ? 1 : -1)
                      : "h" === i
                        ? (o = s || r ? -1 : 1)
                        : ((n = s ? -1 : a ? 1 : 0), (o = l ? -1 : r ? 1 : 0)),
                      t.update(
                        T(t.cache.x + 0.01 * o),
                        T(t.cache.y + 0.01 * n),
                      ),
                      e.preventDefault());
                  } else
                    n.startsWith("Arrow") &&
                      (t.options.onstop(), e.preventDefault());
                }
              },
              _tapstart(e) {
                (n(
                  document,
                  ["mouseup", "touchend", "touchcancel"],
                  t._tapstop,
                ),
                  n(document, ["mousemove", "touchmove"], t._tapmove),
                  e.cancelable && e.preventDefault(),
                  t._tapmove(e));
              },
              _tapmove(e) {
                const { options: i, cache: o } = t,
                  { lock: n, element: s, wrapper: r } = i,
                  a = r.getBoundingClientRect();
                let l = 0,
                  c = 0;
                if (e) {
                  const t = e && e.touches && e.touches[0];
                  ((l = e ? (t || e).clientX : 0),
                    (c = e ? (t || e).clientY : 0),
                    l < a.left
                      ? (l = a.left)
                      : l > a.left + a.width && (l = a.left + a.width),
                    c < a.top
                      ? (c = a.top)
                      : c > a.top + a.height && (c = a.top + a.height),
                    (l -= a.left),
                    (c -= a.top));
                } else o && ((l = o.x * a.width), (c = o.y * a.height));
                ("h" !== n &&
                  (s.style.left = `calc(${(l / a.width) * 100}% - ${s.offsetWidth / 2}px)`),
                  "v" !== n &&
                    (s.style.top = `calc(${(c / a.height) * 100}% - ${s.offsetHeight / 2}px)`),
                  (t.cache = { x: l / a.width, y: c / a.height }));
                const d = T(l / a.width),
                  h = T(c / a.height);
                switch (n) {
                  case "v":
                    return i.onchange(d);
                  case "h":
                    return i.onchange(h);
                  default:
                    return i.onchange(d, h);
                }
              },
              _tapstop() {
                (t.options.onstop(),
                  s(
                    document,
                    ["mouseup", "touchend", "touchcancel"],
                    t._tapstop,
                  ),
                  s(document, ["mousemove", "touchmove"], t._tapmove));
              },
              trigger() {
                t._tapmove();
              },
              update() {
                let e =
                    arguments.length > 0 && void 0 !== arguments[0]
                      ? arguments[0]
                      : 0,
                  i =
                    arguments.length > 1 && void 0 !== arguments[1]
                      ? arguments[1]
                      : 0;
                const {
                  left: o,
                  top: n,
                  width: s,
                  height: r,
                } = t.options.wrapper.getBoundingClientRect();
                ("h" === t.options.lock && (i = e),
                  t._tapmove({ clientX: o + s * e, clientY: n + r * i }));
              },
              destroy() {
                const { options: e, _tapstart: i, _keyboard: o } = t;
                (s(document, ["keydown", "keyup"], o),
                  s([e.wrapper, e.element], "mousedown", i),
                  s([e.wrapper, e.element], "touchstart", i, { passive: !1 }));
              },
            },
            { options: i, _tapstart: o, _keyboard: r } = t;
          return (
            n([i.wrapper, i.element], "mousedown", o),
            n([i.wrapper, i.element], "touchstart", o, { passive: !1 }),
            n(document, ["keydown", "keyup"], r),
            t
          );
        }
        function M() {
          let e =
            arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
          e = Object.assign(
            { onchange: () => 0, className: "", elements: [] },
            e,
          );
          const t = n(e.elements, "click", (t) => {
            (e.elements.forEach((i) =>
              i.classList[t.target === i ? "add" : "remove"](e.className),
            ),
              e.onchange(t),
              t.stopPropagation());
          });
          return { destroy: () => s(...t) };
        }
        const A = {
            variantFlipOrder: { start: "sme", middle: "mse", end: "ems" },
            positionFlipOrder: {
              top: "tbrl",
              right: "rltb",
              bottom: "btrl",
              left: "lrbt",
            },
            position: "bottom",
            margin: 8,
          },
          I = (e, t, i) => {
            const {
                container: o,
                margin: n,
                position: s,
                variantFlipOrder: r,
                positionFlipOrder: a,
              } = {
                container: document.documentElement.getBoundingClientRect(),
                ...A,
                ...i,
              },
              { left: l, top: c } = t.style;
            ((t.style.left = "0"), (t.style.top = "0"));
            const d = e.getBoundingClientRect(),
              h = t.getBoundingClientRect(),
              u = {
                t: d.top - h.height - n,
                b: d.bottom + n,
                r: d.right + n,
                l: d.left - h.width - n,
              },
              p = {
                vs: d.left,
                vm: d.left + d.width / 2 + -h.width / 2,
                ve: d.left + d.width - h.width,
                hs: d.top,
                hm: d.bottom - d.height / 2 - h.height / 2,
                he: d.bottom - h.height,
              },
              [m, g = "middle"] = s.split("-"),
              f = a[m],
              b = r[g],
              { top: y, left: w, bottom: v, right: C } = o;
            for (const e of f) {
              const i = "t" === e || "b" === e,
                o = u[e],
                [n, s] = i ? ["top", "left"] : ["left", "top"],
                [r, a] = i ? [h.height, h.width] : [h.width, h.height],
                [l, c] = i ? [v, C] : [C, v],
                [d, m] = i ? [y, w] : [w, y];
              if (!(o < d || o + r > l))
                for (const r of b) {
                  const l = p[(i ? "v" : "h") + r];
                  if (!(l < m || l + a > c))
                    return (
                      (t.style[s] = l - h[s] + "px"),
                      (t.style[n] = o - h[n] + "px"),
                      e + r
                    );
                }
            }
            return ((t.style.left = l), (t.style.top = c), null);
          };
        function D(e, t, i) {
          return (
            t in e
              ? Object.defineProperty(e, t, {
                  value: i,
                  enumerable: !0,
                  configurable: !0,
                  writable: !0,
                })
              : (e[t] = i),
            e
          );
        }
        class O {
          constructor(e) {
            (D(this, "_initializingActive", !0),
              D(this, "_recalc", !0),
              D(this, "_nanopop", null),
              D(this, "_root", null),
              D(this, "_color", S()),
              D(this, "_lastColor", S()),
              D(this, "_swatchColors", []),
              D(this, "_setupAnimationFrame", null),
              D(this, "_eventListener", {
                init: [],
                save: [],
                hide: [],
                show: [],
                clear: [],
                change: [],
                changestop: [],
                cancel: [],
                swatchselect: [],
              }),
              (this.options = e = Object.assign({ ...O.DEFAULT_OPTIONS }, e)));
            const {
              swatches: t,
              components: i,
              theme: o,
              sliders: n,
              lockOpacity: s,
              padding: r,
            } = e;
            (["nano", "monolith"].includes(o) && !n && (e.sliders = "h"),
              i.interaction || (i.interaction = {}));
            const { preview: a, opacity: l, hue: c, palette: d } = i;
            ((i.opacity = !s && l),
              (i.palette = d || a || l || c),
              this._preBuild(),
              this._buildComponents(),
              this._bindEvents(),
              this._finalBuild(),
              t && t.length && t.forEach((e) => this.addSwatch(e)));
            const { button: h, app: u } = this._root;
            ((this._nanopop = ((e, t, i) => {
              const o =
                "object" != typeof e || e instanceof HTMLElement
                  ? { reference: e, popper: t, ...i }
                  : e;
              return {
                update() {
                  let e =
                    arguments.length > 0 && void 0 !== arguments[0]
                      ? arguments[0]
                      : o;
                  const { reference: t, popper: i } = Object.assign(o, e);
                  if (!i || !t)
                    throw new Error("Popper- or reference-element missing.");
                  return I(t, i, o);
                },
              };
            })(h, u, { margin: r })),
              h.setAttribute("role", "button"),
              h.setAttribute("aria-label", this._t("btn:toggle")));
            const p = this;
            this._setupAnimationFrame = requestAnimationFrame(function t() {
              if (!u.offsetWidth)
                return (p._setupAnimationFrame = requestAnimationFrame(t));
              (p.setColor(e.default),
                p._rePositioningPicker(),
                e.defaultRepresentation &&
                  ((p._representation = e.defaultRepresentation),
                  p.setColorRepresentation(p._representation)),
                e.showAlways && p.show(),
                (p._initializingActive = !1),
                p._emit("init"));
            });
          }
          _preBuild() {
            const { options: e } = this;
            for (const t of ["el", "container"]) e[t] = c(e[t]);
            ((this._root = ((e) => {
              const {
                  components: t,
                  useAsButton: i,
                  inline: o,
                  appClass: n,
                  theme: s,
                  lockOpacity: r,
                } = e.options,
                l = (e) => (e ? "" : 'style="display:none" hidden'),
                c = (t) => e._t(t),
                d = a(
                  `\n      <div :ref="root" class="pickr">\n\n        ${i ? "" : '<button type="button" :ref="button" class="pcr-button"></button>'}\n\n        <div :ref="app" class="pcr-app ${n || ""}" data-theme="${s}" ${o ? 'style="position: unset"' : ""} aria-label="${c("ui:dialog")}" role="window">\n          <div class="pcr-selection" ${l(t.palette)}>\n            <div :obj="preview" class="pcr-color-preview" ${l(t.preview)}>\n              <button type="button" :ref="lastColor" class="pcr-last-color" aria-label="${c("btn:last-color")}"></button>\n              <div :ref="currentColor" class="pcr-current-color"></div>\n            </div>\n\n            <div :obj="palette" class="pcr-color-palette">\n              <div :ref="picker" class="pcr-picker"></div>\n              <div :ref="palette" class="pcr-palette" tabindex="0" aria-label="${c("aria:palette")}" role="listbox"></div>\n            </div>\n\n            <div :obj="hue" class="pcr-color-chooser" ${l(t.hue)}>\n              <div :ref="picker" class="pcr-picker"></div>\n              <div :ref="slider" class="pcr-hue pcr-slider" tabindex="0" aria-label="${c("aria:hue")}" role="slider"></div>\n            </div>\n\n            <div :obj="opacity" class="pcr-color-opacity" ${l(t.opacity)}>\n              <div :ref="picker" class="pcr-picker"></div>\n              <div :ref="slider" class="pcr-opacity pcr-slider" tabindex="0" aria-label="${c("aria:opacity")}" role="slider"></div>\n            </div>\n          </div>\n\n          <div class="pcr-swatches ${t.palette ? "" : "pcr-last"}" :ref="swatches"></div>\n\n          <div :obj="interaction" class="pcr-interaction" ${l(Object.keys(t.interaction).length)}>\n            <input :ref="result" class="pcr-result" type="text" spellcheck="false" ${l(t.interaction.input)} aria-label="${c("aria:input")}">\n\n            <input :arr="options" class="pcr-type" data-type="HEXA" value="${r ? "HEX" : "HEXA"}" type="button" ${l(t.interaction.hex)}>\n            <input :arr="options" class="pcr-type" data-type="RGBA" value="${r ? "RGB" : "RGBA"}" type="button" ${l(t.interaction.rgba)}>\n            <input :arr="options" class="pcr-type" data-type="HSLA" value="${r ? "HSL" : "HSLA"}" type="button" ${l(t.interaction.hsla)}>\n            <input :arr="options" class="pcr-type" data-type="HSVA" value="${r ? "HSV" : "HSVA"}" type="button" ${l(t.interaction.hsva)}>\n            <input :arr="options" class="pcr-type" data-type="CMYK" value="CMYK" type="button" ${l(t.interaction.cmyk)}>\n\n            <input :ref="save" class="pcr-save" value="${c("btn:save")}" type="button" ${l(t.interaction.save)} aria-label="${c("aria:btn:save")}">\n            <input :ref="cancel" class="pcr-cancel" value="${c("btn:cancel")}" type="button" ${l(t.interaction.cancel)} aria-label="${c("aria:btn:cancel")}">\n            <input :ref="clear" class="pcr-clear" value="${c("btn:clear")}" type="button" ${l(t.interaction.clear)} aria-label="${c("aria:btn:clear")}">\n          </div>\n        </div>\n      </div>\n    `,
                ),
                h = d.interaction;
              return (
                h.options.find((e) => !e.hidden && !e.classList.add("active")),
                (h.type = () =>
                  h.options.find((e) => e.classList.contains("active"))),
                d
              );
            })(this)),
              e.useAsButton && (this._root.button = e.el),
              e.container.appendChild(this._root.root));
          }
          _finalBuild() {
            const e = this.options,
              t = this._root;
            if ((e.container.removeChild(t.root), e.inline)) {
              const i = e.el.parentElement;
              e.el.nextSibling
                ? i.insertBefore(t.app, e.el.nextSibling)
                : i.appendChild(t.app);
            } else e.container.appendChild(t.app);
            (e.useAsButton
              ? e.inline && e.el.remove()
              : e.el.parentNode.replaceChild(t.root, e.el),
              e.disabled && this.disable(),
              e.comparison ||
                ((t.button.style.transition = "none"),
                e.useAsButton ||
                  (t.preview.lastColor.style.transition = "none")),
              this.hide());
          }
          _buildComponents() {
            const e = this,
              t = this.options.components,
              i = (e.options.sliders || "v").repeat(2),
              [o, n] = i.match(/^[vh]+$/g) ? i : [],
              s = () => this._color || (this._color = this._lastColor.clone()),
              r = {
                palette: E({
                  element: e._root.palette.picker,
                  wrapper: e._root.palette.palette,
                  onstop: () => e._emit("changestop", "slider", e),
                  onchange(i, o) {
                    if (!t.palette) return;
                    const n = s(),
                      { _root: r, options: a } = e,
                      { lastColor: l, currentColor: c } = r.preview;
                    e._recalc &&
                      ((n.s = 100 * i),
                      (n.v = 100 - 100 * o),
                      n.v < 0 && (n.v = 0),
                      e._updateOutput("slider"));
                    const d = n.toRGBA().toString(0);
                    ((this.element.style.background = d),
                      (this.wrapper.style.background = `\n                        linear-gradient(to top, rgba(0, 0, 0, ${n.a}), transparent),\n                        linear-gradient(to left, hsla(${n.h}, 100%, 50%, ${n.a}), rgba(255, 255, 255, ${n.a}))\n                    `),
                      a.comparison
                        ? a.useAsButton ||
                          e._lastColor ||
                          l.style.setProperty("--pcr-color", d)
                        : (r.button.style.setProperty("--pcr-color", d),
                          r.button.classList.remove("clear")));
                    const h = n.toHEXA().toString();
                    for (const { el: t, color: i } of e._swatchColors)
                      t.classList[
                        h === i.toHEXA().toString() ? "add" : "remove"
                      ]("pcr-active");
                    c.style.setProperty("--pcr-color", d);
                  },
                }),
                hue: E({
                  lock: "v" === n ? "h" : "v",
                  element: e._root.hue.picker,
                  wrapper: e._root.hue.slider,
                  onstop: () => e._emit("changestop", "slider", e),
                  onchange(i) {
                    if (!t.hue || !t.palette) return;
                    const o = s();
                    (e._recalc && (o.h = 360 * i),
                      (this.element.style.backgroundColor = `hsl(${o.h}, 100%, 50%)`),
                      r.palette.trigger());
                  },
                }),
                opacity: E({
                  lock: "v" === o ? "h" : "v",
                  element: e._root.opacity.picker,
                  wrapper: e._root.opacity.slider,
                  onstop: () => e._emit("changestop", "slider", e),
                  onchange(i) {
                    if (!t.opacity || !t.palette) return;
                    const o = s();
                    (e._recalc && (o.a = Math.round(100 * i) / 100),
                      (this.element.style.background = `rgba(0, 0, 0, ${o.a})`),
                      r.palette.trigger());
                  },
                }),
                selectable: M({
                  elements: e._root.interaction.options,
                  className: "active",
                  onchange(t) {
                    ((e._representation = t.target
                      .getAttribute("data-type")
                      .toUpperCase()),
                      e._recalc && e._updateOutput("swatch"));
                  },
                }),
              };
            this._components = r;
          }
          _bindEvents() {
            const { _root: e, options: t } = this,
              i = [
                n(e.interaction.clear, "click", () => this._clearColor()),
                n([e.interaction.cancel, e.preview.lastColor], "click", () => {
                  (this.setHSVA(
                    ...(this._lastColor || this._color).toHSVA(),
                    !0,
                  ),
                    this._emit("cancel"));
                }),
                n(e.interaction.save, "click", () => {
                  !this.applyColor() && !t.showAlways && this.hide();
                }),
                n(e.interaction.result, ["keyup", "input"], (e) => {
                  (this.setColor(e.target.value, !0) &&
                    !this._initializingActive &&
                    (this._emit("change", this._color, "input", this),
                    this._emit("changestop", "input", this)),
                    e.stopImmediatePropagation());
                }),
                n(e.interaction.result, ["focus", "blur"], (e) => {
                  ((this._recalc = "blur" === e.type),
                    this._recalc && this._updateOutput(null));
                }),
                n(
                  [
                    e.palette.palette,
                    e.palette.picker,
                    e.hue.slider,
                    e.hue.picker,
                    e.opacity.slider,
                    e.opacity.picker,
                  ],
                  ["mousedown", "touchstart"],
                  () => (this._recalc = !0),
                  { passive: !0 },
                ),
              ];
            if (!t.showAlways) {
              const o = t.closeWithKey;
              i.push(
                n(e.button, "click", () =>
                  this.isOpen() ? this.hide() : this.show(),
                ),
                n(
                  document,
                  "keyup",
                  (e) =>
                    this.isOpen() &&
                    (e.key === o || e.code === o) &&
                    this.hide(),
                ),
                n(
                  document,
                  ["touchstart", "mousedown"],
                  (t) => {
                    this.isOpen() &&
                      !l(t).some((t) => t === e.app || t === e.button) &&
                      this.hide();
                  },
                  { capture: !0 },
                ),
              );
            }
            if (t.adjustableNumbers) {
              const t = {
                rgba: [255, 255, 255, 1],
                hsva: [360, 100, 100, 1],
                hsla: [360, 100, 100, 1],
                cmyk: [100, 100, 100, 100],
              };
              d(e.interaction.result, (e, i, o) => {
                const n = t[this.getColorRepresentation().toLowerCase()];
                if (n) {
                  const t = n[o],
                    s = e + (t >= 100 ? 1e3 * i : i);
                  return s <= 0 ? 0 : Number((s < t ? s : t).toPrecision(3));
                }
                return e;
              });
            }
            if (t.autoReposition && !t.inline) {
              let e = null;
              const o = this;
              i.push(
                n(
                  window,
                  ["scroll", "resize"],
                  () => {
                    o.isOpen() &&
                      (t.closeOnScroll && o.hide(),
                      null === e
                        ? ((e = setTimeout(() => (e = null), 100)),
                          requestAnimationFrame(function t() {
                            (o._rePositioningPicker(),
                              null !== e && requestAnimationFrame(t));
                          }))
                        : (clearTimeout(e),
                          (e = setTimeout(() => (e = null), 100))));
                  },
                  { capture: !0 },
                ),
              );
            }
            this._eventBindings = i;
          }
          _rePositioningPicker() {
            const { options: e } = this;
            if (
              !e.inline &&
              !this._nanopop.update({
                container: document.body.getBoundingClientRect(),
                position: e.position,
              })
            ) {
              const e = this._root.app,
                t = e.getBoundingClientRect();
              ((e.style.top = (window.innerHeight - t.height) / 2 + "px"),
                (e.style.left = (window.innerWidth - t.width) / 2 + "px"));
            }
          }
          _updateOutput(e) {
            const { _root: t, _color: i, options: o } = this;
            if (t.interaction.type()) {
              const e = `to${t.interaction.type().getAttribute("data-type")}`;
              t.interaction.result.value =
                "function" == typeof i[e]
                  ? i[e]().toString(o.outputPrecision)
                  : "";
            }
            !this._initializingActive &&
              this._recalc &&
              this._emit("change", i, e, this);
          }
          _clearColor() {
            let e =
              arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
            const { _root: t, options: i } = this;
            (i.useAsButton ||
              t.button.style.setProperty("--pcr-color", "rgba(0, 0, 0, 0.15)"),
              t.button.classList.add("clear"),
              i.showAlways || this.hide(),
              (this._lastColor = null),
              this._initializingActive ||
                e ||
                (this._emit("save", null), this._emit("clear")));
          }
          _parseLocalColor(e) {
            const { values: t, type: i, a: o } = k(e),
              { lockOpacity: n } = this.options,
              s = void 0 !== o && 1 !== o;
            return (
              t && 3 === t.length && (t[3] = void 0),
              { values: !t || (n && s) ? null : t, type: i }
            );
          }
          _t(e) {
            return this.options.i18n[e] || O.I18N_DEFAULTS[e];
          }
          _emit(e) {
            for (
              var t = arguments.length, i = new Array(t > 1 ? t - 1 : 0), o = 1;
              o < t;
              o++
            )
              i[o - 1] = arguments[o];
            this._eventListener[e].forEach((e) => e(...i, this));
          }
          on(e, t) {
            return (this._eventListener[e].push(t), this);
          }
          off(e, t) {
            const i = this._eventListener[e] || [],
              o = i.indexOf(t);
            return (~o && i.splice(o, 1), this);
          }
          addSwatch(e) {
            const { values: t } = this._parseLocalColor(e);
            if (t) {
              const { _swatchColors: e, _root: i } = this,
                o = S(...t),
                s = r(
                  `<button type="button" style="--pcr-color: ${o.toRGBA().toString(0)}" aria-label="${this._t("btn:swatch")}"/>`,
                );
              return (
                i.swatches.appendChild(s),
                e.push({ el: s, color: o }),
                this._eventBindings.push(
                  n(s, "click", () => {
                    (this.setHSVA(...o.toHSVA(), !0),
                      this._emit("swatchselect", o),
                      this._emit("change", o, "swatch", this));
                  }),
                ),
                !0
              );
            }
            return !1;
          }
          removeSwatch(e) {
            const t = this._swatchColors[e];
            if (t) {
              const { el: i } = t;
              return (
                this._root.swatches.removeChild(i),
                this._swatchColors.splice(e, 1),
                !0
              );
            }
            return !1;
          }
          applyColor() {
            let e =
              arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
            const { preview: t, button: i } = this._root,
              o = this._color.toRGBA().toString(0);
            return (
              t.lastColor.style.setProperty("--pcr-color", o),
              this.options.useAsButton || i.style.setProperty("--pcr-color", o),
              i.classList.remove("clear"),
              (this._lastColor = this._color.clone()),
              this._initializingActive || e || this._emit("save", this._color),
              this
            );
          }
          destroy() {
            (cancelAnimationFrame(this._setupAnimationFrame),
              this._eventBindings.forEach((e) => s(...e)),
              Object.keys(this._components).forEach((e) =>
                this._components[e].destroy(),
              ));
          }
          destroyAndRemove() {
            this.destroy();
            const { root: e, app: t } = this._root;
            (e.parentElement && e.parentElement.removeChild(e),
              t.parentElement.removeChild(t),
              Object.keys(this).forEach((e) => (this[e] = null)));
          }
          hide() {
            return (
              !!this.isOpen() &&
              (this._root.app.classList.remove("visible"),
              this._emit("hide"),
              !0)
            );
          }
          show() {
            return (
              !this.options.disabled &&
              !this.isOpen() &&
              (this._root.app.classList.add("visible"),
              this._rePositioningPicker(),
              this._emit("show", this._color),
              this)
            );
          }
          isOpen() {
            return this._root.app.classList.contains("visible");
          }
          setHSVA() {
            let e =
                arguments.length > 0 && void 0 !== arguments[0]
                  ? arguments[0]
                  : 360,
              t =
                arguments.length > 1 && void 0 !== arguments[1]
                  ? arguments[1]
                  : 0,
              i =
                arguments.length > 2 && void 0 !== arguments[2]
                  ? arguments[2]
                  : 0,
              o =
                arguments.length > 3 && void 0 !== arguments[3]
                  ? arguments[3]
                  : 1,
              n =
                arguments.length > 4 && void 0 !== arguments[4] && arguments[4];
            const s = this._recalc;
            if (
              ((this._recalc = !1),
              e < 0 ||
                e > 360 ||
                t < 0 ||
                t > 100 ||
                i < 0 ||
                i > 100 ||
                o < 0 ||
                o > 1)
            )
              return !1;
            this._color = S(e, t, i, o);
            const { hue: r, opacity: a, palette: l } = this._components;
            return (
              r.update(e / 360),
              a.update(o),
              l.update(t / 100, 1 - i / 100),
              n || this.applyColor(),
              s && this._updateOutput(),
              (this._recalc = s),
              !0
            );
          }
          setColor(e) {
            let t =
              arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
            if (null === e) return (this._clearColor(t), !0);
            const { values: i, type: o } = this._parseLocalColor(e);
            if (i) {
              const e = o.toUpperCase(),
                { options: n } = this._root.interaction,
                s = n.find((t) => t.getAttribute("data-type") === e);
              if (s && !s.hidden)
                for (const e of n)
                  e.classList[e === s ? "add" : "remove"]("active");
              return !!this.setHSVA(...i, t) && this.setColorRepresentation(e);
            }
            return !1;
          }
          setColorRepresentation(e) {
            return (
              (e = e.toUpperCase()),
              !!this._root.interaction.options.find(
                (t) => t.getAttribute("data-type").startsWith(e) && !t.click(),
              )
            );
          }
          getColorRepresentation() {
            return this._representation;
          }
          getColor() {
            return this._color;
          }
          getSelectedColor() {
            return this._lastColor;
          }
          getRoot() {
            return this._root;
          }
          disable() {
            return (
              this.hide(),
              (this.options.disabled = !0),
              this._root.button.classList.add("disabled"),
              this
            );
          }
          enable() {
            return (
              (this.options.disabled = !1),
              this._root.button.classList.remove("disabled"),
              this
            );
          }
        }
        return (
          D(O, "utils", i),
          D(O, "version", "1.8.4"),
          D(O, "I18N_DEFAULTS", {
            "ui:dialog": "color picker dialog",
            "btn:toggle": "toggle color picker dialog",
            "btn:swatch": "color swatch",
            "btn:last-color": "use previous color",
            "btn:save": "Save",
            "btn:cancel": "Cancel",
            "btn:clear": "Clear",
            "aria:btn:save": "save and close",
            "aria:btn:cancel": "cancel and close",
            "aria:btn:clear": "clear and close",
            "aria:input": "color input field",
            "aria:palette": "color selection area",
            "aria:hue": "hue selection slider",
            "aria:opacity": "selection slider",
          }),
          D(O, "DEFAULT_OPTIONS", {
            appClass: null,
            theme: "classic",
            useAsButton: !1,
            padding: 8,
            disabled: !1,
            comparison: !0,
            closeOnScroll: !1,
            outputPrecision: 0,
            lockOpacity: !1,
            autoReposition: !0,
            container: "body",
            components: { interaction: {} },
            i18n: {},
            swatches: null,
            inline: !1,
            sliders: null,
            default: "#42445a",
            defaultRepresentation: null,
            position: "bottom-middle",
            adjustableNumbers: !0,
            showAlways: !1,
            closeWithKey: "Escape",
          }),
          D(O, "create", (e) => new O(e)),
          t.default
        );
      })()));
  }),
  Dc = Ac(Ic),
  Oc = [],
  Bc = [];
!(function (e, t) {
  if (e && "undefined" != typeof document) {
    var i,
      o = !0 === t.prepend ? "prepend" : "append",
      n = !0 === t.singleTag,
      s =
        "string" == typeof t.container
          ? document.querySelector(t.container)
          : document.getElementsByTagName("head")[0];
    if (n) {
      var r = Oc.indexOf(s);
      (-1 === r && ((r = Oc.push(s) - 1), (Bc[r] = {})),
        (i = Bc[r] && Bc[r][o] ? Bc[r][o] : (Bc[r][o] = a())));
    } else i = a();
    (65279 === e.charCodeAt(0) && (e = e.substring(1)),
      i.styleSheet
        ? (i.styleSheet.cssText += e)
        : i.appendChild(document.createTextNode(e)));
  }
  function a() {
    var e = document.createElement("style");
    if ((e.setAttribute("type", "text/css"), t.attributes))
      for (var i = Object.keys(t.attributes), n = 0; n < i.length; n++)
        e.setAttribute(i[n], t.attributes[i[n]]);
    var r = "prepend" === o ? "afterbegin" : "beforeend";
    return (s.insertAdjacentElement(r, e), e);
  }
})(
  '/*! Pickr 1.8.4 MIT | https://github.com/Simonwep/pickr */\n.pickr{position:relative;overflow:visible;transform:translateY(0)}.pickr *{box-sizing:border-box;outline:none;border:none;-webkit-appearance:none}.pickr .pcr-button{position:relative;height:2em;width:2em;padding:0.5em;cursor:pointer;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","Roboto","Helvetica Neue",Arial,sans-serif;border-radius:.15em;background:url(\'data:image/svg+xml;utf8, <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 50 50" stroke="%2342445A" stroke-width="5px" stroke-linecap="round"><path d="M45,45L5,5"></path><path d="M45,5L5,45"></path></svg>\') no-repeat center;background-size:0;transition:all 0.3s}.pickr .pcr-button::before{position:absolute;content:\'\';top:0;left:0;width:100%;height:100%;background:url(\'data:image/svg+xml;utf8, <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 2 2"><path fill="white" d="M1,0H2V1H1V0ZM0,1H1V2H0V1Z"/><path fill="gray" d="M0,0H1V1H0V0ZM1,1H2V2H1V1Z"/></svg>\');background-size:.5em;border-radius:.15em;z-index:-1}.pickr .pcr-button::before{z-index:initial}.pickr .pcr-button::after{position:absolute;content:\'\';top:0;left:0;height:100%;width:100%;transition:background 0.3s;background:var(--pcr-color);border-radius:.15em}.pickr .pcr-button.clear{background-size:70%}.pickr .pcr-button.clear::before{opacity:0}.pickr .pcr-button.clear:focus{box-shadow:0 0 0 1px rgba(255,255,255,0.85),0 0 0 3px var(--pcr-color)}.pickr .pcr-button.disabled{cursor:not-allowed}.pickr *,.pcr-app *{box-sizing:border-box;outline:none;border:none;-webkit-appearance:none}.pickr input:focus,.pickr input.pcr-active,.pickr button:focus,.pickr button.pcr-active,.pcr-app input:focus,.pcr-app input.pcr-active,.pcr-app button:focus,.pcr-app button.pcr-active{box-shadow:0 0 0 1px rgba(255,255,255,0.85),0 0 0 3px var(--pcr-color)}.pickr .pcr-palette,.pickr .pcr-slider,.pcr-app .pcr-palette,.pcr-app .pcr-slider{transition:box-shadow 0.3s}.pickr .pcr-palette:focus,.pickr .pcr-slider:focus,.pcr-app .pcr-palette:focus,.pcr-app .pcr-slider:focus{box-shadow:0 0 0 1px rgba(255,255,255,0.85),0 0 0 3px rgba(0,0,0,0.25)}.pcr-app{position:fixed;display:flex;flex-direction:column;z-index:10000;border-radius:0.1em;background:#fff;opacity:0;visibility:hidden;transition:opacity 0.3s, visibility 0s 0.3s;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","Roboto","Helvetica Neue",Arial,sans-serif;box-shadow:0 0.15em 1.5em 0 rgba(0,0,0,0.1),0 0 1em 0 rgba(0,0,0,0.03);left:0;top:0}.pcr-app.visible{transition:opacity 0.3s;visibility:visible;opacity:1}.pcr-app .pcr-swatches{display:flex;flex-wrap:wrap;margin-top:0.75em}.pcr-app .pcr-swatches.pcr-last{margin:0}@supports (display: grid){.pcr-app .pcr-swatches{display:grid;align-items:center;grid-template-columns:repeat(auto-fit, 1.75em)}}.pcr-app .pcr-swatches>button{font-size:1em;position:relative;width:calc(1.75em - 5px);height:calc(1.75em - 5px);border-radius:0.15em;cursor:pointer;margin:2.5px;flex-shrink:0;justify-self:center;transition:all 0.15s;overflow:hidden;background:transparent;z-index:1}.pcr-app .pcr-swatches>button::before{position:absolute;content:\'\';top:0;left:0;width:100%;height:100%;background:url(\'data:image/svg+xml;utf8, <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 2 2"><path fill="white" d="M1,0H2V1H1V0ZM0,1H1V2H0V1Z"/><path fill="gray" d="M0,0H1V1H0V0ZM1,1H2V2H1V1Z"/></svg>\');background-size:6px;border-radius:.15em;z-index:-1}.pcr-app .pcr-swatches>button::after{content:\'\';position:absolute;top:0;left:0;width:100%;height:100%;background:var(--pcr-color);border:1px solid rgba(0,0,0,0.05);border-radius:0.15em;box-sizing:border-box}.pcr-app .pcr-swatches>button:hover{filter:brightness(1.05)}.pcr-app .pcr-swatches>button:not(.pcr-active){box-shadow:none}.pcr-app .pcr-interaction{display:flex;flex-wrap:wrap;align-items:center;margin:0 -0.2em 0 -0.2em}.pcr-app .pcr-interaction>*{margin:0 0.2em}.pcr-app .pcr-interaction input{letter-spacing:0.07em;font-size:0.75em;text-align:center;cursor:pointer;color:#75797e;background:#f1f3f4;border-radius:.15em;transition:all 0.15s;padding:0.45em 0.5em;margin-top:0.75em}.pcr-app .pcr-interaction input:hover{filter:brightness(0.975)}.pcr-app .pcr-interaction input:focus{box-shadow:0 0 0 1px rgba(255,255,255,0.85),0 0 0 3px rgba(66,133,244,0.75)}.pcr-app .pcr-interaction .pcr-result{color:#75797e;text-align:left;flex:1 1 8em;min-width:8em;transition:all 0.2s;border-radius:.15em;background:#f1f3f4;cursor:text}.pcr-app .pcr-interaction .pcr-result::-moz-selection{background:#4285f4;color:#fff}.pcr-app .pcr-interaction .pcr-result::selection{background:#4285f4;color:#fff}.pcr-app .pcr-interaction .pcr-type.active{color:#fff;background:#4285f4}.pcr-app .pcr-interaction .pcr-save,.pcr-app .pcr-interaction .pcr-cancel,.pcr-app .pcr-interaction .pcr-clear{color:#fff;width:auto}.pcr-app .pcr-interaction .pcr-save,.pcr-app .pcr-interaction .pcr-cancel,.pcr-app .pcr-interaction .pcr-clear{color:#fff}.pcr-app .pcr-interaction .pcr-save:hover,.pcr-app .pcr-interaction .pcr-cancel:hover,.pcr-app .pcr-interaction .pcr-clear:hover{filter:brightness(0.925)}.pcr-app .pcr-interaction .pcr-save{background:#4285f4}.pcr-app .pcr-interaction .pcr-clear,.pcr-app .pcr-interaction .pcr-cancel{background:#f44250}.pcr-app .pcr-interaction .pcr-clear:focus,.pcr-app .pcr-interaction .pcr-cancel:focus{box-shadow:0 0 0 1px rgba(255,255,255,0.85),0 0 0 3px rgba(244,66,80,0.75)}.pcr-app .pcr-selection .pcr-picker{position:absolute;height:18px;width:18px;border:2px solid #fff;border-radius:100%;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}.pcr-app .pcr-selection .pcr-color-palette,.pcr-app .pcr-selection .pcr-color-chooser,.pcr-app .pcr-selection .pcr-color-opacity{position:relative;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;display:flex;flex-direction:column;cursor:grab;cursor:-webkit-grab}.pcr-app .pcr-selection .pcr-color-palette:active,.pcr-app .pcr-selection .pcr-color-chooser:active,.pcr-app .pcr-selection .pcr-color-opacity:active{cursor:grabbing;cursor:-webkit-grabbing}.pcr-app[data-theme=\'nano\']{width:14.25em;max-width:95vw}.pcr-app[data-theme=\'nano\'] .pcr-swatches{margin-top:.6em;padding:0 .6em}.pcr-app[data-theme=\'nano\'] .pcr-interaction{padding:0 .6em .6em .6em}.pcr-app[data-theme=\'nano\'] .pcr-selection{display:grid;grid-gap:.6em;grid-template-columns:1fr 4fr;grid-template-rows:5fr auto auto;align-items:center;height:10.5em;width:100%;align-self:flex-start}.pcr-app[data-theme=\'nano\'] .pcr-selection .pcr-color-preview{grid-area:2 / 1 / 4 / 1;height:100%;width:100%;display:flex;flex-direction:row;justify-content:center;margin-left:.6em}.pcr-app[data-theme=\'nano\'] .pcr-selection .pcr-color-preview .pcr-last-color{display:none}.pcr-app[data-theme=\'nano\'] .pcr-selection .pcr-color-preview .pcr-current-color{position:relative;background:var(--pcr-color);width:2em;height:2em;border-radius:50em;overflow:hidden}.pcr-app[data-theme=\'nano\'] .pcr-selection .pcr-color-preview .pcr-current-color::before{position:absolute;content:\'\';top:0;left:0;width:100%;height:100%;background:url(\'data:image/svg+xml;utf8, <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 2 2"><path fill="white" d="M1,0H2V1H1V0ZM0,1H1V2H0V1Z"/><path fill="gray" d="M0,0H1V1H0V0ZM1,1H2V2H1V1Z"/></svg>\');background-size:.5em;border-radius:.15em;z-index:-1}.pcr-app[data-theme=\'nano\'] .pcr-selection .pcr-color-palette{grid-area:1 / 1 / 2 / 3;width:100%;height:100%;z-index:1}.pcr-app[data-theme=\'nano\'] .pcr-selection .pcr-color-palette .pcr-palette{border-radius:.15em;width:100%;height:100%}.pcr-app[data-theme=\'nano\'] .pcr-selection .pcr-color-palette .pcr-palette::before{position:absolute;content:\'\';top:0;left:0;width:100%;height:100%;background:url(\'data:image/svg+xml;utf8, <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 2 2"><path fill="white" d="M1,0H2V1H1V0ZM0,1H1V2H0V1Z"/><path fill="gray" d="M0,0H1V1H0V0ZM1,1H2V2H1V1Z"/></svg>\');background-size:.5em;border-radius:.15em;z-index:-1}.pcr-app[data-theme=\'nano\'] .pcr-selection .pcr-color-chooser{grid-area:2 / 2 / 2 / 2}.pcr-app[data-theme=\'nano\'] .pcr-selection .pcr-color-opacity{grid-area:3 / 2 / 3 / 2}.pcr-app[data-theme=\'nano\'] .pcr-selection .pcr-color-chooser,.pcr-app[data-theme=\'nano\'] .pcr-selection .pcr-color-opacity{height:0.5em;margin:0 .6em}.pcr-app[data-theme=\'nano\'] .pcr-selection .pcr-color-chooser .pcr-picker,.pcr-app[data-theme=\'nano\'] .pcr-selection .pcr-color-opacity .pcr-picker{top:50%;transform:translateY(-50%)}.pcr-app[data-theme=\'nano\'] .pcr-selection .pcr-color-chooser .pcr-slider,.pcr-app[data-theme=\'nano\'] .pcr-selection .pcr-color-opacity .pcr-slider{flex-grow:1;border-radius:50em}.pcr-app[data-theme=\'nano\'] .pcr-selection .pcr-color-chooser .pcr-slider{background:linear-gradient(to right, red, #ff0, lime, cyan, blue, #f0f, red)}.pcr-app[data-theme=\'nano\'] .pcr-selection .pcr-color-opacity .pcr-slider{background:linear-gradient(to right, transparent, black),url(\'data:image/svg+xml;utf8, <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 2 2"><path fill="white" d="M1,0H2V1H1V0ZM0,1H1V2H0V1Z"/><path fill="gray" d="M0,0H1V1H0V0ZM1,1H2V2H1V1Z"/></svg>\');background-size:100%, 0.25em}\n\n',
  {},
);
class Lc extends e.Modal {
  constructor(e, t, i) {
    if ((super(e), (this.plugin = t), (this.commandIndex = i), null !== i)) {
      const e = t.settings.customCommands[i];
      ((this.commandId = e.id),
        (this.commandName = e.name),
        (this.icon = e.icon || ""),
        (this.regexPattern = e.regexPattern || ""),
        (this.regexReplacement = e.regexReplacement || ""),
        (this.regexCaseInsensitive = e.regexCaseInsensitive || !1),
        (this.regexGlobal = !1 !== e.regexGlobal),
        (this.regexMultiline = e.regexMultiline || !1),
        (this.useCondition = e.useCondition || !1),
        (this.conditionPattern = e.conditionPattern || ""));
    } else
      ((this.commandId = ""),
        (this.commandName = ""),
        (this.icon = ""),
        (this.regexPattern = ""),
        (this.regexReplacement = ""),
        (this.regexCaseInsensitive = !1),
        (this.regexGlobal = !0),
        (this.regexMultiline = !1),
        (this.useCondition = !1),
        (this.conditionPattern = ""));
  }
  onOpen() {
    const { contentEl: t } = this;
    (this.modalEl.addClass("custom-commands-modal"),
      t.empty(),
      t.createEl("h2", {
        text:
          null !== this.commandIndex
            ? Xr("Edit regular expression command")
            : Xr("Add regular expression command"),
      }));
    const i = t.createDiv("basic-settings-container");
    (new e.Setting(i)
      .setName(Xr("Command ID"))
      .setDesc(Xr('Unique identifier, no spaces, e.g.: "my-custom-format"'))
      .addText(
        (e) => (
          e.setValue(this.commandId),
          null !== this.commandIndex
            ? (e.setDisabled(!0), e.inputEl.addClass("id-is-disabled"))
            : e.onChange((e) => {
                this.commandId = e;
                const i = t.querySelector(".setting-item:nth-child(2) input");
                i instanceof HTMLInputElement &&
                  ((i.value = e), (this.commandName = e));
              }),
          e
        ),
      ),
      new e.Setting(i)
        .setName(Xr("Command Name"))
        .setDesc(Xr("Displayed name in toolbar and menu"))
        .addText((e) =>
          e.setValue(this.commandName).onChange((e) => (this.commandName = e)),
        ));
    const o = t.createDiv("regex-settings");
    ((o.style.border = "1px solid var(--background-modifier-border)"),
      (o.style.padding = "10px"),
      (o.style.borderRadius = "5px"),
      (o.style.marginBottom = "10px"));
    const n = o.createEl("details", { cls: "ai-help-container" });
    ((n.style.marginBottom = "10px"),
      (n.style.borderRadius = "5px"),
      (n.style.overflow = "hidden"));
    const s = n.createEl("summary", {
      text: Xr("How to use AI to get regular expressions?"),
    });
    ((s.style.padding = "8px 12px"),
      (s.style.backgroundColor = "var(--background-secondary)"),
      (s.style.cursor = "pointer"),
      (s.style.fontWeight = "bold"),
      (s.style.borderRadius = "4px"),
      (s.style.userSelect = "none"));
    const r = n.createDiv("ai-help-content");
    ((r.style.padding = "6px"),
      (r.style.backgroundColor = "var(--background-secondary-alt)"),
      (r.style.borderBottomLeftRadius = "5px"),
      (r.style.borderBottomRightRadius = "5px"),
      (r.style.marginTop = "1px"),
      r.setAttribute("contenteditable", "false"),
      (r.style.userSelect = "text"),
      (r.innerHTML = `\n      <p><strong>${Xr("AI question template:")}</strong><br>\n    ${Xr("[Description]")}:\n      ${Xr("I need to convert the url to a markdown format link")}\n    <br>\n    ${Xr("[Example]")}: \n      ${Xr("For example, convert https://example.com to [https://example.com](https://example.com)")}\n    <br>\n    ${Xr("[Requirements]")}:  \n      ${Xr("Use js regular expression to implement, and output the parameters in the following format (the result does not need to be escaped with json)")}\n    <br>\n    ${Xr("[Output]")}:\n    <br>\n      "name": "[Descriptive Name]", <br>\n      "pattern": "[Regex Pattern]", <br>\n      "replacement": "[Replacement Pattern, if applicable]", <br>\n      "flags": "[Regex Flags]" <br>\n    </p>\n    `),
      new e.Setting(o)
        .setName(Xr("Matching pattern"))
        .setDesc(Xr("Regex pattern to match"))
        .addText(
          (e) =>
            (this.regexPatternInput = e
              .setValue(this.regexPattern)
              .onChange((e) => {
                ((this.regexPattern = e), this.updatePreview());
              })),
        ),
      new e.Setting(o)
        .setName(Xr("Replacement pattern"))
        .setDesc(
          Xr(
            "Replacement pattern (use $1, $2, etc. to reference capture groups)",
          ) + Xr("Use \\n to represent line breaks"),
        )
        .addText(
          (e) =>
            (this.regexReplacementInput = e
              .setValue(this.regexReplacement.replace(/\n/g, "\\n"))
              .onChange((e) => {
                ((this.regexReplacement = e.replace(/\\n/g, "\n")),
                  this.updatePreview());
              })),
        ));
    const a = o.createDiv("regex-options");
    ((a.style.display = "flex"),
      (a.style.gap = "8px"),
      new e.Setting(a)
        .setName(Xr("Ignore case"))
        .setDesc(Xr("Match case-insensitive"))
        .addToggle((e) =>
          e.setValue(this.regexCaseInsensitive).onChange((e) => {
            ((this.regexCaseInsensitive = e), this.updatePreview());
          }),
        ),
      new e.Setting(a)
        .setName(Xr("Global replace"))
        .setDesc(Xr("Replace all matches"))
        .addToggle((e) =>
          e.setValue(this.regexGlobal).onChange((e) => {
            ((this.regexGlobal = e), this.updatePreview());
          }),
        ),
      new e.Setting(a)
        .setName(Xr("Multiline mode"))
        .setDesc(Xr("^ and $ match the start and end of each line"))
        .addToggle(
          (e) =>
            (this.regexMultilineToggle = e
              .setValue(this.regexMultiline)
              .onChange((e) => {
                ((this.regexMultiline = e), this.updatePreview());
              })),
        ));
    const l = o.createDiv("condition-container");
    new e.Setting(l)
      .setName(Xr("Use condition"))
      .setDesc(Xr("Only apply custom command when text matches the condition"))
      .addToggle(
        (e) =>
          (this.useConditionToggle = e
            .setValue(this.useCondition)
            .onChange((e) => {
              ((this.useCondition = e),
                (c.style.display = e ? "block" : "none"));
            })),
      );
    const c = l.createDiv("condition-settings");
    ((c.style.display = this.useCondition ? "block" : "none"),
      (c.style.border = "1px solid var(--background-modifier-border)"),
      (c.style.padding = "10px"),
      (c.style.borderRadius = "5px"),
      (c.style.marginBottom = "15px"),
      new e.Setting(c)
        .setName(Xr("Condition pattern"))
        .setDesc(Xr("Must exist regular expression or text"))
        .addText(
          (e) =>
            (this.conditionPatternInput = e
              .setValue(this.conditionPattern)
              .onChange((e) => {
                this.conditionPattern = e;
              })),
        ));
    const d = new e.Setting(o)
      .setName(Xr("Icon"))
      .setDesc(Xr("Command icon (click to select)"));
    if (
      ((this.iconDisplay = d.controlEl.createDiv("editingToolbarSettingsIcon")),
      this.icon)
    )
      try {
        e.setIcon(this.iconDisplay, this.icon);
      } catch (e) {
        this.iconDisplay.setText(this.icon);
      }
    (d.addButton((t) =>
      t.setButtonText(Xr("Choose icon")).onClick(() => {
        const t = {
          id: this.commandId,
          name: this.commandName,
          icon: this.icon,
        };
        new Qr(this.plugin, t, !1, (t) => {
          if (((this.icon = t), this.iconDisplay.empty(), this.icon))
            try {
              e.setIcon(this.iconDisplay, this.icon);
            } catch (e) {
              this.iconDisplay.setText(this.icon);
            }
          const i = d.controlEl.querySelector("input");
          i && (i.value = this.icon);
        }).open();
      }),
    ),
      o.createSpan("regex-help"));
    const h = o.createEl("details", { cls: "regex-examples-container" });
    ((h.style.marginTop = "15px"),
      (h.style.borderRadius = "5px"),
      (h.style.overflow = "hidden"));
    const u = h.createEl("summary", {
      text: Xr("Regular expression examples"),
    });
    ((u.style.padding = "8px 12px"),
      (u.style.backgroundColor = "var(--background-secondary)"),
      (u.style.cursor = "pointer"),
      (u.style.fontWeight = "bold"),
      (u.style.borderRadius = "4px"),
      (u.style.userSelect = "none"));
    const p = h.createDiv("examples-content");
    ((p.style.padding = "10px"),
      (p.style.backgroundColor = "var(--background-secondary-alt)"),
      (p.style.borderBottomLeftRadius = "5px"),
      (p.style.borderBottomRightRadius = "5px"),
      (p.style.marginTop = "1px"));
    const m = p.createEl("ul");
    ((m.style.paddingLeft = "20px"), (m.style.margin = "0"));
    [
      {
        name: Xr("URL to Markdown link"),
        pattern: "(https?://\\S+)",
        replacement: "[$1]($1)",
      },
      {
        name: Xr("Convert MM/DD/YYYY to YYYY-MM-DD"),
        pattern: "(\\d{1,2})/(\\d{1,2})/(\\d{4})",
        replacement: "$3-$1-$2",
      },
      {
        name: Xr("Add bold to keywords"),
        pattern: "\\b(important|critical|urgent)\\b",
        replacement: "**$1**",
      },
      {
        name: Xr("Format phone number"),
        pattern: "(\\d{3})(\\d{3})(\\d{4})",
        replacement: "($1) $2-$3",
      },
      { name: Xr("Remove extra spaces"), pattern: "\\s{2,}", replacement: " " },
      {
        name: Xr("Convert HTML bold tags to Markdown format"),
        pattern: "<strong>(.*?)</strong>",
        replacement: "**$1**",
      },
      {
        name: Xr("Convert quoted text to quote block"),
        pattern: '"([^"]+)"',
        replacement: "> $1",
      },
      {
        name: Xr("Add uniform alias to Markdown links"),
        pattern: "\\[([^\\]]+)\\]\\(([^\\)]+)\\)",
        replacement: "[$1|alias]($2)",
      },
      {
        name: Xr("Delete empty lines (multiline mode)"),
        pattern: "^\\s*$\\n",
        replacement: "",
        toggleMultiline: !0,
      },
      {
        name: Xr("Add list symbol to each line (multiline mode)"),
        pattern: "^(.+)$",
        replacement: "- $1",
        toggleMultiline: !0,
      },
      {
        name: Xr(
          "If the text contains important, set the text highlight (conditional format)",
        ),
        pattern: "(.+)",
        replacement: "==$1==",
        useCondition: !0,
        conditionPattern: "important",
      },
    ].forEach((e) => {
      const t = m.createEl("li");
      t.style.marginBottom = "8px";
      const i = t.createEl("a", { text: e.name, href: "#" });
      ((i.style.color = "var(--text-accent)"),
        (i.style.textDecoration = "none"),
        i.addEventListener("mouseenter", () => {
          i.style.textDecoration = "underline";
        }),
        i.addEventListener("mouseleave", () => {
          i.style.textDecoration = "none";
        }),
        i.addEventListener("click", (t) => {
          (t.preventDefault(),
            (this.regexPattern = e.pattern),
            (this.regexReplacement = e.replacement),
            this.regexPatternInput.setValue(e.pattern),
            this.regexReplacementInput.setValue(e.replacement),
            e.useCondition
              ? ((this.useCondition = !0),
                (this.conditionPattern = e.conditionPattern || ""),
                this.useConditionToggle.setValue(!0),
                this.conditionPatternInput.setValue(this.conditionPattern),
                (c.style.display = "block"))
              : ((this.useCondition = !1),
                this.useConditionToggle.setValue(!1),
                this.conditionPatternInput.setValue(""),
                (c.style.display = "none")),
            e.toggleMultiline
              ? this.regexMultilineToggle.setValue(!0)
              : this.regexMultilineToggle.setValue(!1),
            this.updatePreview(),
            h.removeAttribute("open"));
        }));
    });
    const g = t.createDiv("preview-container");
    ((g.style.marginTop = "20px"),
      (g.style.marginBottom = "20px"),
      (g.style.border = "1px solid var(--background-modifier-border)"),
      (g.style.padding = "10px"),
      (g.style.borderRadius = "5px"),
      g.createEl("label", { text: Xr("Preview") }));
    const f = g.createDiv("preview-input-container");
    f.style.marginBottom = "10px";
    const b = f.createEl("label", { text: Xr("Example text:") });
    ((b.style.display = "block"),
      (b.style.marginBottom = "5px"),
      (this.previewInput = f.createEl("textarea", {
        attr: {
          placeholder: Xr(
            "Input example text to view the formatting effect of the command...",
          ),
        },
      })),
      (this.previewInput.style.height = "auto"),
      (this.previewInput.style.width = "100%"),
      (this.previewInput.style.padding = "8px"),
      (this.previewInput.style.borderRadius = "4px"),
      (this.previewInput.style.border =
        "1px solid var(--background-modifier-border)"),
      (this.previewInput.value =
        "Sample text https://example.com important text    1234567890"),
      this.previewInput.addEventListener("input", () => {
        this.updatePreview();
      }));
    const y = g.createDiv("preview-output-container"),
      w = y.createEl("label", { text: Xr("Result: ") });
    ((w.style.display = "block"),
      (w.style.marginBottom = "5px"),
      (this.previewOutput = y.createDiv("preview-output")),
      (this.previewOutput.style.padding = "8px"),
      (this.previewOutput.style.borderRadius = "4px"),
      (this.previewOutput.style.border =
        "1px solid var(--background-modifier-border)"),
      (this.previewOutput.style.backgroundColor =
        "var(--background-secondary)"),
      (this.previewOutput.style.minHeight = "3em"),
      this.updatePreview(),
      new e.Setting(t)
        .addButton((t) =>
          t
            .setButtonText("保存")
            .setCta()
            .onClick(() => {
              if (!this.commandId || !this.commandName)
                return void new e.Notice(
                  Xr("Command ID and command name cannot be empty"),
                );
              if (this.commandId.includes(" "))
                return void new e.Notice(
                  Xr("Command ID cannot contain spaces"),
                );
              if (!this.regexPattern)
                return void new e.Notice(Xr("Regex pattern cannot be empty"));
              const t =
                null === this.commandIndex
                  ? `custom-${this.commandId}`
                  : this.commandId;
              if (null === this.commandIndex) {
                if (
                  this.plugin.settings.customCommands.findIndex(
                    (e) => e.id === t,
                  ) >= 0
                )
                  return void new e.Notice(
                    Xr("Command") +
                      " " +
                      this.commandId +
                      " " +
                      Xr("already exists"),
                    8e3,
                  );
              }
              const i = {
                id: t,
                name: this.commandName,
                icon: this.icon,
                useRegex: !0,
                regexPattern: this.regexPattern,
                regexReplacement: this.regexReplacement.replace(/\\n/g, "\n"),
                regexCaseInsensitive: this.regexCaseInsensitive,
                regexGlobal: this.regexGlobal,
                regexMultiline: this.regexMultiline,
                useCondition: this.useCondition,
                conditionPattern: this.conditionPattern,
                prefix: "",
                suffix: "",
                char: 0,
                line: 0,
                islinehead: !1,
              };
              (null !== this.commandIndex
                ? (this.plugin.settings.customCommands[this.commandIndex] = i)
                : this.plugin.settings.customCommands.push(i),
                this.plugin.saveSettings().then(() => {
                  (this.close(),
                    setTimeout(() => {
                      (dispatchEvent(new Event("editingToolbar-NewCommand")),
                        this.plugin.reloadCustomCommands());
                    }, 100));
                }));
            }),
        )
        .addButton((e) =>
          e.setButtonText(Xr("Cancel")).onClick(() => this.close()),
        ));
  }
  onClose() {
    const { contentEl: e } = this;
    e.empty();
  }
  updatePreview() {
    const e = this.previewInput.value;
    let t = e;
    try {
      if (this.regexPattern) {
        let i = "";
        (this.regexGlobal && (i += "g"),
          this.regexCaseInsensitive && (i += "i"),
          this.regexMultiline && (i += "m"));
        const o = new RegExp(this.regexPattern, i),
          n = this.regexReplacement.replace(/\\n/g, "\n");
        ((t = e.replace(o, n)), this.showCompleteRegexCode(i));
      }
      (this.previewOutput.empty(),
        t.split("\n").forEach((e, t, i) => {
          (this.previewOutput.createSpan({ text: e }),
            t < i.length - 1 && this.previewOutput.createEl("br"));
        }),
        (this.previewOutput.style.color = "var(--text-normal)"));
    } catch (e) {
      (this.previewOutput.setText(Xr("Error: ") + e.message),
        (this.previewOutput.style.color = "var(--text-error)"));
      const t = this.previewOutput.parentElement?.querySelector(
        ".regex-code-container",
      );
      t && t.remove();
    }
  }
  showCompleteRegexCode(e) {
    const t = this.previewOutput.parentElement;
    if (!t) return;
    let i = t.querySelector(".regex-code-container");
    if (i) {
      i.empty();
      const e = i.createEl("div", {
        text: Xr(
          "Complete regular expression code (copy to AI for explanation)",
        ),
      });
      ((e.style.marginBottom = "5px"), (e.style.fontWeight = "bold"));
    } else {
      ((i = t.createDiv("regex-code-container")),
        (i.style.marginTop = "15px"),
        (i.style.borderTop = "1px solid var(--background-modifier-border)"),
        (i.style.paddingTop = "10px"));
      const e = i.createEl("div", {
        text: Xr(
          "Complete regular expression code (copy to AI for explanation)",
        ),
      });
      ((e.style.marginBottom = "5px"), (e.style.fontWeight = "bold"));
    }
    const o = i.createEl("pre");
    ((o.style.backgroundColor = "var(--background-code)"),
      (o.style.padding = "8px"),
      (o.style.borderRadius = "4px"),
      (o.style.overflowX = "auto"),
      (o.style.fontFamily = "monospace"),
      (o.style.fontSize = "var(--font-smaller)"));
    let n = `//${Xr("Explain the syntax of JavaScript regular expressions")}\n`;
    ((n += `const regex = /${this.escapeRegexForDisplay(this.regexPattern)}/${e};\n`),
      (n += `const result = text.replace(regex, "${this.escapeStringForDisplay(this.regexReplacement)}");\n`),
      this.useCondition &&
        this.conditionPattern &&
        ((n += `\n//${Xr("Conditional matching")}\n`),
        (n += `const condition = /${this.escapeRegexForDisplay(this.conditionPattern)}/;\n`),
        (n += "if (condition.test(text)) {\n"),
        (n += `  //${Xr("Apply regular expression replacement")}\n`),
        (n += `  const result = text.replace(regex, "${this.escapeStringForDisplay(this.regexReplacement)}");\n`),
        (n += "}")),
      (o.textContent = n));
    const s = i.createEl("button", { text: Xr("Copy code") });
    ((s.style.marginTop = "5px"),
      (s.style.padding = "4px 8px"),
      (s.style.borderRadius = "4px"),
      (s.style.cursor = "pointer"),
      s.addEventListener("click", () => {
        navigator.clipboard
          .writeText(n)
          .then(() => {
            ((s.textContent = Xr("Copied!")),
              setTimeout(() => {
                s.textContent = Xr("Copy code");
              }, 2e3));
          })
          .catch((e) => {
            console.error("Failed to copy code: ", e);
          });
      }));
  }
  escapeRegexForDisplay(e) {
    return e.replace(/\\/g, "\\\\");
  }
  escapeStringForDisplay(e) {
    return e.replace(/"/g, '\\"');
  }
}
class Pc extends e.Modal {
  constructor(e, t, i) {
    if ((super(e), (this.plugin = t), (this.commandIndex = i), null !== i)) {
      const e = t.settings.customCommands[i];
      ((this.commandId = e.id),
        (this.commandName = e.name),
        (this.prefix = e.prefix),
        (this.suffix = e.suffix),
        (this.char = e.char),
        (this.line = e.line),
        (this.islinehead = e.islinehead),
        (this.icon = e.icon || ""));
    } else
      ((this.commandId = ""),
        (this.commandName = ""),
        (this.prefix = ""),
        (this.suffix = ""),
        (this.char = 0),
        (this.line = 0),
        (this.islinehead = !1),
        (this.icon = ""));
  }
  onOpen() {
    const { contentEl: t } = this;
    (this.modalEl.addClass("custom-commands-modal"),
      t.empty(),
      t.createEl("h2", {
        text:
          null !== this.commandIndex
            ? Xr("Edit Custom Command")
            : Xr("Add Custom Command"),
      }));
    const i = t.createDiv("switch-to-regex-container");
    ((i.style.marginBottom = "20px"), (i.style.textAlign = "center"));
    const o = i.createEl("button", { text: Xr("Switch Regex Command Window") });
    (o.addClass("mod-cta"),
      o.addEventListener("click", () => {
        (this.close(), new Lc(this.app, this.plugin, null).open());
      }),
      new e.Setting(t)
        .setName(Xr("Command ID"))
        .setDesc(Xr('Unique identifier, no spaces, e.g.: "my-custom-format"'))
        .addText(
          (e) => (
            (this.commandIdInput = e),
            e.setValue(this.commandId),
            null !== this.commandIndex
              ? (e.setDisabled(!0), e.inputEl.addClass("id-is-disabled"))
              : e.onChange((e) => {
                  ((this.commandId = e),
                    this.commandNameInput &&
                      (this.commandNameInput.setValue(e),
                      (this.commandName = e)));
                }),
            e
          ),
        ),
      new e.Setting(t)
        .setName(Xr("Command Name"))
        .setDesc(Xr("Displayed name in toolbar and menu"))
        .addText(
          (e) =>
            (this.commandNameInput = e
              .setValue(this.commandName)
              .onChange((e) => (this.commandName = e))),
        ));
    const n = { "\n": "↵", "\t": "⇥" },
      s = Object.fromEntries(Object.entries(n).map(([e, t]) => [t, e]));
    function r(e) {
      let t = e;
      for (const [e, i] of Object.entries(n))
        t = t.replace(
          new RegExp(e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "g"),
          i,
        );
      return t;
    }
    function a(e) {
      let t = e;
      for (const [e, i] of Object.entries(s))
        t = t.replace(
          new RegExp(e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "g"),
          i,
        );
      return t;
    }
    const l = Object.entries(n).map(([e, t]) => {
      let i = t;
      switch (e) {
        case "\n":
          i += " (New Line)";
          break;
        case "\t":
          i += " (Tab)";
      }
      return { placeholder: t, label: i };
    });
    function c(e, t) {
      t.setAttribute("title", "点击可选择并复制文本");
      const i = e.controlEl.createDiv({ cls: "special-char-buttons" });
      ((i.style.display = "flex"),
        (i.style.flexWrap = "wrap"),
        (i.style.gap = "5px"),
        (i.style.marginTop = "5px"),
        l.forEach(({ placeholder: e, label: t }) => {
          const o = i.createDiv({ cls: "char-copy-container" });
          ((o.style.position = "relative"), (o.style.display = "inline-block"));
          const n = o.createEl("button", { text: t });
          ((n.style.padding = "2px 6px"),
            (n.style.fontSize = "12px"),
            (n.style.minWidth = "auto"),
            (n.style.border = "1px solid var(--background-modifier-border)"),
            (n.style.cursor = "pointer"),
            n.setAttribute("data-char", e),
            n.addEventListener("click", (t) => {
              (t.preventDefault(),
                navigator.clipboard
                  .writeText(e)
                  .then(() => {
                    const e = o.createDiv({ cls: "copy-tooltip" });
                    ((e.style.position = "absolute"),
                      (e.style.bottom = "100%"),
                      (e.style.left = "50%"),
                      (e.style.transform = "translateX(-50%)"),
                      (e.style.backgroundColor =
                        "var(--background-modifier-success)"),
                      (e.style.color = "white"),
                      (e.style.padding = "2px 6px"),
                      (e.style.borderRadius = "4px"),
                      (e.style.fontSize = "12px"),
                      (e.style.pointerEvents = "none"),
                      (e.style.whiteSpace = "nowrap"),
                      (e.style.zIndex = "100"),
                      (e.textContent = "已复制!"),
                      setTimeout(() => {
                        e.remove();
                      }, 2e3));
                  })
                  .catch((e) => {
                    console.error("无法复制文本: ", e);
                  }));
            }),
            n.addEventListener("mouseenter", () => {
              ((n.style.backgroundColor = "var(--interactive-accent)"),
                (n.style.color = "var(--text-on-accent)"));
            }),
            n.addEventListener("mouseleave", () => {
              ((n.style.backgroundColor = ""), (n.style.color = ""));
            }));
        }));
    }
    const d = new e.Setting(t)
      .setName(Xr("Prefix"))
      .setDesc(
        Xr("Add content before selected text") +
          Xr("Use ↵ to represent line breaks"),
      )
      .addText((e) =>
        e.setValue(r(this.prefix)).onChange((e) => {
          this.prefix = a(e);
          const t = this.getMirrorText(e);
          t && ((this.suffix = a(t)), this.suffixInput.setValue(t));
        }),
      );
    c(d, d.controlEl.querySelector("input"));
    const h = new e.Setting(t)
      .setName(Xr("Suffix"))
      .setDesc(Xr("Add content after selected text"))
      .addText((e) => {
        ((this.suffixInput = e),
          e.setValue(r(this.suffix)).onChange((e) => {
            this.suffix = a(e);
          }));
      });
    (c(h, h.controlEl.querySelector("input")),
      new e.Setting(t)
        .setName(Xr("Cursor Position Offset"))
        .setDesc(Xr("Default 0, format will keep the text selected"))
        .addText((e) =>
          e
            .setValue(this.char.toString())
            .onChange((e) => (this.char = parseInt(e) || 0)),
        ),
      new e.Setting(t)
        .setName(Xr("Line Offset"))
        .setDesc(Xr("Line offset of cursor after formatting"))
        .addText((e) =>
          e
            .setValue(this.line.toString())
            .onChange((e) => (this.line = parseInt(e) || 0)),
        ),
      new e.Setting(t)
        .setName(Xr("Line Head Format"))
        .setDesc(Xr("Whether to insert at the beginning of the next line"))
        .addToggle((e) =>
          e.setValue(this.islinehead).onChange((e) => (this.islinehead = e)),
        ));
    const u = new e.Setting(t)
      .setName(Xr("Icon"))
      .setDesc(Xr("Command icon (click to select)"));
    if (
      ((this.iconDisplay = u.controlEl.createDiv("editingToolbarSettingsIcon")),
      this.icon)
    )
      try {
        e.setIcon(this.iconDisplay, this.icon);
      } catch (e) {
        this.iconDisplay.setText(this.icon);
      }
    (u.addButton((t) =>
      t.setButtonText(Xr("Choose Icon")).onClick(() => {
        const t = {
          id: this.commandId,
          name: this.commandName,
          icon: this.icon,
        };
        new Qr(this.plugin, t, !1, (t) => {
          if (((this.icon = t), this.iconDisplay.empty(), this.icon))
            try {
              e.setIcon(this.iconDisplay, this.icon);
            } catch (e) {
              this.iconDisplay.setText(this.icon);
            }
          const i = u.controlEl.querySelector("input");
          i && (i.value = this.icon);
        }).open();
      }),
    ),
      new e.Setting(t)
        .addButton((t) =>
          t
            .setButtonText(Xr("Save"))
            .setCta()
            .onClick(() => {
              if (!this.commandId || !this.commandName)
                return void new e.Notice(
                  Xr("Command ID and command name cannot be empty"),
                );
              if (this.commandId.includes(" "))
                return void new e.Notice(
                  Xr("Command ID cannot contain spaces"),
                );
              const t =
                null === this.commandIndex
                  ? `custom-${this.commandId}`
                  : this.commandId;
              if (null === this.commandIndex) {
                if (
                  this.plugin.settings.customCommands.findIndex(
                    (e) => e.id === t,
                  ) >= 0
                )
                  return void new e.Notice(
                    Xr("The command") + this.commandId + Xr("already exists"),
                    8e3,
                  );
              }
              const i = {
                id: t,
                name: this.commandName,
                prefix: this.prefix,
                suffix: this.suffix,
                char: this.char,
                line: this.line,
                islinehead: this.islinehead,
                icon: this.icon,
              };
              if (null !== this.commandIndex) {
                if (
                  this.plugin.settings.customCommands[this.commandIndex]
                    .icon !== this.icon
                ) {
                  const e = `toolbar:${t}`;
                  (this.updateCommandIcon(this.plugin.settings.menuCommands, e),
                    this.plugin.settings.enableMultipleConfig &&
                      (this.updateCommandIcon(
                        this.plugin.settings.followingCommands,
                        e,
                      ),
                      this.updateCommandIcon(
                        this.plugin.settings.topCommands,
                        e,
                      ),
                      this.updateCommandIcon(
                        this.plugin.settings.fixedCommands,
                        e,
                      ),
                      this.plugin.settings.isLoadOnMobile &&
                        this.updateCommandIcon(
                          this.plugin.settings.mobileCommands,
                          e,
                        )));
                }
                this.plugin.settings.customCommands[this.commandIndex] = i;
              } else this.plugin.settings.customCommands.push(i);
              this.plugin.saveSettings().then(() => {
                (this.close(),
                  setTimeout(() => {
                    (dispatchEvent(new Event("editingToolbar-NewCommand")),
                      this.plugin.reloadCustomCommands());
                  }, 100));
              });
            }),
        )
        .addButton((e) =>
          e.setButtonText(Xr("Cancel")).onClick(() => this.close()),
        ),
      setTimeout(() => {
        this.commandIndex
          ? this.commandIdInput.inputEl.focus()
          : this.commandNameInput.inputEl.focus();
      }, 10));
  }
  updateCommandIcon(e, t) {
    e &&
      e.forEach((e) => {
        (e.id === t && (e.icon = this.icon),
          e.SubmenuCommands && this.updateCommandIcon(e.SubmenuCommands, t));
      });
  }
  onClose() {
    const { contentEl: e } = this;
    e.empty();
  }
  getMirrorText(e) {
    const t = {
      "**": "**",
      "*": "*",
      __: "__",
      _: "_",
      "~~": "~~",
      "`": "`",
      "```": "```",
      $: "$",
      $$: "$$",
      "(": ")",
      "[": "]",
      "{": "}",
      "<": ">",
      "==": "==",
      "*==": "==*",
      "**==": "==**",
      "***==": "==***",
    };
    if (!e) return "";
    if (e in t) return t[e];
    const i = e.match(/^<(\w+)([^>]*)>$/);
    return i ? `</${i[1]}>` : "";
  }
}
class Nc extends e.Modal {
  constructor(e, t, i) {
    (super(e),
      (this.deployOptions = []),
      (this.plugin = t),
      (this.command = i),
      (this.deployOptions = [
        { id: "following", name: Xr("Following Style"), enabled: !0 },
        { id: "top", name: Xr("Top Style"), enabled: !0 },
        { id: "fixed", name: Xr("Fixed Style"), enabled: !0 },
      ]),
      this.plugin.settings.isLoadOnMobile &&
        this.deployOptions.push({
          id: "mobile",
          name: Xr("Mobile Style"),
          enabled: !0,
        }));
  }
  onOpen() {
    const { contentEl: t } = this;
    (t.empty(),
      t.createEl("h3", { text: Xr("Deploy command to configurations") }),
      t.createDiv("deploy-option"));
    const i = t.createDiv("deploy-options");
    this.deployOptions.forEach((t) => {
      new e.Setting(i)
        .setName(t.name)
        .addToggle((e) =>
          e.setValue(t.enabled).onChange((e) => {
            t.enabled = e;
          }),
        )
        .settingEl.addClass("deploy-option");
    });
    const o = t.createDiv("deploy-buttons");
    new e.Setting(o)
      .addButton((e) =>
        e
          .setButtonText(Xr("Deploy"))
          .setCta()
          .onClick(() => {
            (this.deployCommand(), this.close());
          }),
      )
      .addButton((e) =>
        e.setButtonText(Xr("Cancel")).onClick(() => {
          this.close();
        }),
      );
  }
  deployCommand() {
    const t = {
      id: `toolbar:${this.command.id}`,
      name: this.command.name,
      icon: this.command.icon || "obsidian-new",
    };
    this.plugin.settings.menuCommands.some((e) => e.id === t.id) ||
      this.plugin.settings.menuCommands.push({ ...t });
    let i = 0;
    (this.deployOptions.forEach((e) => {
      if (e.enabled) {
        let o;
        switch (e.id) {
          case "mobile":
            o = this.plugin.settings.mobileCommands;
            break;
          case "following":
            o = this.plugin.settings.followingCommands;
            break;
          case "top":
            o = this.plugin.settings.topCommands;
            break;
          case "fixed":
            o = this.plugin.settings.fixedCommands;
        }
        o && !o.some((e) => e.id === t.id) && (o.push({ ...t }), i++);
      }
    }),
      this.plugin.saveSettings().then(() => {
        let t = "";
        if (i > 0) {
          const e = this.deployOptions
            .filter((e) => e.enabled)
            .map((e) => e.name)
            .join(", ");
          t = Xr("Command deployed to: ") + e;
        } else t = Xr("Command already exists in selected configurations");
        (new e.Notice(t),
          dispatchEvent(new Event("editingToolbar-NewCommand")),
          this.plugin.reloadCustomCommands());
      }));
  }
}
class Rc extends e.Modal {
  constructor(e, t, i) {
    (super(e),
      (this.plugin = t),
      (this.mode = i),
      (this.exportType = "all"),
      (this.importMode = "update"));
  }
  onOpen() {
    const { contentEl: t } = this;
    if (
      (t.addClass("toolbar-import-export-modal"),
      t.createEl("h2", {
        text:
          "import" === this.mode
            ? Xr("Import Configuration")
            : Xr("Export Configuration"),
        cls: "import-export-title",
      }),
      "export" === this.mode)
    ) {
      new e.Setting(t)
        .setName(Xr("Export Type"))
        .setDesc(Xr("Choose what to export"))
        .addDropdown((e) => {
          (e
            .addOption("all", Xr("All Settings"))
            .addOption("All commands", Xr("All Toolbar Commands"))
            .addOption("custom", Xr("Custom Commands Only")),
            this.plugin.settings.enableMultipleConfig &&
              e
                .addOption("following", Xr("Following Style Only"))
                .addOption("top", Xr("Top Style Only"))
                .addOption("fixed", Xr("Fixed Style Only"))
                .addOption("mobile", Xr("Mobile Style Only")),
            e.setValue(this.exportType).onChange((e) => {
              ((this.exportType = e), this.updateExportContent());
            }));
        });
      const i = t.createDiv("export-container");
      ((i.style.border = "1px solid var(--background-modifier-border)"),
        (i.style.padding = "10px"),
        (i.style.borderRadius = "5px"),
        (this.textArea = new e.TextAreaComponent(i)),
        this.textArea
          .setValue("")
          .setPlaceholder(Xr("Loading..."))
          .then((e) => {
            ((e.inputEl.style.width = "100%"),
              (e.inputEl.style.height = "200px"),
              (e.inputEl.style.fontFamily = "monospace"),
              (e.inputEl.style.fontSize = "12px"),
              (e.inputEl.style.padding = "8px"),
              (e.inputEl.style.border =
                "1px solid var(--background-modifier-border)"),
              (e.inputEl.style.borderRadius = "4px"));
          }),
        this.updateExportContent());
      const o = t.createDiv("import-export-button-container");
      ((o.style.display = "flex"),
        (o.style.justifyContent = "flex-end"),
        (o.style.marginTop = "16px"));
      o.createEl("button", {
        text: Xr("Copy to Clipboard"),
        cls: "mod-cta",
      }).addEventListener("click", () => {
        navigator.clipboard
          .writeText(this.textArea.getValue())
          .then(() => {
            new e.Notice(Xr("Configuration copied to clipboard"));
          })
          .catch((t) => {
            (console.error("Failed to copy: ", t),
              new e.Notice(Xr("Failed to copy configuration")));
          });
      });
    } else {
      new e.Setting(t)
        .setName(Xr("Import Mode"))
        .setDesc(Xr("Choose how to import the configuration"))
        .addDropdown((e) => {
          e.addOption(
            "update",
            Xr("Update Mode (Add new items and update existing ones)"),
          )
            .addOption(
              "overwrite",
              Xr("Overwrite Mode (Replace settings with imported ones)"),
            )
            .setValue(this.importMode)
            .onChange((e) => {
              ((this.importMode = e),
                this.importButton.setButtonText(
                  "overwrite" === this.importMode
                    ? Xr("Overwrite Import")
                    : Xr("Update Import"),
                ),
                this.warningContent.setText(
                  "overwrite" === this.importMode
                    ? Xr(
                        "Warning: Overwrite mode will replace existing settings with imported ones.",
                      )
                    : Xr(
                        "Warning: Update mode will add new items and update existing ones.",
                      ),
                ));
            });
        });
      const i = t.createDiv("import-container");
      ((i.style.border = "1px solid var(--background-modifier-border)"),
        (i.style.padding = "10px"),
        (i.style.borderRadius = "5px"),
        (this.textArea = new e.TextAreaComponent(i)),
        this.textArea
          .setValue("")
          .setPlaceholder(Xr("Paste configuration here..."))
          .then((e) => {
            ((e.inputEl.style.width = "100%"),
              (e.inputEl.style.height = "200px"),
              (e.inputEl.style.fontFamily = "monospace"),
              (e.inputEl.style.fontSize = "12px"),
              (e.inputEl.style.padding = "8px"),
              (e.inputEl.style.border =
                "1px solid var(--background-modifier-border)"),
              (e.inputEl.style.borderRadius = "4px"));
          }));
      const o = t.createDiv("import-export-button-container");
      ((o.style.display = "flex"),
        (o.style.justifyContent = "flex-end"),
        (o.style.marginTop = "16px"),
        new e.Setting(o).addButton((e) => {
          this.importButton = e
            .setIcon("import")
            .setButtonText(Xr("Import Configuration"))
            .onClick(() => {
              this.importConfiguration();
            });
        }));
      const n = t.createDiv("import-export-warning");
      ((n.style.marginTop = "16px"),
        (n.style.padding = "8px 12px"),
        (n.style.backgroundColor = "rgba(var(--color-red-rgb), 0.1)"),
        (n.style.borderRadius = "4px"),
        (n.style.border = "1px solid rgba(var(--color-red-rgb), 0.3)"));
      const s = n.createEl("p", {
        text: Xr(
          "Warning: Update mode will add new items and update existing ones.",
        ),
        cls: "warning-text",
      });
      ((s.style.margin = "0"), (this.warningContent = s));
    }
  }
  updateExportContent() {
    let e = {
      _exportInfo: {
        version: this.plugin.manifest.version,
        exportType: this.exportType,
        exportTime: new Date().toISOString(),
        pluginId: this.plugin.manifest.id,
      },
    };
    switch (this.exportType) {
      case "all":
        e = {
          ...e,
          menuCommands: this.plugin.settings.menuCommands || [],
          followingCommands: this.plugin.settings.followingCommands || [],
          topCommands: this.plugin.settings.topCommands || [],
          fixedCommands: this.plugin.settings.fixedCommands || [],
          mobileCommands: this.plugin.settings.mobileCommands || [],
          customCommands: this.plugin.settings.customCommands || [],
          enableMultipleConfig: this.plugin.settings.enableMultipleConfig,
          positionStyle: this.plugin.settings.positionStyle,
          aestheticStyle: this.plugin.settings.aestheticStyle,
          appendMethod: this.plugin.settings.appendMethod,
          autohide: this.plugin.settings.autohide,
          isLoadOnMobile: this.plugin.settings.isLoadOnMobile,
          cMenuNumRows: this.plugin.settings.cMenuNumRows,
          custom_bg1: this.plugin.settings.custom_bg1,
          custom_bg2: this.plugin.settings.custom_bg2,
          custom_bg3: this.plugin.settings.custom_bg3,
          custom_bg4: this.plugin.settings.custom_bg4,
          custom_bg5: this.plugin.settings.custom_bg5,
          custom_fc1: this.plugin.settings.custom_fc1,
          custom_fc2: this.plugin.settings.custom_fc2,
          custom_fc3: this.plugin.settings.custom_fc3,
          custom_fc4: this.plugin.settings.custom_fc4,
          custom_fc5: this.plugin.settings.custom_fc5,
          toolbarBackgroundColor: this.plugin.settings.toolbarBackgroundColor,
          toolbarIconColor: this.plugin.settings.toolbarIconColor,
          toolbarIconSize: this.plugin.settings.toolbarIconSize,
        };
        break;
      case "All commands":
        e = {
          ...e,
          menuCommands: this.plugin.settings.menuCommands || [],
          followingCommands: this.plugin.settings.followingCommands || [],
          topCommands: this.plugin.settings.topCommands || [],
          fixedCommands: this.plugin.settings.fixedCommands || [],
          mobileCommands: this.plugin.settings.mobileCommands || [],
          enableMultipleConfig: this.plugin.settings.enableMultipleConfig,
        };
        break;
      case "custom":
        e = { ...e, customCommands: this.plugin.settings.customCommands || [] };
        break;
      case "following":
        e = {
          ...e,
          followingCommands: this.plugin.settings.followingCommands || [],
        };
        break;
      case "top":
        e = { ...e, topCommands: this.plugin.settings.topCommands || [] };
        break;
      case "fixed":
        e = { ...e, fixedCommands: this.plugin.settings.fixedCommands || [] };
        break;
      case "mobile":
        e = { ...e, mobileCommands: this.plugin.settings.mobileCommands || [] };
    }
    (this.validateExportContent(e),
      this.textArea.setValue(JSON.stringify(e, null, 2)));
  }
  validateExportContent(e) {
    ([
      "menuCommands",
      "followingCommands",
      "topCommands",
      "fixedCommands",
      "mobileCommands",
      "customCommands",
    ].forEach((t) => {
      t in e && !e[t] && (e[t] = []);
    }),
      "enableMultipleConfig" in e &&
        void 0 === e.enableMultipleConfig &&
        (e.enableMultipleConfig = !1),
      "autohide" in e && void 0 === e.autohide && (e.autohide = !1),
      "Iscentered" in e && void 0 === e.Iscentered && (e.Iscentered = !1),
      "isLoadOnMobile" in e &&
        void 0 === e.isLoadOnMobile &&
        (e.isLoadOnMobile = !0),
      "positionStyle" in e && !e.positionStyle && (e.positionStyle = "top"),
      "aestheticStyle" in e &&
        !e.aestheticStyle &&
        (e.aestheticStyle = "default"),
      "appendMethod" in e && !e.appendMethod && (e.appendMethod = "workspace"),
      "cMenuNumRows" in e && void 0 === e.cMenuNumRows && (e.cMenuNumRows = 1));
  }
  async importConfiguration() {
    try {
      const t = this.textArea.getValue();
      if (!t.trim())
        return void new e.Notice(Xr("Please paste configuration data first"));
      const i = JSON.parse(t);
      if (!i || "object" != typeof i)
        return void new e.Notice(Xr("Invalid import data format"));
      const o = "menuCommands" in i,
        n = "customCommands" in i,
        s = "followingCommands" in i,
        r = "topCommands" in i,
        a = "fixedCommands" in i,
        l = "mobileCommands" in i,
        c = "positionStyle" in i || "aestheticStyle" in i,
        d = "enableMultipleConfig" in i,
        h = i.positionStyle,
        u = o && Array.isArray(i.menuCommands) && i.menuCommands.length > 0,
        p = n && Array.isArray(i.customCommands) && i.customCommands.length > 0,
        m =
          s &&
          Array.isArray(i.followingCommands) &&
          i.followingCommands.length > 0,
        g = r && Array.isArray(i.topCommands) && i.topCommands.length > 0,
        f = a && Array.isArray(i.fixedCommands) && i.fixedCommands.length > 0,
        b = l && Array.isArray(i.mobileCommands) && i.mobileCommands.length > 0,
        y =
          o && (!Array.isArray(i.menuCommands) || 0 === i.menuCommands.length),
        w =
          n &&
          (!Array.isArray(i.customCommands) || 0 === i.customCommands.length),
        v =
          s &&
          (!Array.isArray(i.followingCommands) ||
            0 === i.followingCommands.length),
        C = r && (!Array.isArray(i.topCommands) || 0 === i.topCommands.length),
        x =
          a &&
          (!Array.isArray(i.fixedCommands) || 0 === i.fixedCommands.length),
        k =
          l &&
          (!Array.isArray(i.mobileCommands) || 0 === i.mobileCommands.length);
      let S = Xr("This import will:") + "\n";
      if (
        (c && (S += "• " + Xr("Update general settings") + "\n"),
        u &&
          (S +=
            "• " +
            Xr("Update Main Menu Commands") +
            " (" +
            i.menuCommands.length +
            " )\n"),
        p &&
          (S +=
            "• " +
            Xr("Update Custom Commands") +
            " (" +
            i.customCommands.length +
            " )\n"),
        m &&
          (S +=
            "• " +
            Xr("Update Following Style Commands") +
            " (" +
            i.followingCommands.length +
            " )\n"),
        g &&
          (S +=
            "• " +
            Xr("Update Top Style Commands") +
            " (" +
            i.topCommands.length +
            " )\n"),
        f &&
          (S +=
            "• " +
            Xr("Update Fixed Style Commands") +
            " (" +
            i.fixedCommands.length +
            " )\n"),
        b &&
          (S +=
            "• " +
            Xr("Update Mobile Style Commands") +
            " (" +
            i.mobileCommands.length +
            " )\n"),
        "overwrite" === this.importMode &&
          (y && (S += "• " + Xr("Clear all Main Menu Commands") + " ⚠️\n"),
          w && (S += "• " + Xr("Clear all Custom Commands") + " ⚠️\n"),
          v && (S += "• " + Xr("Clear all Following Style Commands") + " ⚠️\n"),
          C && (S += "• " + Xr("Clear all Top Style Commands") + " ⚠️\n"),
          x && (S += "• " + Xr("Clear all Fixed Style Commands") + " ⚠️\n"),
          k && (S += "• " + Xr("Clear all Mobile Style Commands") + " ⚠️\n")),
        d)
      ) {
        const e = i.enableMultipleConfig ? Xr("Enable") : Xr("Disable");
        S += "• " + Xr("Set Multiple Config to:") + " " + e + "\n";
      }
      if (
        (h &&
          (S +=
            "• " +
            Xr("Set Position Style to:") +
            " " +
            this.getPositionStyleName(h) +
            "\n"),
        !(u || p || m || g || f || b || y || w || v || C || x || k || c || d))
      )
        return void new e.Notice(
          Xr("No valid configuration found in import data"),
        );
      ("overwrite" === this.importMode
        ? (S +=
            "\n" +
            Xr(
              "⚠️ Overwrite mode will replace existing settings with imported ones.",
            ))
        : (S +=
            "\n" +
            Xr(
              "ℹ️ Update mode will merge imported settings with existing ones.",
            )),
        Ec.show(this.app, {
          message: S + "\n" + Xr("Do you want to continue?"),
          onConfirm: async () => {
            const t = {
              positionStyle: this.plugin.settings.positionStyle,
              menuCommands: [...this.plugin.settings.menuCommands],
              customCommands: [...this.plugin.settings.customCommands],
              followingCommands: [...this.plugin.settings.followingCommands],
              topCommands: [...this.plugin.settings.topCommands],
              fixedCommands: [...this.plugin.settings.fixedCommands],
              mobileCommands: [...this.plugin.settings.mobileCommands],
            };
            try {
              ("overwrite" === this.importMode
                ? this.performOverwriteImport(i)
                : this.performUpdateImport(i),
                this.fixImportedCommandIds(),
                await this.plugin.saveSettings(),
                this.plugin.reloadCustomCommands(),
                dispatchEvent(new Event("editingToolbar-NewCommand")),
                new e.Notice(Xr("Configuration imported successfully")),
                this.close());
            } catch (e) {
              throw (this.restoreBackup(t), e);
            }
          },
        }));
    } catch (t) {
      (console.error("Import error: ", t),
        new e.Notice(Xr("Error: ") + " " + t.message));
    }
  }
  performOverwriteImport(e) {
    (this.importGeneralSettings(e),
      e.menuCommands && (this.plugin.settings.menuCommands = e.menuCommands),
      e.customCommands &&
        (this.plugin.settings.customCommands = e.customCommands),
      e.followingCommands &&
        (this.plugin.settings.followingCommands = e.followingCommands),
      e.topCommands && (this.plugin.settings.topCommands = e.topCommands),
      e.fixedCommands && (this.plugin.settings.fixedCommands = e.fixedCommands),
      e.mobileCommands &&
        (this.plugin.settings.mobileCommands = e.mobileCommands));
  }
  performUpdateImport(e) {
    (this.importGeneralSettings(e),
      e.menuCommands &&
        this.updateCommandArray(
          this.plugin.settings.menuCommands,
          e.menuCommands,
        ),
      e.customCommands &&
        this.updateCommandArray(
          this.plugin.settings.customCommands,
          e.customCommands,
        ),
      e.followingCommands &&
        this.updateCommandArray(
          this.plugin.settings.followingCommands,
          e.followingCommands,
        ),
      e.topCommands &&
        this.updateCommandArray(
          this.plugin.settings.topCommands,
          e.topCommands,
        ),
      e.fixedCommands &&
        this.updateCommandArray(
          this.plugin.settings.fixedCommands,
          e.fixedCommands,
        ),
      e.mobileCommands &&
        this.updateCommandArray(
          this.plugin.settings.mobileCommands,
          e.mobileCommands,
        ));
  }
  updateCommandArray(e, t) {
    return e
      ? (t.forEach((t) => {
          const i = e.findIndex((e) => e.id === t.id);
          (i >= 0 ? (e[i] = t) : e.push(t),
            t.SubmenuCommands &&
              e[i]?.SubmenuCommands &&
              this.updateCommandArray(e[i].SubmenuCommands, t.SubmenuCommands));
        }),
        e)
      : t.slice();
  }
  importGeneralSettings(e) {
    [
      "positionStyle",
      "aestheticStyle",
      "appendMethod",
      "autohide",
      "Iscentered",
      "isLoadOnMobile",
      "cMenuNumRows",
      "enableMultipleConfig",
      "custom_bg1",
      "custom_bg2",
      "custom_bg3",
      "custom_bg4",
      "custom_bg5",
      "custom_fc1",
      "custom_fc2",
      "custom_fc3",
      "custom_fc4",
      "custom_fc5",
      "toolbarBackgroundColor",
      "toolbarIconColor",
      "toolbarIconSize",
    ].forEach((t) => {
      void 0 !== e[t] && (this.plugin.settings[t] = e[t]);
    });
  }
  fixImportedCommandIds() {
    const e = {
        "editor:toggle-numbered-list": "toolbar:toggle-numbered-list",
        "editor:toggle-bullet-list": "toolbar:toggle-bullet-list",
        "editor:toggle-highlight": "toolbar:toggle-highlight",
        "toggle-highlight": "toolbar:toggle-highlight",
        "toolbar:editor:toggle-bold": "toolbar:toggle-bold",
        "toolbar:editor:toggle-italics": "toolbar:toggle-italics",
        "toolbar:editor:toggle-strikethrough": "toolbar:toggle-strikethrough",
        "toolbar:editor:toggle-inline-math": "toolbar:toggle-inline-math",
        "toolbar:editor:insert-callout": "toolbar:insert-callout",
        "toolbar:editor:insert-link": "toolbar:insert-link",
        "cMenuToolbar-Divider-Line": "editingToolbar-Divider-Line",
      },
      t = (i) => {
        i &&
          Array.isArray(i) &&
          i.forEach((i) => {
            (i.id && e[i.id] && (i.id = e[i.id]),
              i.SubmenuCommands &&
                Array.isArray(i.SubmenuCommands) &&
                t(i.SubmenuCommands));
          });
      };
    (t(this.plugin.settings.menuCommands),
      t(this.plugin.settings.customCommands),
      t(this.plugin.settings.followingCommands),
      t(this.plugin.settings.topCommands),
      t(this.plugin.settings.fixedCommands),
      t(this.plugin.settings.mobileCommands));
  }
  restoreBackup(e) {
    ((this.plugin.settings.positionStyle = e.positionStyle),
      (this.plugin.settings.menuCommands = e.menuCommands),
      (this.plugin.settings.customCommands = e.customCommands),
      (this.plugin.settings.followingCommands = e.followingCommands),
      (this.plugin.settings.topCommands = e.topCommands),
      (this.plugin.settings.fixedCommands = e.fixedCommands),
      (this.plugin.settings.mobileCommands = e.mobileCommands));
  }
  onClose() {
    const { contentEl: e } = this;
    e.empty();
  }
  getPositionStyleName(e) {
    switch (e) {
      case "following":
        return Xr("Following Style");
      case "top":
        return Xr("Top Style");
      case "fixed":
        return Xr("Fixed Style");
      default:
        return e;
    }
  }
}
const Fc = [
  { id: "general", name: Xr("General"), icon: "gear" },
  { id: "appearance", name: Xr("Appearance"), icon: "brush" },
  {
    id: "customcommands",
    name: Xr("Custom Commands"),
    icon: "lucide-rectangle-ellipsis",
  },
  { id: "commands", name: Xr("Toolbar Commands"), icon: "lucide-command" },
  { id: "importexport", name: Xr("Import/Export"), icon: "lucide-import" },
];
function qc(e) {
  const { el: t, containerEl: i, swatches: o, opacity: n, defaultColor: s } = e;
  return {
    el: t,
    container: i,
    theme: "nano",
    swatches: o,
    lockOpacity: !n,
    default: s,
    position: "left-middle",
    components: {
      preview: !0,
      hue: !0,
      opacity: !!n,
      interaction: {
        hex: !0,
        rgba: !1,
        hsla: !1,
        input: !0,
        cancel: !0,
        save: !0,
      },
    },
  };
}
function _c(e, t) {
  let i;
  return (
    t.forEach((t, o) => {
      t.id === e && (i = o);
    }),
    i
  );
}
class zc extends e.PluginSettingTab {
  constructor(e, t) {
    (super(e, t),
      (this.pickrs = []),
      (this.activeTab = "general"),
      (this.aestheticStyleMap = {
        default: "editingToolbarDefaultAesthetic",
        tiny: "editingToolbarTinyAesthetic",
        glass: "editingToolbarGlassAesthetic",
        custom: "editingToolbarCustomAesthetic",
        top: "top",
        following: "editingToolbarFlex",
        fixed: "fixed",
      }),
      (this.plugin = t),
      (this.currentEditingConfig = this.plugin.settings.positionStyle),
      addEventListener("editingToolbar-NewCommand", () => {
        (ha(this.plugin), xa(e, this.plugin), this.display());
      }));
  }
  display() {
    this.destroyPickrs();
    const { containerEl: t } = this;
    (t.empty(), this.createHeader(t));
    const i = t.createEl("div", { cls: "toolbar-tabs" });
    Fc.forEach((t) => {
      const o = i.createEl("div", {
        cls: "toolbar-tab " + (this.activeTab === t.id ? "active" : ""),
      });
      (e.setIcon(o, t.icon),
        o.createEl("span", { text: t.name }),
        o.addEventListener("click", () => {
          ((this.activeTab = t.id), this.display());
        }));
    });
    const o = t.createEl("div", { cls: "toolbar-content" });
    switch (this.activeTab) {
      case "general":
        this.displayGeneralSettings(o);
        break;
      case "appearance":
        this.displayAppearanceSettings(o);
        break;
      case "customcommands":
        this.displayCustomCommandSettings(o);
        break;
      case "commands":
        this.displayCommandSettings(o);
        break;
      case "importexport":
        this.displayImportExportSettings(o);
    }
  }
  createDeleteButton(e, t, i = Xr("Delete")) {
    let o,
      n = !1;
    e.setIcon("editingToolbarDelete")
      .setTooltip(i)
      .onClick(async () => {
        n
          ? (clearTimeout(o),
            e.setIcon("editingToolbarDelete").setTooltip(i),
            e.buttonEl.removeClass("mod-warning"),
            (n = !1),
            await t())
          : ((n = !0),
            e
              .setTooltip(Xr("Confirm Delete?"))
              .setButtonText(Xr("Confirm Delete?")),
            e.buttonEl.addClass("mod-warning"),
            (o = setTimeout(() => {
              (e.setIcon("editingToolbarDelete").setTooltip(i),
                e.buttonEl.removeClass("mod-warning"),
                (n = !1));
            }, 3500)));
      });
  }
  displayGeneralSettings(t) {
    const i = t.createDiv("generalSetting-container");
    ((i.style.padding = "16px"),
      (i.style.borderRadius = "8px"),
      (i.style.backgroundColor = "var(--background-secondary)"),
      (i.style.marginBottom = "20px"),
      new e.Setting(i)
        .setName(Xr("Toolbar Append Method"))
        .setDesc(Xr("Choose where Toolbar will append upon regeneration."))
        .addDropdown((e) => {
          let t = {};
          (na.map((e) => (t[e] = e)),
            e.addOptions(t),
            e.setValue(this.plugin.settings.appendMethod).onChange((e) => {
              ((this.plugin.settings.appendMethod = e),
                this.plugin.saveSettings());
            }));
        }),
      new e.Setting(i)
        .setName(Xr("Enable Multiple Configurations"))
        .setDesc(
          Xr(
            "Enable different command configurations for each position style (following, top, fixed).",
          ),
        )
        .addToggle((e) =>
          e
            .setValue(this.plugin.settings.enableMultipleConfig || !1)
            .onChange(async (e) => {
              ((this.plugin.settings.enableMultipleConfig = e),
                this.plugin.onPositionStyleChange(this.plugin.positionStyle),
                await this.plugin.saveSettings(),
                this.display());
            }),
        ),
      new e.Setting(i)
        .setName(Xr("Top Toolbar"))
        .setDesc(Xr("Enable the toolbar positioned at the top."))
        .addToggle((e) => {
          e.setValue(this.plugin.settings.enableTopToolbar || !1).onChange(
            async (e) => {
              const t = this.plugin.settings,
                i = this.plugin.positionStyle;
              t.enableTopToolbar = e;
              let o = null;
              (e
                ? (o = "top")
                : "top" === i &&
                  (o = t.enableFollowingToolbar
                    ? "following"
                    : t.enableFixedToolbar
                      ? "fixed"
                      : null),
                o && o !== i && this.plugin.onPositionStyleChange(o),
                await this.plugin.saveSettings(),
                this.plugin.handleeditingToolbar(),
                this.display());
            },
          );
        }),
      new e.Setting(i)
        .setName(Xr("Following Toolbar"))
        .setDesc(Xr("Enable the toolbar that appears upon text selection."))
        .addToggle((e) => {
          e.setValue(
            this.plugin.settings.enableFollowingToolbar || !1,
          ).onChange(async (e) => {
            const t = this.plugin.settings,
              i = this.plugin.positionStyle;
            t.enableFollowingToolbar = e;
            let o = null;
            (e
              ? (o = "following")
              : "following" === i &&
                (o = t.enableTopToolbar
                  ? "top"
                  : t.enableFixedToolbar
                    ? "fixed"
                    : null),
              o && o !== i && this.plugin.onPositionStyleChange(o),
              await this.plugin.saveSettings(),
              this.plugin.handleeditingToolbar(),
              this.display());
          });
        }),
      new e.Setting(i)
        .setName(Xr("Fixed Toolbar"))
        .setDesc(
          Xr(
            "Enable the toolbar whose position may be fixed where you please.",
          ),
        )
        .addToggle((e) => {
          e.setValue(this.plugin.settings.enableFixedToolbar || !1).onChange(
            async (e) => {
              const t = this.plugin.settings,
                i = this.plugin.positionStyle;
              t.enableFixedToolbar = e;
              let o = null;
              (e
                ? (o = "fixed")
                : "fixed" === i &&
                  (o = t.enableTopToolbar
                    ? "top"
                    : t.enableFollowingToolbar
                      ? "following"
                      : null),
                o && o !== i && this.plugin.onPositionStyleChange(o),
                await this.plugin.saveSettings(),
                this.plugin.handleeditingToolbar(),
                this.display());
            },
          );
        }),
      new e.Setting(i)
        .setName(Xr("Mobile Enabled or Not"))
        .setDesc(
          Xr(
            "Whether to enable on mobile devices with device width less than 768px.",
          ),
        )
        .addToggle((e) =>
          e
            .setValue(this.plugin.settings?.isLoadOnMobile ?? !1)
            .onChange((e) => {
              ((this.plugin.settings.isLoadOnMobile = e),
                this.plugin.saveSettings(),
                this.triggerRefresh());
            }),
        ));
  }
  displayAppearanceSettings(t) {
    const i = t.createDiv("appearanceSetting-container");
    ((i.style.padding = "16px"),
      (i.style.borderRadius = "8px"),
      (i.style.backgroundColor = "var(--background-secondary)"),
      (i.style.marginBottom = "20px"));
    const o =
      this.plugin.appearanceEditStyle ||
      this.plugin.settings.positionStyle ||
      "top";
    ((this.plugin.appearanceEditStyle = o),
      new e.Setting(i)
        .setName(Xr("Toolbar Settings"))
        .setDesc(
          Xr("Choose which toolbar style's appearance you want to edit."),
        )
        .addDropdown((e) => {
          const t = {};
          (ra.map((e) => (t[e] = e)),
            e
              .addOptions(t)
              .setValue(o)
              .onChange(async (e) => {
                const t = e;
                ((this.plugin.appearanceEditStyle = t),
                  (this.plugin.settings.positionStyle = t),
                  await this.plugin.saveSettings(),
                  this.display());
              }));
        }),
      "top" === o &&
        (new e.Setting(i)
          .setName(Xr("Toolbar Auto-hide"))
          .setDesc(
            Xr(
              "The toolbar is displayed when the mouse moves over it, otherwise it is automatically hidden",
            ),
          )
          .addToggle((e) =>
            e.setValue(this.plugin.settings?.autohide).onChange((e) => {
              ((this.plugin.settings.autohide = e),
                this.plugin.saveSettings(),
                this.triggerRefresh());
            }),
          ),
        new e.Setting(i)
          .setName(Xr("Toolbar Centred Display"))
          .setDesc(
            Xr(
              "Whether the toolbar is centred or full-width, the default is full-width.",
            ),
          )
          .addToggle((e) =>
            e.setValue(this.plugin.settings?.Iscentered).onChange((e) => {
              ((this.plugin.settings.Iscentered = e),
                this.plugin.saveSettings(),
                this.triggerRefresh());
            }),
          )),
      "fixed" === o &&
        (new e.Setting(i)
          .setName(Xr("Toolbar Columns"))
          .setDesc(
            Xr("Choose the number of columns per row to display on Toolbar."),
          )
          .addSlider((t) => {
            t.setLimits(1, 32, 1)
              .setValue(this.plugin.settings.cMenuNumRows)
              .onChange(
                e.debounce(
                  async (e) => {
                    ((this.plugin.settings.cMenuNumRows = e),
                      await this.plugin.saveSettings(),
                      this.triggerRefresh());
                  },
                  100,
                  !0,
                ),
              )
              .setDynamicTooltip();
          }),
        new e.Setting(i)
          .setName(Xr("Fixed Position Offset"))
          .setDesc(
            Xr("Choose the offset of the Toolbar in the fixed position."),
          )
          .addButton((e) =>
            e.setButtonText(Xr("Settings")).onClick(() => {
              new oa(this.app, this.plugin).open();
            }),
          )),
      this.createColorSettings(t));
  }
  displayCommandSettings(t) {
    const i = t.createDiv("commandSetting-container");
    if (
      ((i.style.padding = "16px"),
      (i.style.borderRadius = "8px"),
      (i.style.backgroundColor = "var(--background-secondary)"),
      (i.style.marginBottom = "20px"),
      this.plugin.settings.enableMultipleConfig &&
        new e.Setting(i)
          .setName(Xr("Current Configuration"))
          .setDesc(Xr("Switch between different command configurations."))
          .addDropdown((e) => {
            (e.addOption("top", Xr("Top Style")),
              e.addOption("fixed", Xr("Fixed Style")),
              e.addOption("following", Xr("Following Style")),
              this.plugin.settings.isLoadOnMobile &&
                e.addOption("mobile", Xr("Mobile Style")),
              e.setValue(this.currentEditingConfig),
              e.onChange(async (e) => {
                ((this.currentEditingConfig = e), this.display());
              }));
          }),
      this.plugin.settings.enableMultipleConfig)
    ) {
      const i = this.currentEditingConfig;
      this.getCommandsArrayByType(i);
      const o = t.createDiv("command-buttons-container");
      ((o.style.display = "flex"),
        (o.style.flexDirection = "column"),
        (o.style.gap = "10px"),
        (o.style.padding = "16px"),
        (o.style.borderRadius = "8px"),
        (o.style.backgroundColor = "var(--background-secondary)"));
      const n = new e.Setting(o)
        .setName(Xr("Import From"))
        .setDesc(Xr("Copy commands from another style configuration."));
      let s = "Main menu";
      const r = new e.Setting(o);
      (r.addDropdown((e) => {
        (e.addOption("Main menu", "Main Menu Commands"),
          "following" !== i &&
            this.plugin.settings.followingCommands &&
            e.addOption("following", Xr("Following Style")),
          "top" !== i &&
            this.plugin.settings.topCommands &&
            e.addOption("top", Xr("Top Style")),
          "fixed" !== i &&
            this.plugin.settings.fixedCommands &&
            e.addOption("fixed", Xr("Fixed Style")),
          "mobile" !== i &&
            this.plugin.settings.mobileCommands &&
            e.addOption("mobile", Xr("Mobile Style")),
          e.setValue(s).onChange((e) => {
            s = e;
          }));
      }),
        r.addExtraButton((e) => e.setIcon("arrow-right")),
        r.addButton((t) =>
          t
            .setButtonText(this.currentEditingConfig + " " + Xr("Import"))
            .setTooltip("Copy commands from selected style.")
            .onClick(async () => {
              const t = this.getCommandsArrayByType(s);
              if (!t || 0 === t.length)
                return void new e.Notice(
                  "The selected style has no commands to import.",
                );
              const o =
                `Import commands from "${s}" to "${this.currentEditingConfig}" ` +
                Xr("configuration") +
                "?";
              Ec.show(this.app, {
                message: o,
                onConfirm: async () => {
                  switch (i) {
                    case "Main menu":
                      this.plugin.settings.menuCommands = [...t];
                      break;
                    case "following":
                      this.plugin.settings.followingCommands = [...t];
                      break;
                    case "top":
                      this.plugin.settings.topCommands = [...t];
                      break;
                    case "fixed":
                      this.plugin.settings.fixedCommands = [...t];
                      break;
                    case "mobile":
                      this.plugin.settings.mobileCommands = [...t];
                  }
                  (await this.plugin.saveSettings(),
                    new e.Notice(
                      `Commands imported successfully from "${s}" to "${this.currentEditingConfig}" ` +
                        Xr("configuration"),
                    ),
                    this.display());
                },
              });
            }),
        ),
        n.addButton((t) =>
          t
            .setButtonText(Xr("Clear") + " " + `${this.currentEditingConfig}`)
            .setTooltip(Xr("Remove all commands from this configuration."))
            .setWarning()
            .onClick(async () => {
              Ec.show(this.app, {
                message: Xr(
                  "Are you sure you want to clear all commands under the current style?",
                ),
                onConfirm: async () => {
                  switch (i) {
                    case "following":
                      this.plugin.settings.followingCommands = [];
                      break;
                    case "top":
                      this.plugin.settings.topCommands = [];
                      break;
                    case "fixed":
                      this.plugin.settings.fixedCommands = [];
                      break;
                    case "mobile":
                      this.plugin.settings.mobileCommands = [];
                  }
                  (await this.plugin.saveSettings(),
                    new e.Notice("All commands have been removed."),
                    this.display());
                },
              });
            }),
        ));
    } else {
      i.createDiv("command-buttons-container")
        .createEl("button", { text: Xr("One-click Clear"), cls: "mod-warning" })
        .addEventListener("click", async () => {
          Ec.show(this.app, {
            message: Xr(
              "Are you sure you want to clear all commands under the current style?",
            ),
            onConfirm: async () => {
              ((this.plugin.settings.menuCommands = []),
                await this.plugin.saveSettings(),
                new e.Notice(Xr("All commands have been removed.")),
                this.display());
            },
          });
        });
    }
    const o = t.createDiv("command-lists-container");
    ((o.style.padding = "16px"),
      (o.style.borderRadius = "8px"),
      o.addClass(`${this.currentEditingConfig}`),
      this.plugin.settings.enableMultipleConfig &&
        o.createEl("div", {
          cls: `position-style-info ${this.currentEditingConfig}`,
          text:
            Xr("Currently editing commands for") +
            ` "${this.currentEditingConfig} Style" ` +
            Xr("configuration"),
        }),
      new e.Setting(o)
        .setName(Xr("Toolbar Commands"))
        .setDesc(
          Xr(
            "Add a command onto Toolbar from Obsidian's commands library. To reorder the commands, drag and drop the command items. To delete them, use the delete buttom to the right of the command item. Toolbar will not automaticaly refresh after reordering commands. Use the refresh button above.",
          ),
        )
        .addButton((e) => {
          e.setIcon("plus")
            .setTooltip(Xr("Add"))
            .onClick(() => {
              (new ta(this.plugin, this.currentEditingConfig).open(),
                this.triggerRefresh());
            });
        }),
      this.createCommandList(o));
  }
  displayCustomCommandSettings(t) {
    t.empty();
    const i = t.createDiv("custom-commands-container");
    (i.createEl("p", {
      text: Xr("Add, edit or delete custom format commands."),
    }),
      new e.Setting(i)
        .setName(Xr("Use current line for regex commands"))
        .setDesc(
          Xr(
            "When no text is selected, regex commands will use the current line instead of clipboard content",
          ),
        )
        .addToggle((e) =>
          e
            .setValue(this.plugin.settings?.useCurrentLineForRegex ?? !1)
            .onChange(async (e) => {
              ((this.plugin.settings.useCurrentLineForRegex = e),
                await this.plugin.saveSettings());
            }),
        ));
    const o = i.createDiv("command-list-container");
    ((o.style.padding = "16px"),
      (o.style.borderRadius = "8px"),
      (o.style.backgroundColor = "var(--background-secondary)"),
      (o.style.marginBottom = "20px"),
      (o.style.marginTop = "20px"));
    const n = i.createDiv("add-command-button-container");
    ((n.style.padding = "16px"),
      (n.style.borderRadius = "8px"),
      (n.style.backgroundColor = "var(--background-secondary)"),
      (n.style.marginBottom = "20px"),
      (n.style.marginTop = "20px"),
      (n.style.display = "flex"),
      (n.style.gap = "10px"));
    const s = n.createEl("button", { text: Xr("Add Format Command") });
    (s.addClass("mod-cta"),
      s.addEventListener("click", () => {
        new Pc(this.app, this.plugin, null).open();
      }));
    const r = n.createEl("button", { text: Xr("Add Regex Command") });
    (r.addClass("mod-cta"),
      r.addEventListener("click", () => {
        new Lc(this.app, this.plugin, null).open();
      }),
      this.plugin.settings.customCommands.forEach((t, i) => {
        const n = new e.Setting(o).setName(t.name),
          s = createFragment();
        let r = `${Xr("ID")}: ${t.id}`;
        (t.useRegex
          ? (r += `, ${Xr("Pattern")}: ${t.regexPattern}`)
          : (r += `, ${Xr("Prefix")}: ${t.prefix}, ${Xr("Suffix")}: ${t.suffix}`),
          s.createSpan({ text: r }));
        const a = s.createSpan({ cls: "command-type-badge" });
        if (
          (t.useRegex
            ? (a.addClass("regex"), a.setText(Xr("Regex")))
            : a.setText(Xr("Prefix/Suffix")),
          n.descEl.appendChild(s),
          n
            .addButton((i) =>
              i
                .setButtonText(Xr("Add to Toolbar"))
                .setTooltip(Xr("Add this command to the toolbar."))
                .setButtonText(Xr("Add to Toolbar"))
                .setTooltip(Xr("Add this command to the toolbar."))
                .onClick(() => {
                  if (this.plugin.settings.enableMultipleConfig)
                    new Nc(this.app, this.plugin, t).open();
                  else {
                    if (
                      this.plugin.settings.menuCommands.some(
                        (e) => e.id === `toolbar:${t.id}`,
                      )
                    )
                      return void new e.Notice(
                        Xr("This command is already in the toolbar."),
                      );
                    const i = {
                      id: `toolbar:${t.id}`,
                      name: t.name,
                      icon: t.icon || "obsidian-new",
                    };
                    (this.plugin.settings.menuCommands.push(i),
                      this.plugin.saveSettings().then(() => {
                        (new e.Notice(Xr("Command added to toolbar")),
                          dispatchEvent(new Event("editingToolbar-NewCommand")),
                          this.plugin.reloadCustomCommands());
                      }));
                  }
                }),
            )
            .addExtraButton((e) => {
              e.setIcon("pencil")
                .setTooltip(Xr("Edit"))
                .onClick(() => {
                  t.useRegex
                    ? new Lc(this.app, this.plugin, i).open()
                    : new Pc(this.app, this.plugin, i).open();
                });
            })
            .addButton((t) =>
              this.createDeleteButton(t, async () => {
                const t = `toolbar:${this.plugin.settings.customCommands[i].id}`;
                (this.removeCommandFromConfig(
                  this.plugin.settings.menuCommands,
                  t,
                ),
                  this.plugin.settings.enableMultipleConfig &&
                    (this.removeCommandFromConfig(
                      this.plugin.settings.followingCommands,
                      t,
                    ),
                    this.removeCommandFromConfig(
                      this.plugin.settings.topCommands,
                      t,
                    ),
                    this.removeCommandFromConfig(
                      this.plugin.settings.fixedCommands,
                      t,
                    ),
                    this.plugin.settings.isLoadOnMobile &&
                      this.removeCommandFromConfig(
                        this.plugin.settings.mobileCommands,
                        t,
                      )),
                  this.plugin.settings.customCommands.splice(i, 1),
                  await this.plugin.saveSettings(),
                  this.plugin.reloadCustomCommands(),
                  this.display(),
                  new e.Notice(Xr("Command Deleted")));
              }),
            ),
          t.icon)
        )
          try {
            const i = n.nameEl.createSpan({
              cls: "editingToolbarSettingsIcon",
            });
            ((i.style.marginRight = "8px"),
              fa(t.icon) ? (i.innerHTML = t.icon) : e.setIcon(i, t.icon));
          } catch (e) {
            console.error("Failed to set icon:", e);
          }
      }));
  }
  triggerRefresh() {
    setTimeout(() => {
      dispatchEvent(new Event("editingToolbar-NewCommand"));
    }, 100);
  }
  createHeader(t) {
    const i = t.createEl("div", { cls: "toolbar-header" });
    i.createEl("div", { cls: "toolbar-title-container" }).createEl("h1", {
      text: "Obsidian Toolbar: " + this.plugin.manifest.version,
      cls: "toolbar-title",
    });
    const o = i.createEl("div", { cls: "toolbar-info" });
    new e.Setting(o).setClass("toolbar-fix-button").addButton((e) => {
      e.setIcon("wrench")
        .setTooltip(Xr("Fix"))
        .onClick(() => {
          new Mc(this.app, this.plugin).open();
        });
    });
  }
  getAppearanceBucket(e) {
    const t = this.plugin.settings;
    (t.appearanceByStyle && "object" == typeof t.appearanceByStyle) ||
      (t.appearanceByStyle = {});
    const i = t.appearanceByStyle;
    return ((i[e] && "object" == typeof i[e]) || (i[e] = {}), i[e]);
  }
  createColorSettings(t) {
    const i =
        this.plugin.appearanceEditStyle ||
        this.plugin.settings.positionStyle ||
        "top",
      o = this.getAppearanceBucket(i),
      n = t.createDiv("custom-paintbrush-container");
    ((n.style.padding = "16px"),
      (n.style.borderRadius = "8px"),
      (n.style.backgroundColor = "var(--background-secondary)"),
      (n.style.marginBottom = "20px"),
      new e.Setting(n)
        .setName(Xr("🎨 Set Custom Background"))
        .setDesc(Xr("Click on the picker to adjust the color"))
        .setClass("custom_bg")
        .then((e) => {
          const t = e.controlEl.createDiv({ cls: "pickr-container" });
          for (let e = 0; e < 5; e++) {
            const i = t.createDiv({ cls: "picker" }),
              o = Dc.create(
                qc({
                  isView: !1,
                  el: i,
                  containerEl: t,
                  swatches: [
                    "#FFB78B8C",
                    "#CDF4698C",
                    "#A0CCF68C",
                    "#F0A7D88C",
                    "#ADEFEF8C",
                  ],
                  opacity: !0,
                  defaultColor:
                    this.plugin.settings[`custom_bg${e + 1}`] || "#000000",
                }),
              );
            (this.setupPickrEvents(o, `custom_bg${e + 1}`, "background-color"),
              this.pickrs.push(o));
          }
        }),
      new e.Setting(n)
        .setName(Xr("🖌️ Set Custom Font Color"))
        .setDesc(Xr("Click on the picker to adjust the color"))
        .setClass("custom_font")
        .then((e) => {
          const t = e.controlEl.createDiv({ cls: "pickr-container" });
          for (let e = 0; e < 5; e++) {
            const i = t.createDiv({ cls: "picker" }),
              o = Dc.create(
                qc({
                  isView: !1,
                  el: i,
                  containerEl: t,
                  swatches: [
                    "#D83931",
                    "#DE7802",
                    "#245BDB",
                    "#6425D0",
                    "#646A73",
                  ],
                  opacity: !0,
                  defaultColor:
                    this.plugin.settings[`custom_fc${e + 1}`] || "#000000",
                }),
              );
            (this.setupPickrEvents(o, `custom_fc${e + 1}`, "color"),
              this.pickrs.push(o));
          }
        }));
    const s = t.createDiv("custom-toolbar-container");
    ((s.style.padding = "16px"),
      (s.style.borderRadius = "8px"),
      (s.style.backgroundColor = "var(--background-secondary)"),
      new e.Setting(s)
        .setName(Xr("Toolbar Theme"))
        .setDesc(
          Xr(
            "Select a preset toolbar theme, automatically setting the background color, icon color, and size for the selected style.",
          ),
        )
        .addDropdown((e) => {
          const t = {};
          (sa.forEach((e) => {
            t[e] = "custom" === e ? Xr("Custom Theme") : e;
          }),
            e.addOptions(t),
            (e.selectEl.options[3].disabled = !0),
            e.addOption("light", "┌ Light"),
            e.addOption("dark", "├ Dark"),
            e.addOption("vibrant", "├ Vibrant"),
            e.addOption("minimal", "├ Minimal"),
            e.addOption("elegant", "└ Elegant"),
            e.setValue(o.aestheticStyle ?? this.plugin.settings.aestheticStyle),
            e.onChange(async (e) => {
              const i =
                  this.plugin.appearanceEditStyle ||
                  this.plugin.settings.positionStyle ||
                  "top",
                o = this.getAppearanceBucket(i);
              switch (
                (e in t
                  ? ((o.aestheticStyle = e), (o.toolbarIconSize = 18))
                  : (o.aestheticStyle = "custom"),
                e)
              ) {
                case "light":
                  ((o.toolbarBackgroundColor = "#F5F8FA"),
                    (o.toolbarIconColor = "#4A5568"),
                    (o.toolbarIconSize = 18));
                  break;
                case "dark":
                  ((o.toolbarBackgroundColor = "#2D3033"),
                    (o.toolbarIconColor = "#E2E8F0"),
                    (o.toolbarIconSize = 18));
                  break;
                case "vibrant":
                  ((o.toolbarBackgroundColor = "#7E57C2"),
                    (o.toolbarIconColor = "#FFFFFF"),
                    (o.toolbarIconSize = 20));
                  break;
                case "minimal":
                  ((o.toolbarBackgroundColor = "#F8F9FA"),
                    (o.toolbarIconColor = "#6B7280"),
                    (o.toolbarIconSize = 16));
                  break;
                case "elegant":
                  ((o.toolbarBackgroundColor = "#1A2F28"),
                    (o.toolbarIconColor = "#D4AF37"),
                    (o.toolbarIconSize = 19));
              }
              const n =
                  o.toolbarBackgroundColor ??
                  this.plugin.settings.toolbarBackgroundColor,
                s = o.toolbarIconColor ?? this.plugin.settings.toolbarIconColor,
                r = o.toolbarIconSize ?? 18;
              (document.documentElement.style.setProperty(
                "--toolbar-background-color",
                n,
              ),
                document.documentElement.style.setProperty(
                  "--toolbar-icon-color",
                  s,
                ),
                document.documentElement.style.setProperty(
                  "--toolbar-icon-size",
                  `${r}px`,
                ),
                (this.plugin.toolbarIconSize = r),
                this.destroyPickrs(),
                this.display(),
                await this.plugin.saveSettings(),
                this.triggerRefresh());
            }));
        }),
      new e.Setting(s)
        .setName(Xr("Toolbar Background Color"))
        .setDesc(Xr("Set the background color of the toolbar."))
        .setClass("toolbar_background")
        .then((e) => {
          const t = e.controlEl.createDiv({ cls: "pickr-container" }),
            i = t.createDiv({ cls: "picker" }),
            n = Dc.create(
              qc({
                isView: !1,
                el: i,
                containerEl: t,
                swatches: [
                  "#F5F8FA",
                  "#F4F1E8",
                  "#2D3033",
                  "#1A2F28",
                  "#2A1D3B",
                ],
                opacity: !0,
                defaultColor:
                  o.toolbarBackgroundColor ??
                  this.plugin.settings.toolbarBackgroundColor,
              }),
            );
          (this.setupPickrEvents(
            n,
            "toolbarBackgroundColor",
            "background-color",
          ),
            this.pickrs.push(n));
        }),
      new e.Setting(s)
        .setName(Xr("Toolbar Icon Color"))
        .setDesc(Xr("Set the color of the toolbar icon."))
        .setClass("toolbar_icon")
        .then((e) => {
          const t = e.controlEl.createDiv({ cls: "pickr-container" }),
            i = t.createDiv({ cls: "picker" }),
            o = Dc.create(
              qc({
                isView: !1,
                el: i,
                containerEl: t,
                swatches: [
                  "#4A5568",
                  "#D4AF37",
                  "#2D3033",
                  "#6D5846",
                  "#4C2A55",
                ],
                opacity: !1,
                defaultColor: this.plugin.settings.toolbarIconColor,
              }),
            );
          (this.pickrs.push(o),
            this.setupPickrEvents(o, "toolbarIconColor", "icon-color"));
        }),
      new e.Setting(s)
        .setName(Xr("Toolbar Icon Size"))
        .setDesc(Xr("Set the size of the toolbar icon (px); default: 18px"))
        .addSlider((e) => {
          const t = o.toolbarIconSize ?? this.plugin.settings.toolbarIconSize;
          e.setValue(t)
            .setLimits(12, 32, 1)
            .setDynamicTooltip()
            .onChange(async (e) => {
              const t = this.plugin.positionStyle,
                i =
                  this.plugin.appearanceEditStyle ||
                  this.plugin.settings.positionStyle ||
                  "top",
                o = this.getAppearanceBucket(i);
              ((o.toolbarIconSize = e),
                (o.aestheticStyle = "custom"),
                t === i &&
                  ((this.plugin.toolbarIconSize = e),
                  document.documentElement.style.setProperty(
                    "--toolbar-icon-size",
                    `${e}px`,
                  )),
                await this.plugin.saveSettings(),
                this.display(),
                this.triggerRefresh());
            });
        }));
    const r = s.createDiv("toolbar-preview-container");
    (r.addClass("toolbar-preview-section"), (r.style.marginTop = "20px"));
    r.createEl("h3", {
      text: Xr("Toolbar Preview (With a hypothetical command configuration.)"),
    }).style.marginBottom = "10px";
    const a = r.createDiv();
    (a.classList.add("preview-toolbar-wrapper"),
      a.classList.add(`preview-${i}`));
    const l = a.createDiv();
    (l.classList.add("toolbar-preview"),
      l.classList.add(`preview-${i}`),
      l.setAttribute("id", "editingToolbarModalBar"));
    const c =
      o.aestheticStyle ?? this.plugin.settings.aestheticStyle ?? "default";
    if ((this.applyAestheticStyle(l, c, i), "fixed" === i)) {
      const e = this.plugin.settings.toolbarIconSize || 18,
        t = this.plugin.settings.cMenuNumRows || 6;
      ((l.style.display = "grid"),
        (l.style.gridTemplateColumns = `repeat(${t}, ${e + 10}px)`),
        (l.style.gap = `${Math.max((e - 18) / 4, 2)}px`),
        (l.style.margin = "0 auto"));
    }
    [
      { id: "bold", name: "Bold", icon: "bold" },
      { id: "italics", name: "Italics", icon: "italic" },
      { id: "trikethrough", name: "Strikethrough", icon: "strikethrough" },
      { id: "code", name: "Code", icon: "code" },
      { id: "blockquote", name: "Blockquote", icon: "quote-glyph" },
      { id: "insert-link", name: "Link", icon: "link" },
      { id: "left-sidebar", name: "Left sidebar", icon: "lucide-panel-left" },
      { id: "editor:insert-embed", name: "Add embed", icon: "note-glyph" },
      {
        id: "editor:insert-link",
        name: "Insert markdown link",
        icon: "link-glyph",
      },
      { id: "editor:insert-tag", name: "Add tag", icon: "price-tag-glyph" },
      {
        id: "editor:insert-wikilink",
        name: "Add internal link",
        icon: "bracket-glyph",
      },
      { id: "editor:toggle-code", name: "Code", icon: "code-glyph" },
      {
        id: "editor:toggle-blockquote",
        name: "Blockquote",
        icon: "lucide-text-quote",
      },
      {
        id: "editor:toggle-checklist-status",
        name: "Checklist status",
        icon: "checkbox-glyph",
      },
      {
        id: "editor:toggle-comments",
        name: "Comment",
        icon: "percent-sign-glyph",
      },
      {
        id: "editor:insert-callout",
        name: "Insert Callout",
        icon: "lucide-quote",
      },
      {
        id: "editor:insert-mathblock",
        name: "MathBlock",
        icon: "lucide-sigma-square",
      },
      { id: "editor:insert-table", name: "Insert Table", icon: "lucide-table" },
    ].forEach((t) => {
      const i = new e.ButtonComponent(l);
      (i.setClass("editingToolbarCommandItem"),
        i.buttonEl.classList.add("preview-button"),
        i.setTooltip(t.name),
        t.icon && e.setIcon(i.buttonEl, t.icon));
    });
    const d = "custom" === c,
      h =
        o.toolbarBackgroundColor ?? this.plugin.settings.toolbarBackgroundColor,
      u = o.toolbarIconColor ?? this.plugin.settings.toolbarIconColor,
      p = o.toolbarIconSize ?? this.plugin.settings.toolbarIconSize ?? 18;
    d && h
      ? (l.style.backgroundColor = h)
      : l.style.removeProperty("background-color");
    l.querySelectorAll("svg").forEach((e) => {
      (d && u ? (e.style.color = u) : e.style.removeProperty("color"),
        (e.style.width = `${p}px`),
        (e.style.height = `${p}px`));
    });
  }
  createCommandList(t) {
    let i = [];
    if (this.plugin.settings.enableMultipleConfig)
      switch (this.currentEditingConfig) {
        case "mobile":
          i = this.plugin.settings.mobileCommands;
          break;
        case "following":
          i = this.plugin.settings.followingCommands;
          break;
        case "top":
          i = this.plugin.settings.topCommands;
          break;
        case "fixed":
          i = this.plugin.settings.fixedCommands;
          break;
        default:
          i = this.plugin.settings.menuCommands;
      }
    else i = this.plugin.settings.menuCommands;
    const o = t.createEl("div", { cls: "editingToolbarSettingsTabsContainer" });
    let n = "";
    sc.create(o, {
      group: "item",
      animation: 500,
      draggable: ".setting-item",
      ghostClass: "sortable-ghost",
      chosenClass: "sortable-chosen",
      dragClass: "sortable-drag",
      dragoverBubble: !1,
      forceFallback: !0,
      fallbackOnBody: !0,
      swapThreshold: 0.7,
      fallbackClass: "sortable-fallback",
      easing: "cubic-bezier(1, 0, 0, 1)",
      delay: 800,
      delayOnTouchOnly: !0,
      touchStartThreshold: 5,
      filter:
        ".setting-item-control button, .dropdown, .editingToolbarMenuTypeDropdown",
      preventOnFilter: !1,
      onChoose: function (e) {
        e.item.classList.add("sortable-chosen-feedback");
      },
      onUnchoose: function (e) {
        e.item.classList.remove("sortable-chosen-feedback");
      },
      onSort: (e) => {
        if (e.from.className === e.to.className) {
          const t = i,
            [o] = t.splice(e.oldIndex, 1);
          if (
            (t.splice(e.newIndex, 0, o),
            this.plugin.settings.enableMultipleConfig)
          )
            switch (this.currentEditingConfig) {
              case "mobile":
                this.plugin.settings.mobileCommands = t;
                break;
              case "following":
                this.plugin.settings.followingCommands = t;
                break;
              case "top":
                this.plugin.settings.topCommands = t;
                break;
              case "fixed":
                this.plugin.settings.fixedCommands = t;
            }
          else this.plugin.settings.menuCommands = t;
          this.plugin.saveSettings();
        }
        this.triggerRefresh();
      },
      onStart: function (e) {
        n = e.item.className;
      },
    });
    const s = i;
    s.forEach((t, r) => {
      const a = new e.Setting(o);
      if ("SubmenuCommands" in t) {
        if (
          (a.settingEl.setAttribute("data-id", t.id),
          a
            .setClass("editingToolbarCommandItem")
            .setClass("editingToolbarCommandsubItem")
            .setName(t.name)
            .addButton((e) => {
              (e.setClass("editingToolbarSettingsIcon").onClick(async () => {
                new Qr(
                  this.plugin,
                  t,
                  !1,
                  null,
                  this.currentEditingConfig,
                ).open();
              }),
                fa(t.icon)
                  ? (e.buttonEl.innerHTML = t.icon)
                  : e.setIcon(t.icon));
            })
            .addButton((e) => {
              e.setIcon("pencil")
                .setTooltip(Xr("Change Submenu Name"))
                .setClass("editingToolbarSettingsButton")
                .onClick(async () => {
                  new ia(
                    this.app,
                    this.plugin,
                    t,
                    !1,
                    this.currentEditingConfig,
                  ).open();
                });
            })
            .addDropdown((i) => {
              (i
                .addOption("submenu", Xr("Button Submenu"))
                .addOption("dropdown", Xr("Dropdown Menu"))
                .setValue(t.menuType || "submenu")
                .onChange(async (i) => {
                  ((t.menuType = i),
                    this.plugin.updateCurrentCommands(
                      s,
                      this.currentEditingConfig,
                    ),
                    await this.plugin.saveSettings(),
                    this.triggerRefresh(),
                    new e.Notice(
                      Xr("Menu type changed to") +
                        ": " +
                        Xr(
                          "dropdown" === i ? "Dropdown Menu" : "Button Submenu",
                        ),
                    ));
                }),
                i.selectEl.addClass("editingToolbarMenuTypeDropdown"));
            })
            .addButton((e) =>
              this.createDeleteButton(e, async () => {
                (s.remove(t),
                  this.plugin.updateCurrentCommands(
                    s,
                    this.currentEditingConfig,
                  ),
                  await this.plugin.saveSettings(),
                  this.display(),
                  this.triggerRefresh(),
                  console.log(
                    `%cCommand '${t.name}' was removed from editingToolbar`,
                    "color: #989cab",
                  ));
              }),
            ),
          "editingToolbar-plugin:change-font-color" == t.id)
        )
          return;
        if ("editingToolbar-plugin:change-background-color" == t.id) return;
        const o = a.settingEl.createEl("div", {
          cls: "editingToolbarSettingsTabsContainer_sub",
        });
        (sc.create(o, {
          group: {
            name: "item",
            pull: !0,
            put: function () {
              return !n.includes("editingToolbarCommandsubItem");
            },
          },
          draggable: ".setting-item",
          animation: 150,
          ghostClass: "sortable-ghost",
          chosenClass: "sortable-chosen",
          dragClass: "sortable-drag",
          dragoverBubble: !1,
          fallbackOnBody: !0,
          swapThreshold: 0.7,
          forceFallback: !0,
          delay: 800,
          delayOnTouchOnly: !0,
          touchStartThreshold: 5,
          fallbackClass: "sortable-fallback",
          easing: "cubic-bezier(1, 0, 0, 1)",
          onStart: function () {},
          onSort: (e) => {
            if (e.from.className === e.to.className) {
              const t = i,
                o = t[r]?.SubmenuCommands;
              if (o) {
                const [i] = o.splice(e.oldIndex, 1);
                (o.splice(e.newIndex, 0, i),
                  this.plugin.updateCurrentCommands(
                    t,
                    this.currentEditingConfig,
                  ),
                  this.plugin.saveSettings());
              }
            } else if (
              "editingToolbarSettingsTabsContainer" === e.to.className
            ) {
              const t = i;
              let o = _c(e.target.parentElement.dataset.id, t);
              const n = t[o]?.SubmenuCommands;
              if (n) {
                const [i] = n.splice(e.oldIndex, 1);
                (t.splice(e.newIndex, 0, i),
                  this.plugin.updateCurrentCommands(
                    t,
                    this.currentEditingConfig,
                  ),
                  this.plugin.saveSettings());
              } else console.error("Subresult is undefined.");
            } else if (
              "editingToolbarSettingsTabsContainer" === e.from.className
            ) {
              const t = i,
                o = _c(e.target.parentElement.dataset.id, t),
                n = t[o]?.SubmenuCommands;
              if (n) {
                const [i] = t.splice(e.oldIndex, 1);
                (n.splice(e.newIndex, 0, i),
                  this.plugin.updateCurrentCommands(
                    t,
                    this.currentEditingConfig,
                  ),
                  this.plugin.saveSettings());
              } else console.error("Subresult is undefined.");
            }
            this.triggerRefresh();
          },
        }),
          t.SubmenuCommands.forEach((i) => {
            const n = new e.Setting(o);
            (n
              .setClass("editingToolbarCommandItem")
              .addButton((e) => {
                (e.setClass("editingToolbarSettingsIcon").onClick(async () => {
                  new Qr(
                    this.plugin,
                    i,
                    !0,
                    null,
                    this.currentEditingConfig,
                  ).open();
                }),
                  fa(i?.icon)
                    ? (e.buttonEl.innerHTML = i.icon)
                    : e.setIcon(i.icon));
              })
              .setName(i.name)
              .addButton((e) => {
                e.setIcon("pencil")
                  .setTooltip(Xr("Change Command Name"))
                  .setClass("editingToolbarSettingsButton")
                  .onClick(async () => {
                    new ia(
                      this.app,
                      this.plugin,
                      i,
                      !0,
                      this.currentEditingConfig,
                    ).open();
                  });
              })
              .addButton((e) =>
                this.createDeleteButton(e, async () => {
                  (t.SubmenuCommands.remove(i),
                    await this.plugin.saveSettings(),
                    this.display(),
                    this.triggerRefresh(),
                    console.log(
                      `%cCommand '${t.name}' was removed from editingToolbar`,
                      "color: #989cab",
                    ));
                }),
              ),
              n.nameEl);
          }));
      } else
        (a.addButton((e) => {
          (e.setClass("editingToolbarSettingsIcon").onClick(async () => {
            new Qr(this.plugin, t, !1, null, this.currentEditingConfig).open();
          }),
            fa(t.icon) ? (e.buttonEl.innerHTML = t.icon) : e.setIcon(t.icon));
        }),
          "editingToolbar-Divider-Line" == t.id &&
            a.setClass("editingToolbar-Divider-Line"),
          a
            .setClass("editingToolbarCommandItem")
            .setName(t.name)
            .addButton((e) => {
              e.setIcon("pencil")
                .setTooltip(Xr("Change Command Name"))
                .setClass("editingToolbarSettingsButton")
                .onClick(async () => {
                  new ia(
                    this.app,
                    this.plugin,
                    t,
                    !1,
                    this.currentEditingConfig,
                  ).open();
                });
            })
            .addButton((e) => {
              e.setIcon("editingToolbarSub")
                .setTooltip(Xr("Add Submenu"))
                .setClass("editingToolbarSettingsButton")
                .setClass("editingToolbarSettingsButtonaddsub")
                .onClick(async () => {
                  const e = {
                      id: "SubmenuCommands-" + Rr(1),
                      name: "submenu",
                      icon: "remix-Filter3Line",
                      SubmenuCommands: [],
                    },
                    t = i;
                  (t.splice(r + 1, 0, e),
                    this.plugin.updateCurrentCommands(
                      t,
                      this.currentEditingConfig,
                    ),
                    await this.plugin.saveSettings(),
                    this.display(),
                    this.triggerRefresh(),
                    console.log(`%cCommand '${e.id}' add `, "color: #989cab"));
                });
            })
            .addButton((e) => {
              e.setIcon("vertical-split")
                .setTooltip(Xr("Add Separator"))
                .setClass("editingToolbarSettingsButton")
                .setClass("editingToolbarSettingsButtonaddsub")
                .onClick(async () => {
                  const e = {
                      id: "editingToolbar-Divider-Line",
                      name: Xr("Vertical Split"),
                      icon: "vertical-split",
                    },
                    t = i;
                  (t.splice(r + 1, 0, e),
                    this.plugin.updateCurrentCommands(
                      t,
                      this.currentEditingConfig,
                    ),
                    await this.plugin.saveSettings(),
                    this.display(),
                    this.triggerRefresh());
                });
            })
            .addButton((e) =>
              this.createDeleteButton(e, async () => {
                (s.remove(t),
                  this.plugin.updateCurrentCommands(
                    s,
                    this.currentEditingConfig,
                  ),
                  await this.plugin.saveSettings(),
                  this.display(),
                  this.triggerRefresh(),
                  console.log(
                    `%cCommand '${t.name}' was removed from editingToolbar`,
                    "color: #989cab",
                  ));
              }),
            ));
    });
  }
  setupPickrEvents(e, t, i) {
    e.on("save", (e) => {
      const o = e.toHEXA().toString(),
        n = this.plugin.positionStyle,
        s =
          this.plugin.appearanceEditStyle ||
          this.plugin.settings.positionStyle ||
          n ||
          "top";
      if ("toolbarBackgroundColor" === t || "toolbarIconColor" === t) {
        const e = this.getAppearanceBucket(s);
        ((e[t] = o),
          n === s &&
            document.documentElement.style.setProperty(`--toolbar-${i}`, o),
          "custom" !== e.aestheticStyle && (e.aestheticStyle = "custom"),
          this.display(),
          this.triggerRefresh());
      } else this.plugin.settings[t] = o;
      this.plugin.saveSettings();
    });
  }
  destroyPickrs() {
    (this.pickrs.forEach((e) => {
      e && e.destroyAndRemove();
    }),
      (this.pickrs = []));
  }
  hide() {
    (this.destroyPickrs(), this.triggerRefresh());
  }
  removeCommandFromConfig(e, t) {
    if (e)
      for (let i = e.length - 1; i >= 0; i--)
        e[i].id !== t
          ? e[i].SubmenuCommands &&
            this.removeCommandFromConfig(e[i].SubmenuCommands, t)
          : e.splice(i, 1);
  }
  displayImportExportSettings(t) {
    const i = t.createDiv("import-export-container");
    ((i.style.padding = "16px"),
      (i.style.borderRadius = "8px"),
      (i.style.backgroundColor = "var(--background-secondary)"),
      (i.style.marginBottom = "20px"),
      new e.Setting(i)
        .setName(Xr("Export Configuration"))
        .setDesc(Xr("Export your toolbar configuration to share with others."))
        .addButton((e) =>
          e
            .setButtonText(Xr("Export"))
            .setCta()
            .onClick(() => {
              new Rc(this.app, this.plugin, "export").open();
            }),
        ),
      new e.Setting(i)
        .setName(Xr("Import Configuration"))
        .setDesc(Xr("Import toolbar configuration from JSON."))
        .addButton((e) =>
          e
            .setButtonText(Xr("Import"))
            .setCta()
            .onClick(() => {
              new Rc(this.app, this.plugin, "import").open();
            }),
        ));
    const o = t.createDiv("import-export-info");
    ((o.style.marginTop = "20px"),
      (o.style.padding = "16px"),
      (o.style.borderRadius = "8px"),
      (o.style.backgroundColor = "var(--background-secondary)"),
      (o.createEl("h3", {
        text: Xr("Usage Instructions"),
        cls: "import-export-heading",
      }).style.marginTop = "0"));
    const n = o.createEl("ul");
    ((n.style.paddingLeft = "20px"),
      n.createEl("li", {
        text: Xr(
          "Export: Generate a JSON configuration that you can save or share.",
        ),
      }),
      n.createEl("li", {
        text: Xr("Import: Paste a previously exported JSON configuration."),
      }));
    const s = t.createDiv("community-share-container");
    ((s.style.marginTop = "20px"),
      (s.style.padding = "16px"),
      (s.style.borderRadius = "8px"),
      (s.style.backgroundColor = "rgba(var(--color-green-rgb), 0.1)"),
      (s.style.border = "1px solid rgba(var(--color-green-rgb), 0.3)"),
      (s.createEl("h3", {
        text: Xr("Join the Community"),
        cls: "community-heading",
      }).style.marginTop = "0"));
    ((s.createEl("p").innerHTML =
      Xr("Share your toolbar settings and styles in our") +
      ' <a href="https://github.com/PKM-er/obsidian-toolbar/discussions/categories/show-and-tell" target="_blank" rel="noopener noreferrer">Show and Tell</a> '),
      s.createEl("p", {
        text: Xr(
          "Get inspired by what others have created or showcase your own customizations.",
        ),
      }));
    const r = t.createDiv("import-export-warning");
    ((r.style.marginTop = "20px"),
      (r.style.padding = "16px"),
      (r.style.borderRadius = "8px"),
      (r.style.backgroundColor = "rgba(var(--color-red-rgb), 0.1)"),
      (r.style.border = "1px solid rgba(var(--color-red-rgb), 0.3)"),
      (r.createEl("p", {
        text: Xr(
          "Warning: Importing configuration will overwrite your current settings. Consider exporting your current configuration first as a backup.",
        ),
        cls: "warning-text",
      }).style.margin = "0"));
  }
  applyAestheticStyle(e, t, i) {
    Object.values(this.aestheticStyleMap).forEach((t) => {
      e.removeClass(t);
    });
    const o = this.aestheticStyleMap[t] || this.aestheticStyleMap.default;
    e.addClass(o);
    const n = this.aestheticStyleMap[i] || this.aestheticStyleMap.top;
    e.addClass(n);
  }
  getCommandsArrayByType(e) {
    switch (e) {
      case "following":
        return this.plugin.settings.followingCommands;
      case "top":
        return this.plugin.settings.topCommands;
      case "fixed":
        return this.plugin.settings.fixedCommands;
      case "mobile":
        return this.plugin.settings.mobileCommands;
      default:
        return this.plugin.settings.menuCommands;
    }
  }
}
const Vc = {
  editingToolbar:
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" stroke-width="0" stroke-linecap="round" stroke-linejoin="round"><path d="M19 10H5c-1.103 0-2 .897-2 2v8c0 1.103.897 2 2 2h14c1.103 0 2-.897 2-2v-8c0-1.103-.897-2-2-2zM5 20v-8h14l.002 8H5zM5 6h14v2H5zm2-4h10v2H7z" fill="currentColor"/></svg>',
  editingToolbarSub:
    '<svg t="1661526346488" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="16880"  ><path d="M597.333333 85.333333h-341.333333C187.733333 85.333333 128 140.8 128 213.333333v597.333334c0 72.533333 59.733333 128 128 128h426.666667c72.533333 0 128-55.466667 128-128V298.666667l-213.333334-213.333334z m170.666667 725.333334c0 46.933333-38.4 85.333333-85.333333 85.333333H256c-46.933333 0-85.333333-38.4-85.333333-85.333333V213.333333c0-46.933333 38.4-85.333333 85.333333-85.333333h298.666667v213.333333h213.333333v469.333334z m-320-234.666667h128c12.8 0 21.333333 8.533333 21.333333 21.333333s-8.533333 21.333333-21.333333 21.333334h-128v128c0 12.8-8.533333 21.333333-21.333333 21.333333s-21.333333-8.533333-21.333334-21.333333v-128h-128c-12.8 0-21.333333-8.533333-21.333333-21.333334s8.533333-21.333333 21.333333-21.333333h128v-128c0-12.8 8.533333-21.333333 21.333334-21.333333s21.333333 8.533333 21.333333 21.333333v128z" fill="#8a8a8a" p-id="16881"></path></svg>',
  editingToolbarAdd:
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" stroke="white" stroke-width="0" stroke-linecap="round" stroke-linejoin="round"><path d="M13 7h-2v4H7v2h4v4h2v-4h4v-2h-4z" fill="currentColor"/><path d="M12 2C6.486 2 2 6.486 2 12s4.486 10 10 10s10-4.486 10-10S17.514 2 12 2zm0 18c-4.411 0-8-3.589-8-8s3.589-8 8-8s8 3.589 8 8s-3.589 8-8 8z" fill="currentColor"/></svg>',
  editingToolbarDelete:
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" stroke="white" stroke-width="0" stroke-linecap="round" stroke-linejoin="round"><path d="M5 20a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8h2V6h-4V4a2 2 0 0 0-2-2H9a2 2 0 0 0-2 2v2H3v2h2zM9 4h6v2H9zM8 8h9v12H7V8z" fill="var(--text-error)"/><path d="M9 10h2v8H9zm4 0h2v8h-2z" fill="var(--text-error)"/></svg>',
  editingToolbarReload:
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" stroke="white" stroke-width="0" stroke-linecap="round" stroke-linejoin="round"><path d="M19 10H5c-1.103 0-2 .897-2 2v8c0 1.103.897 2 2 2h14c1.103 0 2-.897 2-2v-8c0-1.103-.897-2-2-2zM5 20v-8h14l.002 8H5zM5 6h14v2H5zm2-4h10v2H7z" fill="currentColor"/></svg>',
  "codeblock-glyph":
    '<svg xmlns="http://www.w3.org/2000/svg" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path fill="currentColor" d="M20 3H4c-1.103 0-2 .897-2 2v14c0 1.103.897 2 2 2h16c1.103 0 2-.897 2-2V5c0-1.103-.897-2-2-2zM4 19V7h16l.002 12H4z" fill="currentColor"/><path d="M9.293 9.293L5.586 13l3.707 3.707l1.414-1.414L8.414 13l2.293-2.293zm5.414 0l-1.414 1.414L15.586 13l-2.293 2.293l1.414 1.414L18.414 13z"/></svg>',
  "underline-glyph":
    '<svg xmlns="http://www.w3.org/2000/svg" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 1024 1024"><path fill="currentColor" d="M824 804H200c-4.4 0-8 3.4-8 7.6v60.8c0 4.2 3.6 7.6 8 7.6h624c4.4 0 8-3.4 8-7.6v-60.8c0-4.2-3.6-7.6-8-7.6zm-312-76c69.4 0 134.6-27.1 183.8-76.2C745 602.7 772 537.4 772 468V156c0-6.6-5.4-12-12-12h-60c-6.6 0-12 5.4-12 12v312c0 97-79 176-176 176s-176-79-176-176V156c0-6.6-5.4-12-12-12h-60c-6.6 0-12 5.4-12 12v312c0 69.4 27.1 134.6 76.2 183.8C377.3 701 442.6 728 512 728z"/></svg>',
  "superscript-glyph":
    '<svg xmlns="http://www.w3.org/2000/svg" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path fill="currentColor"d="M16 7.41L11.41 12L16 16.59L14.59 18L10 13.41L5.41 18L4 16.59L8.59 12L4 7.41L5.41 6L10 10.59L14.59 6L16 7.41M21.85 9h-4.88V8l.89-.82c.76-.64 1.32-1.18 1.7-1.63c.37-.44.56-.85.57-1.23a.884.884 0 0 0-.27-.7c-.18-.19-.47-.28-.86-.29c-.31.01-.58.07-.84.17l-.66.39l-.45-1.17c.27-.22.59-.39.98-.53S18.85 2 19.32 2c.78 0 1.38.2 1.78.61c.4.39.62.93.62 1.57c-.01.56-.19 1.08-.54 1.55c-.34.48-.76.93-1.27 1.36l-.64.52v.02h2.58V9z"/></svg>',
  "subscript-glyph":
    '<svg xmlns="http://www.w3.org/2000/svg" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path fill="currentColor" d="M16 7.41L11.41 12L16 16.59L14.59 18L10 13.41L5.41 18L4 16.59L8.59 12L4 7.41L5.41 6L10 10.59L14.59 6L16 7.41m5.85 13.62h-4.88v-1l.89-.8c.76-.65 1.32-1.19 1.7-1.63c.37-.44.56-.85.57-1.24a.898.898 0 0 0-.27-.7c-.18-.16-.47-.28-.86-.28c-.31 0-.58.06-.84.18l-.66.38l-.45-1.17c.27-.21.59-.39.98-.53s.82-.24 1.29-.24c.78.04 1.38.25 1.78.66c.4.41.62.93.62 1.57c-.01.56-.19 1.08-.54 1.55c-.34.47-.76.92-1.27 1.36l-.64.52v.02h2.58v1.35z"/></svg>',
  "bot-glyph":
    '<svg xmlns="http://www.w3.org/2000/svg" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path fill="currentColor" d="M21.928 11.607c-.202-.488-.635-.605-.928-.633V8c0-1.103-.897-2-2-2h-6V4.61c.305-.274.5-.668.5-1.11a1.5 1.5 0 0 0-3 0c0 .442.195.836.5 1.11V6H5c-1.103 0-2 .897-2 2v2.997l-.082.006A1 1 0 0 0 1.99 12v2a1 1 0 0 0 1 1H3v5c0 1.103.897 2 2 2h14c1.103 0 2-.897 2-2v-5a1 1 0 0 0 1-1v-1.938a1.006 1.006 0 0 0-.072-.455zM5 20V8h14l.001 3.996L19 12v2l.001.005l.001 5.995H5z" fill="currentColor"/><ellipse cx="8.5" cy="12" rx="1.5" ry="2" fill="currentColor"/><ellipse cx="15.5" cy="12" rx="1.5" ry="2" fill="currentColor"/><path d="M8 16h8v2H8z" fill="currentColor"/></svg>',
  "header-1":
    '<svg class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" fill="currentColor"><path fill="currentColor"  d="M835.626667 349.397333A42.666667 42.666667 0 0 1 853.333333 384v426.666667a42.666667 42.666667 0 0 1-85.333333 0v-367.488l-71.850667 23.978666a42.666667 42.666667 0 0 1-26.965333-80.981333l128-42.666667a42.666667 42.666667 0 0 1 38.4 5.888zM128 170.666667a42.666667 42.666667 0 0 1 42.666667 42.666666v256h256V213.333333a42.666667 42.666667 0 1 1 85.333333 0v597.333334a42.666667 42.666667 0 1 1-85.333333 0v-256H170.666667v256a42.666667 42.666667 0 1 1-85.333334 0V213.333333a42.666667 42.666667 0 0 1 42.666667-42.666666z" p-id="1635"></path></svg>',
  "header-2":
    '<svg class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" fill="currentColor"><path d="M768 426.666667a85.333333 85.333333 0 0 0-85.333333 85.333333v21.333333a42.666667 42.666667 0 1 1-85.333334 0V512a170.666667 170.666667 0 0 1 170.666667-170.666667h7.338667a163.328 163.328 0 0 1 115.498666 278.869334L742.997333 768H896a42.666667 42.666667 0 1 1 0 85.333333h-256a42.666667 42.666667 0 0 1-30.165333-72.832l220.672-220.672A77.994667 77.994667 0 0 0 775.338667 426.666667H768zM128 170.666667a42.666667 42.666667 0 0 1 42.666667 42.666666v256h256V213.333333a42.666667 42.666667 0 1 1 85.333333 0v597.333334a42.666667 42.666667 0 1 1-85.333333 0v-256H170.666667v256a42.666667 42.666667 0 1 1-85.333334 0V213.333333a42.666667 42.666667 0 0 1 42.666667-42.666666z" p-id="1791"></path></svg>',
  "header-3":
    '<svg class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" fill="currentColor"><path d="M597.333333 384a42.666667 42.666667 0 0 1 42.666667-42.666667h256a42.666667 42.666667 0 0 1 30.165333 72.832l-105.941333 105.984A170.752 170.752 0 0 1 768 853.333333a170.666667 170.666667 0 0 1-160.938667-113.877333 42.666667 42.666667 0 0 1 80.469334-28.373333A85.333333 85.333333 0 1 0 768 597.333333h-42.666667a42.666667 42.666667 0 0 1-30.165333-72.832L793.002667 426.666667H640a42.666667 42.666667 0 0 1-42.666667-42.666667zM128 170.666667a42.666667 42.666667 0 0 1 42.666667 42.666666v256h256V213.333333a42.666667 42.666667 0 1 1 85.333333 0v597.333334a42.666667 42.666667 0 1 1-85.333333 0v-256H170.666667v256a42.666667 42.666667 0 1 1-85.333334 0V213.333333a42.666667 42.666667 0 0 1 42.666667-42.666666z" p-id="1949"></path></svg>',
  "header-4":
    '<svg class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" fill="currentColor"><path d="M780.714667 343.296a42.666667 42.666667 0 0 1 28.032 53.418667L719.36 682.666667H896a42.666667 42.666667 0 1 1 0 85.333333h-234.666667a42.666667 42.666667 0 0 1-40.704-55.381333l106.666667-341.333334a42.666667 42.666667 0 0 1 53.418667-27.989333z" p-id="2107"></path><path d="M853.333333 554.666667a42.666667 42.666667 0 0 1 42.666667 42.666666v213.333334a42.666667 42.666667 0 1 1-85.333333 0v-213.333334a42.666667 42.666667 0 0 1 42.666666-42.666666zM128 170.666667a42.666667 42.666667 0 0 1 42.666667 42.666666v256h256V213.333333a42.666667 42.666667 0 1 1 85.333333 0v597.333334a42.666667 42.666667 0 1 1-85.333333 0v-256H170.666667v256a42.666667 42.666667 0 1 1-85.333334 0V213.333333a42.666667 42.666667 0 0 1 42.666667-42.666666z" p-id="2108"></path></svg>',
  "header-5":
    '\n  <svg class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" fill="currentColor"><path d="M683.946667 373.674667A42.666667 42.666667 0 0 1 725.333333 341.333333h170.666667a42.666667 42.666667 0 1 1 0 85.333334h-137.301333l-22.016 88.234666A170.666667 170.666667 0 1 1 640 795.562667a42.666667 42.666667 0 1 1 64-56.448 85.333333 85.333333 0 1 0 0-112.896 42.666667 42.666667 0 0 1-73.386667-38.528l53.333334-214.016zM128 170.666667a42.666667 42.666667 0 0 1 42.666667 42.666666v256h256V213.333333a42.666667 42.666667 0 1 1 85.333333 0v597.333334a42.666667 42.666667 0 1 1-85.333333 0v-256H170.666667v256a42.666667 42.666667 0 1 1-85.333334 0V213.333333a42.666667 42.666667 0 0 1 42.666667-42.666666z" p-id="2264"></path></svg>',
  "header-6":
    '<svg class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" fill="currentColor"><path d="M831.274667 303.957333a42.666667 42.666667 0 0 1 16.725333 57.984l-83.498667 151.466667a170.453333 170.453333 0 0 1 88.746667 22.741333 169.557333 169.557333 0 0 1 62.506667 232.277334 171.093333 171.093333 0 0 1-232.96 62.165333 169.557333 169.557333 0 0 1-62.805334-231.850667l153.301334-278.016a42.666667 42.666667 0 0 1 57.984-16.768z m-20.48 306.176a85.76 85.76 0 0 0-116.736 31.018667 84.224 84.224 0 0 0 31.189333 115.456 85.76 85.76 0 0 0 116.736-31.018667 84.224 84.224 0 0 0-31.232-115.456zM128 170.666667a42.666667 42.666667 0 0 1 42.666667 42.666666v256h256V213.333333a42.666667 42.666667 0 1 1 85.333333 0v597.333334a42.666667 42.666667 0 1 1-85.333333 0v-256H170.666667v256a42.666667 42.666667 0 1 1-85.333334 0V213.333333a42.666667 42.666667 0 0 1 42.666667-42.666666z" p-id="2422"></path></svg>',
  "header-n":
    '<svg  viewBox="0 0 24 24" ><path d="M2 3a1 1 0 0 0-1 1v16a1 1 0 1 0 2 0v-7h9v7a1 1 0 1 0 2 0V4a1 1 0 1 0-2 0v7H3V4a1 1 0 0 0-1-1Zm14 9a1 1 0 0 1 1.984-.177 4.099 4.099 0 0 1 1.757-.576 3.447 3.447 0 0 1 3.759 3.432V20a1 1 0 1 1-2 0v-5.32c0-.851-.73-1.519-1.578-1.442A2.114 2.114 0 0 0 18 15.344V20a1 1 0 1 1-2 0v-8Z" fill="currentColor"></path></svg>',
  obsidian:
    '<svg viewBox="0 0 100 100" fill="none" stroke="currentColor" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" class="logo-wireframe"><path d="M 30.91 17.52 L 34.43 35.7 M 61.44 14.41 L 62.61 0 M 34.43 35.7 L 37.57 90.47 M 81 26.39 L 61.44 14.41 L 34.43 35.7 L 65.35 100 M 62.61 0 L 30.91 17.52 L 18 45.45 L 37.57 90.47 L 65.35 100 L 70.44 89.8 L 81 26.39 L 62.61 0 Z"></path></svg>',
  "obsidian-new":
    '<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path fill="#A88BFA" d="m6.91927 14.5955c.64053-.1907 1.67255-.4839 2.85923-.5565-.71191-1.7968-.88376-3.3691-.74554-4.76905.15962-1.61678.72977-2.9662 1.28554-4.11442.1186-.24501.2326-.47313.3419-.69198.1549-.30984.3004-.60109.4365-.8953.2266-.48978.3948-.92231.4798-1.32416.0836-.39515.0841-.74806-.0148-1.08657-.099-.338982-.3093-.703864-.7093-1.1038132-.5222-.1353116-1.1017-.0165173-1.53613.3742922l-5.15591 4.638241c-.28758.25871-.47636.60929-.53406.99179l-.44455 2.94723c.69903.6179 2.42435 2.41414 3.47374 4.90644.09364.2224.1819.4505.26358.6838z"></path><path fill="#A88BFA" d="m2.97347 10.3512c-.02431.1037-.05852.205-.10221.3024l-2.724986 6.0735c-.279882.6238-.15095061 1.3552.325357 1.8457l4.288349 4.4163c2.1899-3.2306 1.87062-6.2699.87032-8.6457-.75846-1.8013-1.90801-3.2112-2.65683-3.9922z"></path><path fill="#A88BFA" d="m5.7507 23.5094c.07515.012.15135.0192.2281.0215.81383.0244 2.18251.0952 3.29249.2997.90551.1669 2.70051.6687 4.17761 1.1005 1.1271.3294 2.2886-.5707 2.4522-1.7336.1192-.8481.343-1.8075.7553-2.6869l-.0095.0033c-.6982-1.9471-1.5865-3.2044-2.5178-4.0073-.9284-.8004-1.928-1.1738-2.8932-1.3095-1.60474-.2257-3.07497.1961-4.00103.4682.55465 2.3107.38396 5.0295-1.48417 7.8441z"></path><path fill="#A88BFA" d="m17.3708 19.3102c.9267-1.3985 1.5868-2.4862 1.9352-3.0758.1742-.295.1427-.6648-.0638-.9383-.5377-.7126-1.5666-2.1607-2.1272-3.5015-.5764-1.3785-.6624-3.51876-.6673-4.56119-.0019-.39626-.1275-.78328-.3726-1.09465l-3.3311-4.23183c-.0117.19075-.0392.37998-.0788.56747-.1109.52394-.32 1.04552-.5585 1.56101-.1398.30214-.3014.62583-.4646.95284-.1086.21764-.218.4368-.3222.652-.5385 1.11265-1.0397 2.32011-1.1797 3.73901-.1299 1.31514.0478 2.84484.8484 4.67094.1333.0113.2675.0262.4023.0452 1.1488.1615 2.3546.6115 3.4647 1.5685.9541.8226 1.8163 2.0012 2.5152 3.6463z"></path></svg>',
};
class Wc {
  constructor(e) {
    this.plugin = e;
  }
  init() {
    ((this.statusBarIcon = this.plugin.addStatusBarItem()),
      this.statusBarIcon.addClass("editingToolbar-statusbar-button"),
      e.setIcon(this.statusBarIcon, "editingToolbar"),
      this.registerClickEvent());
  }
  registerClickEvent() {
    this.plugin.registerDomEvent(this.statusBarIcon, "click", () => {
      const e = this.statusBarIcon.parentElement.getBoundingClientRect(),
        t = this.statusBarIcon.getBoundingClientRect();
      this.showMenu(t, e);
    });
  }
  showMenu(t, i) {
    const o = new e.Menu();
    (o.addSections(["settings"]),
      this.addVisibilityToggle(o),
      this.addAestheticStyleToggle(o),
      o.addSections(["viewType"]),
      this.addViewTypeToggle(o),
      o.addSections(["controls"]),
      this.addToolbarControls(o));
    (o.dom.addClass("editingToolbar-statusbar-menu"),
      o.showAtPosition({ x: t.right + 5, y: i.top - 5 }));
  }
  addVisibilityToggle(t) {
    (t.addItem((t) => {
      (t.setTitle(Xr("Hide & Show")),
        !e.requireApiVersion("0.15.0") || t.setSection("settings"));
      const i = t.dom,
        o = new e.ToggleComponent(i)
          .setValue(this.plugin.settings.cMenuVisibility)
          .setDisabled(!0),
        n = async () => {
          ((this.plugin.settings.cMenuVisibility =
            !this.plugin.settings.cMenuVisibility),
            o.setValue(this.plugin.settings.cMenuVisibility),
            1 == this.plugin.settings.cMenuVisibility
              ? setTimeout(() => {
                  dispatchEvent(new Event("editingToolbar-NewCommand"));
                }, 100)
              : Ur(this.plugin.settings.cMenuVisibility),
            ha(this.plugin),
            await this.plugin.saveSettings());
        };
      t.onClick((e) => {
        (e.preventDefault(), e.stopImmediatePropagation(), n());
      });
    }),
      t.addItem((t) => {
        (t.setTitle(Xr("Toolbar Position")),
          !e.requireApiVersion("0.15.0") || t.setSection("settings"),
          t.setIcon("dock"));
        const i = t.setSubmenu();
        (i.addItem((t) => {
          t.setTitle(Xr("Top Toolbar"));
          const i = t.dom,
            o = new e.ToggleComponent(i)
              .setValue(this.plugin.settings.enableTopToolbar || !1)
              .setDisabled(!0);
          t.onClick(async (e) => {
            (e.preventDefault(), e.stopPropagation());
            const t = this.plugin.settings,
              i = this.plugin.positionStyle;
            ((t.enableTopToolbar = !t.enableTopToolbar),
              o.setValue(t.enableTopToolbar));
            let n = null;
            (t.enableTopToolbar
              ? (n = "top")
              : "top" === i &&
                (n = t.enableFollowingToolbar
                  ? "following"
                  : t.enableFixedToolbar
                    ? "fixed"
                    : null),
              n && n !== i && this.plugin.onPositionStyleChange(n),
              await this.plugin.saveSettings(),
              this.plugin.handleeditingToolbar());
          });
        }),
          i.addItem((t) => {
            t.setTitle(Xr("Following Toolbar"));
            const i = t.dom,
              o = new e.ToggleComponent(i)
                .setValue(this.plugin.settings.enableFollowingToolbar || !1)
                .setDisabled(!0);
            t.onClick(async (e) => {
              (e.preventDefault(), e.stopPropagation());
              const t = this.plugin.settings,
                i = this.plugin.positionStyle;
              ((t.enableFollowingToolbar = !t.enableFollowingToolbar),
                o.setValue(t.enableFollowingToolbar));
              let n = null;
              (t.enableFollowingToolbar
                ? (n = "following")
                : "following" === i &&
                  (n = t.enableTopToolbar
                    ? "top"
                    : t.enableFixedToolbar
                      ? "fixed"
                      : null),
                n && n !== i && this.plugin.onPositionStyleChange(n),
                await this.plugin.saveSettings(),
                this.plugin.handleeditingToolbar());
            });
          }),
          i.addItem((t) => {
            t.setTitle(Xr("Fixed Toolbar"));
            const i = t.dom,
              o = new e.ToggleComponent(i)
                .setValue(this.plugin.settings.enableFixedToolbar || !1)
                .setDisabled(!0);
            t.onClick(async (e) => {
              (e.preventDefault(), e.stopPropagation());
              const t = this.plugin.settings,
                i = this.plugin.positionStyle;
              ((t.enableFixedToolbar = !t.enableFixedToolbar),
                o.setValue(t.enableFixedToolbar));
              let n = null;
              (t.enableFixedToolbar
                ? (n = "fixed")
                : "fixed" === i &&
                  (n = t.enableTopToolbar
                    ? "top"
                    : t.enableFollowingToolbar
                      ? "following"
                      : null),
                n && n !== i && this.plugin.onPositionStyleChange(n),
                await this.plugin.saveSettings(),
                this.plugin.handleeditingToolbar());
            });
          }));
      }));
  }
  addViewTypeToggle(t) {
    const i = this.plugin.app.workspace.getActiveViewOfType(e.ItemView);
    if (!i) return;
    const o = i.getViewType();
    t.addItem((t) => {
      (t.setTitle(Xr("Current View: ") + o),
        !e.requireApiVersion("0.15.0") || t.setSection("settings"),
        t.setIcon("layout-template"));
      const n = t.setSubmenu(),
        s = la.isAllowedViewType(i);
      (n.addItem((e) => {
        (e.setTitle(
          Xr(
            s
              ? "Disable toolbar for this view"
              : "Enable toolbar for this view",
          ),
        ),
          e.setIcon(s ? "eye-off" : "eye"),
          e.onClick(async () => {
            (this.plugin.settings.viewTypeSettings ||
              (this.plugin.settings.viewTypeSettings = {}),
              (this.plugin.settings.viewTypeSettings[o] = !s),
              await this.plugin.saveSettings(),
              ha(this.plugin),
              setTimeout(() => {
                dispatchEvent(new Event("editingToolbar-NewCommand"));
              }, 100));
          }));
      }),
        n.addItem((e) => {
          (e.setTitle(Xr("Manage all view types")), e.setIcon("settings-2"));
          const t = e.setSubmenu(),
            i = new Set([
              "markdown",
              "canvas",
              "thino_view",
              "meld-encrypted-view",
              ...Object.keys(this.plugin.settings.viewTypeSettings || {}),
            ]);
          Array.from(i)
            .sort()
            .forEach((e) => {
              const i = this.isViewTypeAllowed(e);
              t.addItem((t) => {
                (t.setTitle(e),
                  t.setIcon(i ? "check" : ""),
                  t.onClick(async () => {
                    (this.plugin.settings.viewTypeSettings ||
                      (this.plugin.settings.viewTypeSettings = {}),
                      (this.plugin.settings.viewTypeSettings[e] = !i),
                      o === e &&
                        (ha(this.plugin),
                        setTimeout(() => {
                          dispatchEvent(new Event("editingToolbar-NewCommand"));
                        }, 100)),
                      await this.plugin.saveSettings());
                  }));
              });
            });
        }));
    });
  }
  isViewTypeAllowed(e) {
    if (
      !this.plugin.settings.viewTypeSettings ||
      void 0 === this.plugin.settings.viewTypeSettings[e]
    ) {
      return [
        "markdown",
        "canvas",
        "thino_view",
        "meld-encrypted-view",
      ].includes(e);
    }
    return this.plugin.settings.viewTypeSettings[e];
  }
  addToolbarControls(t) {
    const i = [
      {
        icon: "plus",
        title: Xr("Add Command"),
        click: () => new ta(this.plugin).open(),
      },
    ];
    ("fixed" === this.plugin.positionStyle &&
      i.push({
        icon: "file-sliders",
        title: Xr("Position Settings"),
        click: () => new oa(this.plugin.app, this.plugin).open(),
      }),
      i.forEach((i) => {
        t.addItem((t) => {
          (t.setIcon(i.icon),
            t.setTitle(i.title),
            t.onClick(i.click),
            e.requireApiVersion("0.15.0") && t.setSection("controls"));
        });
      }));
  }
  addAestheticStyleToggle(t) {
    t.addItem((t) => {
      (t.setTitle(Xr("Appearance Style")),
        !e.requireApiVersion("0.15.0") || t.setSection("settings"),
        t.setIcon("cherry"));
      const i = t.setSubmenu();
      sa.forEach((e) => {
        i.addItem((t) => {
          (t.setTitle(e),
            t.setIcon(this.plugin.settings.aestheticStyle === e ? "check" : ""),
            t.onClick(async () => {
              ((this.plugin.settings.aestheticStyle = e),
                await this.plugin.saveSettings(),
                ha(this.plugin),
                setTimeout(() => {
                  dispatchEvent(new Event("editingToolbar-NewCommand"));
                }, 100));
            }));
        });
      });
    });
  }
}
let Hc, $c;
class Uc extends e.Modal {
  constructor(e) {
    (super(e.app),
      (this.plugin = e),
      (this.type = "note"),
      (this.title = ""),
      (this.content = ""),
      (this.collapse = "none"),
      (this.allCalloutOptions = []),
      (this.builtInCalloutTypes = [
        {
          type: "note",
          aliases: [],
          icon: "lucide-pencil",
          label: "Note",
          color: "var(--callout-default)",
        },
        {
          type: "abstract",
          aliases: ["summary", "tldr"],
          icon: "lucide-clipboard-list",
          label: "Abstract",
          color: "var(--callout-summary)",
        },
        {
          type: "info",
          aliases: [],
          icon: "lucide-info",
          label: "Info",
          color: "var(--callout-info)",
        },
        {
          type: "todo",
          aliases: [],
          icon: "lucide-check-circle-2",
          label: "Todo",
          color: "var(--callout-todo)",
        },
        {
          type: "important",
          aliases: [],
          icon: "lucide-flame",
          label: "Important",
          color: "var(--callout-important)",
        },
        {
          type: "tip",
          aliases: ["hint"],
          icon: "lucide-flame",
          label: "Tip",
          color: "var(--callout-tip)",
        },
        {
          type: "success",
          aliases: ["check", "done"],
          icon: "lucide-check",
          label: "Success",
          color: "var(--callout-success)",
        },
        {
          type: "question",
          aliases: ["help", "faq"],
          icon: "lucide-help-circle",
          label: "Question",
          color: "var(--callout-question)",
        },
        {
          type: "warning",
          aliases: ["caution", "attention"],
          icon: "lucide-alert-triangle",
          label: "Warning",
          color: "var(--callout-warning)",
        },
        {
          type: "failure",
          aliases: ["fail", "missing"],
          icon: "lucide-x",
          label: "Failure",
          color: "var(--callout-fail)",
        },
        {
          type: "danger",
          aliases: ["error"],
          icon: "lucide-zap",
          label: "Danger",
          color: "var(--callout-error)",
        },
        {
          type: "bug",
          aliases: [],
          icon: "lucide-bug",
          label: "Bug",
          color: "var(--callout-bug)",
        },
        {
          type: "example",
          aliases: [],
          icon: "lucide-list",
          label: "Example",
          color: "var(--callout-example)",
        },
        {
          type: "quote",
          aliases: ["cite"],
          icon: "lucide-quote",
          label: "Quote",
          color: "var(--callout-quote)",
        },
      ]),
      this.containerEl.addClass("insert-callout-modal"),
      this.prepareCalloutOptions());
    const t = this.plugin.commandsManager.getActiveEditor();
    if (t) {
      const e = t.getSelection();
      e && (this.content = e);
    }
    this.allCalloutOptions.find((e) => e.type === this.type) ||
      (this.type =
        this.allCalloutOptions.length > 0
          ? this.allCalloutOptions[0].type
          : "note");
  }
  prepareCalloutOptions() {
    if (
      (this.builtInCalloutTypes.forEach((e) => {
        (this.allCalloutOptions.push({
          type: e.type,
          label: e.label,
          icon: e.icon,
          color: e.color,
          isAdmonition: !1,
        }),
          e.aliases.forEach((t) => {
            this.allCalloutOptions.push({
              type: t,
              label: `${e.label} (${t})`,
              icon: e.icon,
              color: e.color,
              isAdmonition: !1,
            });
          }));
      }),
      this.plugin.admonitionDefinitions)
    ) {
      const e = Object.values(this.plugin.admonitionDefinitions);
      e.length > 0 &&
        e.forEach((e) => {
          this.allCalloutOptions.some((t) => t.type === e.type) ||
            this.allCalloutOptions.push({
              type: e.type,
              label:
                e.title || e.type.charAt(0).toUpperCase() + e.type.slice(1),
              icon: e.icon,
              color: `rgb(${e.color})`,
              isAdmonition: !0,
              sourcePlugin: "Admonition",
            });
        });
    }
  }
  onOpen() {
    this.display();
  }
  async display() {
    const { contentEl: t } = this;
    (t.empty(),
      t.addEventListener("keydown", (e) => {
        "Enter" === e.key &&
          (e.ctrlKey || e.metaKey) &&
          (e.preventDefault(), this.insertButton && this.insertButton.click());
      }));
    const i = t.createDiv("callout-type-container");
    ((this.iconContainerEl = i.createDiv("callout-icon-container")),
      new e.Setting(i).setName(Xr("Callout Type")).addDropdown((e) => {
        const t = this.allCalloutOptions.filter((e) => !e.isAdmonition),
          i = this.allCalloutOptions.filter((e) => e.isAdmonition);
        if (t.length > 0 && i.length > 0) {
          e.addOption("---separator---", "---- Admonitions ----");
          const t = e.selectEl.options[e.selectEl.options.length - 1];
          t && (t.disabled = !0);
        }
        (i.forEach((t) => {
          e.addOption(t.type, `${t.label} (Admonition)`);
        }),
          e.addOption("---separator---", "---- Default ----"),
          t.forEach((t) => {
            e.addOption(t.type, t.label);
          }),
          this.allCalloutOptions.some((e) => e.type === this.type) ||
            (this.type =
              this.allCalloutOptions.length > 0
                ? this.allCalloutOptions[0].type
                : "note"),
          e.setValue(this.type),
          e.onChange((t) => {
            "---separator---" !== t
              ? ((this.type = t),
                this.updateIconAndColor(this.iconContainerEl, t))
              : e.setValue(this.type);
          }));
      }),
      this.updateIconAndColor(this.iconContainerEl, this.type),
      new e.Setting(t)
        .setName(Xr("Title"))
        .setDesc(Xr("Optional, leave blank for default title"))
        .addText((e) => {
          e.setPlaceholder(Xr("Input title"))
            .setValue(this.title)
            .onChange((e) => {
              this.title = e;
            });
        }),
      new e.Setting(t).setName(Xr("Collapse State")).addDropdown((e) => {
        e.addOption("none", Xr("Default"))
          .addOption("open", Xr("Open"))
          .addOption("closed", Xr("Closed"))
          .setValue(this.collapse)
          .onChange((e) => {
            this.collapse = e;
          });
      }),
      new e.Setting(t).setName(Xr("Content")).addTextArea((e) => {
        (e
          .setPlaceholder(Xr("Input content"))
          .setValue(this.content)
          .onChange((e) => {
            this.content = e;
          }),
          (e.inputEl.rows = 5),
          (e.inputEl.cols = 40),
          (this.contentTextArea = e.inputEl));
      }));
    const o = t.createDiv("shortcut-hint");
    (o.setText(
      `${e.Platform.isMacOS ? "⌘" : "Ctrl"} + Enter ${Xr("to insert")}`,
    ),
      (o.style.textAlign = "right"),
      (o.style.fontSize = "0.8em"),
      (o.style.opacity = "0.7"),
      (o.style.marginTop = "5px"),
      new e.Setting(t)
        .addButton(
          (e) => (
            e
              .setButtonText(Xr("Insert"))
              .setCta()
              .onClick(() => {
                (this.insertCallout(), this.close());
              }),
            (this.insertButton = e.buttonEl),
            e
          ),
        )
        .addButton(
          (e) => (
            e
              .setButtonText(Xr("Cancel"))
              .setTooltip(Xr("Cancel"))
              .onClick(() => this.close()),
            e
          ),
        ),
      setTimeout(() => {
        this.contentTextArea && this.contentTextArea.focus();
      }, 10));
  }
  updateIconAndColor(t, i) {
    if (!t) return;
    const o = this.allCalloutOptions.find((e) => e.type === i);
    if ((t.empty(), o))
      if (o.isAdmonition) {
        const i = o.icon;
        if ("custom" === i.type && i.svg) {
          t.innerHTML = i.svg;
          const e = t.querySelector("svg");
          e &&
            ((e.style.fill = o.color),
            (e.style.width = "var(--icon-size)"),
            (e.style.height = "var(--icon-size)"));
        } else
          i.name.startsWith("lucide-") || "default" === i.type
            ? (e.setIcon(t, i.name),
              t.style.setProperty("--callout-color", o.color))
            : (e.setIcon(t, "lucide-box"),
              t.style.setProperty("--callout-color", o.color));
      } else
        (e.setIcon(t, o.icon), t.style.setProperty("--callout-color", o.color));
    else
      (e.setIcon(t, "lucide-alert-circle"),
        t.style.removeProperty("--callout-color"));
  }
  insertCallout() {
    const e = this.plugin.commandsManager.getActiveEditor();
    if (!e) return;
    let t = `> [!${this.type}]`;
    ("none" !== this.collapse &&
      (t += "" + ("open" === this.collapse ? "+" : "-")),
      this.title && (t += ` ${this.title}`),
      (t += `\n> ${this.content.replace(/\n/g, "\n> ")}`));
    const i = e.getCursor(),
      o = e.getLine(i.line),
      n = 0 === i.ch;
    let s;
    if (e.getSelection()) {
      !n && o.trim().length > 0 && (t = "\n" + t);
      const i = e.getCursor("from");
      e.replaceSelection(t);
      const r = t.split("\n").length;
      s = { line: i.line + r, ch: 0 };
    } else {
      (!n && o.trim().length > 0 && (t = "\n" + t), e.replaceRange(t, i));
      const r = t.split("\n").length;
      s = { line: i.line + r, ch: 0 };
    }
    setTimeout(() => {
      (e.replaceRange("\n", s),
        e.setCursor({ line: s.line + 1, ch: 0 }),
        e.focus());
    }, 0);
  }
}
class jc {
  static isValidUrl(e) {
    try {
      return (new URL(e), !0);
    } catch (e) {
      return !1;
    }
  }
  static parseTitle(e, t) {
    const i = [
      e.includes("mp.weixin.qq.com") ? this.wxTitlePattern : null,
      this.htmlTitlePattern,
      /<title [^>]*>(.*?)<\/title>/i,
      /<meta name="title" content="([^<]*)" \/>/im,
    ].filter(Boolean);
    for (const e of i) {
      const i = t.match(e);
      if (i && "string" == typeof i[1]) return i[1].trim();
    }
    throw new Error("Unable to parse the title tag");
  }
  static getFallbackTitle(e) {
    const t = e.match(/[^/\\]+$/);
    return t
      ? t[0]
          .replace(/\.[^/.]+$/, "")
          .replace(/[-_]/g, " ")
          .trim()
      : e;
  }
  static async fetchRemoteTitle(t) {
    if (!this.isValidUrl(t) || !t.match(/^https?:\/\//))
      return this.getFallbackTitle(t);
    try {
      const i = await e.requestUrl({
        url: t,
        method: "GET",
        headers: {
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        },
        throw: !0,
      });
      if (200 !== i.status) throw new Error(`Status code ${i.status}`);
      const o = i.text,
        n = this.parseTitle(t, o);
      return !n || n.length > 100 ? this.getFallbackTitle(t) : n;
    } catch (e) {
      return (
        console.error(`Failed to fetch title for ${t}:`, e),
        this.getFallbackTitle(t)
      );
    }
  }
}
((jc.htmlTitlePattern = /<title>([^<]*)<\/title>/im),
  (jc.wxTitlePattern = /<meta property="og:title" content="([^<]*)" \/>/im));
class Yc extends e.Modal {
  constructor(e) {
    (super(e.app),
      (this.plugin = e),
      (this.linkText = ""),
      (this.linkUrl = ""),
      (this.linkAlias = ""),
      (this.isEmbed = !1),
      (this.insertNewLine = !1),
      (this.imageWidth = ""),
      (this.imageHeight = ""),
      (this.prefixText = ""),
      (this.suffixText = ""),
      (this.selectedText = ""));
    const t = this.plugin.commandsManager.getActiveEditor();
    if (t) {
      const e = t.getSelection() || "";
      e ? this.handleSelectedText(t, e) : this.handleCursorPosition(t);
    } else this.parseClipboard();
    this.updateHeader();
  }
  handleSelectedText(e, t) {
    const i = this.tryExpandSelection(e, t);
    if (i) {
      const t = this.formatTargetText(i);
      (e.setSelection(i.from, i.to),
        (this.selectedText = t),
        this.parseSelectedText(t));
    } else ((this.selectedText = t), this.parseSelectedText(t));
  }
  handleCursorPosition(e) {
    const t = e.getCursor(),
      i = this.findLinkAtCursor(e, t);
    if (i) {
      const t = this.formatTargetText(i);
      (e.setSelection(i.from, i.to),
        (this.selectedText = t),
        this.parseSelectedText(t));
    } else this.parseClipboard();
  }
  tryExpandSelection(e, t) {
    const i = e.getCursor("from"),
      o = e.getLine(i.line),
      n = i.ch,
      s = e.getCursor("to").ch;
    return this.matchLinkInLine(o, n, s, i.line);
  }
  findLinkAtCursor(e, t) {
    const i = e.getLine(t.line),
      o = t.ch;
    return this.matchLinkInLine(i, o, o, t.line);
  }
  matchLinkInLine(e, t, i, o) {
    const n = /(!)?\[([^\]]+)\]\(([^\s)]+)(?:\s+["']([^"']*)["'])?\)/g;
    let s;
    for (; null !== (s = n.exec(e)); ) {
      const e = !!s[1],
        n = s.index,
        r = s.index + s[0].length,
        a = s[2],
        l = s[3],
        c = s[4] || "";
      if (t <= r && i >= n)
        return {
          isImage: e,
          text: a,
          url: l,
          title: c,
          from: { line: o, ch: n },
          to: { line: o, ch: r },
        };
    }
    const r =
      /(?:^|\s)([a-zA-Z][a-zA-Z\d+\-.]*:\/\/\S+|\S+\.[a-zA-Z]{2,}(?:\/\S*)?)/g;
    for (; null !== (s = r.exec(e)); ) {
      const e = s[1],
        n = s.index + (s[0].startsWith(" ") ? 1 : 0),
        r = n + e.length;
      if (t <= r && i >= n)
        return {
          isImage: /\.(jpg|jpeg|png|gif|webp|bmp)$/i.test(e),
          text: e,
          url: e,
          title: "",
          from: { line: o, ch: n },
          to: { line: o, ch: r },
        };
    }
    return null;
  }
  formatTargetText(e) {
    return e.isImage
      ? `![${e.text}](${e.url}${e.title ? ` "${e.title}"` : ""})`
      : e.title
        ? `[${e.text}](${e.url} "${e.title}")`
        : `[${e.text}](${e.url})`;
  }
  parseSelectedText(e) {
    const t = e.match(/!\[.*?\]\(.*?\)/);
    if (t) {
      const i = e.substring(0, t.index),
        o = e.substring(t.index + t[0].length),
        n = this.parseMarkdownImageLink(e);
      if (n)
        return (
          (this.linkText = n.title),
          (this.linkUrl = n.url),
          (this.linkAlias = n.quotedTitle || ""),
          (this.imageWidth = n.width || ""),
          (this.imageHeight = n.height || ""),
          (this.isEmbed = !0),
          (this.prefixText = i),
          void (this.suffixText = o)
        );
    }
    const i = e.match(
      /\[([^\]]+)\]\(([a-zA-Z]+:\/\/[^\s)]+)(?:\s+["']([^"']*)["'])?\)/,
    );
    if (i) {
      const t = i[0],
        o = e.substring(0, i.index),
        n = e.substring(i.index + t.length),
        s = this.parseMarkdownLink(t);
      (s &&
        ((this.linkText = s.text),
        (this.linkUrl = s.url),
        (this.linkAlias = s.title || ""),
        (this.isEmbed = !1)),
        (this.prefixText = o),
        (this.suffixText = n));
    } else {
      const t = this.parseMixedContent(e);
      t && ((this.linkText = t.title), (this.linkUrl = t.url));
    }
  }
  parseMixedContent(e) {
    let t;
    return (t = e.match(/^\[(.*?)\]\((.*?)\)$/))
      ? { title: t[1].trim(), url: t[2].trim() }
      : (t = e.match(/<a[^>]+href=["']([^"']+)["'][^>]*>([^<]+)<\/a>/i))
        ? { title: t[2].trim(), url: t[1].trim() }
        : (t = e.match(/^(.*?)\s*((?:https?:\/\/|www\.)\S+)$/i)) && t[1].trim()
          ? { title: t[1].trim(), url: t[2].trim() }
          : this.isValidUrl(e.trim())
            ? { title: this.extractTitleFromUrl(e.trim()), url: e.trim() }
            : { title: e.trim(), url: "" };
  }
  extractTitleFromUrl(e) {
    const t = e.match(/^([a-zA-Z]+):\/\/(.+)$/);
    if (t) {
      const [, e, i] = t,
        o = i.split(/[/\\]/),
        n = o[o.length - 1];
      return n ? decodeURIComponent(n).trim() : e.toUpperCase();
    }
    const i = e.match(/^\[\[(.*?)\]\]$/);
    if (i) return i[1];
    const o = e.match(/[^/\\]+$/);
    return o
      ? o[0]
          .replace(/\.[^/.]+$/, "")
          .replace(/[-_]/g, " ")
          .trim()
      : e;
  }
  isValidUrl(e) {
    if (!e || e.includes("\n") || /\s/.test(e)) return !1;
    if (
      [
        "obsidian://",
        "zotero://",
        "evernote://",
        "notion://",
        "bear://",
        "things://",
        "drafts://",
        "x-devonthink-item://",
        "file://",
        "ftp://",
        "ftps://",
        "http://",
        "https://",
        "tel:",
        "mailto:",
      ].some((t) => e.startsWith(t))
    )
      return !0;
    if (e.match(/^\[\[.*?\]\]$/)) return !0;
    if (
      e.match(/^[./\\]/) ||
      e.match(/^[a-zA-Z]:\\/) ||
      e.match(/^\/[^/]/) ||
      e.match(/^[a-zA-Z]+:\/\//)
    )
      return !0;
    try {
      return (new URL(e), !0);
    } catch (e) {
      return !1;
    }
  }
  parseMarkdownImageLink(e) {
    const t = e.match(
      /!\[(.*?)(?:\|(\d+)(?:x(\d+))?)?\]\(\s*([^\s)]+)(?:\s+["']([^"']*)["'])?\s*\)/,
    );
    if (t) {
      const [, e, i, o, n, s] = t;
      if (((this.isEmbed = !0), this.embedToggle)) {
        this.embedToggle.setValue(!0);
        const e = this.contentEl.querySelector(".image-size-setting");
        e && (e.style.display = "block");
      }
      return {
        title: e.trim(),
        url: n.trim(),
        width: i,
        height: o,
        quotedTitle: s?.trim(),
      };
    }
    return null;
  }
  parseMarkdownLink(e) {
    const t = e.match(
      /\[([^\]]+)\]\(([a-zA-Z]+:\/\/[^\s)]+)(?:\s+["']([^"']*)["'])?\)/,
    );
    if (t) {
      const [, e, i, o] = t;
      return { text: e.trim(), url: i.trim(), title: o?.trim() };
    }
    return null;
  }
  async parseClipboard() {
    try {
      const e = await this.readClipboard(),
        t = e["text/plain"];
      if (t) {
        const e = this.parseMarkdownImageLink(t);
        if (e)
          return (
            (this.linkText = e.title),
            (this.linkUrl = e.url),
            (this.linkAlias = e.quotedTitle || ""),
            (e.width || e.height) &&
              ((this.isEmbed = !0),
              (this.imageWidth = e.width || ""),
              (this.imageHeight = e.height || "")),
            void this.updateUI()
          );
        const i = this.parseMarkdownLink(t);
        if (i)
          return (
            (this.linkText = i.text),
            (this.linkUrl = i.url),
            (this.linkAlias = i.title || ""),
            (this.isEmbed = !1),
            void this.updateUI()
          );
      }
      if (e["text/html"]) {
        const t = this.parseHtmlContent(e["text/html"]);
        t &&
          ((this.linkText = this.linkText || t.title), (this.linkUrl = t.url));
      } else if (e["text/markdown"]) {
        const t = this.parseMarkdownContent(e["text/markdown"]);
        t &&
          ((this.linkText = this.linkText || t.title), (this.linkUrl = t.url));
      } else if (e["text/plain"]) {
        const t = this.parseMixedContent(e["text/plain"]);
        t &&
          ((this.linkText = this.linkText || t.title), (this.linkUrl = t.url));
      }
      this.updateUI();
    } catch (e) {
      console.error("Failed to read clipboard:", e);
    }
  }
  async readClipboard() {
    const e = {};
    try {
      const t = await navigator.clipboard.read();
      for (const i of t) {
        const t = i.types;
        for (const o of t)
          if (
            "text/html" === o ||
            "text/plain" === o ||
            "text/markdown" === o
          ) {
            const t = await i.getType(o);
            e[o] = await t.text();
          }
      }
    } catch (t) {
      try {
        const t = await navigator.clipboard.readText();
        e["text/plain"] = t;
      } catch (e) {
        console.error("Failed to read clipboard:", e);
      }
    }
    return e;
  }
  parseHtmlContent(e) {
    const t = new DOMParser().parseFromString(e, "text/html"),
      i = t.querySelector("a");
    if (i) return { title: i.textContent?.trim() || "", url: i.href };
    const o = t.body.textContent || "";
    return this.parseMixedContent(o);
  }
  parseMarkdownContent(e) {
    const t = e.match(/\[([^\]]+)\]\(([^)]+)\)/);
    return t
      ? { title: t[1].trim(), url: t[2].trim() }
      : this.parseMixedContent(e);
  }
  onOpen() {
    this.display();
  }
  updateHeader() {
    const e = this.getPreviewText();
    this.previewSetting &&
      (this.previewSetting.controlEl.querySelector("input").value = e);
  }
  getPreviewText() {
    const e = this.linkText || "",
      t = this.linkUrl;
    let i = this.isEmbed ? "!" : "";
    return (
      (i += `[${e}`),
      this.isEmbed &&
        (this.imageWidth || this.imageHeight) &&
        ((i += "|"),
        this.imageWidth && this.imageHeight
          ? (i += `${this.imageWidth}x${this.imageHeight}`)
          : this.imageWidth
            ? (i += this.imageWidth)
            : this.imageHeight && (i += `x${this.imageHeight}`)),
      (i += `](${t}`),
      this.linkAlias && (i += ` "${this.linkAlias}"`),
      (i += ")"),
      i
    );
  }
  async display() {
    const { contentEl: t } = this;
    (t.empty(),
      t.addClass("insert-link-modal"),
      (this.titleEl.textContent = ""),
      this.titleEl.addClass("insert-link-modal-title"),
      t.addEventListener("keydown", (e) => {
        "Enter" === e.key &&
          (e.ctrlKey || e.metaKey) &&
          (e.preventDefault(), this.insertButton && this.insertButton.click());
      }));
    new e.Setting(t)
      .addButton((t) => {
        t.setIcon("lucide-globe")
          .setTooltip(Xr("Fetch Remote Title"))
          .onClick(async () => {
            if (this.linkUrl) {
              (t.setDisabled(!0), t.setIcon("lucide-loader"));
              const e = await this.fetchRemoteTitle(this.linkUrl);
              (t.setIcon("lucide-globe"),
                t.setDisabled(!1),
                (this.linkText = e),
                this.linkTextInput.setValue(e),
                this.updateHeader());
            } else new e.Notice(Xr("Please enter a URL first"));
          });
      })
      .setName(Xr("Link Text"))
      .addText((e) => {
        ((this.linkTextInput = e),
          e
            .setPlaceholder(Xr("Link Text"))
            .setValue(this.linkText)
            .onChange((e) => {
              ((this.linkText = e), this.updateHeader());
            }));
      });
    const i = new e.Setting(t).setName(Xr("Title")).addText((e) => {
        ((this.linkAliasInput = e),
          e
            .setPlaceholder(Xr("Link Title (optional)"))
            .setValue(this.linkAlias)
            .onChange((e) => {
              ((this.linkAlias = e), this.updateHeader());
            }));
      }),
      o = new e.Setting(t)
        .setName(Xr("Link URL"))
        .setClass("link-url-setting")
        .addText((e) => {
          ((this.linkUrlInput = e),
            e
              .setPlaceholder(Xr("Link URL"))
              .setValue(this.linkUrl)
              .onChange((e) => {
                ((this.linkUrl = e.trim()),
                  this.validateUrl(this.linkUrl),
                  this.updateHeader());
              }));
        })
        .addButton((e) => {
          e.setIcon("lucide-clipboard")
            .setTooltip(Xr("Paste and Parse"))
            .onClick(async () => {
              (await this.parseClipboard(), this.updateHeader());
            });
        });
    ((this.urlErrorMsg = o.descEl.createDiv("url-error")),
      (this.urlErrorMsg.style.color = "var(--text-error)"),
      (this.urlErrorMsg.style.display = "none"));
    const n = new e.Setting(t)
      .setName(Xr("Embed Content"))
      .setDesc(Xr("If it is an image, turn on"));
    ((this.embedToggle = new e.ToggleComponent(n.controlEl)),
      this.embedToggle.setValue(this.isEmbed).onChange((e) => {
        this.isEmbed = e;
        const o = t.querySelector(".image-size-setting");
        (i.settingEl,
          o && (o.style.display = e ? "flex" : "none"),
          this.updateHeader());
      }));
    const s = new e.Setting(t).addButton((e) => {
      e.setIcon("lucide-maximize")
        .setTooltip(Xr("Fit Editor Width"))
        .onClick(() => {
          const e = this.getImageDimensions();
          e &&
            ((this.imageWidth = e.width.toString()),
            (this.imageHeight = e.height?.toString()),
            s.components[1].setValue(this.imageWidth),
            this.imageHeight && s.components[2].setValue(this.imageHeight),
            this.updateHeader());
        });
    });
    s.setClass("image-size-setting")
      .setName(Xr("Image Size"))
      .addText((e) => {
        (e.inputEl.addClass("image-width-input"),
          e
            .setPlaceholder(Xr("Image Width"))
            .setValue(this.imageWidth)
            .onChange((t) => {
              ((this.imageWidth = t.replace(/[^\d]/g, "")),
                e.setValue(this.imageWidth),
                this.updateHeader());
            }));
      });
    const r = s.controlEl.createDiv("image-size-icon");
    (e.setIcon(r, "lucide-x"),
      s.addText((e) => {
        (e.inputEl.addClass("image-height-input"),
          e
            .setPlaceholder(Xr("Image Height"))
            .setValue(this.imageHeight)
            .onChange((t) => {
              ((this.imageHeight = t.replace(/[^\d]/g, "")),
                e.setValue(this.imageHeight),
                this.updateHeader());
            }));
      }),
      (s.settingEl.style.display = this.isEmbed ? "block" : "none"),
      new e.Setting(t)
        .setName(Xr("Insert New Line"))
        .setDesc(Xr("Insert a link on the next line"))
        .addToggle((e) => {
          e.setValue(this.insertNewLine).onChange((e) => {
            ((this.insertNewLine = e), this.updateHeader());
          });
        }),
      (this.previewSetting = new e.Setting(t)
        .setClass("preview-setting")
        .setTooltip(this.getPreviewText())
        .addText((e) => {
          e.setValue(this.getPreviewText()).inputEl.setAttribute(
            "readonly",
            "true",
          );
        })));
    const a = t.createDiv("shortcut-hint");
    (a.setText(
      `${e.Platform.isMacOS ? "⌘" : "Ctrl"} + Enter ${Xr("to insert")}`,
    ),
      (a.style.textAlign = "right"),
      (a.style.fontSize = "0.8em"),
      (a.style.opacity = "0.7"),
      (a.style.marginTop = "5px"),
      new e.Setting(t)
        .addButton((e) => {
          (e
            .setButtonText(Xr("Insert"))
            .setCta()
            .onClick(() => {
              (this.insertLink(), this.close());
            }),
            (this.insertButton = e.buttonEl));
        })
        .addButton((e) =>
          e.setButtonText(Xr("Cancel")).onClick(() => {
            this.close();
          }),
        ),
      setTimeout(() => {
        this.linkText || this.linkUrl
          ? !this.linkText && this.linkUrl
            ? this.linkTextInput.inputEl.focus()
            : this.linkText && !this.linkUrl
              ? this.linkUrlInput.inputEl.focus()
              : this.linkAliasInput.inputEl.focus()
          : this.linkTextInput.inputEl.focus();
      }, 10));
  }
  async fetchRemoteTitle(e) {
    return jc.fetchRemoteTitle(e);
  }
  getImageDimensions() {
    const t = this.app.workspace.getActiveViewOfType(e.MarkdownView);
    if (!t) return null;
    const i = t.contentEl.querySelector(".markdown-source-view .cm-content"),
      o = t.contentEl;
    if (!i || !o) return null;
    const n = i.offsetWidth,
      s = o.offsetHeight,
      r = Math.floor(s / 2);
    if ("preview" === t.getMode() || "source" === t.getMode()) {
      const e = i.querySelectorAll("img");
      if (e.length > 0) {
        let t = null;
        if (
          (this.linkUrl &&
            e.forEach((e) => {
              e.src === this.linkUrl &&
                e.complete &&
                e.naturalWidth > 0 &&
                (t = e);
            }),
          t)
        ) {
          const e = t.naturalWidth,
            i = e / t.naturalHeight;
          let o = Math.min(e, Math.floor(0.65 * n)),
            s = Math.floor(o / i);
          return (
            s > r && ((s = r), (o = Math.floor(s * i))),
            { width: o, height: s }
          );
        }
      }
    }
    const a = Math.floor(r * (4 / 3));
    return { width: Math.min(Math.floor(0.65 * n), a), height: null };
  }
  validateUrl(e) {
    return e
      ? this.isValidUrl(e)
        ? ((this.urlErrorMsg.style.display = "none"), !0)
        : ((this.urlErrorMsg.textContent = Xr("URL Format Error")),
          (this.urlErrorMsg.style.display = "block"),
          !1)
      : ((this.urlErrorMsg.style.display = "none"), !0);
  }
  insertLink() {
    if (!this.validateUrl(this.linkUrl)) return;
    const e = this.plugin.commandsManager.getActiveEditor();
    if (!e) return;
    let t = this.linkText || this.linkUrl;
    const i = this.linkUrl;
    let o,
      n = this.isEmbed ? "!" : "";
    ((n += `[${t}`),
      this.isEmbed &&
        (this.imageWidth || this.imageHeight) &&
        ((n += "|"),
        this.imageWidth && this.imageHeight
          ? (n += `${this.imageWidth}x${this.imageHeight}`)
          : this.imageWidth
            ? (n += this.imageWidth)
            : this.imageHeight && (n += `x${this.imageHeight}`)),
      (n += `](${i}`),
      this.linkAlias && (n += ` "${this.linkAlias}"`),
      (n += ")"));
    if (e.somethingSelected()) {
      const t = e.getCursor("from"),
        i = e.getCursor("to");
      if (this.insertNewLine)
        (e.replaceRange("\n" + n, {
          line: i.line,
          ch: e.getLine(i.line).length,
        }),
          (o = { line: i.line + 1, ch: n.length }));
      else {
        const s = this.prefixText + n + this.suffixText;
        (e.replaceRange(s, { line: t.line, ch: t.ch }, i),
          (o = { line: t.line, ch: this.prefixText.length + n.length }));
      }
    } else {
      const t = e.getCursor(),
        i = e.getLine(t.line);
      if (this.insertNewLine) {
        const s = t.line + 1;
        (e.replaceRange("\n", { line: t.line, ch: i.length }),
          e.setCursor({ line: s, ch: 0 }),
          e.replaceRange(n, { line: s, ch: 0 }),
          (o = { line: s, ch: n.length }));
      } else
        (e.replaceRange(n, t), (o = { line: t.line, ch: t.ch + n.length }));
    }
    setTimeout(() => {
      (o && e.setCursor(o), e.focus());
    }, 0);
  }
  updateUI() {
    (this.linkTextInput && this.linkTextInput.setValue(this.linkText),
      this.linkUrlInput &&
        (this.linkUrlInput.setValue(this.linkUrl),
        this.validateUrl(this.linkUrl)));
    const e = this.contentEl.querySelector(".image-width-input"),
      t = this.contentEl.querySelector(".image-height-input");
    (e && (e.value = this.imageWidth),
      t && (t.value = this.imageHeight),
      this.linkAliasInput && this.linkAliasInput.setValue(this.linkAlias));
    const i = this.contentEl.querySelector(".setting-item:nth-child(2)");
    (i && (i.style.display = "flex"), this.updateHeader());
  }
}
class Gc {
  static getPlainText(t) {
    const i = t.getSelection();
    if (!i) return void new e.Notice(Xr("Please select text first"));
    let o = i
      .replace(/\[([^\[\]]*)\]\([^\(\)]+\)/gim, "$1")
      .replace(
        /(^#+\s|(?<=^|\s*)#|^>|^\- \[( |x)\]|^\+ |<[^<>]+>|^1\. |^\-+$|^\*+$|==|\*+|~~|```|!*\[\[|\]\])/gm,
        "",
      )
      .replace(/^[ ]+|[ ]+$/gm, "")
      .replace(/(\r\n|\n)+/gm, "\n");
    (navigator.clipboard.writeText(o),
      new e.Notice(Xr("Plain text copied to clipboard")));
  }
  static insertBlankLines(e) {
    const t = e.getValue();
    if (!t) return;
    const i = t.replace(/([^\n])\n([^\n])/g, "$1\n\n$2");
    e.setValue(i);
  }
  static processWhitespace(t, i = {}) {
    const o = t.getSelection();
    if (!o) return void new e.Notice(Xr("Please select text first"));
    let n = o;
    i.all
      ? (n = n.replace(/[ \u3000\t]+/g, ""))
      : (i.tabs && (n = n.replace(/\t/g, "")),
        i.compress && (n = n.replace(/[ \u3000]+/g, " ")));
    let s = n.split(/\r?\n/);
    if ((i.trim && (s = s.map((e) => e.trim())), i.removeEmptyLines))
      s = s.filter((e) => e.length > 0);
    else if (i.compactEmptyLines) {
      const e = [];
      for (let t = 0; t < s.length; t++)
        (0 === s[t].length && t > 0 && 0 === s[t - 1].length) || e.push(s[t]);
      s = e;
    }
    ((n = s.join("\n")),
      i.removeEmptyLines && (n = n.trim()),
      t.replaceSelection(n),
      new e.Notice(Xr("Whitespace cleaning completed")));
  }
  static splitLines(t) {
    const i = t.getSelection();
    if (!i) return void new e.Notice(Xr("Please select text first"));
    const o = this.detectPattern(i);
    let n;
    if (o)
      ((n = i
        .split(o)
        .map((e) => e.trim())
        .filter((e) => e.length > 0)),
        new e.Notice(Xr("List pattern detected, auto-split")));
    else {
      const t = this.detectSeparator(i);
      if (!t)
        return void new e.Notice(
          Xr("No obvious separator or list pattern detected"),
        );
      ((n = this.smartSplit(i, t)),
        new e.Notice(`${Xr("Merged with")} '${t}' ${Xr("Merge completed")}`));
    }
    t.replaceSelection(n.join("\n"));
  }
  static detectPattern(e) {
    const t = /\s?\d+[\.、]\s?/g,
      i = /\s?[→=>]\s?/g;
    return (e.match(t) || []).length > 1
      ? t
      : (e.match(i) || []).length > 1
        ? i
        : null;
  }
  static smartSplit(e, t) {
    const i = [];
    let o = "",
      n = null;
    const s = {
      '"': '"',
      "'": "'",
      "“": "”",
      "‘": "’",
      "(": ")",
      "（": "）",
      "《": "》",
      "[": "]",
      "[[": "]]",
    };
    for (let r = 0; r < e.length; r++) {
      const a = e[r];
      n
        ? ((o += a), a === n && (n = null))
        : s[a]
          ? ((n = s[a]), (o += a))
          : a === t
            ? (i.push(o.trim()), (o = ""))
            : (o += a);
    }
    return (o && i.push(o.trim()), i.filter((e) => e.length > 0));
  }
  static detectSeparator(e) {
    let t = 0,
      i = null;
    return (
      ["、", "，", ",", ";", "；", "|", "·"].forEach((o) => {
        const n = e.split(o).length - 1;
        n > t && ((t = n), (i = o));
      }),
      i
    );
  }
  static async smartPaste(t) {
    try {
      const e = await navigator.clipboard.readText();
      if (!e) return;
      let i = e.replace(/(\r\n|\n){3,}/g, "\n\n");
      ((i = i.replace(/[ \t]+$/gm, "")), t.replaceSelection(i));
    } catch (t) {
      new e.Notice(Xr("Paste failed"));
    }
  }
  static smartTypography(t) {
    const i = t.getSelection();
    if (!i || 0 === i.trim().length)
      return void new e.Notice(Xr("Please select text first"));
    const o = (i.match(/[\u4e00-\u9fa5]/g) || []).length / i.length > 0.1;
    let n = i;
    const s = [];
    ([
      /`[^`]+`/g,
      /\$[^$]+\$/g,
      /https?:\/\/[^\s)]+/g,
      /!\[.*?\]\(.*?\)/g,
      /\[.*?\]\(.*?\)/g,
    ].forEach((e) => {
      n = n.replace(e, (e) => (s.push(e), `__PROTECTED_${s.length - 1}__`));
    }),
      o
        ? ((n = n
            .replace(/,/g, "，")
            .replace(/\.(?!\d)/g, "。")
            .replace(/;/g, "；")
            .replace(/:/g, "：")
            .replace(/\?/g, "？")
            .replace(/!/g, "！")
            .replace(/\(/g, "（")
            .replace(/\)/g, "）")
            .replace(/"([^"]*)"/g, "“$1”")
            .replace(/([\u4e00-\u9fa5])([a-zA-Z0-9])/g, "$1 $2")
            .replace(/([a-zA-Z0-9])([\u4e00-\u9fa5])/g, "$1 $2")),
          new e.Notice(
            Xr("Detected Chinese context: converted to full-width symbols"),
          ))
        : ((n = n
            .replace(/，/g, ", ")
            .replace(/。/g, ". ")
            .replace(/；/g, "; ")
            .replace(/：/g, ": ")
            .replace(/？/g, "? ")
            .replace(/！/g, "! ")
            .replace(/（/g, "(")
            .replace(/）/g, ")")
            .replace(/[""]/g, '"')
            .replace(/ {2,}/g, " ")),
          new e.Notice(
            Xr(
              "Detected code/English context: converted to half-width symbols",
            ),
          )),
      s.forEach((e, t) => {
        n = n.replace(`__PROTECTED_${t}__`, e);
      }),
      t.replaceSelection(n));
  }
  static dedupe(t, i = {}) {
    const o = t.getSelection();
    if (!o) return void new e.Notice(Xr("Please select text to dedupe first"));
    const n = o.split(/\r?\n/),
      s = new Set(),
      r = [];
    for (const e of n) {
      const t = i.trimBeforeCompare ? e.trim() : e;
      "" !== t
        ? s.has(t) || (s.add(t), r.push(e))
        : i.includeEmpty
          ? s.has("") || (s.add(""), r.push(e))
          : r.push(e);
    }
    (i.sort && r.sort((e, t) => e.localeCompare(t, "zh-CN", { numeric: !0 })),
      t.replaceSelection(r.join("\n")),
      new e.Notice(
        `${Xr("Deduplication completed, remaining")} ${r.length} ${Xr("lines")}`,
      ));
  }
  static addWrap(t, i = "", o = "", n = !0) {
    const s = t.getSelection(),
      r = s && "" !== s.trim(),
      a = r ? s : t.getValue();
    if (!a) return;
    const l = a
      .split("\n")
      .map((e) => (n && 0 === e.trim().length ? e : `${i}${e}${o}`))
      .join("\n");
    (r ? t.replaceSelection(l) : t.setValue(l),
      new e.Notice(Xr("Prefix/suffix added")));
  }
  static numberList(t, i = 1, o = 1, n = ". ", s = "") {
    const r = t.getSelection();
    if (!r) return void new e.Notice(Xr("Please select text to number first"));
    const a = r.split("\n");
    let l = i;
    const c = a
      .map((e) => {
        if ("" === e.trim()) return e;
        const t = e.replace(/^\s*\d+[\.\)）、]?\s*/, ""),
          i = `${s}${l}${n}${t}`;
        return ((l += o), i);
      })
      .join("\n");
    (t.replaceSelection(c),
      new e.Notice(`${Xr("Numbering completed: starting from")} ${i}`));
  }
  static extractBetween(t, i, o) {
    if (!i && !o)
      return void new e.Notice(Xr("Please specify start or end string"));
    const n = t.getValue();
    if (n)
      try {
        const s = (e) => e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"),
          r = s(i),
          a = s(o),
          l = new RegExp(`${r}(.*?)${a}`, "g"),
          c = [];
        let d;
        for (; null !== (d = l.exec(n)); ) void 0 !== d[1] && c.push(d[1]);
        c.length > 0
          ? (t.setValue(c.join("\n")),
            new e.Notice(`${Xr("Extracted")} ${c.length} ${Xr("matches")}`))
          : new e.Notice(Xr("No matches found"));
      } catch (t) {
        new e.Notice(Xr("Extraction failed"));
      }
  }
  static mergeLines(t, i) {
    const o = t.getSelection();
    if (!o || "" === o.trim())
      return void new e.Notice(Xr("Please select lines to merge first"));
    const n = o.split(/\r?\n/),
      s = "" !== i.separator;
    let r = "";
    for (let e = 0; e < n.length; e++) {
      let t = i.trimLines ? n[e].trim() : n[e];
      if ("" !== t) {
        if ("" !== r && !r.endsWith("\n"))
          if (s) r += i.separator;
          else {
            const e = r.slice(-1),
              i = t.charAt(0);
            (/[\u4e00-\u9fa5]/.test(e) && /[\u4e00-\u9fa5]/.test(i)) ||
              (r += " ");
          }
        r += t;
      } else i.preserveParagraphs && !s && (r += "\n\n");
    }
    ((r = r.replace(/[ ]{2,}/g, " ").trim()),
      t.replaceSelection(r),
      new e.Notice(
        s ? `${Xr("Merged with")} '${i.separator}'` : Xr("Merge completed"),
      ));
  }
  static convertListToTableMultiDim(e) {
    const t = e.getSelection();
    if (!t || "" === t.trim()) return;
    const i = t.split(/\r?\n/),
      o = /^((\s*)(?:[-*+]|\d+\.)\s+)(.*)/;
    let n = 0;
    const s = i
        .map((e) => e.match(o))
        .filter((e) => e && e[2].length > 0)
        .map((e) => e[2].replace(/\t/g, "    ").length),
      r = s.length > 0 ? Math.min(...s) : 4;
    i.forEach((e) => {
      const t = e.match(o);
      if (t) {
        const e = Math.round(t[2].replace(/\t/g, " ".repeat(r)).length / r);
        e > n && (n = e);
      }
    });
    let a = [],
      l = [],
      c = [],
      d = !1;
    for (let e = 0; e < i.length; e++) {
      const t = i[e],
        s = t.match(o);
      if (s) {
        d = !0;
        const e = s[3].trim(),
          t = Math.round((s[2] || "").replace(/\t/g, " ".repeat(r)).length / r);
        1 === n
          ? 0 === t
            ? (c.length > 0 && l.push([...c]), (c = [e, ""]))
            : (c[1] = c[1] ? c[1] + "<br>" + e : e)
          : (void 0 !== c[t] && (l.push([...c]), (c = c.slice(0, t))),
            (c[t] = e));
      } else if (d) {
        if ("" !== t.trim()) {
          const e = c.length - 1;
          e >= 0 && (c[e] += "<br>" + t.trim());
        }
      } else a.push(t);
    }
    c.length > 0 && l.push(c);
    const h = 1 === n ? l : this.applyVisualMerge(l);
    this.renderFinalResult(e, a, h, [], n + 1);
  }
  static applyVisualMerge(e) {
    let t = [];
    return e.map((e, i) => {
      if (0 === i) return ((t = [...e]), e);
      const o = e.map((i, o) => {
        const n = e.slice(0, o).every((e, i) => e === t[i] || "" === e);
        return n && i === t[o] ? "" : i;
      });
      return ((t = [...e]), o);
    });
  }
  static renderFinalResult(t, i, o, n, s) {
    const r =
        "| " +
        Array.from({ length: s }, (e, t) =>
          0 === t ? Xr("Item") : `${Xr("Content")} ${t}`,
        ).join(" | ") +
        " |\n",
      a = "| " + Array.from({ length: s }, () => "---").join(" | ") + " |\n",
      l = o
        .map((e) => {
          const t = Array.from({ length: s }, (t, i) =>
            (e[i] || "").replace(/\|/g, "\\|"),
          );
          return `| ${t.join(" | ")} |`;
        })
        .join("\n");
    let c = r + a + l,
      d = "";
    (i.length > 0 && (d += i.join("\n").trimEnd() + "\n\n"),
      (d += c),
      n.length > 0 && (d += "\n\n" + n.join("\n").trimStart()));
    const h = t.getCursor("from");
    if (h.line > 0 && 0 === i.length) {
      "" !== t.getLine(h.line - 1).trim() && (d = "\n" + d);
    }
    (t.replaceSelection(d),
      new e.Notice(
        Xr(
          "Super conversion completed: context preserved and layout optimized",
        ),
      ));
  }
  static convertTableToList(t) {
    let i = t.getSelection();
    if (!i || !i.includes("|")) {
      const e = t.getCursor("from"),
        o = t.lineCount();
      let n = e.line;
      for (; n > 0; ) {
        if (!t.getLine(n - 1).includes("|")) break;
        n--;
      }
      let s = e.line;
      for (; s < o - 1; ) {
        if (!t.getLine(s + 1).includes("|")) break;
        s++;
      }
      if (n <= s) {
        const e = [];
        for (let i = n; i <= s; i++) {
          const o = t.getLine(i);
          o.includes("|") && e.push(o);
        }
        e.length > 0 &&
          ((i = e.join("\n")),
          t.setSelection(
            { line: n, ch: 0 },
            { line: s, ch: t.getLine(s).length },
          ));
      }
    }
    if (!i || !i.includes("|"))
      return void new e.Notice(Xr("Please select a valid Markdown table"));
    const o = i.split(/\r?\n/),
      n = [];
    for (const e of o) {
      if (e.match(/^\s*\|?[\s\-:|]+\|?\s*$/) || "" === e.trim()) continue;
      e.trim()
        .replace(/^\|/, "")
        .replace(/\|$/, "")
        .split("|")
        .map((e) => e.trim())
        .forEach((e, t) => {
          if ("" !== e && e !== Xr("Item") && !e.startsWith(Xr("Content"))) {
            const i = "  ".repeat(t);
            n.push(`${i}- ${e}`);
          }
        });
    }
    (t.replaceSelection(n.join("\n")),
      new e.Notice(Xr("Table converted to multi-level list")));
  }
}
class Zc extends e.Modal {
  constructor(e, t, i, o) {
    (super(e),
      (this.result = {}),
      (this.title = t),
      (this.fields = i),
      (this.onSubmit = o),
      i.forEach((e) => {
        this.result[e.key] = e.defaultValue || "";
      }));
  }
  onOpen() {
    const { contentEl: t } = this;
    (t.empty(),
      t.createEl("h2", { text: this.title }),
      this.fields.forEach((i) => {
        new e.Setting(t).setName(i.label).addText((e) => {
          (e
            .setPlaceholder(i.placeholder || "")
            .setValue(i.defaultValue || "")
            .onChange((e) => {
              this.result[i.key] = e;
            }),
            i === this.fields[0] && setTimeout(() => e.inputEl.focus(), 10),
            e.inputEl.addEventListener("keydown", (e) => {
              "Enter" === e.key && (e.preventDefault(), this.submit());
            }));
        });
      }),
      new e.Setting(t)
        .addButton((e) =>
          e
            .setButtonText(Xr("Confirm"))
            .setCta()
            .onClick(() => {
              this.submit();
            }),
        )
        .addButton((e) =>
          e.setButtonText(Xr("Cancel")).onClick(() => {
            this.close();
          }),
        ));
  }
  submit() {
    (this.onSubmit(this.result), this.close());
  }
  onClose() {
    const { contentEl: e } = this;
    e.empty();
  }
}
class Kc {
  constructor(e) {
    ((this.executeCommandWithoutBlur = async (e, t) => {
      e && (await t(), e.focus());
    }),
      (this._commandsMap = {
        hrline: {
          char: 5,
          line: 1,
          prefix: "\n---",
          suffix: "\n",
          islinehead: !0,
        },
        justify: {
          char: 0,
          line: 0,
          prefix: '<p align="justify">',
          suffix: "</p>",
          islinehead: !1,
        },
        left: {
          char: 0,
          line: 0,
          prefix: '<p align="left">',
          suffix: "</p>",
          islinehead: !1,
        },
        right: {
          char: 0,
          line: 0,
          prefix: '<p align="right">',
          suffix: "</p>",
          islinehead: !1,
        },
        center: {
          char: 0,
          line: 0,
          prefix: "<center>",
          suffix: "</center>",
          islinehead: !1,
        },
        underline: {
          char: 0,
          line: 0,
          prefix: "<u>",
          suffix: "</u>",
          islinehead: !1,
        },
        superscript: {
          char: 0,
          line: 0,
          prefix: "<sup>",
          suffix: "</sup>",
          islinehead: !1,
        },
        subscript: {
          char: 0,
          line: 0,
          prefix: "<sub>",
          suffix: "</sub>",
          islinehead: !1,
        },
        codeblock: {
          char: 4,
          line: 0,
          prefix: "\n```\n",
          suffix: "\n```\n",
          islinehead: !1,
        },
      }),
      (this.modCommands = [
        { id: "editor:insert-embed", name: "Insert Embed", icon: "note-glyph" },
        { id: "editor:insert-link", name: "Insert Link", icon: "link-glyph" },
        {
          id: "editor:insert-tag",
          name: "Insert Tag",
          icon: "price-tag-glyph",
        },
        {
          id: "editor:insert-wikilink",
          name: "Insert Internal link",
          icon: "bracket-glyph",
        },
        { id: "editor:toggle-code", name: "Insert Code", icon: "code-glyph" },
        {
          id: "editor:toggle-blockquote",
          name: "Insert Blockquote",
          icon: "lucide-text-quote",
        },
        {
          id: "editor:toggle-checklist-status",
          name: "Cycle List and Checklist",
          icon: "checkbox-glyph",
        },
        {
          id: "editor:toggle-comments",
          name: "Insert Comment",
          icon: "percent-sign-glyph",
        },
        {
          id: "editor:insert-callout",
          name: "Insert Callout",
          icon: "lucide-quote",
        },
        {
          id: "editor:insert-mathblock",
          name: "Insert MathBlock",
          icon: "lucide-sigma-square",
        },
        {
          id: "editor:insert-table",
          name: "Insert Table",
          icon: "lucide-table",
        },
        {
          id: "editor:swap-line-up",
          name: "Swap Line Up",
          icon: "lucide-corner-right-up",
        },
        {
          id: "editor:swap-line-down",
          name: "Swap Line Down",
          icon: "lucide-corner-right-down",
        },
        {
          id: "editor:attach-file",
          name: "Attach File",
          icon: "lucide-paperclip",
        },
        {
          id: "editor:clear-formatting",
          name: "Clear Formatting",
          icon: "lucide-eraser",
        },
      ]),
      (this.applyCommand = (e, t) => {
        const i = t.getSelection(),
          o = t.getCursor("from"),
          n = t.getCursor("to");
        let s = e.prefix;
        e.islinehead && o.ch > 0 && (s = "\n" + s);
        const r = e.suffix,
          a = { line: o.line - e.line, ch: o.ch - s.length };
        if (t.getRange(a, o) == s) {
          const l = { line: o.line + e.line, ch: n.ch + r.length };
          if (t.getRange(n, l) == r) {
            (t.replaceRange(i, a, l), t.setCursor(o.line - e.line, o.ch));
            const n = { line: o.line, ch: o.ch - s.length },
              r = { line: o.line, ch: n.ch + i.length };
            return void t.setSelection(n, r);
          }
        }
        if ((t.replaceSelection(`${s}${i}${r}`), e.char > 0))
          t.setCursor(o.line + e.line, o.ch + e.char + i.length);
        else {
          const e = o,
            n = { line: e.line, ch: e.ch + s.length },
            r = { line: e.line, ch: n.ch + i.length };
          t.setSelection(n, r);
        }
      }),
      (this.plugin = e));
  }
  async applyRegexCommand(t, i) {
    try {
      let o = t.getSelection(),
        n = t.getCursor("from"),
        s = t.getCursor("to");
      if (!o)
        if (this.plugin.settings.useCurrentLineForRegex) {
          const i = n.line,
            r = t.getLine(i);
          if (!r || "" === r.trim())
            return void new e.Notice(
              Xr(
                "Current line is empty, please select text or move to a non-empty line",
              ),
            );
          ((o = r),
            (n = { line: i, ch: 0 }),
            (s = { line: i, ch: r.length }),
            t.setSelection(n, s));
        } else
          try {
            const i = await this.readClipboard();
            if (
              ((o = i["text/html"]
                ? e.htmlToMarkdown(i["text/html"])
                : i["text/markdown"] || i["text/plain"]),
              !o)
            )
              return void new e.Notice(
                Xr("Please select text or copy text to clipboard first"),
              );
            t.replaceRange(o, n, n);
            const s = t.offsetToPos(t.posToOffset(n) + o.length);
            t.setSelection(n, s);
          } catch (t) {
            return (
              console.error("读取剪贴板失败:", t),
              void new e.Notice(Xr("Please select text first"))
            );
          }
      if (i.useCondition && i.conditionPattern) {
        if (!new RegExp(i.conditionPattern).test(o))
          return void new e.Notice(
            Xr("The selected text does not meet the condition requirements"),
          );
      }
      let r = "";
      (!1 !== i.regexGlobal && (r += "g"),
        i.regexCaseInsensitive && (r += "i"),
        i.regexMultiline && (r += "m"));
      const a = new RegExp(i.regexPattern, r),
        l = t.getCursor("from"),
        c = t.getCursor("to");
      t.transaction({
        changes: [{ from: l, to: c, text: o.replace(a, i.regexReplacement) }],
      });
      const d = t.getSelection(),
        h = t.offsetToPos(t.posToOffset(l)),
        u = t.offsetToPos(t.posToOffset(l) + d.length);
      t.setSelection(h, u);
    } catch (t) {
      (console.error("正则表达式命令执行错误:", t),
        new e.Notice(Xr("Regex command execution error: ") + t.message));
    }
  }
  async readClipboard() {
    const e = {};
    try {
      const t = await navigator.clipboard.read();
      for (const i of t) {
        const t = i.types;
        for (const o of t)
          if (
            "text/html" === o ||
            "text/plain" === o ||
            "text/markdown" === o
          ) {
            const t = await i.getType(o);
            e[o] = await t.text();
          }
      }
    } catch (t) {
      try {
        const t = await navigator.clipboard.readText();
        e["text/plain"] = t;
      } catch (e) {
        console.error("读取剪贴板失败:", e);
      }
    }
    return e;
  }
  getActiveEditor() {
    const e = this.plugin.app.workspace?.activeEditor;
    if (e && e.editor) return e.editor;
    const t = this.plugin.app.workspace.activeLeaf?.view?.editor;
    return t || null;
  }
  registerCommands() {
    (this.plugin.addCommand({
      id: "renumber-ordered-list",
      name: "Renumber Ordered List",
      editorCallback: (e) => {
        e && this.executeCommandWithoutBlur(e, () => Vr(e));
      },
    }),
      this.plugin.addCommand({
        id: "hide-show-menu",
        name: "Hide/Show ",
        icon: "editingToolbar",
        callback: async () => {
          ((this.plugin.settings.cMenuVisibility =
            !this.plugin.settings.cMenuVisibility),
            this.plugin.settings.cMenuVisibility
              ? setTimeout(() => {
                  dispatchEvent(new Event("editingToolbar-NewCommand"));
                }, 100)
              : Ur(this.plugin.settings.cMenuVisibility),
            ha(this.plugin),
            await this.plugin.saveSettings());
        },
      }),
      this.plugin.addCommand({
        id: "toggle-top-toolbar",
        name: "Toggle Top Toolbar",
        callback: async () => {
          const e = this.plugin.settings,
            t = this.plugin.positionStyle;
          e.enableTopToolbar = !e.enableTopToolbar;
          let i = null;
          (e.enableTopToolbar
            ? (i = "top")
            : "top" === t &&
              (i = e.enableFollowingToolbar
                ? "following"
                : e.enableFixedToolbar
                  ? "fixed"
                  : null),
            i && i !== t && this.plugin.onPositionStyleChange(i),
            await this.plugin.saveSettings(),
            this.plugin.handleeditingToolbar());
        },
      }),
      this.plugin.addCommand({
        id: "toggle-following-toolbar",
        name: "Toggle Following Toolbar",
        callback: async () => {
          const e = this.plugin.settings,
            t = this.plugin.positionStyle;
          e.enableFollowingToolbar = !e.enableFollowingToolbar;
          let i = null;
          (e.enableFollowingToolbar
            ? (i = "following")
            : "following" === t &&
              (i = e.enableTopToolbar
                ? "top"
                : e.enableFixedToolbar
                  ? "fixed"
                  : null),
            i && i !== t && this.plugin.onPositionStyleChange(i),
            await this.plugin.saveSettings(),
            this.plugin.handleeditingToolbar());
        },
      }),
      this.plugin.addCommand({
        id: "toggle-fixed-toolbar",
        name: "Toggle Fixed Toolbar",
        callback: async () => {
          const e = this.plugin.settings,
            t = this.plugin.positionStyle;
          e.enableFixedToolbar = !e.enableFixedToolbar;
          let i = null;
          (e.enableFixedToolbar
            ? (i = "fixed")
            : "fixed" === t &&
              (i = e.enableTopToolbar
                ? "top"
                : e.enableFollowingToolbar
                  ? "following"
                  : null),
            i && i !== t && this.plugin.onPositionStyleChange(i),
            await this.plugin.saveSettings(),
            this.plugin.handleeditingToolbar());
        },
      }),
      this.plugin.addCommand({
        id: "get-plain-text",
        name: "Get Plain Text",
        editorCallback: (e) => {
          Gc.getPlainText(e);
        },
      }),
      this.plugin.addCommand({
        id: "insert-blank-lines",
        name: "Insert Blank Lines",
        editorCallback: (e) => {
          Gc.insertBlankLines(e);
        },
      }),
      this.plugin.addCommand({
        id: "remove-blank-lines",
        name: "Remove Blank Lines",
        editorCallback: (e) =>
          Gc.processWhitespace(e, { removeEmptyLines: !0 }),
      }),
      this.plugin.addCommand({
        id: "split-lines",
        name: "Split Lines",
        editorCallback: (e) => {
          Gc.splitLines(e);
        },
      }),
      this.plugin.addCommand({
        id: "smart-symbols",
        name: "Full Half Converter",
        editorCallback: (e) => {
          Gc.smartTypography(e);
        },
      }),
      this.plugin.addCommand({
        id: "dedupe-lines",
        name: "Dedupe Lines",
        editorCallback: (e) => Gc.dedupe(e, { trimBeforeCompare: !0 }),
      }),
      this.plugin.addCommand({
        id: "add-wrap",
        name: "Add Prefix/Suffix",
        editorCallback: (e) => {
          new Zc(
            this.plugin.app,
            Xr("Add Prefix/Suffix"),
            [
              {
                key: "prefix",
                label: Xr("Prefix"),
                placeholder: Xr("Enter prefix"),
                defaultValue: "",
              },
              {
                key: "suffix",
                label: Xr("Suffix"),
                placeholder: Xr("Enter suffix"),
                defaultValue: "",
              },
            ],
            (t) => {
              const i = t;
              Gc.addWrap(e, i.prefix, i.suffix, !0);
            },
          ).open();
        },
      }),
      this.plugin.addCommand({
        id: "number-lines",
        name: "Number Lines (Custom)",
        editorCallback: (e) => {
          new Zc(
            this.plugin.app,
            Xr("Number Lines Configuration"),
            [
              {
                key: "start",
                label: Xr("Start Number"),
                placeholder: "1",
                defaultValue: "1",
              },
              {
                key: "step",
                label: Xr("Step"),
                placeholder: "1",
                defaultValue: "1",
              },
              {
                key: "sep",
                label: Xr("Separator"),
                placeholder: ". ",
                defaultValue: ". ",
              },
            ],
            (t) => {
              const i = parseInt(t.start) || 1,
                o = parseInt(t.step) || 1,
                n = t.sep || ". ";
              Gc.numberList(e, i, o, n, "");
            },
          ).open();
        },
      }),
      this.plugin.addCommand({
        id: "remove-whitespace-trim",
        name: "Trim Line Ends",
        editorCallback: (e) => {
          Gc.processWhitespace(e, { trim: !0 });
        },
      }),
      this.plugin.addCommand({
        id: "remove-whitespace-compress",
        name: "Shrink Extra Spaces",
        editorCallback: (e) => {
          Gc.processWhitespace(e, { compress: !0 });
        },
      }),
      this.plugin.addCommand({
        id: "remove-whitespace-all",
        name: "Remove All Whitespace",
        editorCallback: (e) => {
          Gc.processWhitespace(e, { all: !0 });
        },
      }),
      this.plugin.addCommand({
        id: "list-to-table",
        name: Xr("List to Table"),
        editorCallback: (e) => {
          Gc.convertListToTableMultiDim(e);
        },
      }),
      this.plugin.addCommand({
        id: "table-to-list",
        name: Xr("Table to List"),
        editorCallback: (e) => Gc.convertTableToList(e),
      }),
      this.plugin.addCommand({
        id: "extract-between",
        name: "Extract Between Strings",
        editorCallback: (e) => {
          new Zc(
            this.plugin.app,
            Xr("Extract Between Strings"),
            [
              {
                key: "start",
                label: Xr("Start String"),
                placeholder: Xr("Enter start string"),
                defaultValue: "[",
              },
              {
                key: "end",
                label: Xr("End String"),
                placeholder: Xr("Enter end string"),
                defaultValue: "]",
              },
            ],
            (t) => {
              const i = t;
              Gc.extractBetween(e, i.start, i.end);
            },
          ).open();
        },
      }),
      this.plugin.addCommand({
        id: "merge-lines",
        name: Xr("Merge Lines"),
        editorCallback: (e) => {
          new Zc(
            this.plugin.app,
            Xr("Merge Lines Settings"),
            [
              {
                key: "sep",
                label: Xr("Separator (leave empty for smart spacing)"),
                placeholder: Xr("e.g., comma, pipe, arrow"),
                defaultValue: "",
              },
            ],
            (t) => {
              Gc.mergeLines(e, {
                separator: t.sep,
                preserveParagraphs: "" === t.sep,
                trimLines: !0,
              });
            },
          ).open();
        },
      }),
      this.plugin.addCommand({
        id: "format-eraser",
        name: "Format Eraser",
        callback: () => {
          const e = this.getActiveEditor();
          e && this.executeCommandWithoutBlur(e, () => va(this.plugin, e));
        },
        icon: "eraser",
      }),
      this.plugin.addCommand({
        id: "change-font-color",
        name: "Change Font Color",
        callback: () => {
          const e = this.getActiveEditor();
          e &&
            this.executeCommandWithoutBlur(e, () =>
              _r(this.plugin.settings.cMenuFontColor ?? "#2DC26B", e),
            );
        },
        icon: '<svg width="24" height="24" focusable="false" fill="currentColor"><g fill-rule="evenodd"><path id="change-font-color-icon" d="M3 18h18v3H3z" style="fill:#2DC26B"></path><path d="M8.7 16h-.8a.5.5 0 01-.5-.6l2.7-9c.1-.3.3-.4.5-.4h2.8c.2 0 .4.1.5.4l2.7 9a.5.5 0 01-.5.6h-.8a.5.5 0 01-.4-.4l-.7-2.2c0-.3-.3-.4-.5-.4h-3.4c-.2 0-.4.1-.5.4l-.7 2.2c0 .3-.2.4-.4.4zm2.6-7.6l-.6 2a.5.5 0 00.5.6h1.6a.5.5 0 00.5-.6l-.6-2c0-.3-.3-.4-.5-.4h-.4c-.2 0-.4.1-.5.4z"></path></g></svg>',
      }),
      this.plugin.addCommand({
        id: "change-background-color",
        name: "Change Background Color",
        callback: () => {
          const e = this.getActiveEditor();
          e &&
            this.executeCommandWithoutBlur(e, () =>
              zr(this.plugin.settings.cMenuBackgroundColor ?? "#FA541C", e),
            );
        },
        icon: '<svg width="18" height="24" viewBox="0 0 256 256" version="1.1" xmlns="http://www.w3.org/2000/svg"><g   stroke="none" stroke-width="1" fill="currentColor" fill-rule="evenodd"><g  ><g fill="currentColor"><g transform="translate(119.502295, 137.878331) rotate(-135.000000) translate(-119.502295, -137.878331) translate(48.002295, 31.757731)" ><path d="M100.946943,60.8084699 L43.7469427,60.8084699 C37.2852111,60.8084699 32.0469427,66.0467383 32.0469427,72.5084699 L32.0469427,118.70847 C32.0469427,125.170201 37.2852111,130.40847 43.7469427,130.40847 L100.946943,130.40847 C107.408674,130.40847 112.646943,125.170201 112.646943,118.70847 L112.646943,72.5084699 C112.646943,66.0467383 107.408674,60.8084699 100.946943,60.8084699 Z M93.646,79.808 L93.646,111.408 L51.046,111.408 L51.046,79.808 L93.646,79.808 Z" fill-rule="nonzero"></path><path d="M87.9366521,16.90916 L87.9194966,68.2000001 C87.9183543,69.4147389 86.9334998,70.399264 85.7187607,70.4 L56.9423078,70.4 C55.7272813,70.4 54.7423078,69.4150264 54.7423078,68.2 L54.7423078,39.4621057 C54.7423078,37.2523513 55.5736632,35.1234748 57.0711706,33.4985176 L76.4832996,12.4342613 C78.9534987,9.75382857 83.1289108,9.5834005 85.8093436,12.0535996 C87.1658473,13.303709 87.9372691,15.0644715 87.9366521,16.90916 Z" fill-rule="evenodd"></path><path d="M131.3,111.241199 L11.7,111.241199 C5.23826843,111.241199 0,116.479467 0,122.941199 L0,200.541199 C0,207.002931 5.23826843,212.241199 11.7,212.241199 L131.3,212.241199 C137.761732,212.241199 143,207.002931 143,200.541199 L143,122.941199 C143,116.479467 137.761732,111.241199 131.3,111.241199 Z M124,130.241 L124,193.241 L19,193.241 L19,130.241 L124,130.241 Z" fill-rule="nonzero"></path></g></g><path d="M51,218 L205,218 C211.075132,218 216,222.924868 216,229 C216,235.075132 211.075132,240 205,240 L51,240 C44.9248678,240 40,235.075132 40,229 C40,222.924868 44.9248678,218 51,218 Z" id="change-background-color-icon" style="fill:#FA541C"></path></g></g></svg>',
      }),
      this.plugin.addCommand({
        id: "indent-list",
        name: "Indent List",
        callback: () => {
          const e = this.getActiveEditor();
          e && this.executeCommandWithoutBlur(e, () => e?.indentList());
        },
        icon: "indent-glyph",
      }),
      this.plugin.addCommand({
        id: "undent-list",
        name: "Unindent List",
        callback: () => {
          const e = this.getActiveEditor();
          e && this.executeCommandWithoutBlur(e, () => e?.unindentList());
        },
        icon: "unindent-glyph",
      }),
      this.plugin.addCommand({
        id: "toggle-numbered-list",
        name: "Numbered List",
        callback: () => {
          const e = this.getActiveEditor();
          e && this.executeCommandWithoutBlur(e, () => e?.toggleNumberList());
        },
        icon: "number-list-glyph",
      }),
      this.plugin.addCommand({
        id: "toggle-bullet-list",
        name: "Unordered List",
        callback: () => {
          const e = this.getActiveEditor();
          e && this.executeCommandWithoutBlur(e, () => e?.toggleBulletList());
        },
        icon: "bullet-list-glyph",
      }),
      this.plugin.addCommand({
        id: "toggle-highlight",
        name: "Highlight",
        callback: () => {
          const e = this.getActiveEditor();
          e &&
            this.executeCommandWithoutBlur(e, () =>
              e?.toggleMarkdownFormatting("highlight"),
            );
        },
        icon: "highlight-glyph",
      }),
      this.plugin.addCommand({
        id: "toggle-bold",
        name: "Toggle Bold",
        callback: () => {
          const e = this.getActiveEditor();
          e &&
            this.executeCommandWithoutBlur(e, () => {
              e.toggleMarkdownFormatting("bold");
            });
        },
        icon: "bold-glyph",
      }),
      this.plugin.addCommand({
        id: "toggle-italics",
        name: "Toggle Italics",
        callback: () => {
          const e = this.getActiveEditor();
          e &&
            this.executeCommandWithoutBlur(e, () =>
              e?.toggleMarkdownFormatting("italic"),
            );
        },
        icon: "italic-glyph",
      }),
      this.plugin.addCommand({
        id: "toggle-strikethrough",
        name: "Toggle Strikethrough",
        callback: () => {
          const e = this.getActiveEditor();
          e &&
            this.executeCommandWithoutBlur(e, () =>
              e?.toggleMarkdownFormatting("strikethrough"),
            );
        },
        icon: "strikethrough-glyph",
      }),
      this.plugin.addCommand({
        id: "toggle-inline-math",
        name: "Toggle Inline Math",
        callback: () => {
          const e = this.getActiveEditor();
          e &&
            this.executeCommandWithoutBlur(e, () =>
              e?.toggleMarkdownFormatting("math"),
            );
        },
        icon: "lucide-sigma",
      }),
      this.plugin.addCommand({
        id: "editor:cycle-list-checklist",
        name: "Cycle List and Checklist",
        icon: "lucide-check-square",
        callback: () => {
          const e = this.getActiveEditor();
          e && this.executeCommandWithoutBlur(e, () => e?.toggleCheckList(!0));
        },
      }),
      this.plugin.addCommand({
        id: "editor-undo",
        name: "Undo Edit",
        callback: () => {
          const e = this.getActiveEditor();
          e && this.executeCommandWithoutBlur(e, () => e?.undo());
        },
        icon: "undo-glyph",
      }),
      this.plugin.addCommand({
        id: "editor-redo",
        name: "Redo Edit",
        callback: () => {
          const e = this.getActiveEditor();
          e && this.executeCommandWithoutBlur(e, () => e?.redo());
        },
        icon: "redo-glyph",
      }),
      this.plugin.addCommand({
        id: "editor-copy",
        name: "Copy",
        callback: () => {
          const e = this.getActiveEditor();
          e &&
            this.executeCommandWithoutBlur(e, async () => {
              try {
                (await window.navigator.clipboard.writeText(e.getSelection()),
                  this.plugin.app.commands.executeCommandById("editor:focus"));
              } catch (e) {
                console.error("Copy failed:", e);
              }
            });
        },
        icon: "lucide-copy",
      }),
      this.plugin.addCommand({
        id: "editor-paste",
        name: "Paste",
        callback: () => {
          const e = this.getActiveEditor();
          e &&
            this.executeCommandWithoutBlur(e, async () => {
              try {
                const t = await window.navigator.clipboard.readText();
                (t && e.replaceSelection(t),
                  this.plugin.app.commands.executeCommandById("editor:focus"));
              } catch (e) {
                console.error("Paste failed:", e);
              }
            });
        },
        icon: "lucide-clipboard-type",
      }),
      this.plugin.addCommand({
        id: "editor-cut",
        name: "Cut",
        callback: () => {
          const e = this.getActiveEditor();
          e &&
            this.executeCommandWithoutBlur(e, async () => {
              try {
                (await window.navigator.clipboard.writeText(e.getSelection()),
                  e.replaceSelection(""),
                  this.plugin.app.commands.executeCommandById("editor:focus"));
              } catch (e) {
                console.error("Cut failed:", e);
              }
            });
        },
        icon: "lucide-scissors",
      }),
      this.plugin.addCommand({
        id: "insert-callout",
        name: "Insert Callout(Modal)",
        icon: "lucide-quote",
        callback: () => {
          new Uc(this.plugin).open();
        },
      }),
      this.plugin.addCommand({
        id: "insert-link",
        name: "Insert Link(Modal)",
        icon: "lucide-link",
        callback: () => {
          new Yc(this.plugin).open();
        },
      }),
      this.plugin.addCommand({
        id: "fullscreen-focus",
        name: "Toggle Fullscreen Focus Mode",
        hotkeys: [{ modifiers: ["Mod", "Shift"], key: "F11" }],
        callback: () =>
          (function (t) {
            (Object.defineProperty(exports, "__esModule", { value: !0 }),
              (exports.toggleFull =
                exports.isFull =
                exports.exitFull =
                exports.beFull =
                  void 0));
            let i = document.documentElement,
              o = i.querySelector("head"),
              n = document.createElement("style"),
              s = "requestFullscreen",
              r = "exitFullscreen",
              a = "fullscreenElement";
            "webkitRequestFullScreen" in i
              ? ((s = "webkitRequestFullScreen"),
                (r = "webkitExitFullscreen"),
                (a = "webkitFullscreenElement"))
              : "msRequestFullscreen" in i
                ? ((s = "msRequestFullscreen"),
                  (r = "msExitFullscreen"),
                  (a = "msFullscreenElement"))
                : "mozRequestFullScreen" in i
                  ? ((s = "mozRequestFullScreen"),
                    (r = "mozCancelFullScreen"),
                    (a = "mozFullScreenElement"))
                  : "requestFullscreen" in i ||
                    console.log("当前浏览器不支持Fullscreen API !");
            const l = t.workspace.getActiveViewOfType(e.MarkdownView);
            if (!l) return;
            let c,
              d = l.containerEl,
              h = document.body?.querySelector(
                ".mod-vertical.mod-root .workspace-tab-container",
              );
            function u(e) {
              return e[s]();
            }
            function p() {
              return (
                i.contains(n) && (null == o || o.removeChild(n)),
                document[r]()
              );
            }
            function m(e) {
              return e === document[a];
            }
            ((c = new MutationObserver(function (e) {
              e.forEach(function (e) {
                e.addedNodes.forEach(function (e) {
                  if (m(h))
                    try {
                      (document.body.removeChild(e), d.appendChild(e));
                    } catch (e) {
                      console.log(e.message);
                    }
                });
              });
            })),
              h.addEventListener("fullscreenchange", function () {
                m(h) || c.disconnect();
              }),
              m(h)
                ? (c.disconnect(), p())
                : (u(h), c.observe(document.body, { childList: !0 })),
              (exports.beFull = u),
              (exports.exitFull = p),
              (exports.isFull = m),
              (exports.toggleFull = function (e) {
                return m(e) ? (p(), !1) : (u(e), !0);
              }));
          })(app),
        icon: "fullscreen",
      }),
      this.plugin.addCommand({
        id: "workplace-fullscreen-focus",
        name: "Toggle Workplace Fullscreen Focus",
        callback: () =>
          (function (t) {
            Hc = e.requireApiVersion("0.15.0")
              ? activeWindow.document
              : window.document;
            let i = Hc;
            t.workspace.leftSplit.collapsed && t.workspace.rightSplit.collapsed
              ? (t.commands.executeCommandById("app:toggle-right-sidebar"),
                t.commands.executeCommandById("app:toggle-left-sidebar"),
                t.workspace.leftRibbon.show(),
                i.body.classList.contains("auto-hide-header") &&
                  i.body.classList.remove("auto-hide-header"))
              : (i.body.classList.contains("auto-hide-header") ||
                  i.body.classList.add("auto-hide-header"),
                t.workspace.leftRibbon.hide(),
                t.workspace.leftSplit.collapsed ||
                  t.commands.executeCommandById("app:toggle-left-sidebar"),
                t.workspace.rightSplit.collapsed ||
                  t.commands.executeCommandById("app:toggle-right-sidebar"));
          })(app),
        hotkeys: [{ modifiers: ["Mod"], key: "F11" }],
        icon: "remix-SplitCellsHorizontal",
      }));
    for (let e = 0; e <= 6; e++)
      this.plugin.addCommand({
        id: `header${e}-text`,
        name: 0 === e ? "Remove header level" : `Header ${e}`,
        callback: () => {
          const t = this.getActiveEditor();
          t && this.executeCommandWithoutBlur(t, () => qr("#".repeat(e), t));
        },
        icon: 0 === e ? "heading-glyph" : `header-${e}`,
      });
    (Object.keys(this._commandsMap).forEach((e) => {
      this.plugin.addCommand({
        id: `${e}`,
        name: `Toggle ${e}`,
        icon: `${e}-glyph`,
        callback: () => {
          const t = this.getActiveEditor();
          t &&
            this.executeCommandWithoutBlur(t, () => {
              this.applyCommand(this._commandsMap[e], t);
            });
        },
      });
    }),
      this.modCommands.forEach((e) => {
        this.plugin.addCommand({
          id: `${e.id}`,
          name: `${e.name}`,
          icon: `${e.icon}`,
          callback: () => {
            const t = this.getActiveEditor();
            t &&
              this.executeCommandWithoutBlur(t, async () => {
                const i = t.getCursor("to");
                let o = this.getCharacterOffset(e.id);
                (await this.plugin.app.commands.executeCommandById(`${e.id}`),
                  0 != o && t.setCursor(i.line, i.ch + o));
              });
          },
        });
      }),
      this.plugin.addCommand({
        id: "toggle-format-brush",
        name: "Toggle Format Brush",
        icon: "paintbrush",
        editorCallback: (e) => {
          this.plugin.toggleFormatBrush();
        },
      }),
      this.registerCustomCommands());
    [
      "toggle-bold",
      "toggle-italics",
      "toggle-strikethrough",
      "toggle-highlight",
      "toggle-code",
      "toggle-blockquote",
      "header0-text",
      "header1-text",
      "header2-text",
      "header3-text",
      "header4-text",
      "header5-text",
      "header6-text",
      "toggle-numbered-list",
      "toggle-bullet-list",
      "format-eraser",
      "indent-list",
      "undent-list",
      "change-font-color",
      "change-background-color",
      ...this.plugin.settings.customCommands.map((e) => `${e.id}`),
      ...Object.keys(this._commandsMap),
    ].forEach((e) => {
      const t = this.plugin.app.commands.commands[`toolbar:${e}`];
      if (t && t.callback) {
        const i = t.callback;
        t.callback = () => {
          (i(), this.plugin.setLastExecutedCommand(`toolbar:${e}`));
        };
      }
    });
  }
  getCharacterOffset(e) {
    switch (e) {
      case "editor:insert-tag":
        return 1;
      case "editor:insert-callout":
        return 11;
      default:
        return 0;
    }
  }
  reloadCustomCommands() {
    (this.plugin.settings.customCommands.forEach((e) => {
      const t = `${e.id}`;
      this.plugin.app.commands.commands[`toolbar:${t}`] &&
        delete this.plugin.app.commands.commands[`toolbar:${t}`];
    }),
      this.registerCustomCommands());
  }
  registerCustomCommands() {
    this.plugin.settings.customCommands.forEach((e) => {
      const t = `${e.id}`;
      this.plugin.addCommand({
        id: t,
        name: e.name,
        icon: e.icon,
        editorCallback: (i) => {
          if (e.useRegex && e.regexPattern)
            i &&
              this.executeCommandWithoutBlur(i, () => {
                (this.applyRegexCommand(i, e),
                  this.plugin.setLastExecutedCommand(`toolbar:${t}`));
              });
          else {
            const o = {
              prefix: e.prefix,
              suffix: e.suffix,
              char: e.char,
              line: e.line,
              islinehead: e.islinehead,
            };
            ((this._commandsMap[e.id] = o),
              i &&
                this.executeCommandWithoutBlur(i, () => {
                  (this.applyCommand(o, i),
                    this.plugin.setLastExecutedCommand(`toolbar:${t}`));
                }));
          }
        },
      });
    });
  }
  get commandsMap() {
    return this._commandsMap;
  }
}
const Jc = ["top", "following", "fixed", "mobile"],
  Xc = [
    "toolbarBackgroundColor",
    "toolbarIconColor",
    "toolbarIconSize",
    "aestheticStyle",
  ];
function Qc(e, t) {
  (e.appearanceByStyle && "object" == typeof e.appearanceByStyle) ||
    (e.appearanceByStyle = {});
  const i = e.appearanceByStyle;
  (Jc.forEach((e) => {
    (i[e] && "object" == typeof i[e]) || (i[e] = {});
  }),
    t &&
      Xc.forEach((t) => {
        const o = e[t];
        void 0 !== o &&
          Jc.forEach((e) => {
            const n = i[e];
            t in n || (n[t] = o);
          });
      }));
}
class ed extends e.Plugin {
  constructor() {
    (super(...arguments),
      (this.appearanceEditStyle = null),
      (this.admonitionDefinitions = null),
      (this.lastExecutedCommand = null),
      (this.formatBrushActive = !1),
      (this.formatBrushNotice = null),
      (this.lastCalloutType = null),
      (this.lastExecutedCommandName = null),
      (this.toolbarCache = new Map()),
      (this.popoverCache = new Map()),
      (this.handleeditingToolbar = () => {
        if (
          (this.formatBrushActive ||
            $c.body.classList.remove("format-brush-cursor"),
          !this.settings.cMenuVisibility)
        )
          return void ["top", "following", "fixed"].forEach((e) => {
            const t = ua(this.app, this, e);
            t && (t.style.display = "none");
          });
        const t = this.app.workspace.getActiveViewOfType(e.ItemView);
        if (!la.isAllowedViewType(t))
          return void ["top", "following", "fixed"].forEach((e) => {
            const t = ua(this.app, this, e);
            t && (t.style.visibility = "hidden");
          });
        const i = t?.getViewType(),
          o = "markdown" === i,
          n = o && la.isSourceMode(t);
        if (o && !n)
          return void ["top", "following", "fixed"].forEach((e) => {
            const t = ua(this.app, this, e);
            t && (t.style.visibility = "hidden");
          });
        const s = [
          {
            key: "top",
            enabled:
              "function" == typeof this.isTopToolbarActive
                ? this.isTopToolbarActive()
                : this.settings.enableTopToolbar ||
                  (!this.settings.enableFollowingToolbar &&
                    !this.settings.enableFixedToolbar &&
                    "top" === this.positionStyle),
          },
          {
            key: "following",
            enabled:
              "function" == typeof this.isFollowingToolbarActive
                ? this.isFollowingToolbarActive()
                : this.settings.enableFollowingToolbar ||
                  (!this.settings.enableTopToolbar &&
                    !this.settings.enableFixedToolbar &&
                    "following" === this.positionStyle),
          },
          {
            key: "fixed",
            enabled:
              this.settings.enableFixedToolbar ||
              (!this.settings.enableTopToolbar &&
                !this.settings.enableFollowingToolbar &&
                "fixed" === this.positionStyle),
          },
        ];
        for (const { key: e, enabled: t } of s) {
          const i = ua(this.app, this, e);
          if (!t) {
            i && (i.style.visibility = "hidden");
            continue;
          }
          i || xa(this.app, this, e);
          const o = ua(this.app, this, e);
          o && (o.style.visibility = "following" === e ? "hidden" : "visible");
        }
      }),
      (this.handleeditingToolbar_layout = () => {
        this.handleeditingToolbar();
      }),
      (this.handleeditingToolbar_resize = () => {
        if (!this.settings.cMenuVisibility || !this.isTopToolbarActive())
          return !1;
        const t = app.workspace.getActiveViewOfType(e.ItemView);
        if (!la.isSourceMode(t)) return !1;
        const i = this.app.workspace.activeLeaf.view.leaf.width ?? 0;
        if (i <= 0 || this.Leaf_Width === i) return !1;
        if (((this.Leaf_Width = i), this.settings.cMenuWidth && i)) {
          if (i - this.settings.cMenuWidth < 78 && i > this.settings.cMenuWidth)
            return;
          setTimeout(() => {
            (!(function (t) {
              ca = e.requireApiVersion("0.15.0")
                ? activeWindow.document
                : window.document;
              const i = ca,
                o = i.querySelectorAll(".editingToolbarModalBar"),
                n = i.querySelectorAll(".editingToolbarPopoverBar");
              (o.forEach((e) => {
                (e.firstChild && e.removeChild(e.firstChild), e.remove());
              }),
                n.forEach((e) => {
                  (e.firstChild && e.removeChild(e.firstChild), e.remove());
                }),
                t && t.clearToolbarCache());
            })(this),
              xa(app, this));
          }, 200);
        }
      }),
      (this.handleKeyboardSelection = (e) => {
        (this.commandsManager.getActiveEditor(),
          [
            "ArrowUp",
            "ArrowDown",
            "ArrowLeft",
            "ArrowRight",
            "Home",
            "End",
            "PageUp",
            "PageDown",
            "ShiftLeft",
            "ShiftRight",
          ].includes(e.code) || e.shiftKey
            ? this.handleTextSelection()
            : !e.shiftKey &&
              this.isFollowingToolbarActive() &&
              this.hideToolbarIfNotSelected());
      }));
  }
  initPerStyleAppearance() {
    const e = this.settings;
    if (!e) return;
    const t = !e.appearanceByStyle;
    Qc(e, t);
    const i = e.appearanceByStyle,
      o = () => {
        const t =
          this.appearanceEditStyle ||
          this.positionStyle ||
          e.positionStyle ||
          "top";
        return Jc.includes(t) ? t : "top";
      };
    Xc.forEach((t) => {
      if (!(t in e)) return;
      const n = e[t];
      Object.defineProperty(e, t, {
        configurable: !0,
        enumerable: !0,
        get() {
          const e = o(),
            s = i[e];
          return s && Object.prototype.hasOwnProperty.call(s, t) ? s[t] : n;
        },
        set(i) {
          const n = o();
          Qc(e, !1);
          e.appearanceByStyle[n][t] = i;
        },
      });
    });
  }
  async onload() {
    const t = this.manifest.version;
    (console.log("editingToolbar v" + t + " loaded"),
      ($c = e.requireApiVersion("0.15.0")
        ? activeWindow.document
        : window.document),
      await this.loadSettings(),
      this.initPerStyleAppearance(),
      (this.settingTab = new zc(this.app, this)),
      this.addSettingTab(this.settingTab),
      (this.commandsManager = new Kc(this)),
      this.commandsManager.registerCommands());
    const i = this.commandsManager.getActiveEditor();
    (this.app.workspace.onLayoutReady(() => {
      ((this.statusBar = new Wc(this)),
        this.statusBar.init(),
        setTimeout(() => {
          this.settings.cMenuVisibility || this.handleeditingToolbar();
        }, 100));
    }),
      this.init_evt($c, i),
      e.requireApiVersion("0.15.0") &&
        this.app.workspace.on("window-open", (e) => {
          this.init_evt(e.doc, i);
        }));
    const o = this.settings?.lastVersion || "0.0.0",
      n = (e) => {
        const t = e.split(".").map((e) => parseInt(e));
        return { major: t[0] || 0, minor: t[1] || 0, patch: t[2] || 0 };
      },
      s = n(o);
    n(t);
    const r = new Mc(this.app, this),
      a = "0.0.0" === o;
    a && r.fixCommandIds();
    (!a &&
      (s.major < 3 ||
        (3 === s.major && s.minor < 2) ||
        (3 === s.major && 2 === s.minor && s.patch < 2)) &&
      (this.settings.commandIdsFixed ||
        (await r.fixCommandIds(),
        (this.settings.commandIdsFixed = !0),
        await this.saveSettings()),
      setTimeout(() => {
        r.open();
      }, 3e3)),
      (this.settings.lastVersion = t),
      await this.saveSettings());
    (app.plugins.enabledPlugins.has("obsidian-memos") &&
      this.registerEvent(
        this.app.workspace.on(
          "thino-editor-created",
          this.handleeditingToolbar,
        ),
      ),
      this.registerEvent(
        this.app.workspace.on("active-leaf-change", this.handleeditingToolbar),
      ),
      this.registerEvent(
        this.app.workspace.on(
          "layout-change",
          this.handleeditingToolbar_layout,
        ),
      ),
      this.registerEvent(
        this.app.workspace.on("resize", this.handleeditingToolbar_resize),
      ),
      1 == this.settings.cMenuVisibility &&
        setTimeout(() => {
          dispatchEvent(new Event("editingToolbar-NewCommand"));
        }, 100),
      this.registerDomEvent($c, "contextmenu", (t) => {
        if (
          this.settings.isLoadOnMobile &&
          e.Platform.isMobile &&
          this.isFollowingToolbarActive()
        ) {
          const { target: e } = t;
          if (e instanceof HTMLElement) {
            null !== e.closest(".cm-editor") && t.preventDefault();
          }
        }
      }),
      this.app.workspace.onLayoutReady(async () => {
        await this.tryGetAdmonitionTypes();
      }),
      this.registerEvent(
        this.app.workspace.on("editor-menu", (e, t, i) => {
          const o = t.getCursor(),
            n = t.getLine(o.line);
          /^\d+\.\s/.test(n) &&
            e.addItem((e) =>
              e
                .setSection("info")
                .setTitle(Xr("Renumber List"))
                .setIcon("list-restart")
                .onClick(() => Vr(t)),
            );
        }),
      ),
      this.registerEvent(
        this.app.workspace.on("url-menu", (e, t, i) => {
          e.addItem((e) =>
            e
              .setTitle("Edit Link(Modal)")
              .setSection("info")
              .setIcon("link")
              .onClick(() => {
                new Yc(this).open();
              }),
          );
        }),
      ),
      Object.keys(Vc).forEach((t) => {
        e.addIcon(t, Vc[t]);
      }),
      (this.toolbarIconSize = this.settings.toolbarIconSize),
      (this.positionStyle = this.settings.positionStyle),
      $c.documentElement.style.setProperty(
        "--toolbar-background-color",
        this.settings.toolbarBackgroundColor,
      ),
      $c.documentElement.style.setProperty(
        "--toolbar-icon-color",
        this.settings.toolbarIconColor,
      ),
      $c.documentElement.style.setProperty(
        "--toolbar-icon-size",
        `${this.settings.toolbarIconSize}px`,
      ));
  }
  async tryGetAdmonitionTypes(e = 0) {
    const t = this.app.plugins?.getPlugin("obsidian-admonition");
    t && this.processAdmonitionTypes(t);
  }
  processAdmonitionTypes(e) {
    const t = e;
    t.admonitions &&
    "object" == typeof t.admonitions &&
    !Array.isArray(t.admonitions) &&
    Object.keys(t.admonitions).length > 0
      ? (Object.keys(t.admonitions),
        (this.admonitionDefinitions = t.admonitions))
      : (console.warn(
          "未能从 admonitionPlugin.admonitions (作为对象) 获取类型。",
        ),
        (this.admonitionDefinitions = null));
  }
  isLoadMobile() {
    let t = window.innerWidth > 0 ? window.innerWidth : screen.width,
      i = !!this.settings?.isLoadOnMobile && this.settings.isLoadOnMobile;
    return (
      !(e.Platform.isMobileApp && !i && t <= 768) ||
      (console.log("Toolbar disable loading on mobile"), !1)
    );
  }
  onunload() {
    (this.app.workspace.off("active-leaf-change", this.handleeditingToolbar),
      this.app.workspace.off("layout-change", this.handleeditingToolbar_layout),
      this.app.workspace.off("resize", this.handleeditingToolbar_resize),
      this.formatBrushNotice &&
        (this.formatBrushNotice.hide(), (this.formatBrushNotice = null)),
      this.quiteAllFormatBrushes(),
      ha(this),
      console.log("editingToolbar unloaded"));
  }
  isView() {
    const t = this.app.workspace.getActiveViewOfType(e.ItemView);
    return la.isAllowedViewType(t);
  }
  setIS_MORE_Button(e) {
    this.IS_MORE_Button = e;
  }
  setEN_BG_Format_Brush(e) {
    this.EN_BG_Format_Brush = e;
  }
  setEN_FontColor_Format_Brush(e) {
    this.EN_FontColor_Format_Brush = e;
  }
  setEN_Text_Format_Brush(e) {
    this.EN_Text_Format_Brush = e;
  }
  setTemp_Notice(e) {
    this.Temp_Notice = e;
  }
  async loadSettings() {
    this.settings = Object.assign({}, aa, await this.loadData());
    if (
      !this.settings.enableTopToolbar &&
      !this.settings.enableFollowingToolbar &&
      !this.settings.enableFixedToolbar &&
      this.settings.positionStyle
    ) {
      switch (this.settings.positionStyle) {
        case "top":
          this.settings.enableTopToolbar = !0;
          break;
        case "following":
          this.settings.enableFollowingToolbar = !0;
          break;
        case "fixed":
          this.settings.enableFixedToolbar = !0;
      }
      await this.saveSettings();
    }
  }
  getCurrentCommands(t) {
    if (!this.settings.enableMultipleConfig) return this.settings.menuCommands;
    let i = t || this.positionStyle;
    if (this.settings.isLoadOnMobile && e.Platform.isMobileApp)
      return this.settings.mobileCommands;
    switch (i) {
      case "following":
        return this.settings.followingCommands;
      case "top":
        return this.settings.topCommands;
      case "fixed":
        return this.settings.fixedCommands;
      default:
        return this.settings.menuCommands;
    }
  }
  updateCurrentCommands(t, i) {
    if (!this.settings.enableMultipleConfig)
      return void (this.settings.menuCommands = t);
    let o = i;
    switch (
      (o ||
        (o =
          this.settings.isLoadOnMobile && e.Platform.isMobileApp
            ? "mobile"
            : this.positionStyle),
      o)
    ) {
      case "following":
        this.settings.followingCommands = t;
        break;
      case "top":
        this.settings.topCommands = t;
        break;
      case "fixed":
        this.settings.fixedCommands = t;
        break;
      case "mobile":
        this.settings.mobileCommands = t;
        break;
      default:
        this.settings.menuCommands = t;
    }
  }
  async saveSettings() {
    await this.saveData(this.settings);
  }
  setLastExecutedCommand(e) {
    this.lastExecutedCommand = e;
    const t = this.app.commands.commands[e];
    if (t && t.name) this.lastExecutedCommandName = t.name;
    else {
      const t = e.split(":");
      this.lastExecutedCommandName = t[t.length - 1].replace(/-/g, " ");
    }
  }
  toggleFormatBrush() {
    const t = this.commandsManager.getActiveEditor();
    let i = !1,
      o = "";
    if (t)
      if (t.somethingSelected()) {
        const e = t.getSelection();
        if (/^\*\*.*\*\*$/.test(e))
          ((this.lastExecutedCommand = "editor:toggle-bold"),
            (this.lastExecutedCommandName = "Bold"),
            (i = !0));
        else if (/^\*.*\*$/.test(e) || /^_.*_$/.test(e))
          ((this.lastExecutedCommand = "editor:toggle-italics"),
            (this.lastExecutedCommandName = "Italic"),
            (i = !0));
        else if (/^~~.*~~$/.test(e))
          ((this.lastExecutedCommand = "editor:toggle-strikethrough"),
            (this.lastExecutedCommandName = "Strikethrough"),
            (i = !0));
        else if (/^==.*==$/.test(e))
          ((this.lastExecutedCommand = "editor:toggle-highlight"),
            (this.lastExecutedCommandName = "Highlight"),
            (i = !0));
        else if (/^`.*`$/.test(e))
          ((this.lastExecutedCommand = "editor:toggle-code"),
            (this.lastExecutedCommandName = "Code"),
            (i = !0));
        else if (/^<font color=".*">.*<\/font>$/.test(e))
          ((this.lastExecutedCommand = "toolbar:change-font-color"),
            (this.lastExecutedCommandName = "Font Color"),
            (i = !0));
        else if (/^<mark style="background:.*">.*<\/mark>$/.test(e))
          ((this.lastExecutedCommand = "toolbar:change-background-color"),
            (this.lastExecutedCommandName = "Background Color"),
            (i = !0));
        else if (/^<u>([^<]+)<\/u>$/.test(e))
          ((this.lastExecutedCommand = "editor:toggle-underline"),
            (this.lastExecutedCommandName = "Underline"),
            (i = !0));
        else if (/^<center>([^<]+)<\/center>$/.test(e))
          ((this.lastExecutedCommand = "toolbar:center"),
            (this.lastExecutedCommandName = "Center"),
            (i = !0));
        else if (/^<p align="left">(.*?)<\/p>$/.test(e))
          ((this.lastExecutedCommand = "toolbar:left"),
            (this.lastExecutedCommandName = "Left Align"),
            (i = !0));
        else if (/^<p align="right">(.*?)<\/p>$/.test(e))
          ((this.lastExecutedCommand = "toolbar:right"),
            (this.lastExecutedCommandName = "Right Align"),
            (i = !0));
        else if (/^<p align="justify">(.*?)<\/p>$/.test(e))
          ((this.lastExecutedCommand = "toolbar:justify"),
            (this.lastExecutedCommandName = "Justify"),
            (i = !0));
        else if (/^<sup>(.*?)<\/sup>$/.test(e))
          ((this.lastExecutedCommand = "toolbar:superscript"),
            (this.lastExecutedCommandName = "Superscript"),
            (i = !0));
        else if (/^<sub>(.*?)<\/sub>$/.test(e))
          ((this.lastExecutedCommand = "toolbar:subscript"),
            (this.lastExecutedCommandName = "Subscript"),
            (i = !0));
        else if (
          /^> \[!(note|tip|warning|danger|info|success|question|quote)\]/i.test(
            e,
          )
        ) {
          const t = e.match(
            /^> \[!(note|tip|warning|danger|info|success|question|quote)\]/i,
          );
          t &&
            ((this.lastExecutedCommand = "editor:insert-callout"),
            (this.lastExecutedCommandName = "Callout-" + t[1].toLowerCase()),
            (i = !0),
            (o = t[1].toLowerCase()));
        } else
          /^# /.test(e)
            ? ((this.lastExecutedCommand = "editor:set-heading-1"),
              (this.lastExecutedCommandName = "Heading 1"),
              (i = !0))
            : /^## /.test(e)
              ? ((this.lastExecutedCommand = "editor:set-heading-2"),
                (this.lastExecutedCommandName = "Heading 2"),
                (i = !0))
              : /^### /.test(e)
                ? ((this.lastExecutedCommand = "editor:set-heading-3"),
                  (this.lastExecutedCommandName = "Heading 3"),
                  (i = !0))
                : /^#### /.test(e)
                  ? ((this.lastExecutedCommand = "editor:set-heading-4"),
                    (this.lastExecutedCommandName = "Heading 4"),
                    (i = !0))
                  : /^##### /.test(e)
                    ? ((this.lastExecutedCommand = "editor:set-heading-5"),
                      (this.lastExecutedCommandName = "Heading 5"),
                      (i = !0))
                    : /^###### /.test(e) &&
                      ((this.lastExecutedCommand = "editor:set-heading-6"),
                      (this.lastExecutedCommandName = "Heading 6"),
                      (i = !0));
      } else {
        const e = t.getCursor(),
          o = t.getLine(e.line),
          n = e.ch,
          s = [],
          r = /<u>([^<]+)<\/u>/g;
        let a;
        for (; null !== (a = r.exec(o)); ) {
          const e = a.index,
            t = a.index + a[0].length;
          n > e &&
            n < t &&
            s.push({
              command: "toolbar:toggle-underline",
              name: "Underline",
              distance: Math.min(n - e, t - n),
            });
        }
        const l = /<center>([^<]+)<\/center>/g;
        for (; null !== (a = l.exec(o)); ) {
          const e = a.index,
            t = a.index + a[0].length;
          n > e &&
            n < t &&
            s.push({
              command: "toolbar:center",
              name: "Center",
              distance: Math.min(n - e, t - n),
            });
        }
        const c = /<p align="left">([^<]+)<\/p>/g;
        for (; null !== (a = c.exec(o)); ) {
          const e = a.index,
            t = a.index + a[0].length;
          n > e &&
            n < t &&
            s.push({
              command: "toolbar:left",
              name: "Left Align",
              distance: Math.min(n - e, t - n),
            });
        }
        const d = /<p align="right">([^<]+)<\/p>/g;
        for (; null !== (a = d.exec(o)); ) {
          const e = a.index,
            t = a.index + a[0].length;
          n > e &&
            n < t &&
            s.push({
              command: "toolbar:right",
              name: "Right Align",
              distance: Math.min(n - e, t - n),
            });
        }
        const h = /<p align="justify">([^<]+)<\/p>/g;
        for (; null !== (a = h.exec(o)); ) {
          const e = a.index,
            t = a.index + a[0].length;
          n > e &&
            n < t &&
            s.push({
              command: "toolbar:justify",
              name: "Justify",
              distance: Math.min(n - e, t - n),
            });
        }
        const u = /<sup>([^<]+)<\/sup>/g;
        for (; null !== (a = u.exec(o)); ) {
          const e = a.index,
            t = a.index + a[0].length;
          n > e &&
            n < t &&
            s.push({
              command: "toolbar:superscript",
              name: "Superscript",
              distance: Math.min(n - e, t - n),
            });
        }
        const p = /<sub>([^<]+)<\/sub>/g;
        for (; null !== (a = p.exec(o)); ) {
          const e = a.index,
            t = a.index + a[0].length;
          n > e &&
            n < t &&
            s.push({
              command: "toolbar:subscript",
              name: "Subscript",
              distance: Math.min(n - e, t - n),
            });
        }
        const m = /\*\*([^*]+)\*\*/g;
        for (; null !== (a = m.exec(o)); ) {
          const e = a.index,
            t = a.index + a[0].length;
          n > e &&
            n < t &&
            s.push({
              command: "editor:toggle-bold",
              name: "Bold",
              distance: Math.min(n - e, t - n),
            });
        }
        const g = /~~([^~]+)~~/g;
        for (; null !== (a = g.exec(o)); ) {
          const e = a.index,
            t = a.index + a[0].length;
          n > e &&
            n < t &&
            s.push({
              command: "editor:toggle-strikethrough",
              name: "Strikethrough",
              distance: Math.min(n - e, t - n),
            });
        }
        const f = /==([^=]+)==/g;
        for (; null !== (a = f.exec(o)); ) {
          const e = a.index,
            t = a.index + a[0].length;
          n > e &&
            n < t &&
            s.push({
              command: "editor:toggle-highlight",
              name: "Highlight",
              distance: Math.min(n - e, t - n),
            });
        }
        const b = /`([^`]+)`/g;
        for (; null !== (a = b.exec(o)); ) {
          const e = a.index,
            t = a.index + a[0].length;
          n > e &&
            n < t &&
            s.push({
              command: "editor:toggle-code",
              name: "Code",
              distance: Math.min(n - e, t - n),
            });
        }
        const y = /<font color="([^"]+)">([^<]+)<\/font>/g;
        for (; null !== (a = y.exec(o)); ) {
          const e = a.index,
            t = a.index + a[0].length;
          n > e &&
            n < t &&
            s.push({
              command: "toolbar:change-font-color",
              name: "Font Color",
              distance: Math.min(n - e, t - n),
            });
        }
        const w = /<span style="background:([^"]+)">([^<]+)<\/span>/g;
        for (; null !== (a = w.exec(o)); ) {
          const e = a.index,
            t = a.index + a[0].length;
          n > e &&
            n < t &&
            s.push({
              command: "toolbar:change-background-color",
              name: "Background Color",
              distance: Math.min(n - e, t - n),
            });
        }
        if (s.length > 0) {
          s.sort((e, t) => e.distance - t.distance);
          const e = s[0];
          ((this.lastExecutedCommand = e.command),
            (this.lastExecutedCommandName = e.name),
            (i = !0));
        }
        if (!i) {
          const e = /(\*|_)([^*_]+)(\*|_)/g;
          for (; null !== (a = e.exec(o)); )
            ((this.lastExecutedCommand = "editor:toggle-italics"),
              (this.lastExecutedCommandName = "Italic"),
              (i = !0));
        }
        i ||
          (/^# /.test(o) && n > 0
            ? ((this.lastExecutedCommand = "editor:set-heading-1"),
              (this.lastExecutedCommandName = "Heading 1"),
              (i = !0))
            : /^## /.test(o) && n > 1
              ? ((this.lastExecutedCommand = "editor:set-heading-2"),
                (this.lastExecutedCommandName = "Heading 2"),
                (i = !0))
              : /^### /.test(o) && n > 2
                ? ((this.lastExecutedCommand = "editor:set-heading-3"),
                  (this.lastExecutedCommandName = "Heading 3"),
                  (i = !0))
                : /^#### /.test(o) && n > 3
                  ? ((this.lastExecutedCommand = "editor:set-heading-4"),
                    (this.lastExecutedCommandName = "Heading 4"),
                    (i = !0))
                  : /^##### /.test(o) && n > 4
                    ? ((this.lastExecutedCommand = "editor:set-heading-5"),
                      (this.lastExecutedCommandName = "Heading 5"),
                      (i = !0))
                    : /^###### /.test(o) &&
                      n > 5 &&
                      ((this.lastExecutedCommand = "editor:set-heading-6"),
                      (this.lastExecutedCommandName = "Heading 6"),
                      (i = !0)));
      }
    i || this.lastExecutedCommand
      ? ((this.formatBrushActive = !this.formatBrushActive),
        this.formatBrushActive
          ? ($c.body.classList.add("format-brush-cursor"),
            (this.EN_FontColor_Format_Brush = !1),
            (this.EN_BG_Format_Brush = !1),
            (this.EN_Text_Format_Brush = !1),
            (this.lastCalloutType = o),
            this.formatBrushNotice && this.formatBrushNotice.hide(),
            (this.formatBrushNotice = new e.Notice(
              Xr("Format brush ON! Select text to apply【") +
                this.lastExecutedCommandName +
                Xr("】format"),
              0,
            )))
          : ($c.body.classList.remove("format-brush-cursor"),
            this.formatBrushNotice &&
              (this.formatBrushNotice.hide(), (this.formatBrushNotice = null))))
      : new e.Notice(
          Xr(
            "Please execute a format command or select format text first, then enable the format brush",
          ),
        );
  }
  applyCalloutFormat(e, t, i) {
    const o = `> [!${i}]\n> ${t
      .replace(
        /^> \[!(note|tip|warning|danger|info|success|question|quote)\] ?/i,
        "",
      )
      .trim()
      .split("\n")
      .map((e, t) => e.replace(/^\s*>\s*/, ""))
      .join("\n> ")}`;
    e.replaceSelection(o);
  }
  applyFormatBrush(t) {
    if (!this.lastExecutedCommand || !this.formatBrushActive) return;
    const i = this.app.commands.commands[this.lastExecutedCommand];
    (i && i.callback && i.callback(),
      i &&
        i.editorCallback &&
        i.editorCallback(
          t,
          this.app.workspace.getActiveViewOfType(e.MarkdownView),
        ));
  }
  quiteAllFormatBrushes() {
    ((this.EN_FontColor_Format_Brush = !1),
      (this.EN_BG_Format_Brush = !1),
      (this.EN_Text_Format_Brush = !1),
      $c.body.classList.remove("format-brush-cursor"),
      this.formatBrushActive &&
        ((this.formatBrushActive = !1),
        this.formatBrushNotice &&
          (this.formatBrushNotice.hide(), (this.formatBrushNotice = null))),
      this.Temp_Notice && (this.Temp_Notice.hide(), (this.Temp_Notice = null)));
  }
  getCommandsManager() {
    return this.commandsManager;
  }
  reloadCustomCommands() {
    this.commandsManager.reloadCustomCommands();
  }
  init_evt(t, i) {
    this.resetFormatBrushStates();
    const o = e.debounce(() => {
      this.handleTextSelection();
    }, 100);
    (this.registerDomEvent(t, "mousedown", (e) => {
      if (!this.isView() || !this.commandsManager.getActiveEditor()) return;
      const i = Date.now();
      (1 === e.button &&
        this.registerDomEvent(t, "mouseup", (e) => {
          Date.now() - i < 300 &&
            1 === e.button &&
            this.handleMiddleClickToolbar(e);
        }),
        this.resetFormatBrushIfActive(t, e));
    }),
      e.Platform.isMobileApp
        ? this.registerDomEvent(t, "selectionchange", () => {
            o();
          })
        : this.registerDomEvent(t, "mouseup", (e) => {
            1 !== e.button && o();
          }),
      this.registerDomEvent(t, "keyup", this.handleKeyboardSelection),
      this.registerScrollAndBlurEvents(t));
  }
  resetFormatBrushStates() {
    ((this.EN_FontColor_Format_Brush = !1),
      (this.EN_BG_Format_Brush = !1),
      (this.EN_Text_Format_Brush = !1),
      (this.formatBrushActive = !1));
  }
  getCachedToolbar(e) {
    const t = this.toolbarCache.get(e);
    return t && t.isConnected ? t : (t && this.toolbarCache.delete(e), null);
  }
  setCachedToolbar(e, t) {
    this.toolbarCache.set(e, t);
  }
  getCachedPopover(e) {
    const t = this.popoverCache.get(e);
    return t && t.isConnected ? t : (t && this.popoverCache.delete(e), null);
  }
  setCachedPopover(e, t) {
    this.popoverCache.set(e, t);
  }
  clearToolbarCache(e) {
    e
      ? (this.toolbarCache.delete(e), this.popoverCache.delete(e))
      : (this.toolbarCache.clear(), this.popoverCache.clear());
  }
  isTopToolbarActive() {
    return (
      !!this.settings.enableTopToolbar ||
      (!this.settings.enableFollowingToolbar &&
        !this.settings.enableFixedToolbar &&
        "top" === this.positionStyle)
    );
  }
  isFollowingToolbarActive() {
    return (
      !!this.settings.enableFollowingToolbar ||
      (!this.settings.enableTopToolbar &&
        !this.settings.enableFixedToolbar &&
        "following" === this.positionStyle)
    );
  }
  handleMiddleClickToolbar(e) {
    const t = this.commandsManager.getActiveEditor();
    this.isFollowingToolbarActive() &&
      t?.hasFocus() &&
      this.showFollowingToolbar(t);
  }
  resetFormatBrushIfActive(e, t) {
    if (2 === t.button && this.isFormatBrushActive()) {
      const t = (i) => {
        (i.preventDefault(),
          i.stopPropagation(),
          e.removeEventListener("contextmenu", t, { capture: !0 }));
      };
      (e.addEventListener("contextmenu", t, { capture: !0 }), wa(this));
    }
  }
  isFormatBrushActive() {
    return (
      this.EN_FontColor_Format_Brush ||
      this.EN_BG_Format_Brush ||
      this.EN_Text_Format_Brush ||
      this.formatBrushActive
    );
  }
  registerScrollAndBlurEvents(e) {
    const t = this.throttle(() => {
      this.isFollowingToolbarActive() && this.hideToolbarIfNotSelected();
    }, 200);
    (this.registerDomEvent($c, "wheel", t),
      this.registerDomEvent(e, "blur", () => {
        this.hideToolbarIfNotSelected();
      }));
  }
  hideToolbarIfNotSelected() {
    const e = ua(this.app, this, "following");
    e && this.isFollowingToolbarActive() && (e.style.visibility = "hidden");
  }
  handleTextSelection() {
    if (!this.isView()) return;
    const e = this.commandsManager.getActiveEditor();
    e?.hasFocus() &&
      (e.somethingSelected()
        ? this.handleSelectedText(e)
        : this.hideToolbarIfNotSelected());
  }
  handleSelectedText(e) {
    this.EN_FontColor_Format_Brush
      ? _r(this.settings.cMenuFontColor, e)
      : this.EN_BG_Format_Brush
        ? zr(this.settings.cMenuBackgroundColor, e)
        : this.EN_Text_Format_Brush
          ? va(0, e)
          : this.formatBrushActive && this.lastCalloutType
            ? this.applyCalloutFormat(e, e.getSelection(), this.lastCalloutType)
            : this.formatBrushActive && this.lastExecutedCommand
              ? this.applyFormatBrush(e)
              : this.isFollowingToolbarActive() && this.showFollowingToolbar(e);
  }
  throttle(e, t = 100) {
    let i;
    return function (...o) {
      const n = this;
      i || (e.apply(n, o), (i = !0), setTimeout(() => (i = !1), t));
    };
  }
  showFollowingToolbar(e) {
    if (!this.isFollowingToolbarActive()) return;
    const t = ua(this.app, this, "following");
    t
      ? ((t.style.visibility = "visible"),
        t.classList.add("editingToolbarFlex"),
        t.classList.remove("editingToolbarGrid"),
        Ca(this.app, this.toolbarIconSize, this, e, !0))
      : Ca(this.app, this.toolbarIconSize, this, e, !0);
  }
  onPositionStyleChange(t) {
    const i = this.appearanceEditStyle;
    if (
      ((this.appearanceEditStyle = null),
      (this.positionStyle = t),
      (this.settings.positionStyle = t),
      this.settings.enableMultipleConfig)
    )
      switch (t) {
        case "following":
          (this.settings.followingCommands &&
            0 !== this.settings.followingCommands.length) ||
            ((this.settings.followingCommands = [
              ...this.settings.menuCommands,
            ]),
            this.saveSettings(),
            new e.Notice(
              Xr("Following style commands successfully initialized"),
            ));
          break;
        case "top":
          (this.settings.topCommands &&
            0 !== this.settings.topCommands.length) ||
            ((this.settings.topCommands = [...this.settings.menuCommands]),
            this.saveSettings(),
            new e.Notice(Xr("Top style commands successfully initialized")));
          break;
        case "fixed":
          (this.settings.fixedCommands &&
            0 !== this.settings.fixedCommands.length) ||
            ((this.settings.fixedCommands = [...this.settings.menuCommands]),
            this.saveSettings(),
            new e.Notice(Xr("Fixed style commands successfully initialized")));
          break;
        case "mobile":
          (this.settings.mobileCommands &&
            0 !== this.settings.mobileCommands.length) ||
            ((this.settings.mobileCommands = [...this.settings.menuCommands]),
            this.saveSettings(),
            new e.Notice(Xr("Mobile style commands successfully initialized")));
      }
    this.toolbarIconSize = this.settings.toolbarIconSize;
    const o = $c ?? document;
    (o &&
      o.documentElement &&
      (o.documentElement.style.setProperty(
        "--toolbar-background-color",
        this.settings.toolbarBackgroundColor,
      ),
      o.documentElement.style.setProperty(
        "--toolbar-icon-color",
        this.settings.toolbarIconColor,
      ),
      o.documentElement.style.setProperty(
        "--toolbar-icon-size",
        `${this.settings.toolbarIconSize}px`,
      )),
      dispatchEvent(new Event("editingToolbar-NewCommand")),
      (this.appearanceEditStyle = i));
  }
}
module.exports = ed;

/* nosourcemap */
