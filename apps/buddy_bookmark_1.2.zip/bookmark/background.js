// 监听来自content script的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getHistory') {
    // 获取最近的历史记录
    chrome.history.search({
      text: '',
      maxResults: 1000,
      startTime: Date.now() - 30 * 24 * 60 * 60 * 1000 // 最近30天
    }, (results) => {
      sendResponse(results);
    });
    return true; // 保持消息通道开启
  }
  
  if (request.action === 'getBookmarks') {
    // 获取所有书签
    chrome.bookmarks.getTree((bookmarkTree) => {
      const bookmarks = flattenBookmarks(bookmarkTree);
      sendResponse(bookmarks);
    });
    return true;
  }
  
  if (request.action === 'openUrl') {
    // 在新标签页打开URL
    chrome.tabs.create({ url: request.url });
  }
});

// 扁平化书签树结构
function flattenBookmarks(nodes) {
  const bookmarks = [];
  
  function traverse(node) {
    if (node.url) {
      bookmarks.push({
        title: node.title,
        url: node.url,
        dateAdded: node.dateAdded
      });
    }
    
    if (node.children) {
      node.children.forEach(child => traverse(child));
    }
  }
  
  nodes.forEach(node => traverse(node));
  return bookmarks;
}
