// 监听Shift+O快捷键
document.addEventListener('keydown', (e) => {
  // Shift+O (O = 79)
  if (e.shiftKey && e.key === 'O') {
    e.preventDefault();
    showSearchBox();
  }

  // ESC关闭搜索框
  if (e.key === 'Escape') {
    hideSearchBox();
  }
});

// 搜索框相关变量
let searchBox = null;
let searchInput = null;
let resultsContainer = null;
let allResults = [];
let selectedIndex = -1;
let currentTheme = 'dark';
let openInNewTab = true; // 默认新窗口打开

// 获取保存的设置
chrome.storage.sync.get(['theme', 'openInNewTab'], (result) => {
  currentTheme = result.theme || 'dark';
  openInNewTab = result.openInNewTab !== undefined ? result.openInNewTab : true;
});

// 监听设置变化，实时生效
chrome.storage.onChanged.addListener((changes, namespace) => {
  if (namespace === 'sync') {
    if (changes.theme) {
      currentTheme = changes.theme.newValue;
      // 如果搜索框已打开，立即应用新主题
      if (searchBox && document.body.contains(searchBox)) {
        searchBox.setAttribute('data-theme', currentTheme);
        const themeToggle = searchBox.querySelector('#theme-toggle');
        if (themeToggle) {
          themeToggle.textContent = currentTheme === 'dark' ? '☀️' : '🌙';
        }
      }
    }
    if (changes.openInNewTab) {
      openInNewTab = changes.openInNewTab.newValue;
    }
  }
});

// 显示搜索框
function showSearchBox() {
  if (searchBox && document.body.contains(searchBox)) {
    searchInput.focus();
    return;
  }

  createSearchBox();
  searchInput.focus();
}

// 创建搜索框
function createSearchBox() {
  searchBox = document.createElement('div');
  searchBox.id = 'quick-search-box';
  searchBox.setAttribute('data-theme', currentTheme);
  searchBox.innerHTML = `
    <div class="search-container">
      <div class="search-input-wrapper">
        <input type="text" id="quick-search-input" placeholder="搜索历史或书签..." autocomplete="off">
        <button class="theme-toggle" id="theme-toggle" title="切换主题">
          ${currentTheme === 'dark' ? '☀️' : '🌙'}
        </button>
      </div>
      <div id="search-results" class="search-results"></div>
    </div>
  `;

  document.body.appendChild(searchBox);

  searchInput = searchBox.querySelector('#quick-search-input');
  resultsContainer = searchBox.querySelector('#search-results');
  const themeToggle = searchBox.querySelector('#theme-toggle');

  // 绑定事件
  searchInput.addEventListener('input', handleSearch);
  searchInput.addEventListener('keydown', handleKeyDown);
  
  // 主题切换
  themeToggle.addEventListener('click', (e) => {
    e.stopPropagation();
    toggleTheme();
  });

  // 点击外部关闭
  searchBox.addEventListener('click', (e) => {
    if (e.target === searchBox) {
      hideSearchBox();
    }
  });

  // 初始搜索
  loadAllData();
}

// 切换主题
function toggleTheme() {
  currentTheme = currentTheme === 'dark' ? 'light' : 'dark';
  searchBox.setAttribute('data-theme', currentTheme);
  
  const themeToggle = searchBox.querySelector('#theme-toggle');
  themeToggle.textContent = currentTheme === 'dark' ? '☀️' : '🌙';
  
  // 保存设置
  chrome.storage.sync.set({ theme: currentTheme });
}

// 隐藏搜索框
function hideSearchBox() {
  if (searchBox && document.body.contains(searchBox)) {
    searchBox.remove();
    searchBox = null;
    searchInput = null;
    resultsContainer = null;
    allResults = [];
    selectedIndex = -1;
  }
}

// 加载所有数据
async function loadAllData() {
  try {
    // 获取历史记录
    const historyData = await chrome.runtime.sendMessage({ action: 'getHistory' });
    
    // 获取书签
    const bookmarksData = await chrome.runtime.sendMessage({ action: 'getBookmarks' });

    // 合并数据并去重（通过URL）
    const urlMap = new Map();
    const combinedResults = [
      ...historyData.map(item => ({ ...item, type: 'history' })),
      ...bookmarksData.map(item => ({ ...item, type: 'bookmark' }))
    ];

    // 去重逻辑：书签优先，保留书签项，如果没有书签则保留历史
    combinedResults.forEach(item => {
      if (!urlMap.has(item.url)) {
        urlMap.set(item.url, item);
      } else if (item.type === 'bookmark' && urlMap.get(item.url).type === 'history') {
        // 如果之前是历史，现在是书签，替换为书签
        urlMap.set(item.url, item);
      }
    });

    allResults = Array.from(urlMap.values());
    displayResults(allResults);
  } catch (error) {
    console.error('加载数据失败:', error);
  }
}

// 搜索处理
async function handleSearch() {
  const query = searchInput.value.toLowerCase().trim();

  if (!allResults.length) {
    await loadAllData();
  }

  let filtered = allResults;

  if (query) {
    filtered = allResults.filter(item => {
      return item.title.toLowerCase().includes(query) ||
             item.url.toLowerCase().includes(query);
    });
  }

  displayResults(filtered);
}

// 显示搜索结果
function displayResults(results) {
  selectedIndex = -1;
  
  if (results.length === 0) {
    resultsContainer.innerHTML = '<div class="no-results">未找到结果</div>';
    return;
  }

  resultsContainer.innerHTML = results.map((item, index) => `
    <div class="result-item" data-index="${index}" data-url="${escapeHtml(item.url)}">
      <div class="result-icon">${item.type === 'history' ? '🕐' : '⭐'}</div>
      <div class="result-content">
        <div class="result-title">${escapeHtml(item.title)}</div>
        <div class="result-url">${escapeHtml(item.url)}</div>
      </div>
    </div>
  `).join('');

  // 绑定点击事件
  const items = resultsContainer.querySelectorAll('.result-item');
  items.forEach(item => {
    item.addEventListener('click', () => {
      openUrl(item.dataset.url);
      hideSearchBox();
    });

    item.addEventListener('mouseenter', () => {
      items.forEach(i => i.classList.remove('selected'));
      item.classList.add('selected');
      selectedIndex = parseInt(item.dataset.index);
    });
  });

  // 显示最多50条结果
  if (results.length > 50) {
    const moreDiv = document.createElement('div');
    moreDiv.className = 'more-results';
    moreDiv.textContent = `还有 ${results.length - 50} 条结果未显示...`;
    resultsContainer.appendChild(moreDiv);
  }
}

// 键盘导航
function handleKeyDown(e) {
  const items = resultsContainer.querySelectorAll('.result-item');
  
  if (e.key === 'ArrowDown') {
    e.preventDefault();
    selectedIndex = Math.min(selectedIndex + 1, items.length - 1);
    updateSelection(items);
  } else if (e.key === 'ArrowUp') {
    e.preventDefault();
    selectedIndex = Math.max(selectedIndex - 1, 0);
    updateSelection(items);
  } else if (e.key === 'Enter' && selectedIndex >= 0) {
    e.preventDefault();
    const selected = items[selectedIndex];
    if (selected) {
      openUrl(selected.dataset.url);
      hideSearchBox();
    }
  }
}

// 打开URL
function openUrl(url) {
  if (openInNewTab) {
    chrome.runtime.sendMessage({ action: 'openUrl', url });
  } else {
    window.location.href = url;
  }
}

// 更新选中状态
function updateSelection(items) {
  items.forEach((item, index) => {
    item.classList.toggle('selected', index === selectedIndex);
  });
  
  // 滚动到可见区域
  if (selectedIndex >= 0 && items[selectedIndex]) {
    items[selectedIndex].scrollIntoView({ block: 'nearest' });
  }
}

// HTML转义
function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}
