// 加载保存的设置
document.addEventListener('DOMContentLoaded', () => {
  chrome.storage.sync.get(['theme', 'openInNewTab'], (result) => {
    const currentTheme = result.theme || 'dark';
    const newTab = result.openInNewTab !== undefined ? result.openInNewTab : true;
    
    // 更新暗色主题滑块
    const darkModeToggle = document.getElementById('dark-mode-toggle');
    darkModeToggle.checked = currentTheme === 'dark';
    
    // 更新新标签页滑块
    const newTabToggle = document.getElementById('new-tab-toggle');
    newTabToggle.checked = newTab;
    
    // 监听暗色主题切换
    darkModeToggle.addEventListener('change', (e) => {
      const theme = e.target.checked ? 'dark' : 'light';
      chrome.storage.sync.set({ theme });
    });
    
    // 监听新标签页切换
    newTabToggle.addEventListener('change', (e) => {
      chrome.storage.sync.set({ openInNewTab: e.target.checked });
    });
  });
});

