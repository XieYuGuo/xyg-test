## 图标说明

请在此目录下放置以下三个PNG格式的图标文件：

- `icon16.png` - 尺寸: 16x16 像素
- `icon48.png` - 尺寸: 48x48 像素  
- `icon128.png` - 尺寸: 128x128 像素

### 推荐图标生成工具

1. **在线工具**:
   - https://favicon.io/ (免费，支持多种格式)
   - https://icoconverter.com/ (PNG转换工具)
   - https://www.canva.com/ (设计工具)

2. **设计建议**:
   - 使用简洁的设计
   - 主题可以是放大镜、搜索图标、书本等
   - 确保在小尺寸下也能清晰识别
   - 使用单一颜色或渐变色

### 临时方案

如果您暂时没有图标，可以从以下网站免费获取:
- https://www.iconfinder.com/
- https://icons8.com/
- https://www.flaticon.com/

搜索 "search"、"bookmark" 或 "history" 相关的图标。
