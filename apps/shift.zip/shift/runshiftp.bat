@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

@REM 设置UTF-8编码，确保中文正常显示
set PYTHONIOENCODING=utf-8

@REM 获取脚本所在目录（shiftp.py 所在目录）
set "SCRIPT_DIR=%~dp0"

@REM 不切换目录，保持在调用 runshiftp.bat 时的工作目录
@REM 这样 Python 脚本中的 os.getcwd() 才能获取到调用时的目录

@REM 调用 shiftp.py，传递所有参数
python "%SCRIPT_DIR%..\shift\shiftp.py" %*

@REM 检查执行结果
if %errorlevel% neq 0 (
    echo.
    echo 执行失败！
    exit /b %errorlevel%
)

exit /b 0
