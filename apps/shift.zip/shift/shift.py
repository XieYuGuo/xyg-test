import os
import sys
import time
from typing import cast
from openpyxl import Workbook
from openpyxl.worksheet.worksheet import Worksheet
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from datetime import datetime, timedelta


# ==================== 配置项 ====================
# 排班班次配置（字符串格式）
SHIFT_SCHEDULE = """
G班 2026-03-16
H班 2026-03-13
G班 2026-03-02
H班 2026-02-24
G班 2026-02-02
H班 2026-01-26
G班 2026-01-19
H班 2026-01-16
G班 2025-12-29
H班 2025-12-22
G班 2025-12-15
H班 2025-12-08
G班 2025-12-01
H班 2025-11-28
G班 2025-11-24
H班 2025-11-21
G班 2025-11-17
H班 2025-11-10
G班 2025-10-27
H班 2025-10-20
G班 2025-10-13
H班 2025-09-22
G班 2025-09-15
H班 2025-09-08
G班 2025-09-01
H班 2025-08-25
G班 2025-08-11
H班 2025-07-14
G班 2025-05-26
H班 2025-05-19
G班 2025-01-10
"""

# 班次颜色配置
SHIFT_COLORS = {
    "G班": "D9D9D9",  # G班（白班）- 灰色
    "H班": "FFC000",  # H班（夜班）- 黄橙色
}

# 默认填充颜色（非班次日期）
DEFAULT_FILL_COLOR = "D9D9D9"
# =================================================

# 2026年中国法定节假日安排
holidays_2026 = {
    datetime(2026, 1, 1): "元旦",
    datetime(2026, 1, 2): "元旦假期",
    datetime(2026, 1, 3): "元旦假期",
    datetime(2026, 2, 15): "春节假期",
    datetime(2026, 2, 16): "春节假期",
    datetime(2026, 2, 17): "春节（除夕）",
    datetime(2026, 2, 18): "春节（初一）",
    datetime(2026, 2, 19): "春节（初二）",
    datetime(2026, 2, 20): "春节（初三）",
    datetime(2026, 2, 21): "春节假期",
    datetime(2026, 2, 22): "春节假期",
    datetime(2026, 2, 23): "春节假期",
    datetime(2026, 4, 4): "清明节",
    datetime(2026, 4, 5): "清明节假期",
    datetime(2026, 4, 6): "清明节假期",
    datetime(2026, 5, 1): "劳动节",
    datetime(2026, 5, 2): "劳动节假期",
    datetime(2026, 5, 3): "劳动节假期",
    datetime(2026, 5, 4): "劳动节假期",
    datetime(2026, 5, 5): "劳动节假期",
    datetime(2026, 5, 31): "端午节",
    datetime(2026, 6, 1): "端午节假期",
    datetime(2026, 6, 2): "端午节假期",
    datetime(2026, 10, 1): "国庆节",
    datetime(2026, 10, 2): "国庆节假期",
    datetime(2026, 10, 3): "国庆节假期",
    datetime(2026, 10, 4): "国庆节假期",
    datetime(2026, 10, 5): "国庆节假期",
    datetime(2026, 10, 6): "国庆节假期",
    datetime(2026, 10, 7): "国庆节假期",
    datetime(2026, 10, 8): "国庆节假期",
}

# 调休工作日
workdays_adjustment = {
    datetime(2026, 2, 14): "春节调休上班",
    datetime(2026, 2, 24): "春节调休上班",
    datetime(2026, 4, 26): "劳动节调休上班",
    datetime(2026, 5, 9): "劳动节调休上班",
    datetime(2026, 9, 27): "国庆节调休上班",
    datetime(2026, 10, 11): "国庆节调休上班",
}

wb = Workbook()
ws = cast(Worksheet, wb.active)
ws.title = "2026年日历"

# 日期到单元格坐标的映射（用于后续填充颜色）
date_to_cell: dict[datetime, tuple[int, int]] = {}

title_font = Font(name='微软雅黑', size=16, bold=True, color='FFFFFF')
month_title_font = Font(name='微软雅黑', size=11, bold=True)
weekday_header_font = Font(name='微软雅黑', size=9, bold=True)
date_font = Font(name='微软雅黑', size=9)
holiday_font = Font(name='微软雅黑', size=8, color='C00000')

title_fill = PatternFill(start_color='2F5496', end_color='2F5496', fill_type='solid')
month_title_fill = PatternFill(start_color='FFFF00', end_color='FFFF00', fill_type='solid')
weekday_fill = PatternFill(start_color='92CDDC', end_color='92CDDC', fill_type='solid')
weekend_fill = PatternFill(start_color='92D050', end_color='92D050', fill_type='solid')
holiday_fill = PatternFill(start_color='FFFF00', end_color='FFFF00', fill_type='solid')
workday_fill = PatternFill(fill_type=None)
adjustment_fill = PatternFill(start_color='BDD7EE', end_color='BDD7EE', fill_type='solid')

center_align = Alignment(horizontal='center', vertical='center', wrap_text=True)
blue_border = Border(
    left=Side(style='thin', color='0070C0'),
    right=Side(style='thin', color='0070C0'),
    top=Side(style='thin', color='0070C0'),
    bottom=Side(style='thin', color='0070C0')
)

ws.merge_cells('A1:W1')
ws['A1'] = "2026年公司日历"
ws['A1'].font = title_font
ws['A1'].fill = title_fill
ws['A1'].alignment = center_align

for col in range(1, 25):
    ws.column_dimensions[get_column_letter(col)].width = 11

def get_date_type_and_name(date: datetime) -> tuple[str, str]:
    if date in holidays_2026:
        return "节假日", holidays_2026[date]
    elif date in workdays_adjustment:
        return "调休工作日", workdays_adjustment[date]
    elif date.weekday() >= 5:
        return "周末", ""
    else:
        return "工作日", ""

def draw_month_calendar(start_row: int, start_col: int, year: int, month: int) -> int:
    month_names = ["", "一月", "二月", "三月", "四月", "五月", "六月",
                   "七月", "八月", "九月", "十月", "十一月", "十二月"]
    
    ws.merge_cells(start_row=start_row, start_column=start_col, 
                   end_row=start_row, end_column=start_col + 6)
    month_cell = ws.cell(row=start_row, column=start_col)
    month_cell.value = f"{year}年{month_names[month]}"  # pyright: ignore[reportAttributeAccessIssue]
    month_cell.font = month_title_font
    month_cell.fill = month_title_fill
    month_cell.alignment = center_align
    month_cell.border = blue_border
    
    for col in range(start_col, start_col + 7):
        ws.cell(row=start_row, column=col).border = blue_border
    
    weekdays = ["日", "一", "二", "三", "四", "五", "六"]
    header_row = start_row + 1
    for i, day in enumerate(weekdays):
        cell = ws.cell(row=header_row, column=start_col + i, value=day)
        cell.font = weekday_header_font
        cell.fill = weekday_fill
        cell.alignment = center_align
        cell.border = blue_border
    
    first_day = datetime(year, month, 1)
    if month == 12:
        next_month = datetime(year + 1, 1, 1)
    else:
        next_month = datetime(year, month + 1, 1)
    
    first_weekday = first_day.weekday()
    start_offset = (first_weekday + 1) % 7
    
    current_row = header_row + 1
    current_col = start_col + start_offset
    current_date = first_day
    
    while current_date < next_month:
        date_type, holiday_name = get_date_type_and_name(current_date)
        day = current_date.day
        
        cell = ws.cell(row=current_row, column=current_col)
        
        if holiday_name:
            cell.value = f"{day}\n{holiday_name}"  # pyright: ignore[reportAttributeAccessIssue]
            cell.font = holiday_font
        else:
            cell.value = day  # pyright: ignore[reportAttributeAccessIssue]
            cell.font = date_font
        
        cell.alignment = center_align
        cell.border = blue_border
        
        # 记录日期到单元格的映射
        date_to_cell[current_date] = (current_row, current_col)
        
        if date_type == "节假日":
            cell.fill = holiday_fill
        elif date_type == "周末":
            cell.fill = weekend_fill
        elif date_type == "调休工作日":
            cell.fill = adjustment_fill
            cell.font = Font(name='微软雅黑', size=9, color='0000FF', bold=True)
        else:
            cell.fill = workday_fill
        
        current_col += 1
        if current_col > start_col + 6:
            current_col = start_col
            current_row += 1
        
        current_date += timedelta(days=1)
    
    for row in range(start_row, start_row + 8):
        for col in range(start_col, start_col + 7):
            if ws.cell(row=row, column=col).value is None and row < start_row + 8:
                ws.cell(row=row, column=col).border = blue_border
    
    for row in range(start_row, start_row + 8):
        ws.row_dimensions[row].height = 28
    
    return start_row + 8

month_layout = [
    (3, 1), (3, 9), (3, 17),
    (12, 1), (12, 9), (12, 17),
    (21, 1), (21, 9), (21, 17),
    (30, 1), (30, 9), (30, 17),
]

months = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
for idx, month in enumerate(months):
    start_row, start_col = month_layout[idx]
    _ = draw_month_calendar(start_row, start_col, 2026, month)

legend_row = 41
ws.merge_cells(start_row=legend_row, start_column=1, end_row=legend_row, end_column=7)
ws.cell(row=legend_row, column=1, value="图例说明：").font = Font(name='微软雅黑', size=11, bold=True)

legend_items = [
    ("工作日", workday_fill, "周末", weekend_fill),
    ("节假日", holiday_fill, "调休", adjustment_fill)
]

legend_row += 1
col = 1
for name, fill, name2, fill2 in legend_items:
    cell = ws.cell(row=legend_row, column=col, value=name)
    cell.fill = fill
    cell.alignment = center_align
    cell.border = blue_border
    col += 1
    if name2:
        cell = ws.cell(row=legend_row, column=col, value=name2)
        cell.fill = fill2
        cell.alignment = center_align
        cell.border = blue_border
        col += 1

stats_row = legend_row + 2
ws.merge_cells(start_row=stats_row, start_column=1, end_row=stats_row, end_column=7)
ws.cell(row=stats_row, column=1, value="统计信息：").font = Font(name='微软雅黑', size=11, bold=True)

total_days = (datetime(2026, 12, 31) - datetime(2026, 1, 1)).days + 1
weekend_count = 0
holiday_count = len(holidays_2026)

for i in range(total_days):
    date = datetime(2026, 1, 1) + timedelta(days=i)
    if date.weekday() >= 5 and date not in holidays_2026:
        weekend_count += 1

workday_count = total_days - weekend_count - holiday_count + len(workdays_adjustment)

stats_info = [
    f"全年总天数：{total_days}天",
    f"工作日天数：{workday_count}天",
    f"周末天数：{weekend_count}天",
    f"法定节假日：{holiday_count}天",
    f"调休工作日：{len(workdays_adjustment)}天"
]


stats_row += 1
for idx, info in enumerate(stats_info):
    _ = ws.cell(row=stats_row, column=1 + idx, value=info)


def parse_shift_schedule(schedule_str: str) -> list[tuple[datetime, str]]:
    """
    解析排班班次配置字符串
    
    Args:
        schedule_str: 排班班次配置字符串
        
    Returns:
        [(日期, 班次类型)] 列表，按日期排序
    """
    shifts: list[tuple[datetime, str]] = []
    for line in schedule_str.strip().split('\n'):
        line = line.strip()
        if not line:
            continue
        parts = line.split()
        if len(parts) >= 2:
            shift_type = parts[0]  # G班 或 H班
            date_str = parts[1]    # 2026-03-16
            try:
                date = datetime.strptime(date_str, "%Y-%m-%d")
                shifts.append((date, shift_type))
            except ValueError:
                print(f"警告: 无法解析日期 '{date_str}'")
    # 按日期排序
    shifts.sort(key=lambda x: x[0])
    return shifts


def fill_shift_colors() -> None:
    """
    根据排班班次配置填充日期单元格背景色
    """
    # 解析排班班次配置
    shifts = parse_shift_schedule(SHIFT_SCHEDULE)
    
    if not shifts:
        print("警告: 未找到有效的排班班次配置")
        return
    
    # 构建日期到班次类型的映射
    date_to_shift: dict[datetime, str] = {date: shift_type for date, shift_type in shifts}
    
    # 排序后的班次日期列表
    sorted_shift_dates = [date for date, _ in shifts]
    
    # 最后一个班次的日期
    last_shift_date = sorted_shift_dates[-1]
    
    # 遍历全年所有日期，确定填充颜色
    start_date = datetime(2026, 1, 1)
    end_date = datetime(2026, 12, 31)
    current_date = start_date
    
    shift_index = 0  # 下一个班次日期的索引
    
    while current_date <= end_date:
        date_type, _ = get_date_type_and_name(current_date)
        
        # 周末和节假日不填充排班颜色（保留原有颜色）
        if date_type in ["节假日", "周末"]:
            current_date += timedelta(days=1)
            continue
        
        # 更新班次索引：找到下一个班次日期
        while shift_index < len(sorted_shift_dates) and sorted_shift_dates[shift_index] < current_date:
            shift_index += 1
        
        # 确定填充颜色
        should_fill = False
        color = DEFAULT_FILL_COLOR
        
        if current_date in date_to_shift:
            # 当前日期是班次日期
            shift_type = date_to_shift[current_date]
            color = SHIFT_COLORS.get(shift_type, DEFAULT_FILL_COLOR)
            should_fill = True
        elif shift_index == 0:
            # 第一个班次之前
            should_fill = True
        elif current_date > last_shift_date:
            # 最后一个班次之后，不做任何颜色填充
            should_fill = False
        elif shift_index < len(sorted_shift_dates):
            # 在两个班次之间，使用上一个班次的颜色
            prev_shift_type = date_to_shift[sorted_shift_dates[shift_index - 1]]
            color = SHIFT_COLORS.get(prev_shift_type, DEFAULT_FILL_COLOR)
            should_fill = True
        
        # 填充颜色
        if should_fill and current_date in date_to_cell:
            row, col = date_to_cell[current_date]
            cell = ws.cell(row=row, column=col)
            cell.fill = PatternFill(start_color=color, end_color=color, fill_type='solid')
        
        current_date += timedelta(days=1)


def get_output_path() -> str:
    """
    根据命令行参数确定输出路径
    
    Returns:
        输出文件路径
    """
    call_dir = os.getcwd()
    
    if len(sys.argv) > 1:
        # 有命令行参数
        input_path = sys.argv[1]
        
        # 如果是相对路径，基于 call_dir 解析为绝对路径
        if not os.path.isabs(input_path):
            input_path = os.path.join(call_dir, input_path)
        
        # 判断是目录还是文件
        # 如果路径以分隔符结尾，或者路径确实存在且是目录，则认为是目录
        if input_path.endswith(os.sep) or (os.path.exists(input_path) and os.path.isdir(input_path)):
            # 是目录，生成默认文件名
            now = datetime.now()
            timestamp_ms = int(time.time() * 1000)
            filename = f"shift_{now.strftime('%Y%m%d')}_{timestamp_ms}.xlsx"
            return os.path.join(input_path, filename)
        
        # 判断传入的是文件路径还是目录路径
        ext = os.path.splitext(input_path)[1].lower()
        if ext in ['.xlsx', '.xls']:
            # 有Excel扩展名，认为是文件路径
            return input_path
        elif ext:
            # 有扩展名但不是Excel文件扩展名，报错
            print(f"错误：只允许输出 Excel 文件（.xlsx 或 .xls），当前扩展名为 '{ext}'")
            sys.exit(1)
        else:
            # 没有扩展名，认为是目录路径，生成默认文件名
            now = datetime.now()
            timestamp_ms = int(time.time() * 1000)
            filename = f"shift_{now.strftime('%Y%m%d')}_{timestamp_ms}.xlsx"
            return os.path.join(input_path, filename)
    else:
        # 没有参数，使用执行 bat 脚本的路径（os.getcwd()）
        now = datetime.now()
        timestamp_ms = int(time.time() * 1000)
        filename = f"shift_{now.strftime('%Y%m%d')}_{timestamp_ms}.xlsx"
        return os.path.join(call_dir, filename)


def main():
    """主函数"""
    # 填充排班班次颜色
    fill_shift_colors()
    
    # 获取输出路径
    output_path = get_output_path()
    
    # 确保输出目录存在
    output_dir = os.path.dirname(output_path)
    if output_dir and not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    # 保存文件
    wb.save(output_path)
    print(f"整合视图日历文件已生成: {output_path}")


if __name__ == '__main__':
    main()
else:
    # 作为模块导入时也生成日历（保持向后兼容）
    fill_shift_colors()
    output_path = os.path.join(os.getcwd(), "2026年公司日历_整合视图.xlsx")
    wb.save(output_path)
    print(f"整合视图日历文件已生成: {output_path}")
