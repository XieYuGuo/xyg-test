# pyright: reportAny=false, reportUnknownMemberType=false, reportUnknownArgumentType=false, reportUnknownVariableType=false, reportMissingTypeStubs=false
import os
import re
import sys
import json
import urllib.request
from datetime import datetime, timedelta, date
from collections import defaultdict
from typing import cast
from openpyxl import Workbook
from openpyxl.worksheet.worksheet import Worksheet
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter


# ==================== 配置项 ====================
# 排班班次配置（支持两种格式）
# 格式一示例（连续记录格式）：
# SHIFT_SCHEDULE = """
# 2026: [0105-0109]A[0110]B+[0113-0117]B[0120-0124]A
# """
# 格式二示例（班次+日期格式）：
SHIFT_SCHEDULE = """
A班 2026-03-16
B班 2026-03-13
A班 2026-03-02
B班 2026-02-24
A班 2026-02-02
B班 2026-01-26
A班 2026-01-19
B班 2026-01-16
A班 2025-12-29
B班 2025-12-22
A班 2025-12-15
B班 2025-12-08
A班 2025-12-01
B班 2025-11-28
A班 2025-11-24
B班 2025-11-21
A班 2025-11-17
B班 2025-11-10
A班 2025-10-27
B班 2025-10-20
A班 2025-10-13
B班 2025-09-22
A班 2025-09-15
B班 2025-09-08
A班 2025-09-01
B班 2025-08-25
A班 2025-08-11
B班 2025-07-14
A班 2025-05-26
B班 2025-05-19
A班 2025-01-10
A+班 2026-03-14
A+班 2026-01-25
A+班 2026-01-17
B+班 2025-12-21
B+班 2025-12-07
A+班 2025-11-22
B+班 2025-11-15
B+班 2025-11-09
B+班 2025-11-01
B+班 2025-10-25
B+班 2025-10-19
B+班 2025-10-12
B+班 2025-09-21
B+班 2025-09-07
A+班 2025-08-31
B+班 2025-08-24
B+班 2025-08-10
B+班 2025-07-26
A+班 2025-06-28
B+班 2025-06-15
B+班 2025-06-14
"""

# 班次颜色配置（A班=B班=G班颜色, B班=H班颜色）
SHIFT_COLORS = {
    "A班": "D9D9D9",  # A班（白班）- 灰色，对应 shift.py 的 G班
    "B班": "FFC000",  # B班（夜班）- 黄橙色，对应 shift.py 的 H班
    "A+班": "B1A0C7",  # A+班（加白班）- 紫色
    "B+班": "B1A0C7",  # B+班（加夜班）- 紫色
}

# 默认填充颜色（非班次日期）
DEFAULT_FILL_COLOR = "D9D9D9"
# =================================================

# 尝试导入 chinese_calendar 库
_chinese_calendar = None
try:
    import chinese_calendar as _chinese_calendar
except ImportError:
    pass

# 节假日数据缓存
_HOLIDAYS_CACHE: dict[int, dict[datetime, str]] = {}
_WORKDAYS_CACHE: dict[int, dict[datetime, str]] = {}

# API 配置
HOLIDAY_API_URL = "https://holiday.ailcc.com/api/holiday/year/{}"

# 节假日名称中英文映射
HOLIDAY_NAME_MAP = {
    "New Year's Day": "元旦",
    "Spring Festival": "春节",
    "Tomb-sweeping Day": "清明节",
    "Labour Day": "劳动节",
    "Dragon Boat Festival": "端午节",
    "Mid-autumn Festival": "中秋节",
    "National Day": "国庆节",
}


def _fetch_holiday_from_api(year: int) -> tuple[dict[datetime, str], dict[datetime, str]]:
    """
    从 API 获取指定年份的节假日数据
    
    Args:
        year: 年份
        
    Returns:
        (节假日字典, 调休工作日字典)
    """
    holidays: dict[datetime, str] = {}
    workdays: dict[datetime, str] = {}
    
    try:
        url = HOLIDAY_API_URL.format(year)
        with urllib.request.urlopen(url, timeout=10) as response:
            data = json.loads(response.read().decode('utf-8'))
        
        if data.get('code') == 0 and 'holiday' in data:
            for _, info in data['holiday'].items():
                dt = datetime.strptime(info['date'], '%Y-%m-%d')
                name = info.get('name', '节假日')
                
                # 判断是节假日还是调休工作日
                # API 中 holiday=true 表示是休息日（节假日或周末）
                # 需要额外判断是否为调休工作日
                if info.get('holiday', False):
                    # 是节假日（包括周末的法定节假日）
                    holidays[dt] = name
                else:
                    # 是调休工作日（周末上班）
                    workdays[dt] = f"{name}调休上班" if "调休" not in name else name
    except Exception as e:
        print(f"警告：从 API 获取节假日数据失败 - {e}")
    
    return holidays, workdays


def _fetch_holiday_from_library(year: int) -> tuple[dict[datetime, str], dict[datetime, str]]:
    """
    使用 chinese_calendar 库获取指定年份的节假日数据
    
    Args:
        year: 年份
        
    Returns:
        (节假日字典, 调休工作日字典)
    """
    holidays: dict[datetime, str] = {}
    workdays: dict[datetime, str] = {}
    
    if _chinese_calendar is None:
        return holidays, workdays
    
    try:
        start_date = date(year, 1, 1)
        end_date = date(year, 12, 31)
        current = start_date
        
        while current <= end_date:
            dt = datetime.combine(current, datetime.min.time())
            
            # 使用 chinese_calendar 判断是否为节假日
            is_holiday_flag = _chinese_calendar.is_holiday(current)
            is_workday_flag = _chinese_calendar.is_workday(current)
            
            # 调休工作日：周末但需要上班
            if is_workday_flag and current.weekday() >= 5:
                workdays[dt] = "调休上班"
            # 节假日（包括周末的法定节假日）
            elif is_holiday_flag:
                # 尝试获取节假日名称，区分法定节假日和普通周末
                try:
                    on_holiday = _chinese_calendar.get_holiday_detail(current)
                    if on_holiday and len(on_holiday) > 1 and on_holiday[1]:
                        en_name = str(on_holiday[1])
                        # 转换为中文名称
                        cn_name = HOLIDAY_NAME_MAP.get(en_name, en_name)
                        holidays[dt] = cn_name
                    # 如果没有节假日名称，说明是普通周末，不添加到 holidays
                except Exception:
                    # 异常情况，假设是普通周末，不添加
                    pass
            
            current += timedelta(days=1)
    except Exception as e:
        print(f"警告：从 chinese_calendar 库获取数据失败 - {e}")
    
    return holidays, workdays


def get_holidays_for_year(year: int) -> dict[datetime, str]:
    """
    获取指定年份的节假日数据（优先使用缓存，其次库，最后API）
    
    Args:
        year: 年份
        
    Returns:
        节假日字典 {日期: 名称}
    """
    if year in _HOLIDAYS_CACHE:
        return _HOLIDAYS_CACHE[year]
    
    # 优先使用 chinese_calendar 库
    if _chinese_calendar is not None:
        holidays, workdays = _fetch_holiday_from_library(year)
        if holidays:
            _HOLIDAYS_CACHE[year] = holidays
            _WORKDAYS_CACHE[year] = workdays
            return holidays
    
    # 回退到 API
    holidays, workdays = _fetch_holiday_from_api(year)
    if holidays or workdays:
        _HOLIDAYS_CACHE[year] = holidays
        _WORKDAYS_CACHE[year] = workdays
    
    return holidays


def get_workdays_for_year(year: int) -> dict[datetime, str]:
    """
    获取指定年份的调休工作日数据（优先使用缓存，其次库，最后API）
    
    Args:
        year: 年份
        
    Returns:
        调休工作日字典 {日期: 名称}
    """
    if year in _WORKDAYS_CACHE:
        return _WORKDAYS_CACHE[year]
    
    # 触发数据获取
    _ = get_holidays_for_year(year)
    
    return _WORKDAYS_CACHE.get(year, {})


def is_workday(dt: datetime) -> bool:
    """
    判断某日期是否为工作日
    
    工作日定义：不是周末、不是节假日，或者是调休工作日
    
    Args:
        dt: 日期
        
    Returns:
        是否为工作日
    """
    # 优先使用 chinese_calendar 库（最准确）
    if _chinese_calendar is not None:
        try:
            return _chinese_calendar.is_workday(dt.date())
        except Exception:
            pass
    
    year = dt.year
    holidays = get_holidays_for_year(year)
    workdays = get_workdays_for_year(year)
    
    # 调休工作日（周末调休上班）
    if dt in workdays:
        return True
    
    # 节假日
    if dt in holidays:
        return False
    
    # 周末（周六=5, 周日=6）
    if dt.weekday() >= 5:
        return False
    
    return True


def detect_format(content: str) -> int:
    """
    检测班次信息的格式
    
    Args:
        content: 文件内容
        
    Returns:
        1 表示格式一（连续记录格式），2 表示格式二（班次+日期格式）
    """
    content = content.strip()
    
    # 格式一的检测：年份: 开头，包含 [] 和班次类型
    # 例如：2026: [0105-0109]A[0110]B+...
    if re.match(r'^\d{4}\s*:', content):
        return 1
    
    # 格式二的检测：班次类型 空格 日期
    # 例如：B班 2026-01-26
    lines = content.split('\n')
    for line in lines:
        line = line.strip()
        if not line:
            continue
        # 检测是否为 "班次类型 日期" 格式
        if re.match(r'^[AB][+]?\s*班\s+\d{4}[-]?\d{2}[-]?\d{2}', line):
            return 2
    
    return 0  # 未知格式


def parse_format1(content: str) -> list[tuple[datetime, str]]:
    """
    解析格式一的班次信息
    
    转换逻辑：
    - 记录第一段班次起始日期
    - 找下一个主要班次（A↔B交替），中间的加班（A+/B+）也要记录
    - 跳过中间的同类班次（如找B班时跳过A班）
    
    Args:
        content: 格式一内容，如 "2026: [0105-0109]A[0110]B+..."
        
    Returns:
        [(起始日期, 班次类型)] 列表
    """
    shifts: list[tuple[datetime, str]] = []
    
    # 按行分割，每行一个年份
    lines = content.strip().split('\n')
    
    for line in lines:
        line = line.strip()
        if not line:
            continue
            
        # 解析年份和班次数据
        match = re.match(r'^(\d{4})\s*:\s*(.+)$', line)
        if not match:
            continue
            
        year = int(match.group(1))
        schedule_str = match.group(2)
        
        # 解析班次数据
        # 匹配模式：[日期范围或单日期]班次类型
        pattern = r'\[([^\]]+)\]([AB][+]?)'
        matches = re.findall(pattern, schedule_str)
        
        # 提取所有段（日期, 班次类型）
        segments: list[tuple[datetime, str]] = []
        for date_str, shift_type in matches:
            if '-' in date_str:
                # 日期范围：0105-0109，只取起始日期
                start_str, _ = date_str.split('-')
                month = int(start_str[:2])
                day = int(start_str[2:])
            else:
                # 单日期：0110
                month = int(date_str[:2])
                day = int(date_str[2:])
            date = datetime(year, month, day)
            segments.append((date, shift_type))
        
        # 按转换逻辑处理
        if not segments:
            continue
        
        # 记录第一段
        current_shift = segments[0][1]
        current_main = current_shift[0]  # A 或 B
        shifts.append(segments[0])
        
        # 寻找下一个主要班次（A->B 或 B->A）
        for date, shift_type in segments[1:]:
            # 加班（A+/B+）直接记录
            if shift_type in ('A+', 'B+'):
                shifts.append((date, shift_type))
            else:
                # 主要班次
                main_type = shift_type[0]  # A 或 B
                if main_type != current_main:
                    # 找到了交替班次
                    shifts.append((date, shift_type))
                    current_main = main_type
    
    # 按日期倒序排序（最新的在前面）
    shifts.sort(key=lambda x: x[0], reverse=True)
    return shifts


def parse_format2(content: str) -> list[tuple[datetime, str]]:
    """
    解析格式二的班次信息
    
    Args:
        content: 格式二内容，每行一个班次记录
        
    Returns:
        [(日期, 班次类型)] 列表，按日期倒序排序
    """
    shifts: list[tuple[datetime, str]] = []
    
    lines = content.strip().split('\n')
    for line in lines:
        line = line.strip()
        if not line:
            continue
            
        # 解析班次类型和日期
        # 支持 "A班 2026-01-26" 或 "A+班 2026-01-26" 格式
        # 同时支持 "2026-0110" 这种缺少分隔符的格式
        match = re.match(r'^([AB][+]?)\s*班\s+(\d{4})[-]?(\d{2})[-]?(\d{2})$', line)
        if match:
            shift_type = match.group(1)
            year = int(match.group(2))
            month = int(match.group(3))
            day = int(match.group(4))
            date = datetime(year, month, day)
            shifts.append((date, shift_type))
    
    # 按日期倒序排序（最新的在前面）
    shifts.sort(key=lambda x: x[0], reverse=True)
    return shifts


def format_to_format2(shifts: list[tuple[datetime, str]]) -> str:
    """
    将班次列表转换为格式二输出
    
    Args:
        shifts: [(日期, 班次类型)] 列表
        
    Returns:
        格式二的字符串
    """
    result = []
    for date, shift_type in shifts:
        date_str = date.strftime('%Y-%m-%d')
        result.append(f"{shift_type}班 {date_str}")
    return '\n'.join(result)


def format_to_format1(shifts: list[tuple[datetime, str]]) -> str:
    """
    将班次列表转换为格式一输出（计算连续工作日范围）
    
    转换逻辑：
    1. 加班（A+/B+）只覆盖起始日期
    2. 非加班班次从起始日期开始，向后覆盖连续工作日，直到遇到下一个班次记录或周末/节假日
    3. 两个班次记录之间的空隙（周末/节假日之后的工作日），由"上一个非加班班次"来填补
    
    Args:
        shifts: [(日期, 班次类型)] 列表
        
    Returns:
        格式一的字符串
    """
    if not shifts:
        return ""
    
    # 按日期正序排序
    sorted_shifts = sorted(shifts, key=lambda x: x[0])
    
    # 构建班次日期集合
    shift_dates = {date for date, _ in shifts}
    
    # 按年份分组
    year_shifts: dict[int, list[tuple[datetime, str]]] = defaultdict(list)
    for date, shift_type in sorted_shifts:
        year_shifts[date.year].append((date, shift_type))
    
    result_lines = []
    
    for year in sorted(year_shifts.keys()):
        year_data = year_shifts[year]
        year_end = datetime(year, 12, 31)
        
        # 计算每个班次的覆盖范围
        segments: list[tuple[datetime, datetime, str]] = []  # (start, end, shift_type)
        
        for i, (start_date, shift_type) in enumerate(year_data):
            is_overtime = shift_type in ('A+', 'B+')
            
            if is_overtime:
                # 加班只覆盖起始日期
                segments.append((start_date, start_date, shift_type))
            else:
                # 非加班：从起始日期向后覆盖连续工作日
                end_date = start_date
                current_date = start_date + timedelta(days=1)
                
                while current_date <= year_end:
                    # 遇到下一个班次记录，停止
                    if current_date in shift_dates:
                        break
                    # 遇到非工作日，停止
                    if not is_workday(current_date):
                        break
                    # 继续扩展
                    end_date = current_date
                    current_date += timedelta(days=1)
                
                segments.append((start_date, end_date, shift_type))
        
        # 处理空隙：两个班次之间的空隙（周末/节假日之后的工作日），由上一个非加班班次填补
        filled_segments: list[tuple[datetime, datetime, str]] = []
        last_non_overtime_shift: str | None = None
        
        for i, (start_date, end_date, shift_type) in enumerate(segments):
            filled_segments.append((start_date, end_date, shift_type))
            
            # 更新上一个非加班班次
            if shift_type not in ('A+', 'B+'):
                last_non_overtime_shift = shift_type
            
            # 检查当前段结束到下一段开始之间是否有空隙
            if i < len(segments) - 1:
                next_start = segments[i + 1][0]
                gap_start = end_date + timedelta(days=1)
                
                # 查找空隙中的连续工作日
                gap_workdays: list[datetime] = []
                current = gap_start
                
                while current < next_start:
                    if is_workday(current) and current not in shift_dates:
                        gap_workdays.append(current)
                    current += timedelta(days=1)
                
                # 如果有空隙工作日，用上一个非加班班次填补
                if gap_workdays and last_non_overtime_shift:
                    # 按连续分组
                    gap_segments = _group_consecutive_dates(gap_workdays)
                    for gap_start_date, gap_end_date in gap_segments:
                        filled_segments.append((gap_start_date, gap_end_date, last_non_overtime_shift))
        
        # 按起始日期排序并输出
        filled_segments.sort(key=lambda x: x[0])
        
        schedule_parts = []
        for seg_start, seg_end, seg_type in filled_segments:
            if seg_start == seg_end:
                date_str = f"{seg_start.month:02d}{seg_start.day:02d}"
            else:
                date_str = f"{seg_start.month:02d}{seg_start.day:02d}-{seg_end.month:02d}{seg_end.day:02d}"
            schedule_parts.append(f"[{date_str}]{seg_type}")
        
        result_lines.append(f"{year}: {''.join(schedule_parts)}")
    
    return '\n'.join(result_lines)


def _group_consecutive_dates(dates: list[datetime]) -> list[tuple[datetime, datetime]]:
    """
    将日期列表按连续日期分组
    
    Args:
        dates: 日期列表（已排序）
        
    Returns:
        [(start_date, end_date)] 列表
    """
    if not dates:
        return []
    
    dates.sort()
    result = []
    start = dates[0]
    end = dates[0]
    
    for i in range(1, len(dates)):
        if (dates[i] - end).days == 1:
            end = dates[i]
        else:
            result.append((start, end))
            start = dates[i]
            end = dates[i]
    
    result.append((start, end))
    return result


def output_year_data(year: int) -> None:
    """
    输出指定年份的完整日期数据（节假日和调休工作日）
    
    Args:
        year: 年份
    """
    holidays = get_holidays_for_year(year)
    workdays = get_workdays_for_year(year)
    
    if not holidays and not workdays:
        print(f"暂无 {year} 年的节假日数据")
        print("请检查网络连接或安装 chinese_calendar 库：pip install chinesecalendar")
        return
    
    # 显示数据来源
    source = "chinese_calendar 库" if _chinese_calendar is not None else "在线 API"
    print(f"# {year}年中国法定节假日安排（数据来源：{source}）")
    print(f"HOLIDAYS_{year} = {{")
    for dt in sorted(holidays.keys()):
        name = holidays[dt]
        print(f'    datetime({year}, {dt.month}, {dt.day}): "{name}",')
    print("}")
    
    print()
    print("# 调休工作日")
    print(f"WORKDAYS_{year} = {{")
    for dt in sorted(workdays.keys()):
        name = workdays[dt]
        print(f'    datetime({year}, {dt.month}, {dt.day}): "{name}",')
    print("}")


# ==================== 日历生成相关 ====================

# 样式定义
_title_font = Font(name='微软雅黑', size=16, bold=True, color='FFFFFF')
_month_title_font = Font(name='微软雅黑', size=11, bold=True)
_weekday_header_font = Font(name='微软雅黑', size=9, bold=True)
_date_font = Font(name='微软雅黑', size=9)
_holiday_font = Font(name='微软雅黑', size=8, color='C00000')
_overtime_font = Font(name='微软雅黑', size=8, bold=True)

_title_fill = PatternFill(start_color='2F5496', end_color='2F5496', fill_type='solid')
_month_title_fill = PatternFill(start_color='FFFF00', end_color='FFFF00', fill_type='solid')
_weekday_fill = PatternFill(start_color='92CDDC', end_color='92CDDC', fill_type='solid')
_weekend_fill = PatternFill(start_color='92D050', end_color='92D050', fill_type='solid')
_holiday_fill = PatternFill(start_color='FFFF00', end_color='FFFF00', fill_type='solid')
_workday_fill = PatternFill(fill_type=None)
_adjustment_fill = PatternFill(start_color='BDD7EE', end_color='BDD7EE', fill_type='solid')
_overtime_fill = PatternFill(start_color='B1A0C7', end_color='B1A0C7', fill_type='solid')

_center_align = Alignment(horizontal='center', vertical='center', wrap_text=True)
_blue_border = Border(
    left=Side(style='thin', color='0070C0'),
    right=Side(style='thin', color='0070C0'),
    top=Side(style='thin', color='0070C0'),
    bottom=Side(style='thin', color='0070C0')
)


def _get_date_type_and_name(dt: datetime, holidays: dict[datetime, str], workdays: dict[datetime, str]) -> tuple[str, str]:
    """获取日期类型和节假日名称"""
    if dt in holidays:
        return "节假日", holidays[dt]
    elif dt in workdays:
        return "调休工作日", workdays[dt]
    elif dt.weekday() >= 5:
        return "周末", ""
    else:
        return "工作日", ""


def _draw_month_calendar(
    ws: Worksheet,
    start_row: int,
    start_col: int,
    year: int,
    month: int,
    holidays: dict[datetime, str],
    workdays: dict[datetime, str],
    date_to_cell: dict[datetime, tuple[int, int]]
) -> int:
    """绘制单月日历"""
    month_names = ["", "一月", "二月", "三月", "四月", "五月", "六月",
                   "七月", "八月", "九月", "十月", "十一月", "十二月"]
    
    # 月份标题
    ws.merge_cells(start_row=start_row, start_column=start_col,
                   end_row=start_row, end_column=start_col + 6)
    month_cell = ws.cell(row=start_row, column=start_col)
    month_cell.value = f"{year}年{month_names[month]}"  # pyright: ignore[reportAttributeAccessIssue]
    month_cell.font = _month_title_font
    month_cell.fill = _month_title_fill
    month_cell.alignment = _center_align
    month_cell.border = _blue_border
    
    for col in range(start_col, start_col + 7):
        ws.cell(row=start_row, column=col).border = _blue_border
    
    # 星期标题行
    weekdays = ["日", "一", "二", "三", "四", "五", "六"]
    header_row = start_row + 1
    for i, day in enumerate(weekdays):
        cell = ws.cell(row=header_row, column=start_col + i, value=day)
        cell.font = _weekday_header_font
        cell.fill = _weekday_fill
        cell.alignment = _center_align
        cell.border = _blue_border
    
    # 计算月份日期
    first_day = datetime(year, month, 1)
    if month == 12:
        next_month = datetime(year + 1, 1, 1)
    else:
        next_month = datetime(year, month + 1, 1)
    
    first_weekday = first_day.weekday()
    start_offset = (first_weekday + 1) % 7
    
    current_row = header_row + 1
    current_col = start_col + start_offset
    current_date = first_day
    
    while current_date < next_month:
        date_type, holiday_name = _get_date_type_and_name(current_date, holidays, workdays)
        day = current_date.day
        
        cell = ws.cell(row=current_row, column=current_col)
        
        if holiday_name:
            cell.value = f"{day}\n{holiday_name}"  # pyright: ignore[reportAttributeAccessIssue]
            cell.font = _holiday_font
        else:
            cell.value = day  # pyright: ignore[reportAttributeAccessIssue]
            cell.font = _date_font
        
        cell.alignment = _center_align
        cell.border = _blue_border
        
        # 记录日期到单元格的映射
        date_to_cell[current_date] = (current_row, current_col)
        
        if date_type == "节假日":
            cell.fill = _holiday_fill
        elif date_type == "周末":
            cell.fill = _weekend_fill
        elif date_type == "调休工作日":
            cell.fill = _adjustment_fill
            cell.font = Font(name='微软雅黑', size=9, color='0000FF', bold=True)
        else:
            cell.fill = _workday_fill
        
        current_col += 1
        if current_col > start_col + 6:
            current_col = start_col
            current_row += 1
        
        current_date += timedelta(days=1)
    
    # 填充空白单元格边框
    for row in range(start_row, start_row + 8):
        for col in range(start_col, start_col + 7):
            if ws.cell(row=row, column=col).value is None and row < start_row + 8:
                ws.cell(row=row, column=col).border = _blue_border
    
    # 设置行高
    for row in range(start_row, start_row + 8):
        ws.row_dimensions[row].height = 28
    
    return start_row + 8


def _fill_shift_colors(
    ws: Worksheet,
    date_to_cell: dict[datetime, tuple[int, int]],
    shifts: list[tuple[datetime, str]],
    holidays: dict[datetime, str]
) -> None:
    """
    根据排班班次填充日期单元格颜色
    
    填充逻辑：
    1. 首先给不同班次的日期单元格填充对应颜色
       - A班（白班）：D9D9D9
       - B班（夜班）：FFC000
       - A+（加白班）：B1A0C7，单元格显示两行（日期 + A+）
       - B+（加夜班）：B1A0C7，单元格显示两行（日期 + B+）
       - 节假日单元格不填充班次颜色，除非是A+或B+
    
    2. 然后按日期顺序找到第一个班次，开始找到下一个班次，
       将两个班次之间的日期单元格（排除周末、节假日、加班A+/B+，但不排除调休）
       填充为第一个班次的颜色
    """
    if not shifts:
        return
    
    # 构建日期到班次类型的映射
    date_to_shift: dict[datetime, str] = {date: shift_type for date, shift_type in shifts}
    
    # 按日期正序排序班次列表
    sorted_shifts = sorted(shifts, key=lambda x: x[0])
    
    # 记录已填充颜色的日期（班次日期）
    filled_dates: set[datetime] = set()
    
    # 第一步：给班次对应的日期单元格填充颜色
    for shift_date, shift_type in sorted_shifts:
        if shift_date not in date_to_cell:
            continue
        
        row, col = date_to_cell[shift_date]
        cell = ws.cell(row=row, column=col)
        
        # 判断是否为加班班次
        if shift_type in ('A+', 'B+'):
            # 加班班次：修改单元格内容为两行显示，即使是节假日也填充
            cell.value = f"{shift_date.day}\n{shift_type}"  # pyright: ignore[reportAttributeAccessIssue]
            cell.font = _overtime_font
            cell.fill = PatternFill(
                start_color=SHIFT_COLORS.get(f"{shift_type}班", "B1A0C7"),
                end_color=SHIFT_COLORS.get(f"{shift_type}班", "B1A0C7"),
                fill_type='solid'
            )
            filled_dates.add(shift_date)
        else:
            # 普通班次：节假日不填充，保持原有的节假日颜色
            if shift_date in holidays:
                # 节假日不填充班次颜色，保留原有的黄色
                pass
            else:
                # 非节假日：填充对应颜色
                color = SHIFT_COLORS.get(f"{shift_type}班", DEFAULT_FILL_COLOR)
                cell.fill = PatternFill(start_color=color, end_color=color, fill_type='solid')
                filled_dates.add(shift_date)
    
    # 第二步：填充两个班次之间的日期
    # 遍历每对相邻的班次
    for i in range(len(sorted_shifts) - 1):
        current_shift_date, current_shift_type = sorted_shifts[i]
        next_shift_date, _ = sorted_shifts[i + 1]
        
        # 如果当前班次是加班，跳过（不填充区间）
        if current_shift_type in ('A+', 'B+'):
            continue
        
        # 获取当前班次的颜色
        current_color = SHIFT_COLORS.get(f"{current_shift_type}班", DEFAULT_FILL_COLOR)
        
        # 遍历当前班次到下一个班次之间的日期
        current_date = current_shift_date + timedelta(days=1)
        while current_date < next_shift_date:
            # 跳过已填充的日期
            if current_date in filled_dates:
                current_date += timedelta(days=1)
                continue
            
            # 跳过周末
            if current_date.weekday() >= 5:
                current_date += timedelta(days=1)
                continue
            
            # 跳过节假日
            if current_date in holidays:
                current_date += timedelta(days=1)
                continue
            
            # 跳过加班日期（A+、B+）
            if current_date in date_to_shift and date_to_shift[current_date] in ('A+', 'B+'):
                current_date += timedelta(days=1)
                continue
            
            # 不排除调休日期（调休工作日需要填充）
            # 填充颜色
            if current_date in date_to_cell:
                row, col = date_to_cell[current_date]
                cell = ws.cell(row=row, column=col)
                cell.fill = PatternFill(start_color=current_color, end_color=current_color, fill_type='solid')
                filled_dates.add(current_date)
            
            current_date += timedelta(days=1)


def _add_legend_and_stats(
    ws: Worksheet,
    year: int,
    holidays: dict[datetime, str],
    workdays: dict[datetime, str],
    legend_row: int
) -> None:
    """添加图例和统计信息"""
    # 图例说明
    ws.merge_cells(start_row=legend_row, start_column=1, end_row=legend_row, end_column=7)
    ws.cell(row=legend_row, column=1, value="图例说明：").font = Font(name='微软雅黑', size=11, bold=True)
    
    legend_items = [
        ("工作日", _workday_fill, "周末", _weekend_fill),
        ("节假日", _holiday_fill, "调休", _adjustment_fill),
        ("A+班", _overtime_fill, "B+班", _overtime_fill)
    ]
    
    legend_row += 1
    col = 1
    for name, fill, name2, fill2 in legend_items:
        cell = ws.cell(row=legend_row, column=col, value=name)
        cell.fill = fill
        cell.alignment = _center_align
        cell.border = _blue_border
        col += 1
        if name2:
            cell = ws.cell(row=legend_row, column=col, value=name2)
            cell.fill = fill2
            cell.alignment = _center_align
            cell.border = _blue_border
            col += 1
    
    # 统计信息
    stats_row = legend_row + 2
    ws.merge_cells(start_row=stats_row, start_column=1, end_row=stats_row, end_column=7)
    ws.cell(row=stats_row, column=1, value="统计信息：").font = Font(name='微软雅黑', size=11, bold=True)
    
    total_days = (datetime(year, 12, 31) - datetime(year, 1, 1)).days + 1
    weekend_count = 0
    holiday_count = len(holidays)
    
    for i in range(total_days):
        dt = datetime(year, 1, 1) + timedelta(days=i)
        if dt.weekday() >= 5 and dt not in holidays:
            weekend_count += 1
    
    workday_count = total_days - weekend_count - holiday_count + len(workdays)
    
    stats_info = [
        f"全年总天数：{total_days}天",
        f"工作日天数：{workday_count}天",
        f"周末天数：{weekend_count}天",
        f"法定节假日：{holiday_count}天",
        f"调休工作日：{len(workdays)}天"
    ]
    
    stats_row += 1
    for idx, info in enumerate(stats_info):
        _ = ws.cell(row=stats_row, column=1 + idx, value=info)


def generate_calendar_excel(shifts: list[tuple[datetime, str]], output_path: str) -> None:
    """
    生成日历排班Excel文件
    
    Args:
        shifts: 班次列表 [(日期, 班次类型)]
        output_path: 输出文件路径
    """
    if not shifts:
        print("错误：没有班次数据")
        return
    
    # 按年份分组
    year_shifts: dict[int, list[tuple[datetime, str]]] = defaultdict(list)
    for date, shift_type in shifts:
        year_shifts[date.year].append((date, shift_type))
    
    # 按年份排序
    sorted_years = sorted(year_shifts.keys())
    
    wb = Workbook()
    # 删除默认创建的Sheet
    if 'Sheet' in wb.sheetnames:
        del wb['Sheet']
    
    for year in sorted_years:
        year_data = year_shifts[year]
        
        # 创建Sheet
        ws = cast(Worksheet, wb.create_sheet(title=f"{year}年日历"))
        
        # 获取该年份的节假日和调休工作日
        holidays = get_holidays_for_year(year)
        workdays = get_workdays_for_year(year)
        
        # 日期到单元格的映射
        date_to_cell: dict[datetime, tuple[int, int]] = {}
        
        # 设置列宽
        for col in range(1, 25):
            ws.column_dimensions[get_column_letter(col)].width = 11
        
        # 添加标题
        ws.merge_cells('A1:W1')
        ws['A1'] = f"{year}年公司日历"
        ws['A1'].font = _title_font
        ws['A1'].fill = _title_fill
        ws['A1'].alignment = _center_align
        
        # 月历布局：4行3列
        month_layout = [
            (3, 1), (3, 9), (3, 17),
            (12, 1), (12, 9), (12, 17),
            (21, 1), (21, 9), (21, 17),
            (30, 1), (30, 9), (30, 17),
        ]
        
        months = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
        for idx, month in enumerate(months):
            start_row, start_col = month_layout[idx]
            _ = _draw_month_calendar(ws, start_row, start_col, year, month, holidays, workdays, date_to_cell)
        
        # 填充班次颜色
        _fill_shift_colors(ws, date_to_cell, year_data, holidays)
        
        # 添加图例和统计
        _add_legend_and_stats(ws, year, holidays, workdays, 41)
    
    # 确保输出目录存在
    output_dir = os.path.dirname(output_path)
    if output_dir and not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    # 保存文件
    wb.save(output_path)
    print(f"日历排班文件已生成: {output_path}")


def generate_calendar_from_config() -> None:
    """从配置生成日历排班Excel"""
    content = SHIFT_SCHEDULE.strip()
    if not content:
        print("错误：SHIFT_SCHEDULE 配置为空")
        return
    
    # 检测格式
    format_type = detect_format(content)
    
    if format_type == 0:
        print("错误：SHIFT_SCHEDULE 配置格式无法识别")
        return
    
    # 解析班次信息（格式一先转换为格式二再处理）
    if format_type == 1:
        print("检测到格式一配置，转换为格式二后处理...")
        shifts = parse_format1(content)
    else:
        print("检测到格式二配置，直接处理...")
        shifts = parse_format2(content)
    
    if not shifts:
        print("错误：未能解析出有效的班次数据")
        return
    
    print(f"共解析 {len(shifts)} 条班次记录")
    
    # 获取涉及的年份
    years = sorted(set(date.year for date, _ in shifts))
    if len(years) == 1:
        print(f"涉及年份: {years[0]}")
    else:
        print(f"涉及年份: {', '.join(map(str, years))}")
    
    # 生成输出路径
    call_dir = os.getcwd()
    import time
    now = datetime.now()
    timestamp_ms = int(time.time() * 1000)
    if len(years) == 1:
        filename = f"shift_{years[0]}年日历_{now.strftime('%Y%m%d')}_{timestamp_ms}.xlsx"
    else:
        filename = f"shift_{'_'.join(map(str, years))}年日历_{now.strftime('%Y%m%d')}_{timestamp_ms}.xlsx"
    output_path = os.path.join(call_dir, filename)
    
    # 生成日历Excel
    generate_calendar_excel(shifts, output_path)


def main():
    """主函数"""
    # 检查参数
    if len(sys.argv) < 2:
        # 无参数时，从配置生成日历
        generate_calendar_from_config()
        return
    
    # 检查是否为 -year 参数模式
    if sys.argv[1] == "-year":
        if len(sys.argv) < 3:
            print("错误：-year 参数需要指定年份")
            print("用法：runshiftp.bat -year <年份>")
            sys.exit(1)
        
        try:
            year = int(sys.argv[2])
        except ValueError:
            print(f"错误：无效的年份 '{sys.argv[2]}'")
            sys.exit(1)
        
        output_year_data(year)
        return
    
    # 原有的文件路径模式
    file_path = sys.argv[1]
    
    # 如果是相对路径，基于当前工作目录解析
    if not os.path.isabs(file_path):
        file_path = os.path.join(os.getcwd(), file_path)
    
    # 检查文件是否存在
    if not os.path.exists(file_path):
        print(f"错误：文件不存在 '{file_path}'")
        sys.exit(1)
    
    # 读取文件内容
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
    except Exception as e:
        print(f"错误：读取文件失败 - {e}")
        sys.exit(1)
    
    # 检测格式
    format_type = detect_format(content)
    
    if format_type == 0:
        print("错误：无法识别的班次信息格式")
        sys.exit(1)
    
    # 解析班次信息
    if format_type == 1:
        print("检测到格式一（连续记录格式），转换为格式二...")
        shifts = parse_format1(content)
        output = format_to_format2(shifts)
    else:
        print("检测到格式二（班次+日期格式），转换为格式一...")
        shifts = parse_format2(content)
        output = format_to_format1(shifts)
    
    # 输出结果
    print("\n转换结果：")
    print("-" * 40)
    print(output)
    print("-" * 40)
    print(f"共解析 {len(shifts)} 条班次记录")


if __name__ == '__main__':
    main()